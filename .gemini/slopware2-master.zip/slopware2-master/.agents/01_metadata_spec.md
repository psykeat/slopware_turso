# Slopware — Metadata Spec

Diese Spezifikation definiert die Regeln für Metadaten, Vererbung und Auflösung im System. Sie gilt für Frontend, Backend, Imports, Workspaces und KI-Agenten gleichermaßen.

## 1. Wenn du nur 5 Regeln liest

- Metadaten beschreiben UI-nahe Struktur und Konfiguration, nicht fachliche Kernlogik.
- Frontend, Backend und Agenten konsumieren nur `effective_*`, nie rohe Metadata-Tabellen.
- Workspace-Metadaten bleiben klein: Layout, Slotting, Titel, Default-Open-Intents, deklarative Selection-Sync.
- Einmalige fachliche Sonderfälle werden bevorzugt im Code gelöst, nicht durch neue Metadatenachsen.
- Wenn Core Architecture, Schema oder RLS eine Regel bereits festlegen, gehört sie nicht erneut in die Metadata-Schicht.

## 2. Zweck

Metadaten beschreiben Struktur, Layout, UI-nahe Konfiguration und ergänzende Regeln. Sie sind keine operativen Geschäftsdaten und enthalten keine Kernlogik des Datenmodells.

## 3. Geltungsbereich

Diese Spec gilt für:

- Felddefinitionen (`tenant_fields`)
- Layouts (`tenant_layouts`)
- panel- und workspace-bezogene Layoutartefakte
- Rule-Artefakte (`tenant_rules`)
- systemweite und tenant-spezifische Konfigurationen (`system_settings`)
- Lookup- und Helper-Registries (`helper_table_registry`)
- Schema-Annotationen (`schema_annotations`)
- Connector-Definitionen (`connector_definition`)
- Command- und UI-Registries, soweit metadata-getrieben

Sie gilt nicht für:

- Master Data
- Transaction Data
- Derived Data
- Identity- oder RLS-Logik

## 4. Scope-Modell

Metadaten werden in drei Ebenen organisiert: `global`, `organization`, `tenant`.

## 5. Effective Metadata

Frontend, Backend, Imports und Agenten konsumieren niemals rohe Metadaten direkt. Verwendet werden ausschließlich die aufgelösten PostgreSQL-Views.

Views definiert in `packages/db/src/schema/views.ts`: `effective_fields`, `effective_layout`, `effective_rules`, `effective_settings`, `current_tenant_ctx`. Rohe Metadaten-Tabellen in `packages/db/src/schema/system.ts`.

## 6. Workspace- und Panel-Metadaten

Da die Plattform split-panel-fähig ist, dürfen Metadaten UI-Komposition beschreiben, solange sie keine Fachlogik tragen.

Erlaubt sind:

- Layout
- Slotting
- Titel
- Default-Open-Intents
- deklarative Selection-Sync

Nicht erlaubt sind:

- fachliche Bedingungen
- Schreiblogik
- Rechteableitung
- zustandsabhängige Command-Orchestrierung
- Tenant-Ableitung

Workspace-Defaults dürfen zunächst als statische Code-Konfiguration umgesetzt werden. Metadata ist nur dann der richtige Ort, wenn die Konfiguration wiederverwendbar, scope-fähig und tatsächlich metadata-getrieben sein soll.

## 7. Felddefinitionen

Felddefinitionen dürfen Informationen wie Feldname, Datentyp, Pflichtstatus, Sichtbarkeit, Label, Hilfetext, Lookup-Konfiguration sowie Grid-/Form-Hinweise enthalten. Nicht erlaubt sind Buchungslogik, Steuerlogik, Lagerlogik, RLS-Logik, Identitätslogik oder Statusmaschinen.

## 8. JSONB-Nutzung

JSONB ist nur für optionale Erweiterungen erlaubt, insbesondere i18n-Labels, UI-Konfigurationen, Layout-Definitionen, Rule-Definitionen und additive tenant-spezifische Attribute. Nicht erlaubt sind Beziehungen, Posting-Logik, Inventory-Logik, Steuerfindung, Statusmaschinen sowie Rechte- oder Tenant-Isolation.

## 9. Konsumregeln

- Das Frontend rendert nur `effective_*`
- Das Backend validiert nur gegen `effective_*`
- KI-Agenten arbeiten nur mit `effective_*`
- Generic UI rendert nur effektive Metadaten, nie rohe Metadaten
- Workspace- und Panel-Komposition konsumiert nur freigegebene effektive Layoutartefakte

## 10. Minimalprinzip

Wenn eine Regel bereits eindeutig durch Core Architecture, Datenbankschema, Constraints oder RLS definiert ist, gehört sie nicht in diese Spec. Diese Spec beschreibt Metadata-Verhalten, nicht den gesamten Systemkern.

## 11. Priorität bei Widerspruch

Bei Konflikten gilt:

1. Core Architecture
2. Schema Spec / Migrations
3. Metadata Spec
4. abgeleitete Dokumente
