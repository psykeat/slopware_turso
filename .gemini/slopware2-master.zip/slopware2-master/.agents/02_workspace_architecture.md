# Slopware — Workspace Architecture

Dieses Dokument definiert die Zielarchitektur für Workspaces, Panels, Routing, URL-State, Datenflüsse und Interaktionen in der modernisierten App. Es beschreibt, wie split-panel-fähige Arbeitsbereiche mit TanStack Start strukturiert werden, ohne Domänenlogik in den Client zu verlagern.

## 1. Wenn du nur 5 Regeln liest

- Workspace-State ist URL-/Search-Param-getrieben und muss bookmarkbar, reload-stabil und kanonisch sein.
- `WorkspaceContext` ist eine dünne Orchestrierungsschicht und kein zweites State-System neben dem Router.
- Panels öffnen andere Panels über Intents; Selection-Sync erzeugt nur Navigations-/Öffnungsintents, keine Mutationen.
- Inhaltsdaten werden panel-lokal geladen; langsame Panels dürfen die gesamte Route nicht blockieren.
- Neue Workspaces nutzen zuerst die bestehenden Panel-Adapter und Kernpaneltypen.

## 2. Zielbild

Die App ist kein tab-zentriertes Einzelfenster mit isolierten Seitenwechseln, sondern ein workspace-basiertes System mit parallel sichtbaren Arbeitskontexten. Ein Benutzer kann mehrere Listen, Detailsichten, Lookups, Belegzeilen und Hilfsansichten gleichzeitig geöffnet haben.

Ziel ist eine Oberfläche, die:

- deep-linkbar ist
- reload-stabil ist
- browser-nativ navigierbar ist
- mehrere Panels parallel unterstützt
- große Tabellen performant darstellt
- generische Entities und Beleg-Workflows in ein einheitliches Modell bringt

## 3. Grundbegriffe

- **Workspace** = adressierbarer fachlicher Arbeitskontext, z. B. Adressen, Belege, Artikel, Import oder Administration.
- **Panel** = standardisierte Sicht innerhalb eines Workspaces.
- **Panel Type** = Art des Panels, z. B. `list`, `detail`, `lookup`, `lines`, `inspector`, `assistant`.
- **Panel Slot** = Position im Layout, z. B. links, mitte, rechts oder ein generischer Slot-Index.
- **Panel State** = serialisierbarer Zustand eines Panels, z. B. Entity, Record-ID, Filter, Sortierung, Fokus, Selektion, Docking.
- **Workspace Layout** = Anordnung aktiver Panels, Größenverhältnisse und bevorzugter Pane-Modus.
- **Workspace Intent** = semantischer Öffnungsgrund, z. B. „Adresse öffnen“, „Artikel lookupen“, „Belegpositionen anzeigen“.

## 4. UX-Prinzipien

### 4.1 Split Panel First

Die Architektur ist standardmäßig split-panel-fähig. Ein Workspace kann in 1-, 2- oder 3-Pane-Layouts betrieben werden. Der Benutzer soll z. B. links eine Liste, in der Mitte ein Detail und rechts ein Lookup oder Zeilenpanel gleichzeitig sehen können.

### 4.2 URL als persistenter Arbeitszustand

Der relevante Workspace-Zustand wird in Route und Search Params serialisiert. Ein Reload darf geöffnete Arbeitskontexte nicht zerstören, sofern die zugrunde liegenden Daten noch zugreifbar sind.

### 4.3 Panels statt Modalseiten

Neue fachliche Kontexte werden bevorzugt als Panel innerhalb eines bestehenden Workspaces geöffnet, nicht als vollständiger Seitenwechsel. Modale Overlays bleiben für kurzlebige Bestätigungen oder Spezialinteraktionen erlaubt, sind aber nicht das Standardmodell.

### 4.4 Liste und Detail sind gleichwertige Arbeitsformen

Listen sind nicht nur Navigation, sondern produktive Arbeitsflächen. Details sind nicht zwingend Vollseiten, sondern Panels mit editierbarer Masken-, Zeilen- oder Inspector-Funktion.

### 4.5 Generic UI bleibt Leitprinzip

Workspace und Panels müssen generische Entities ebenso gut unterstützen wie dokumentenartige Spezialfälle. Das Ziel ist kein Nebeneinander aus generischer Plattform und Sonder-UI, sondern ein gemeinsames Panel-Modell.

## 5. Layout-Modell

### 5.1 Unterstützte Pane-Modi

Mindestens folgende Pane-Modi sind vorgesehen:

- `single` — ein Panel sichtbar
- `split-2` — zwei Panels nebeneinander
- `split-3` — drei Panels nebeneinander

Optional erweiterbar:

- `split-2-wide-left`
- `split-2-wide-right`
- `stacked-mobile`
- `overlay-inspector`

### 5.2 Slot-Modell

Ein Workspace besitzt logisch geordnete Slots:

- `slot1`
- `slot2`
- `slot3`

Die semantische Bedeutung ergibt sich aus Layout und Panel-Typ, nicht aus dem Slotnamen allein.

### 5.3 Mobile-Verhalten

Auf kleineren Viewports werden parallele Panels nicht einfach skaliert, sondern in ein mobile-taugliches Modell überführt:

- nur ein aktiver Panel-Stack sichtbar
- Wechsel per Tabs, Drawer oder Zurück-Navigation
- URL-State bleibt dennoch derselbe semantische Workspace-State

## 6. Panel-Typen

Folgende Panel-Typen sind Kern des Systems:

| Panel Type  | Zweck                                                 |
| ----------- | ----------------------------------------------------- |
| `list`      | Grid- oder tabellarische Übersicht einer Entity       |
| `detail`    | Form-/Maskenansicht eines Datensatzes                 |
| `lookup`    | Auswahl- und Suchpanel für referenzierte Daten        |
| `lines`     | Positions- oder Unterzeilenansicht, z. B. Belegzeilen |
| `inspector` | Kontextinfos, Audit, Vorschau, Metadaten              |
| `assistant` | AI-gestützte Hilfs- und Aktionsoberfläche             |

Spezialisierte Panels außerhalb dieses Kernsets sind Ausnahmefälle und müssen begründet werden.

## 7. Routing-Modell

### 7.1 Routenebene

Routen bilden den fachlichen Arbeitsraum ab. Beispiele:

- `/workspace/documents`
- `/workspace/warehouse`
- `/workspace/delivery`
- `/workspace/production`
- `/workspace/cost-centers`

### 7.2 Search Params als Workspace-State

Geöffnete Panels und ihr Zustand werden über Search Params oder ein gleichwertiges route-nahes Zustandssystem beschrieben.

Typische serialisierte Informationen:

- aktiver Pane-Modus
- Panel-Typ je Slot
- Entity je Panel
- aktive Record-ID
- Filter- und Sortierzustand
- Lookup-Kontext
- Fokus oder aktive Auswahl

Die konkrete Kodierung ist frei, solange sie stabil, validierbar und rückwärtsmigrierbar bleibt.

### 7.3 Kanonischer Default-State

Workspace-Routen definieren einen deklarativen `defaultWorkspaceState`. Wird eine Route ohne vollständige Search Params geöffnet, normalisiert `beforeLoad` den Zustand und leitet auf die kanonische URL um.

### 7.4 Route Loader und Initialisierung

Route Loader laden nur den schnellen Rahmen:

- Session und User-Kontext
- Locale
- Tenant-Kontext
- Workspace-Definition
- panel-relevante Effective Metadata
- optionale Query-Prefetches nach TanStack-Pattern

Inhaltsdaten der Panels werden bevorzugt panel-lokal via Query geladen.

## 8. Pending-, Error- und Refresh-Modell

### 8.1 Panel-lokale Pending States

Ladezustände werden primär panel-lokal modelliert. Ein neues Lookup im rechten Panel darf nicht die gesamte Workspace-Seite blockieren.

### 8.2 Segmentiertes Refetching

Listen, Details und Lookups refetchen segmentiert. Ein Speichern im Detailpanel darf gezielt die betroffenen Panels invalidieren, aber nicht blind die gesamte Route neu laden.

### 8.3 Fehlergrenzen

Fehler werden möglichst auf Panel-Ebene gefangen. Ein Fehler im Assistant- oder Lookup-Panel darf nicht den gesamten Workspace unbrauchbar machen.

## 9. Datenflussprinzipien

### 9.1 Reads

Reads erfolgen über kontrollierte Query-Module und route- oder panel-spezifische Loader. Das Frontend konsumiert niemals rohe Metadaten oder beliebige Direkt-Queries an der Domänenschicht vorbei.

### 9.2 Writes

Writes erfolgen über Commands, Server Functions oder explizite API-Routen mit denselben Domain-Modulen. Ein Panel schreibt nie direkt in die Datenbank und kennt keine eigene Geschäftslogik außerhalb des freigegebenen Command-Pfads.

### 9.3 Context Integrity

Jeder Read- und Write-Pfad läuft im serverseitig hergeleiteten Tenant-Kontext. Weder Panel-State noch Drag-and-drop-Payload dürfen Autorisierung oder `tenant_id` bestimmen.

## 10. Generic Panel Contracts

### 10.1 List Panel Contract

Ein `list`-Panel definiert typischerweise:

- `entity`
- `viewKey` oder `layoutKey`
- Filterzustand
- Sortierung
- sichtbare Spalten aus `effective_fields`
- Scroll-/Cursor-Zustand
- aktive Auswahl

Die Darstellung basiert auf `GridRoot`/`GridTable` (`components/grid/`) mit Virtualisierung. Fetching liegt beim Adapter via `useQuery`; der Grid-State (`sorting`, `pagination`, `rowSelection`) ist fully controlled.

### 10.2 Detail Panel Contract

Ein `detail`-Panel definiert typischerweise:

- `entity`
- `recordId`
- `layoutKey`
- Edit- oder View-Modus

Die Darstellung basiert auf `DetailPanelAdapter` (generisch, liest `effective_fields`) oder einem domänenspezifischen Detail-Renderer, der dennoch in das Panel-Modell eingebettet bleibt. Mutationen laufen über `CrudDialog` oder spezialisierte Commands.

### 10.3 Lookup Panel Contract

Ein `lookup`-Panel definiert typischerweise:

- Zieltabelle oder Ziel-Entity
- aufrufendes Feld oder Lookup-Intent
- Suchbegriff
- Standardfilter
- Rückgabeformat

### 10.4 Lines Panel Contract

Ein `lines`-Panel beschreibt Unterdatensätze wie Belegpositionen. Es ist ein eigenständiger Panel-Typ mit möglicher Interaktion zu Detail, Lookup und Commands.

## 11. Interaktionen zwischen Panels

### 11.1 Open Intent

Panels öffnen andere Panels nicht durch direkte Komponentenverkettung, sondern über semantische Intents. Der `dispatchIntent`-Mechanismus im `WorkspaceContext` übersetzt diese in Search-Param-Mutationen des Routers.

Beispiele für Intents:

- `openRecord(entity, id, targetSlot?)`
- `openLookup(table, context, targetSlot?)`
- `openLines(documentId, targetSlot?)`

### 11.2 Selection Synchronization

Eine Auswahl in `slot1` kann `slot2` aktualisieren. Diese Synchronisation ist deklarativ und workspace-gesteuert, nicht über implizite lokale Seiteneffekte.

Selection-Sync darf nur Navigations- oder Öffnungsintents erzeugen, niemals Mutationen.

### 11.3 Drag and Drop

Drag-and-drop ist erlaubt, aber nur als UX-Auslöser für definierte Aktionen:

- Zuordnung eines Lookup-Elements
- Reordering innerhalb erlaubter Listen
- Start eines freigegebenen Commands

Nicht erlaubt:

- rohe SQL-artige Mutationen aus Drop-Events
- Übernahme von `tenant_id` oder Rechten aus Drop-Payloads

## 12. Workspace-spezifische Metadaten

Workspaces dürfen durch effektive Layoutartefakte vorkonfiguriert werden. Bevor neue workspace-spezifische Metadata-Artefakte entstehen, ist zu prüfen, ob eine statische Code-Konfiguration ausreicht.

Erlaubte sind insbesondere:

- Standardlayout
- Slotting
- Titel
- Default-Open-Intents
- deklarative Selection-Sync

Nicht erlaubt sind:

- fachliche Bedingungen
- Schreiblogik
- Rechteableitung
- zustandsabhängige Command-Orchestrierung

## 13. Modulstruktur (implementiert)

- `apps/web/src/routes/_auth/route.tsx` — Protected layout
- `apps/web/src/routes/_auth+/` — Auth-protected routes (workspace, admin)
- `apps/web/src/routes/_guest/` — Guest routes (login, signup)
- `apps/web/src/features/workspace/registry.ts` — WORKSPACES, VIEW_REGISTRY, ENTITY_REGISTRY
- `apps/web/src/features/workspace/components/panels/*` — Panel-Adapter (`ListPanelAdapter`, `DetailPanelAdapter`, `LinesPanelAdapter`)
- `apps/web/src/features/workspace/components/grid/*` — kompositionelles Grid (`GridRoot`, `GridTable`, `GridToolbar`, `GridSearch`, `GridFooter`, `GridPagination`)
- `apps/web/src/features/workspace/components/crud-dialog.tsx` — CRUD Dialog
- `packages/domain/src/queries/*` — Read-Logik
- `packages/domain/src/commands/*` — Write-Logik
- `packages/domain/src/entities/*` — Entity-Registry (16 descriptors)
- `packages/domain/src/metadata/*` — Effective-Metadata-Zugriff
- `packages/domain/src/runtime/*` — SqlClient, withTenant
- `packages/ui/*` — shadcn/ui Primitives (Button, Dialog, Input, …)
- `packages/shared/*` — serialisierbare Workspace- und Panel-Typen
