# Slopware — Interface Design Rules (SOP)

Dieses Dokument definiert die unveränderlichen Design- und UX-Regeln für die Slopware-Plattform. Es dient als primäre Entscheidungsgrundlage für KI-Agenten bei der Erstellung von UI-Komponenten, Workspaces und Panels.

## 🏛️ Das Kern-Modell: Die IDE-Metapher

Die Anwendung ist keine klassische Website, sondern ein **IDE-artiger Arbeitsbereich**.

- **Pane-System**: 1 bis 3 vertikale Panes (Slots).
- **Multi-Tab**: Jedes Pane kann mehrere Views als Sub-Tabs halten.
- **Deep-Link-Stabil**: Der gesamte Zustand (aktive Workspaces, Panes, geöffnete Datensätze) MUSS im URL-Hash abgebildet sein. Ein Browser-Reload muss exakt dasselbe Bild liefern.
- **Inter-Pane-Kommunikation**: Läuft ausschließlich über **Intents** (z.B. `openRecord`). Panels kennen sich nicht gegenseitig.

## 🛡️ Verpflichtende Komponenten (PFLICHT)

Es ist untersagt, eigene Implementierungen für Standard-Aufgaben zu erstellen. Nutze ausschließlich:

| Aufgabe                  | Komponente           | Pfad (src/features/workspace/components/...) |
| :----------------------- | :------------------- | :------------------------------------------- |
| **Tabellarische Listen** | `EntityDataTable`    | `data-table/entity-data-table.tsx`           |
| **Erfassen / Editieren** | `CrudDialog`         | `crud-dialog.tsx`                            |
| **Standard-Listen-Pane** | `ListPanelAdapter`   | `panels/list-panel-adapter.tsx`              |
| **Standard-Detail-Pane** | `DetailPanelAdapter` | `panels/detail-panel-adapter.tsx`            |
| **Referenz-Auswahl**     | `LookupPanelAdapter` | `panels/lookup-panel-adapter.tsx`            |
| **Unterpositionen**      | `LinesPanelAdapter`  | `panels/lines-panel-adapter.tsx`             |

## 📐 Design Tokens & Metriken

### Typografie (DM Sans für UI, DM Mono für Daten)

| Token                | Größe (px) | Gewicht | Verwendung                       |
| :------------------- | :--------- | :------ | :------------------------------- |
| **Section-Label**    | 9.5        | 700     | UPPERCASE, Letter-Spacing 0.10em |
| **KPI-Label**        | 10         | 600     |                                  |
| **Statusbar**        | 10.5       | 400     | DM Mono                          |
| **Heading**          | 11         | 600     | UPPERCASE                        |
| **Button / Input**   | 11.5       | 500     | Standard UI-Elemente             |
| **Table-Body**       | 12         | 400     | Daten-Zellen                     |
| **Tab / Detail-Val** | 12.5       | 500     |                                  |
| **Body-Default**     | 13         | 400     | Standard-Text                    |
| **Detail-Title**     | 18         | 700     |                                  |
| **KPI-Value**        | 22         | 700     | DM Mono                          |

### Farben (Niemals Hex-Codes in JSX!)

- **Neutral**: Nutze `var(--bg)`, `var(--bg-card)`, `var(--border)`, `var(--text-primary)`.
- **Akzent**: Nutze `var(--accent)`, `var(--accent-dark)`, `var(--accent-muted)`.
- **Status (Badges)**: `.badge-green`, `.badge-blue`, `.badge-orange`, `.badge-red`.

### Spacing & Radien

- **Radius**: Nur `--radius-sm` (4px) für kleine Elemente, `--radius` (8px) für Karten/Modals.
- **Padding/Gap**:
  - Toolbar/Table: `6px 10px`, `gap: 8px`.
  - Detail-View: `14px 16px`, `gap: 14px 20px`.
- **Fix-Höhen**:
  - Header: 48px
  - Pane-Tabbar: 32px
  - Statusbar: 24px
  - Button Default: 26px (xs: 22px)

## 🚦 Routing & State Invarianten

1. **Hash-Format**: `#ws=<workspaceId>&pane1=<viewKey>&pane2=...`
2. **Registry-First**: Jede View MUSS in `view-registry.ts` (`VIEW_REGISTRY`) registriert sein. Die Registry unterscheidet `kind: "generic" | "custom" | "dashboard"`.
3. **View-Datei-Konvention**: Für `kind: "custom"` muss die Datei `views/[prefix]/[prefix]-[suffix]-view.tsx` existieren (`export default`, keine Props). Fehlende Dateien werfen einen Startup-Fehler. Für `kind: "generic"` ist keine Datei nötig — `view-resolver.tsx` rendert `EntityDataTable` generisch.
4. **WorkspaceContext**: Views dürfen keinen State als Props empfangen. Workspace-State (selektierte Zeilen, Sprache, Filter, Toast) kommt ausschließlich über `useWorkspaceContext()` aus `workspace-context.tsx`.
5. **Intent-Dispatch**: Navigation zwischen Panels erfolgt via `ctx.dispatchIntent({ action: 'openRecord', ... })`.
6. **i18n-Only**: Absolutes Verbot von Inline-Strings. Nutze `t(key)`. Domain-Labels kommen direkt aus der Registry (`label_de` / `label_en`).

## 🚫 Hard Don'ts (Sofortiger Fehler)

- ❌ **Inline-Styles** oder **Hardcoded Hex-Farben**.
- ❌ **Eigene Scrollbars** (nur Pane-Bodies dürfen scrollen).
- ❌ **Gradients, Glassmorphism, Emojis** (außer Sprach-Flags).
- ❌ **Neue Icons** direkt in JSX (nutze das `ICONS` Registry-Objekt).
- ❌ **Direkte SQL-Calls** aus der UI (immer über Server Functions / Registry).
- ❌ **Modals** für Standard-Workflows (nutze Panels).

## 📁 Referenz-Dokumente

- Detaillierte Tokens: `design.md`
- Workspace-Logik: `.agents/02_workspace_architecture.md`
- Registry-Struktur: `packages/domain/src/entities/registry.ts`
