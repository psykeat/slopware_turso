# 05 — Interface Unification: Workspace Bedienbarkeit

Dieses Dokument beschreibt die konkreten Schwachstellen, die das Workspace-Interface aktuell **unbedienbar** machen, und legt fest was geändert werden muss. Es ist kein Architektur-Redesign — es schließt die Lücke zwischen dem was gebaut wurde und dem was tatsächlich funktioniert.

---

## 1. Diagnose: Was ist kaputt

### 1.1 Intent-Dispatch öffnet kein Panel

`ListPanelAdapter.handleRowClick` ruft `dispatchIntent({ action: "openRecord", entity, id, targetSlot: "s2" })` auf. Dieser Intent landet im `WorkspaceContext`, aber es gibt **keinen Handler**, der daraus eine Panel-State-Mutation erzeugt. Das Klicken auf eine Zeile tut nichts sichtbares.

**Root cause:** `dispatchIntent` und `onUpdatePanel` sind nicht verbunden. Der Context dispatcht Intents ins Leere.

### 1.2 `PaneCtx` ist mit Mock-Typen verdrahtet

```typescript
// pane.tsx — heute
type PaneCtx = {
  selectedAddress: Address | null;       // mock-spezifisch
  selectedDocument: Document | null;     // mock-spezifisch
  selectedArticle: Article | null;       // mock-spezifisch
  setSelected: (entity: string, row: Address | Article | Document) => void;
  ...
}
```

`setSelected` in `workspace.tsx` behandelt nur drei hartcodierte Entities. Alle anderen tun nichts:

```typescript
const setSelected = useCallback((entity: string, row: ...) => {
  if (entity === "address") setSelectedAddress(row as Address);
  if (entity === "document") setSelectedDocument(row as Document);
  if (entity === "article") setSelectedArticle(row as Article);
  // alle anderen Entities: kein Effekt
}, []);
```

Die `PaneCtx` war ein Workaround für Mock-Daten, bevor Intents implementiert waren. Sie ist jetzt dead weight.

### 1.3 `workspace.tsx` initialisiert aus Mock-Daten

```typescript
const [selectedDocument, setSelectedDocument] = useState<Document | null>(MOCK_DOCUMENTS[0]);
```

Produktionspfad und Mock-Pfad sind im selben Workspace-Component vermischt.

### 1.4 `DetailPanelAdapter` bekommt keine ID

`DetailPanelAdapter` erwartet `panel.id` (die Record-ID). Diese wird beim Öffnen aus dem Panel-Picker nie gesetzt (immer `""`), und der Intent-Dispatch, der sie setzen sollte, funktioniert nicht (→ 1.1). Der Detail-Adapter zeigt deshalb immer einen leeren oder Fehlerzustand.

### 1.5 Panel-Tabs zeigen falschen/keinen Label

`pane.tsx` sucht den Panel-Label aus `VIEW_REGISTRY` über eine dreifach verschachtelte `find`-Kette. Panels mit `viewKey` der nicht exakt matcht (z.B. generic entities aus dem Adapter, die kein `viewKey` in der Registry haben) zeigen nur den `type` als Label.

---

## 2. Zielzustand

Nach dieser Arbeit gilt:

- Klick auf eine Listenzeile → Detail-Panel öffnet sich in Slot 2 mit korrekter ID
- Workspace-Wechsel lädt die konfigurierten Default-Panels
- Detail-Panel zeigt die richtigen Felddaten des ausgewählten Datensatzes
- `PaneCtx` enthält keine mock-spezifischen Felder mehr
- Panel-Tab zeigt lesbare Label für alle Panel-Typen

---

## 3. Umsetzung

### Issue 1 — Intent → Panel-State-Mutation verbinden

**Betroffene Dateien:** `workspace.tsx`, `pane.tsx` (evtl. `WorkspaceContext.tsx`)

Der `dispatchIntent`-Handler in `workspace.tsx` muss Intents in `onUpdatePanel`-Aufrufe übersetzen:

```typescript
// workspace.tsx — Ziel
const handleIntent = useCallback(
  (intent: OpenIntent) => {
    if (intent.action === "openRecord") {
      const targetSlot = intent.targetSlot ?? "s2";
      onUpdatePanel(targetSlot, {
        type: "detail",
        entity: intent.entity,
        id: intent.id,
        viewKey: `${intent.entity}:detail`,
      });
    }
    // weitere Intent-Typen: openLines, openLookup etc.
  },
  [onUpdatePanel],
);
```

Der `WorkspaceContext` muss `handleIntent` als `dispatchIntent` exponieren — oder, wenn Context und Workspace-State nicht auf einer Ebene liegen, muss `dispatchIntent` direkt per Prop an `PaneCtx` übergeben werden.

**Akzeptanzkriterium:** Klick auf Zeile in `ListPanelAdapter` öffnet Detail-Panel in s2 mit gesetzter `panel.id`.

---

### Issue 2 — `PaneCtx` von Mock-Typen befreien

**Betroffene Dateien:** `pane.tsx`, `workspace.tsx`, alle Adapter und Views die `ctx.selectedXxx` lesen

`PaneCtx` wird zu:

```typescript
type PaneCtx = {
  dispatchIntent: (intent: OpenIntent) => void;
  t: TFn;
  lang: Lang;
};
```

`setSelected` wird entfernt. Der Selektion-Flow läuft ausschließlich über `dispatchIntent`. Die `selectedAddress`/`selectedDocument`/`selectedArticle`-Felder werden aus allen Consumern entfernt.

**Stellen die `ctx.selectedDocument` o.ä. lesen:** Per grep identifizieren und auf den Intent-Mechanismus umstellen oder direkt aus dem Panel-State des jeweiligen Panels ableiten.

**Akzeptanzkriterium:** `pane.tsx` und `workspace.tsx` importieren kein Mock-Data mehr. `PaneCtx` enthält keine entity-spezifischen Felder.

---

### Issue 3 — Mock-Daten aus `workspace.tsx` entfernen

**Betroffene Dateien:** `workspace.tsx`, `mock-data.ts` (obsolet), alle Views die Mock-Daten direkt konsumieren

`workspace.tsx` entfernt:

```typescript
// weg:
import { MOCK_DOCUMENTS } from "./mock-data";
const [selectedDocument, setSelectedDocument] = useState<Document | null>(MOCK_DOCUMENTS[0]);
```

Views, die noch `mock-data.ts` importieren, werden auf `listEntityFn` / `getEntityByIdFn` umgestellt — oder vorerst mit einem leeren State initialisiert bis sie separat implementiert werden.

**Akzeptanzkriterium:** `mock-data.ts` wird von keiner produktiven Komponente mehr importiert.

---

### Issue 4 — Panel-Tabs lesbar machen

**Betroffene Datei:** `pane.tsx`

Die dreifach-verschachtelte `find`-Logik wird zu einer einfachen Label-Ableitung:

```typescript
function getPanelLabel(panel: PanelState, lang: Lang): string {
  const entity = "entity" in panel ? panel.entity : "";
  const viewKey = "viewKey" in panel ? panel.viewKey : `${entity}:${panel.type}`;
  const vDef = VIEW_REGISTRY.find((v) => v.key === viewKey);
  if (vDef) return lang === "en" ? vDef.label_en : vDef.label_de;
  // Fallback: entity + type lesbar formatieren
  return entity ? `${entity} (${panel.type})` : panel.type;
}
```

**Akzeptanzkriterium:** Alle Panel-Tabs zeigen einen lesbaren String, kein `[object Object]` und kein bloßes `"list"`.

---

## 4. Abhängigkeiten und Reihenfolge

```
Issue 1 (Intent-Dispatch)
  └─ muss vor Issue 3 (Mock-Daten) kommen, weil setSelected durch Intents ersetzt wird

Issue 2 (PaneCtx)
  └─ parallel zu Issue 1, dann abgleichen

Issue 4 (Panel-Tabs)
  └─ unabhängig, jederzeit umsetzbar

Issue 3 (Mock-Daten)
  └─ zuletzt, wenn der Intent-Flow stabil läuft
```

---

## 5. Nicht im Scope

- URL-Persistenz des Panel-States (läuft bereits über `onStateChange` → Search Params)
- Workspace-Navigation / Sidebar (funktioniert bereits via `switchWorkspace`)
- `WorkspaceLayout`, Header, Statusbar — kein Handlungsbedarf
- Neue Panel-Typen (lookup, inspector, assistant)
- Admin-Panel-Optimierungen

---

## 6. Dateien im Fokus

| Datei                            | Was ändert sich                                    |
| -------------------------------- | -------------------------------------------------- |
| `workspace.tsx`                  | `dispatchIntent` handler, mock-data entfernen      |
| `pane.tsx`                       | `PaneCtx` aufräumen, `getPanelLabel` vereinfachen  |
| `panel-resolver.tsx`             | bleibt, evtl. kleine Anpassungen                   |
| `WorkspaceContext.tsx`           | `dispatchIntent` korrekt verdrahten                |
| alle Views mit `ctx.selectedXxx` | auf Intent-Flow oder lokalen Panel-State umstellen |
| `mock-data.ts`                   | obsolet, nach Issue 3 löschen                      |
