# Slopware — Generic Entity CRUD

Dieses Dokument beschreibt das generische CRUD-System für statische Stammdaten-Entities (Adressen, Artikel, Kostenstellen, Lager etc.). Belegerfassung und Bewegungsdaten sind ausdrücklich ausgenommen — sie folgen spezialisierten Command-Pfaden.

---

## 1. Beteiligte Schichten

```
UI                  ListPanelAdapter  →  GridRoot + GridTable + GridToolbar + GridFooter
                         ↓                         (components/grid/)
                    CrudDialog
                         ↓
Server Functions    createEntityFn / patchEntityFn / deactivateEntityFn / deleteEntityFn
                         ↓
Domain              entity-command-service  (createEntity, patchEntity, deactivateEntity, deleteEntity)
                         ↓
Registry            Domain ENTITY_REGISTRY  (Map<string, EntityDescriptor>)
Metadata            effective_fields view   (EffectiveField[])
DB                  PostgreSQL table        (RLS + tenant_id)
```

Es gibt **zwei Registries** mit unterschiedlichen Verantwortungen:

| Registry                  | Datei                                         | Typ                                                 | Verantwortung                                                                    |
| ------------------------- | --------------------------------------------- | --------------------------------------------------- | -------------------------------------------------------------------------------- |
| **Domain Registry**       | `packages/domain/src/entities/registry.ts`    | `Map<string, EntityDescriptor>`                     | Server-Wahrheit: Tabelle, ID-Spalte, Fähigkeiten, Soft-Delete-Feld (16 Entities) |
| **UI Workspace Registry** | `apps/web/src/features/workspace/registry.ts` | `Record<string, {label: string, fields: string[]}>` | Client-Wahrheit: Label, Feldliste (stub — TODO: erweitern um `paths`, `icon`)    |

Beide müssen konsistent sein. Die Domain Registry entscheidet, ob ein Command **ausgeführt** werden darf. Die UI Registry entscheidet, ob ein Button **angezeigt** wird.

---

## 2. Capability Matrix

### Domain Registry — `EntityDescriptor`

| Feld                             | Typ      | Effekt                                                    |
| -------------------------------- | -------- | --------------------------------------------------------- |
| `genericRead: true`              | bool     | Entity ist über `listEntityFn` / `getEntityByIdFn` lesbar |
| `genericPatch: true`             | bool     | Create und Edit über generischen Pfad erlaubt             |
| `genericDelete: true`            | bool     | Hard-Delete erlaubt (fast nie gesetzt)                    |
| `kind: "master"`                 | enum     | Entity ist Stammdatum → Deactivate statt Delete           |
| `softDeleteField: "is_active"`   | enum     | Deactivate setzt `is_active = false`                      |
| `softDeleteField: "archived_at"` | enum     | Deactivate setzt `is_active = false, archived_at = NOW()` |
| `idColumn`                       | string   | Primärschlüssel-Spalte (z.B. `address_id`)                |
| `tableName`                      | string   | Ziel-Tabelle für raw SQL in entity-command-service        |
| `allowedFilters`                 | string[] | Welche Spalten als Filter akzeptiert werden               |
| `sortableFields`                 | string[] | Welche Spalten sortierbar sind                            |

### UI Workspace Registry — `paths.C` (TODO)

Die UI Workspace Registry ist aktuell ein vereinfachter Stub (`Record<string, {label: string, fields: string[]}>`). Die `paths.C`-basierte Button-Steuerung ist noch nicht implementiert.

**Zielzustand:** `ListPanelAdapter` soll die Sichtbarkeit der Buttons aus `paths.C` ableiten:

```ts
const commands = ENTITY_REGISTRY[entity]?.paths?.C ?? [];
const canCreate = commands.includes("create");
const canEdit = commands.includes("update") || commands.includes("patch");
const canDeactivate = commands.includes("deactivate") || commands.includes("patch");
```

**Regelung:** `patch` in `paths.C` aktiviert sowohl Edit- als auch Deactivate-Button. Wenn Deactivate explizit unterdrückt werden soll, muss `patch` aus `paths.C` entfernt werden.

---

## 3. CRUD-Flows im Detail

### 3.1 Create

```
User klickt "+ Neu"
  → ListPanelAdapter: setCrudMode("create"), setCrudRow(null)
  → CrudDialog rendert Formular aus effective_fields (ohne idColumn)
  → User füllt Felder, klickt Speichern
  → CrudDialog: validate() prüft isRequired-Felder (client-seitig)
  → createEntityFn({ entityName, payload })
  → entity-command-service.createEntity():
      1. isEntityPatchable() — Domain Registry prüfen
      2. validateAgainstEffectiveFields() — Felder validieren (required, type, visibility)
      3. INSERT INTO <tableName> (...) RETURNING <idColumn>
  → QueryClient.invalidateQueries(["entity-list", entityName])
  → Dialog schließt
```

**Server-Validierung** prüft zusätzlich zur Client-Validierung:

- Unbekannte Felder (nicht in effective_fields)
- Nicht-sichtbare Felder (`isVisible === false`)
- Typ-Mismatch (boolean, integer/numeric)
- Alle required-Felder vorhanden

### 3.2 Edit (Patch)

```
User klickt Stift-Button
  → ListPanelAdapter: setCrudMode("edit"), setCrudRow(row)
  → CrudDialog rendert Formular (Felder initial leer — bekannte Limitation, s. Abschnitt 5)
  → User trägt neue Werte ein, klickt Speichern
  → patchEntityFn({ entityName, id: row.id, payload })
  → entity-command-service.patchEntity():
      1. isEntityPatchable()
      2. preparePatchPayload() — undefined-Werte entfernen
      3. validateAgainstEffectiveFields()
      4. UPDATE <tableName> SET ... , updated_at = NOW() WHERE <idColumn> = $n
  → invalidateQueries(["entity-list", entityName])
```

### 3.3 Deactivate (Stammdaten)

```
User klickt Archiv-Button
  → ListPanelAdapter: setCrudMode("deactivate"), setCrudRow(row)
  → CrudDialog: Bestätigungsdialog (keine Felder)
  → deactivateEntityFn({ entityName, id })
  → entity-command-service.deactivateEntity():
      1. isMasterData() — muss kind === "master" sein
      2. getSoftDeleteField() — muss softDeleteField konfiguriert sein
      3a. softDeleteField === "is_active"   → SET is_active = false
      3b. softDeleteField === "archived_at" → SET is_active = false, archived_at = NOW()
  → invalidateQueries(["entity-list", entityName])
```

**Master Data darf niemals hard-deleted werden.** `deleteEntity()` konvertiert automatisch zu Soft-Delete wenn `isMasterData()` true ist.

### 3.4 Delete (nicht-Stammdaten)

```
User klickt Archiv-Button (nur wenn kind !== "master" und genericDelete: true)
  → deleteEntityFn({ entityName, id })
  → entity-command-service.deleteEntity():
      - Master Data → Soft-Delete (s.o., Failsafe)
      - Nicht-Master, genericDelete: true → DELETE FROM <tableName> WHERE <idColumn> = $1
```

---

## 4. Metadaten-Rendering

`CrudDialog` baut das Formular aus `effective_fields` (geladen von `getEffectiveFieldsFn`):

- Felder werden nach `displayOrder` sortiert
- `idColumn` wird aus den editierbaren Feldern gefiltert
- Felder mit `isVisible === false` erscheinen nicht
- Pflichtfelder (`isRequired`) werden mit `*` markiert und client-seitig validiert
- Feldtyp-Mapping: `boolean` → `<input type="checkbox">`, alle anderen → `<input type="text">`

`ListPanelAdapter` baut die Grid-Spalten via `fieldsToGridColumns(effectiveFields, lang)` aus `metadata-renderers.ts` und gibt sie an `<GridRoot columns={...}>` weiter. Der Grid-State (`sorting`, `pagination`, `rowSelection`) liegt als `GridState` vollständig beim Adapter und wird via `onStateChange` zurückgespiegelt — das Grid führt kein eigenes Fetching durch.

---

## 5. Grid-Architektur (components/grid/)

Das Grid ist kompositionell aufgebaut. Consumer (z.B. `ListPanelAdapter`) sind für State und Fetching verantwortlich:

```tsx
const [sorting, setSorting] = useState<SortingState>([]);
const [pagination, setPagination] = useState<PaginationState>({ pageIndex: 0, pageSize: 50 });
const [rowSelection, setRowSelection] = useState<RowSelectionState>({});
const gridState: GridState = { sorting, pagination, rowSelection };

<GridRoot data={data} columns={columns} total={total} isLoading={fetching}
          mode="paginated" state={gridState} onStateChange={handleStateChange}
          selectable={true} onRowClick={handleRowClick}>
  <GridToolbar>
    <GridSearch value={search} onChange={handleSearchCommit} />
    {canCreate && <button onClick={handleCreate}>+ Neu</button>}
  </GridToolbar>
  <GridTable renderRowActions={...} renderEditCell={...} emptyMessage={...} />
  <GridFooter>
    <GridSelectionInfo />
    <GridPagination />
  </GridFooter>
</GridRoot>
```

| Komponente          | Verantwortung                                                                          |
| ------------------- | -------------------------------------------------------------------------------------- |
| `GridRoot`          | TanStack Table-Instanz, Context-Provider, Fully Controlled via `state`/`onStateChange` |
| `GridToolbar`       | Wrapper für Kopfzeilen-Slot (Buttons, Labels)                                          |
| `GridSearch`        | Lokales Debouncing, ruft `onChange` erst nach Pause auf                                |
| `GridTable`         | Render-Schicht: Tabelle, Virtualisierung, Inline-Edit, Row-Actions, `aria-sort`        |
| `GridFooter`        | Wrapper für Fußzeilen-Slot                                                             |
| `GridSelectionInfo` | Zeigt `total` und Anzahl selektierter Zeilen                                           |
| `GridPagination`    | Seitennavigation, nur sichtbar wenn `mode="paginated"`                                 |

`GridTable` unterstützt `renderEditCell` für typisierte Inline-Edit-Inputs (statt hardcoded `<input type="text">`).

---

## 6. Bekannte Limitationen

| Limitation                                 | Datei                       | Konsequenz                                                                                                                    |
| ------------------------------------------ | --------------------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| Edit-Formular startet leer                 | `crud-dialog.tsx:47`        | User muss alle Felder neu eintippen; existierende Werte aus `row` werden nicht als Initialwert gesetzt                        |
| Nur `text`/`checkbox` Inputs im CrudDialog | `crud-dialog.tsx:210-215`   | Zahlen, Datum, Dropdowns, Lookups werden als Text-Input gerendert (`GridTable` hat `renderEditCell`, `CrudDialog` noch nicht) |
| `getIdFieldName()` ist statische Map       | `crud-dialog.tsx:29-43`     | Neue Entities müssen manuell eingetragen werden, bis das aus `EntityDescriptor.idColumn` gelesen wird                         |
| Zwei getrennte Registries                  | `registry.ts` (UI + Domain) | Inkonsistenzen sind möglich: Button sichtbar, aber Command schlägt fehl — oder umgekehrt                                      |

---

## 7. Checkliste: Neue statische Entity

1. **DB Migration**: Tabelle mit `tenant_id`, RLS-Policy, Index auf `tenant_id`
2. **Domain Registry** (`packages/domain/src/entities/registry.ts`):
   ```ts
   [
     "my_entity",
     {
       entityName: "my_entity",
       tableName: "my_entity",
       kind: "master", // oder "transaction"/"derived"
       tenantScoped: true,
       genericRead: true,
       genericPatch: true, // false wenn nur lesbar
       genericDelete: false, // true nur für nicht-Stammdaten
       idColumn: "my_entity_id",
       defaultSort: "my_entity_id",
       allowedFilters: ["tenant_id", "name", "is_active"],
       sortableFields: ["my_entity_id", "name"],
       label: { en: "My Entity", de: "Meine Entity" },
       softDeleteField: "is_active", // wenn kind === "master"
     },
   ];
   ```
3. **UI Workspace Registry** (`apps/web/src/features/workspace/registry.ts`) — aktuell simplifizierter Stub:
   ```ts
   my_entity: {
     label: "Meine Entity",
     fields: ["name", "code"],
   }
   ```
   **TODO:** Erweitern um `paths`, `icon`, `label_de`/`label_en` — konsistent zu Domain Registry.
4. **`getIdFieldName()`** in `crud-dialog.tsx` eintragen (bis das automatisch aus Domain Registry gelesen wird)
5. **`tenant_fields`-Metadata** in DB: Felder als `effective_fields` sichtbar machen, Labels, `displayOrder`, `isRequired` setzen
6. **UI Workspace Config**: Falls eigener Workspace/View → in `WORKSPACES` / `VIEW_REGISTRY` eintragen. Nicht jede Entity braucht einen eigenen Workspace.

---

## 8. Wann Generic Path nicht ausreicht

Generic CRUD genügt nicht, wenn:

- Die Entity **Transaktionsdaten** enthält, die nach Posting unveränderlich sein müssen → spezialisierten Command-Pfad in `commands/` implementieren
- **Validierungsregeln** über Feldtyp/Required hinausgehen (Fremdschlüssel-Prüfung, Cross-Field-Validierung, Invarianten)
- **Berechnete Felder** beim Create/Edit automatisch befüllt werden müssen
- Der **Löschpfad** Kaskaden oder Abhängigkeitsprüfungen erfordert
- Die Entity **Belegzeilen oder verschachtelte Daten** hat → `LinesPanelAdapter`
- **Lookup-Felder** im Formular (Dropdown mit Fremdschlüsseln) gebraucht werden → `CrudDialog` rendert das als Text-Input

In diesen Fällen: spezialisierter Command in `packages/domain/src/commands/`, eigener Server-Function-Handler, ggf. Custom Panel.
