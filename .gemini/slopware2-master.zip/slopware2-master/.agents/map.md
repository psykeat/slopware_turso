# Project Map

## Monorepo Packages

```
apps/web/              TanStack Start app — routes, server functions, UI
packages/auth/         Better Auth — config, middleware, client
packages/db/           Drizzle ORM — schema, migrations, seed
packages/domain/       Business logic — queries, commands, entities, metadata
packages/ui/           shadcn components, Tailwind
packages/api/          HTTP handlers
packages/shared/       Types, schemas
packages/integration/  Connectors, JWT
```

## Apps/Web — Source Tree

```
src/
  routes/                          TanStack Router
    __root.tsx                     Root layout
    index.tsx                      Workspace shell (auth-guarded)
    _auth/                         Protected route guard
    _auth+/                        Admin + app routes
      admin/                       Admin panel (users, tenants, orgs, companies)
      app/index.tsx                App entry
    _guest/                        Public routes (login, signup)

  server/
    server-functions.ts            ALL server functions (*Fn suffix)

  features/
    workspace/                     Main workspace feature
      registry.tsx                 UI entity registry, icons, categories
      view-registry.ts             VIEW_REGISTRY — all addressable views
      view-resolver.tsx            resolveView(key) — renders view by key
      workspace-context.tsx        useWorkspaceContext() — workspace state
      workspace-presets.ts         Workspace layout definitions
      panel-resolver.tsx           Panel rendering logic
      metadata-renderers.tsx       effective_fields → grid columns / form fields
      i18n.ts                      t(key, lang) — translation function
      workspace.tsx                Workspace root component
      workspace.css / workspace-design.css

      components/
        crud-dialog.tsx            Create/edit dialog (reads effective_fields)
        convert-dialog.tsx         Document convert/storno dialog
        data-table/
          entity-data-table.tsx    Generic entity table
        panels/
          list-panel-adapter.tsx   Standard list panel
          detail-panel-adapter.tsx Standard detail panel
          lines-panel-adapter.tsx  Sub-positions / line items
          document-list-adapter.tsx Document list panel
        grid/                      Grid keyboard navigation
        form-fields.tsx            Metadata-driven form field rendering
        error-parser.ts            Server error parsing

      views/                       Custom workspace views
        [prefix]/[prefix]-[suffix]-view.tsx  Naming convention
        address/address-detail-view.tsx
        article/article-detail-view.tsx
        article/article-group-detail-view.tsx
        document/document-detail-view.tsx
        document/document-lines-view.tsx
        document/document-tree-view.tsx
        integration/integration-connector-mappings-view.tsx
        integration/integration-import-queue-view.tsx
        integration/integration-tenant-connectors-view.tsx
        meta/meta-admin-view.tsx
        meta/meta-registry-view.tsx
        settings/settings-connector-definitions-view.tsx
        settings/settings-fiscal-period-view.tsx
        settings/settings-main-view.tsx
        stats/stats-kpi-view.tsx
        stats/stats-period-comparison-view.tsx

    admin/                         Admin feature components
    hotkeys/                       Keyboard navigation infrastructure

  lib/                             Shared utilities
  __tests__/                       App-level tests
```

## Packages — Key Files

### Domain (`packages/domain/src/`)

```
entities/registry.ts               ENTITY_REGISTRY — authoritative entity map
queries/entity-read-service.ts     listEntity, getEntityById
commands/entity-command-service.ts createEntity, patchEntity, deleteEntity, deactivateEntity
metadata/effective-service.ts      getEffectiveFields, getEffectiveLayout
lookups/helper-table-service.ts    listHelperTables, getHelperTableItems
runtime/tenant-runtime.ts          withTenant(), SYSTEM_ORG_ID, BASE_TENANT_ID
```

### Auth (`packages/auth/src/`)

```
auth.ts                            Better Auth config
middleware.ts                      authMiddleware for server functions
functions.ts                       $getUser helper
tanstack/                          TanStack integration (queries, middleware)
adminGuard.ts                      Admin role guard
```

### DB (`packages/db/src/`)

```
index.ts                           db — Drizzle client
schema/                            Drizzle table definitions
migrations/                        Auto-generated migrations
functions/                         Database helper functions
seed/                              Seed data
```

## Data Flow

```
UI component
  → useQuery / useMutation
    → *Fn server function (server-functions.ts)
      → authMiddleware + withTenant
        → domain command / query (packages/domain)
          → Drizzle (packages/db)
            → PostgreSQL
```

## View Naming Convention

```
key: "[prefix]:[suffix]"  →  file: views/[prefix]/[prefix]-[suffix]-view.tsx
Examples:
  "stats:kpi"              →  views/stats/stats-kpi-view.tsx
  "document:lines"         →  views/document/document-lines-view.tsx
  "settings:main"          →  views/settings/settings-main-view.tsx
```

## Server Function Convention

```
export const myFn = createServerFn(...)
  .middleware([authMiddleware])
  .validator(z.object({ ... }))
  .handler(async ({ data, context }) => {
    return withTenant(context.tenantId, async (sql) => { ... });
  });
```
