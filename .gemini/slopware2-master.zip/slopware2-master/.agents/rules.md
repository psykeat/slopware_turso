# Rules — Subagent Reference

## Stack

pnpm monorepo. TanStack Start + React + Vite. PostgreSQL 18 (Docker). Better Auth. Drizzle ORM. Tailwind v4 + `--sw-*` design system.

## Packages

`apps/web` (routes, UI, server functions) | `packages/auth` (Better Auth) | `packages/db` (Drizzle, migrations) | `packages/ui` (shadcn, Tailwind) | `packages/domain` (queries, commands, entities) | `packages/api` (HTTP handlers) | `packages/shared` (types, schemas) | `packages/integration` (connectors, JWT)

## Commands

`sh dev.sh` (all) | `sh dev.sh web` (web only) | `vp check` (format+lint+typecheck) | `vp test` | `sh status.sh` (workflow dashboard) | `pnpm db generate/migrate` | `pnpm ui add <cmp>`

## Key Patterns

- Routing: `_auth/**` protected, `_guest/**` guest, `/` workspace (auth-guarded). State in search params.
- Auth: `authMiddleware` on ALL protected server functions. `$getUser` server helper.
- Design: `.sw-root` scoped. `--sw-*` CSS vars. No shadcn/Tailwind inside `.sw-root`.
- TS: No type casting. `Fn` suffix (server fns), `$` prefix (auth helpers). Static imports only.
- DB: RLS + `tenant_id`. `effective_*` views only. Domain commands for writes.
- `SYSTEM_ORG_ID`: `00000000-0000-0000-0000-000000000001` | `BASE_TENANT_ID`: `00000000-0000-0000-0000-000000000002`
- TanStack: Server functions → Query always. Loaders: `ensureQueryData`. `createServerFn` = server-only.

## Specs (load on-demand from `.agents/`)

`tanstack-patterns.md` | `auth.md` | `tenant-context.md` | `schema.md` | `00_core_architecture.md` | `01_metadata_spec.md` | `02_workspace_architecture.md` | `06_generic_entity_crud.md` | `tenant-switcher.md` | `typescript.md`

## Design Deep-Dive

Für UI-Komponenten, Styling, Layout:

- `.agents/03_design_rules.md` — kompakte SOP (Tokens, Mandatory Components, Hard Don'ts, View Convention)
- `design.md` — vollständiges Design System (332 Zeilen, 12 Themes, Component Vocabulary, Checkliste)

## GUARDRAILS

- ❌ NIE ohne Tests committen
- ❌ Atomic Changes only (1 Feature pro Cycle)
- ✅ `vp check` + `vp test` müssen passen vor Commit

## BLOCKER REPORTING (critical)

Wenn du auf ein Problem stößt das du NICHT selbst lösen kannst (Config-Missing, externe Dependencies, Tool-Fehler, etc.):

1. Schreibe es in `plan/blockers.md` — max 3 Zeilen pro Blocker, format: `[BLOCKER] <kurze beschreibung>`
2. Commit was du kannst (auch unvollständig)
3. Setze `plan/task.md` Status auf `blocked` + kurze Erklärung
4. Der Dispatcher liest `plan/blockers.md` vor dem nächsten Cycle und fixt das Problem

## FILE WRITES — JSON encoding limit auf ALLE Werkzeuge

ALLE Tools (write, edit, bash heredoc) gehen durch JSON-Encoding.
Große Inhalte brechen daran. Lösung: **kleine Chunks**.

- **write**: nur < 30 Zeilen
- **edit**: max 20 Zeilen pro Aufruf. Mehrere edits hintereinander für große Dateien.
- **bash heredoc**: nur für Dateien < 60 Zeilen (bash string geht auch durch JSON!)
- **Testdateien**: write minimalen Stub → edit pro `it()`-Block (10-15 Zeilen pro edit)
- **Code-Dateien**: write Stub → edit Block für Block
- **NIEMALS** versuchen eine > 60 Zeilige Datei in einem Aufruf zu schreiben

## Fallow local gate

Before any `git commit` or `git push`, run `fallow audit --format json --quiet --explain`. If verdict is `fail`, fix findings before retry. Default: `gate=new-only` — only current changeset affects verdict.
