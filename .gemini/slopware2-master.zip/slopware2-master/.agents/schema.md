# Slopware — Live Schema

> Generated: 2026-05-07 07:52:18 UTC
> Tables: 63

## Module: uncategorized

### `account`

> _⚠ pending annotation_

| Column                   | Business Name            | Type                        | Class | Constraints             | Description |
| ------------------------ | ------------------------ | --------------------------- | ----- | ----------------------- | ----------- |
| id                       | id                       | text                        | PK    | NOT NULL                |             |
| account_id               | account_id               | text                        | —     | NOT NULL                |             |
| provider_id              | provider_id              | text                        | —     | NOT NULL                |             |
| user_id                  | user_id                  | text                        | —     | NOT NULL                |             |
| access_token             | access_token             | text                        | —     |                         |             |
| refresh_token            | refresh_token            | text                        | —     |                         |             |
| id_token                 | id_token                 | text                        | —     |                         |             |
| access_token_expires_at  | access_token_expires_at  | timestamp without time zone | —     |                         |             |
| refresh_token_expires_at | refresh_token_expires_at | timestamp without time zone | —     |                         |             |
| scope                    | scope                    | text                        | —     |                         |             |
| password                 | password                 | text                        | —     |                         |             |
| created_at               | created_at               | timestamp without time zone | —     | NOT NULL, DEFAULT now() |             |
| updated_at               | updated_at               | timestamp without time zone | —     | NOT NULL                |             |

> INDEX `account_userId_idx` (user_id) [btree]

> CHECK `account_account_id_not_null`: account_id IS NOT NULL
> CHECK `account_created_at_not_null`: created_at IS NOT NULL
> CHECK `account_id_not_null`: id IS NOT NULL
> CHECK `account_provider_id_not_null`: provider_id IS NOT NULL
> CHECK `account_updated_at_not_null`: updated_at IS NOT NULL
> CHECK `account_user_id_not_null`: user_id IS NOT NULL

### `account_determination_rule`

> _⚠ pending annotation_

| Column           | Business Name    | Type                     | Class | Constraints                         | Description |
| ---------------- | ---------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| rule_id          | rule_id          | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id        | tenant_id        | uuid                     | —     | NOT NULL                            |             |
| company_id       | company_id       | uuid                     | —     |                                     |             |
| article_group_id | article_group_id | uuid                     | —     |                                     |             |
| tax_code_id      | tax_code_id      | uuid                     | —     |                                     |             |
| posting_context  | posting_context  | character varying        | —     | NOT NULL                            |             |
| gl_account_id    | gl_account_id    | uuid                     | —     | NOT NULL                            |             |
| created_at       | created_at       | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> INDEX `idx_acct_det_lookup` (tenant_id, posting_context, article_group_id, tax_code_id) [btree]
> INDEX `idx_acct_det_tenant` (tenant_id) [btree]

> CHECK `account_determination_rule_created_at_not_null`: created_at IS NOT NULL
> CHECK `account_determination_rule_gl_account_id_not_null`: gl_account_id IS NOT NULL
> CHECK `account_determination_rule_posting_context_not_null`: posting_context IS NOT NULL
> CHECK `account_determination_rule_rule_id_not_null`: rule_id IS NOT NULL
> CHECK `account_determination_rule_tenant_id_not_null`: tenant_id IS NOT NULL

### `address`

> _⚠ pending annotation_

| Column                      | Business Name               | Type                     | Class | Constraints                         | Description |
| --------------------------- | --------------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| address_id                  | address_id                  | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id                   | tenant_id                   | uuid                     | —     | NOT NULL                            |             |
| address_no                  | address_no                  | character varying        | —     | NOT NULL                            |             |
| address_type                | address_type                | character varying        | —     | NOT NULL                            |             |
| is_customer                 | is_customer                 | boolean                  | —     | NOT NULL, DEFAULT false             |             |
| is_supplier                 | is_supplier                 | boolean                  | —     | NOT NULL, DEFAULT false             |             |
| company_name                | company_name                | character varying        | —     |                                     |             |
| first_name                  | first_name                  | character varying        | —     |                                     |             |
| last_name                   | last_name                   | character varying        | —     |                                     |             |
| address_line_1              | address_line_1              | character varying        | —     | NOT NULL                            |             |
| address_line_2              | address_line_2              | character varying        | —     |                                     |             |
| postal_code                 | postal_code                 | character varying        | —     | NOT NULL                            |             |
| city                        | city                        | character varying        | —     | NOT NULL                            |             |
| state_province              | state_province              | character varying        | —     |                                     |             |
| country_code                | country_code                | char(2)                  | —     | NOT NULL                            |             |
| vat_id                      | vat_id                      | character varying        | —     |                                     |             |
| tax_class_id                | tax_class_id                | uuid                     | —     |                                     |             |
| currency_id                 | currency_id                 | char(3)                  | —     |                                     |             |
| payment_term_id             | payment_term_id             | uuid                     | —     |                                     |             |
| is_active                   | is_active                   | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| archived_at                 | archived_at                 | timestamp with time zone | —     |                                     |             |
| custom_attributes           | custom_attributes           | jsonb                    | —     |                                     |             |
| created_at                  | created_at                  | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| updated_at                  | updated_at                  | timestamp with time zone | —     |                                     |             |
| bank_account_id             | bank_account_id             | uuid                     | —     |                                     |             |
| default_delivery_address_id | default_delivery_address_id | uuid                     | —     |                                     |             |
| search_text                 | search_text                 | text                     | —     |                                     |             |
| address_category_id         | address_category_id         | uuid                     | —     |                                     |             |

> UNIQUE(tenant_id, address_id)
> UNIQUE(tenant_id, address_id)
> UNIQUE(tenant_id, address_no)

> INDEX UNIQUE `address_tenant_id_address_id_key` (tenant_id, address_id) [btree]
> INDEX UNIQUE `address_tenant_id_address_id_unique` (tenant_id, address_id) [btree]
> INDEX UNIQUE `address_tenant_id_address_no_unique` (tenant_id, address_no) [btree]
> INDEX `idx_address_category` (tenant_id, address_category_id) [btree]
> INDEX `idx_address_customer` (tenant_id, is_customer) [btree]
> INDEX `idx_address_search_trgm` (search_text) [btree]
> INDEX `idx_address_supplier` (tenant_id, is_supplier) [btree]
> INDEX `idx_address_tenant` (tenant_id) [btree]
> INDEX `idx_address_type` (tenant_id, address_type) [btree]

> CHECK `address_address_id_not_null`: address_id IS NOT NULL
> CHECK `address_address_line_1_not_null`: address_line_1 IS NOT NULL
> CHECK `address_address_no_not_null`: address_no IS NOT NULL
> CHECK `address_address_type_not_null`: address_type IS NOT NULL
> CHECK `address_city_not_null`: city IS NOT NULL
> CHECK `address_country_code_not_null`: country_code IS NOT NULL
> CHECK `address_created_at_not_null`: created_at IS NOT NULL
> CHECK `address_is_active_not_null`: is_active IS NOT NULL
> CHECK `address_is_customer_not_null`: is_customer IS NOT NULL
> CHECK `address_is_supplier_not_null`: is_supplier IS NOT NULL
> CHECK `address_postal_code_not_null`: postal_code IS NOT NULL
> CHECK `address_tenant_id_not_null`: tenant_id IS NOT NULL

### `address_category`

> _⚠ pending annotation_

| Column            | Business Name     | Type                     | Class | Constraints                         | Description |
| ----------------- | ----------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| category_id       | category_id       | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id         | tenant_id         | uuid                     | —     | NOT NULL                            |             |
| name              | name              | jsonb                    | —     | NOT NULL                            |             |
| is_active         | is_active         | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at        | created_at        | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| custom_attributes | custom_attributes | jsonb                    | —     |                                     |             |

> UNIQUE(tenant_id, category_id)
> UNIQUE(tenant_id, name)

> INDEX UNIQUE `address_category_tenant_id_category_id_key` (tenant_id, category_id) [btree]
> INDEX UNIQUE `address_category_tenant_id_name_unique` (tenant_id, name) [btree]
> INDEX `idx_address_category_tenant` (tenant_id) [btree]

> CHECK `address_category_category_id_not_null`: category_id IS NOT NULL
> CHECK `address_category_created_at_not_null`: created_at IS NOT NULL
> CHECK `address_category_is_active_not_null`: is_active IS NOT NULL
> CHECK `address_category_name_not_null`: name IS NOT NULL
> CHECK `address_category_tenant_id_not_null`: tenant_id IS NOT NULL

### `address_contact`

> _⚠ pending annotation_

| Column         | Business Name  | Type                     | Class | Constraints                         | Description |
| -------------- | -------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| contact_id     | contact_id     | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id      | tenant_id      | uuid                     | —     | NOT NULL                            |             |
| address_id     | address_id     | uuid                     | —     | NOT NULL                            |             |
| first_name     | first_name     | character varying        | —     |                                     |             |
| last_name      | last_name      | character varying        | —     | NOT NULL                            |             |
| email          | email          | character varying        | —     |                                     |             |
| phone_mobile   | phone_mobile   | character varying        | —     |                                     |             |
| phone_landline | phone_landline | character varying        | —     |                                     |             |
| role_function  | role_function  | character varying        | —     |                                     |             |
| is_primary     | is_primary     | boolean                  | —     | NOT NULL, DEFAULT false             |             |
| is_active      | is_active      | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at     | created_at     | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> INDEX `idx_address_contact_address` (address_id) [btree]
> INDEX `idx_address_contact_tenant` (tenant_id) [btree]

> CHECK `address_contact_address_id_not_null`: address_id IS NOT NULL
> CHECK `address_contact_contact_id_not_null`: contact_id IS NOT NULL
> CHECK `address_contact_created_at_not_null`: created_at IS NOT NULL
> CHECK `address_contact_is_active_not_null`: is_active IS NOT NULL
> CHECK `address_contact_is_primary_not_null`: is_primary IS NOT NULL
> CHECK `address_contact_last_name_not_null`: last_name IS NOT NULL
> CHECK `address_contact_tenant_id_not_null`: tenant_id IS NOT NULL

### `address_seq`

> _⚠ pending annotation_

| Column    | Business Name | Type    | Class | Constraints         | Description |
| --------- | ------------- | ------- | ----- | ------------------- | ----------- |
| tenant_id | tenant_id     | uuid    | PK    | NOT NULL            |             |
| next_val  | next_val      | integer | —     | NOT NULL, DEFAULT 1 |             |

> INDEX `idx_address_seq_tenant` (tenant_id) [btree]

> CHECK `address_seq_next_val_not_null`: next_val IS NOT NULL
> CHECK `address_seq_tenant_id_not_null`: tenant_id IS NOT NULL

### `app_user`

> _⚠ pending annotation_

| Column          | Business Name   | Type                     | Class | Constraints                         | Description |
| --------------- | --------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| user_id         | user_id         | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| email           | email           | character varying        | —     | NOT NULL                            |             |
| password_hash   | password_hash   | character varying        | —     | NOT NULL                            |             |
| display_name    | display_name    | character varying        | —     |                                     |             |
| is_active       | is_active       | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at      | created_at      | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| last_company_id | last_company_id | uuid                     | —     |                                     |             |
| is_system_admin | is_system_admin | boolean                  | —     | NOT NULL, DEFAULT false             |             |
| locale          | locale          | varchar(5)               | —     | NOT NULL, DEFAULT de                |             |

> UNIQUE(email)

> INDEX UNIQUE `app_user_email_key` (email) [btree]

> CHECK `app_user_created_at_not_null`: created_at IS NOT NULL
> CHECK `app_user_email_not_null`: email IS NOT NULL
> CHECK `app_user_is_active_not_null`: is_active IS NOT NULL
> CHECK `app_user_is_system_admin_not_null`: is_system_admin IS NOT NULL
> CHECK `app_user_locale_not_null`: locale IS NOT NULL
> CHECK `app_user_password_hash_not_null`: password_hash IS NOT NULL
> CHECK `app_user_user_id_not_null`: user_id IS NOT NULL

### `article`

> _⚠ pending annotation_

| Column               | Business Name        | Type                     | Class | Constraints                         | Description |
| -------------------- | -------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| article_id           | article_id           | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id            | tenant_id            | uuid                     | —     | NOT NULL                            |             |
| article_no           | article_no           | character varying        | —     | NOT NULL                            |             |
| name                 | name                 | character varying        | —     | NOT NULL                            |             |
| description          | description          | text                     | —     |                                     |             |
| article_group_id     | article_group_id     | uuid                     | —     |                                     |             |
| tax_class_id         | tax_class_id         | uuid                     | —     |                                     |             |
| base_unit            | base_unit            | character varying        | —     |                                     |             |
| sales_unit           | sales_unit           | character varying        | —     |                                     |             |
| purchase_unit        | purchase_unit        | character varying        | —     |                                     |             |
| is_active            | is_active            | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| archived_at          | archived_at          | timestamp with time zone | —     |                                     |             |
| custom_attributes    | custom_attributes    | jsonb                    | —     |                                     |             |
| created_at           | created_at           | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| updated_at           | updated_at           | timestamp with time zone | —     |                                     |             |
| default_warehouse_id | default_warehouse_id | uuid                     | —     |                                     |             |
| tracking_mode        | tracking_mode        | character varying        | —     |                                     |             |
| bom_type             | bom_type             | character varying        | —     | NOT NULL, DEFAULT none              |             |

> UNIQUE(tenant_id, article_id)
> UNIQUE(tenant_id, article_id)
> UNIQUE(tenant_id, article_no)

> INDEX UNIQUE `article_tenant_id_article_id_key` (tenant_id, article_id) [btree]
> INDEX UNIQUE `article_tenant_id_article_id_unique` (tenant_id, article_id) [btree]
> INDEX UNIQUE `article_tenant_id_article_no_unique` (tenant_id, article_no) [btree]
> INDEX `idx_article_default_wh` (tenant_id, default_warehouse_id) [btree]
> INDEX `idx_article_group_fk` (article_group_id) [btree]
> INDEX `idx_article_tenant` (tenant_id) [btree]
> INDEX `idx_article_tenant_active` (tenant_id, is_active) [btree]

> CHECK `article_article_id_not_null`: article_id IS NOT NULL
> CHECK `article_article_no_not_null`: article_no IS NOT NULL
> CHECK `article_bom_type_check`: ((bom_type)::text = ANY ((ARRAY['none'::character varying, 'production'::character varying, 'sales'::character varying])::text[]))
> CHECK `article_bom_type_not_null`: bom_type IS NOT NULL
> CHECK `article_created_at_not_null`: created_at IS NOT NULL
> CHECK `article_is_active_not_null`: is_active IS NOT NULL
> CHECK `article_name_not_null`: name IS NOT NULL
> CHECK `article_tenant_id_not_null`: tenant_id IS NOT NULL
> CHECK `article_tracking_mode_check`: (((tracking_mode)::text = ANY ((ARRAY['serial'::character varying, 'batch'::character varying])::text[])) OR (tracking_mode IS NULL))

### `article_bom`

> _⚠ pending annotation_

| Column               | Business Name        | Type                     | Class | Constraints                         | Description |
| -------------------- | -------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| bom_id               | bom_id               | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id            | tenant_id            | uuid                     | —     | NOT NULL                            |             |
| header_article_id    | header_article_id    | uuid                     | —     | NOT NULL                            |             |
| component_article_id | component_article_id | uuid                     | —     | NOT NULL                            |             |
| quantity             | quantity             | numeric                  | —     | NOT NULL                            |             |
| scrap_percentage     | scrap_percentage     | numeric                  | —     | NOT NULL, DEFAULT 0                 |             |
| is_active            | is_active            | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at           | created_at           | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(tenant_id, header_article_id, component_article_id)

> INDEX UNIQUE `article_bom_tenant_id_header_article_id_component_article_id_un` (tenant_id, header_article_id, component_article_id) [btree]

> CHECK `article_bom_bom_id_not_null`: bom_id IS NOT NULL
> CHECK `article_bom_component_article_id_not_null`: component_article_id IS NOT NULL
> CHECK `article_bom_created_at_not_null`: created_at IS NOT NULL
> CHECK `article_bom_header_article_id_not_null`: header_article_id IS NOT NULL
> CHECK `article_bom_is_active_not_null`: is_active IS NOT NULL
> CHECK `article_bom_quantity_check`: (quantity > (0)::numeric)
> CHECK `article_bom_quantity_not_null`: quantity IS NOT NULL
> CHECK `article_bom_scrap_percentage_not_null`: scrap_percentage IS NOT NULL
> CHECK `article_bom_tenant_id_not_null`: tenant_id IS NOT NULL

### `article_group`

> _⚠ pending annotation_

| Column           | Business Name    | Type                     | Class | Constraints                         | Description |
| ---------------- | ---------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| article_group_id | article_group_id | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id        | tenant_id        | uuid                     | —     | NOT NULL                            |             |
| code             | code             | character varying        | —     | NOT NULL                            |             |
| name             | name             | character varying        | —     | NOT NULL                            |             |
| is_active        | is_active        | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at       | created_at       | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(tenant_id, article_group_id)
> UNIQUE(tenant_id, code)

> INDEX UNIQUE `article_group_tenant_id_article_group_id_key` (tenant_id, article_group_id) [btree]
> INDEX UNIQUE `article_group_tenant_id_code_unique` (tenant_id, code) [btree]
> INDEX `idx_article_group_tenant` (tenant_id) [btree]

> CHECK `article_group_article_group_id_not_null`: article_group_id IS NOT NULL
> CHECK `article_group_code_not_null`: code IS NOT NULL
> CHECK `article_group_created_at_not_null`: created_at IS NOT NULL
> CHECK `article_group_is_active_not_null`: is_active IS NOT NULL
> CHECK `article_group_name_not_null`: name IS NOT NULL
> CHECK `article_group_tenant_id_not_null`: tenant_id IS NOT NULL

### `bank_account`

> _⚠ pending annotation_

| Column            | Business Name     | Type                     | Class | Constraints                         | Description |
| ----------------- | ----------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| bank_account_id   | bank_account_id   | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id         | tenant_id         | uuid                     | —     | NOT NULL                            |             |
| company_id        | company_id        | uuid                     | —     |                                     |             |
| address_id        | address_id        | uuid                     | —     |                                     |             |
| iban              | iban              | character varying        | —     | NOT NULL                            |             |
| bic               | bic               | character varying        | —     |                                     |             |
| bank_name         | bank_name         | character varying        | —     |                                     |             |
| currency_id       | currency_id       | char(3)                  | —     |                                     |             |
| is_default        | is_default        | boolean                  | —     | NOT NULL, DEFAULT false             |             |
| is_active         | is_active         | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at        | created_at        | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| custom_attributes | custom_attributes | jsonb                    | —     |                                     |             |

> UNIQUE(tenant_id, iban)

> INDEX UNIQUE `bank_account_tenant_id_iban_unique` (tenant_id, iban) [btree]
> INDEX `idx_bank_account_address` (address_id) [btree]
> INDEX `idx_bank_account_company` (company_id) [btree]
> INDEX `idx_bank_account_tenant` (tenant_id) [btree]

> CHECK `bank_account_bank_account_id_not_null`: bank_account_id IS NOT NULL
> CHECK `bank_account_created_at_not_null`: created_at IS NOT NULL
> CHECK `bank_account_iban_not_null`: iban IS NOT NULL
> CHECK `bank_account_is_active_not_null`: is_active IS NOT NULL
> CHECK `bank_account_is_default_not_null`: is_default IS NOT NULL
> CHECK `bank_account_tenant_id_not_null`: tenant_id IS NOT NULL
> CHECK `chk_bank_account_target`: (((company_id IS NOT NULL) AND (address_id IS NULL)) OR ((company_id IS NULL) AND (address_id IS NOT NULL)))

### `company`

> _⚠ pending annotation_

| Column                  | Business Name           | Type                     | Class | Constraints                         | Description |
| ----------------------- | ----------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| company_id              | company_id              | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id               | tenant_id               | uuid                     | —     | NOT NULL                            |             |
| company_no              | company_no              | character varying        | —     | NOT NULL                            |             |
| name                    | name                    | character varying        | —     | NOT NULL                            |             |
| legal_name              | legal_name              | character varying        | —     |                                     |             |
| country_code            | country_code            | char(2)                  | —     | NOT NULL                            |             |
| currency_id             | currency_id             | char(3)                  | —     | NOT NULL                            |             |
| vat_id                  | vat_id                  | character varying        | —     |                                     |             |
| is_active               | is_active               | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at              | created_at              | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| address_line_1          | address_line_1          | character varying        | —     |                                     |             |
| address_line_2          | address_line_2          | character varying        | —     |                                     |             |
| city                    | city                    | character varying        | —     |                                     |             |
| postal_code             | postal_code             | character varying        | —     |                                     |             |
| phone_landline          | phone_landline          | character varying        | —     |                                     |             |
| phone_mobile            | phone_mobile            | character varying        | —     |                                     |             |
| email                   | email                   | character varying        | —     |                                     |             |
| homepage                | homepage                | character varying        | —     |                                     |             |
| tax_number              | tax_number              | character varying        | —     |                                     |             |
| tax_authority           | tax_authority           | character varying        | —     |                                     |             |
| gln                     | gln                     | character varying        | —     |                                     |             |
| eori_no                 | eori_no                 | character varying        | —     |                                     |             |
| duns_no                 | duns_no                 | character varying        | —     |                                     |             |
| custom_attributes       | custom_attributes       | jsonb                    | —     |                                     |             |
| bank_name               | bank_name               | character varying        | —     |                                     |             |
| bank_bic                | bank_bic                | character varying        | —     |                                     |             |
| bank_iban               | bank_iban               | character varying        | —     |                                     |             |
| fiscal_year_start_month | fiscal_year_start_month | integer                  | —     | NOT NULL, DEFAULT 1                 |             |

> UNIQUE(tenant_id, company_id)
> UNIQUE(tenant_id, company_no)

> INDEX UNIQUE `company_tenant_id_company_id_key` (tenant_id, company_id) [btree]
> INDEX UNIQUE `company_tenant_id_company_no_unique` (tenant_id, company_no) [btree]
> INDEX `idx_company_tenant` (tenant_id) [btree]
> INDEX `idx_company_tenant_active` (tenant_id, is_active) [btree]

> CHECK `company_company_id_not_null`: company_id IS NOT NULL
> CHECK `company_company_no_not_null`: company_no IS NOT NULL
> CHECK `company_country_code_not_null`: country_code IS NOT NULL
> CHECK `company_created_at_not_null`: created_at IS NOT NULL
> CHECK `company_currency_id_not_null`: currency_id IS NOT NULL
> CHECK `company_fiscal_year_start_month_check`: ((fiscal_year_start_month >= 1) AND (fiscal_year_start_month <= 12))
> CHECK `company_fiscal_year_start_month_not_null`: fiscal_year_start_month IS NOT NULL
> CHECK `company_is_active_not_null`: is_active IS NOT NULL
> CHECK `company_name_not_null`: name IS NOT NULL
> CHECK `company_tenant_id_not_null`: tenant_id IS NOT NULL

### `connector_definition`

> _⚠ pending annotation_

| Column           | Business Name    | Type              | Class | Constraints                         | Description |
| ---------------- | ---------------- | ----------------- | ----- | ----------------------------------- | ----------- |
| connector_id     | connector_id     | uuid              | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| slug             | slug             | character varying | —     | NOT NULL                            |             |
| label            | label            | jsonb             | —     | NOT NULL                            |             |
| default_mappings | default_mappings | jsonb             | —     | NOT NULL, DEFAULT {}                |             |
| locked_fields    | locked_fields    | jsonb             | —     | NOT NULL, DEFAULT []                |             |
| atomicity_mode   | atomicity_mode   | character varying | —     | NOT NULL                            |             |

> UNIQUE(slug)

> INDEX UNIQUE `connector_definition_slug_key` (slug) [btree]

> CHECK `connector_definition_atomicity_mode_check`: ((atomicity_mode)::text = ANY ((ARRAY['file'::character varying, 'entity'::character varying, 'run'::character varying])::text[]))
> CHECK `connector_definition_atomicity_mode_not_null`: atomicity_mode IS NOT NULL
> CHECK `connector_definition_connector_id_not_null`: connector_id IS NOT NULL
> CHECK `connector_definition_default_mappings_not_null`: default_mappings IS NOT NULL
> CHECK `connector_definition_label_not_null`: label IS NOT NULL
> CHECK `connector_definition_locked_fields_not_null`: locked_fields IS NOT NULL
> CHECK `connector_definition_slug_not_null`: slug IS NOT NULL

### `cost_center`

> _⚠ pending annotation_

| Column         | Business Name  | Type                     | Class | Constraints                         | Description |
| -------------- | -------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| cost_center_id | cost_center_id | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id      | tenant_id      | uuid                     | —     | NOT NULL                            |             |
| company_id     | company_id     | uuid                     | —     |                                     |             |
| code           | code           | character varying        | —     | NOT NULL                            |             |
| name           | name           | character varying        | —     | NOT NULL                            |             |
| is_active      | is_active      | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at     | created_at     | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(tenant_id, code)
> UNIQUE(tenant_id, cost_center_id)

> INDEX UNIQUE `cost_center_tenant_id_code_unique` (tenant_id, code) [btree]
> INDEX UNIQUE `cost_center_tenant_id_cost_center_id_key` (tenant_id, cost_center_id) [btree]
> INDEX `idx_cost_center_tenant` (tenant_id) [btree]

> CHECK `cost_center_code_not_null`: code IS NOT NULL
> CHECK `cost_center_cost_center_id_not_null`: cost_center_id IS NOT NULL
> CHECK `cost_center_created_at_not_null`: created_at IS NOT NULL
> CHECK `cost_center_is_active_not_null`: is_active IS NOT NULL
> CHECK `cost_center_name_not_null`: name IS NOT NULL
> CHECK `cost_center_tenant_id_not_null`: tenant_id IS NOT NULL

### `country`

> _⚠ pending annotation_

| Column     | Business Name | Type                     | Class | Constraints                         | Description |
| ---------- | ------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| country_id | country_id    | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| iso2_code  | iso2_code     | varchar(2)               | —     | NOT NULL                            |             |
| iso3_code  | iso3_code     | varchar(3)               | —     | NOT NULL                            |             |
| name       | name          | jsonb                    | —     | NOT NULL                            |             |
| is_eu      | is_eu         | boolean                  | —     | NOT NULL, DEFAULT false             |             |
| is_active  | is_active     | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at | created_at    | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(iso2_code)
> UNIQUE(iso3_code)

> INDEX UNIQUE `country_iso2_code_key` (iso2_code) [btree]
> INDEX UNIQUE `country_iso3_code_key` (iso3_code) [btree]

> CHECK `country_country_id_not_null`: country_id IS NOT NULL
> CHECK `country_created_at_not_null`: created_at IS NOT NULL
> CHECK `country_is_active_not_null`: is_active IS NOT NULL
> CHECK `country_is_eu_not_null`: is_eu IS NOT NULL
> CHECK `country_iso2_code_not_null`: iso2_code IS NOT NULL
> CHECK `country_iso3_code_not_null`: iso3_code IS NOT NULL
> CHECK `country_name_not_null`: name IS NOT NULL

### `currency`

> _⚠ pending annotation_

| Column      | Business Name | Type                     | Class | Constraints                         | Description |
| ----------- | ------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| currency_id | currency_id   | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| code        | code          | varchar(3)               | —     | NOT NULL                            |             |
| name        | name          | jsonb                    | —     | NOT NULL                            |             |
| symbol      | symbol        | varchar(5)               | —     |                                     |             |
| decimals    | decimals      | integer                  | —     | NOT NULL, DEFAULT 2                 |             |
| is_active   | is_active     | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at  | created_at    | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(code)

> INDEX UNIQUE `currency_code_key` (code) [btree]

> CHECK `currency_code_not_null`: code IS NOT NULL
> CHECK `currency_created_at_not_null`: created_at IS NOT NULL
> CHECK `currency_currency_id_not_null`: currency_id IS NOT NULL
> CHECK `currency_decimals_not_null`: decimals IS NOT NULL
> CHECK `currency_is_active_not_null`: is_active IS NOT NULL
> CHECK `currency_name_not_null`: name IS NOT NULL

### `delivery_address`

> _⚠ pending annotation_

| Column               | Business Name        | Type                     | Class | Constraints                         | Description |
| -------------------- | -------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| delivery_address_id  | delivery_address_id  | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id            | tenant_id            | uuid                     | —     | NOT NULL                            |             |
| address_id           | address_id           | uuid                     | —     | NOT NULL                            |             |
| name                 | name                 | character varying        | —     |                                     |             |
| address_line_1       | address_line_1       | character varying        | —     | NOT NULL                            |             |
| address_line_2       | address_line_2       | character varying        | —     |                                     |             |
| postal_code          | postal_code          | character varying        | —     | NOT NULL                            |             |
| city                 | city                 | character varying        | —     | NOT NULL                            |             |
| country_code         | country_code         | char(2)                  | —     | NOT NULL                            |             |
| is_active            | is_active            | boolean                  | —     | DEFAULT true                        |             |
| default_for_shipping | default_for_shipping | boolean                  | —     | DEFAULT false                       |             |
| custom_attributes    | custom_attributes    | jsonb                    | —     |                                     |             |
| created_at           | created_at           | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| updated_at           | updated_at           | timestamp with time zone | —     |                                     |             |

> INDEX `idx_delivery_address_partner` (address_id) [btree]
> INDEX `idx_delivery_address_tenant` (tenant_id) [btree]

> CHECK `delivery_address_address_id_not_null`: address_id IS NOT NULL
> CHECK `delivery_address_address_line_1_not_null`: address_line_1 IS NOT NULL
> CHECK `delivery_address_city_not_null`: city IS NOT NULL
> CHECK `delivery_address_country_code_not_null`: country_code IS NOT NULL
> CHECK `delivery_address_created_at_not_null`: created_at IS NOT NULL
> CHECK `delivery_address_delivery_address_id_not_null`: delivery_address_id IS NOT NULL
> CHECK `delivery_address_postal_code_not_null`: postal_code IS NOT NULL
> CHECK `delivery_address_tenant_id_not_null`: tenant_id IS NOT NULL

### `discount_group`

> _⚠ pending annotation_

| Column            | Business Name     | Type                     | Class | Constraints                         | Description |
| ----------------- | ----------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| discount_group_id | discount_group_id | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id         | tenant_id         | uuid                     | —     | NOT NULL                            |             |
| name              | name              | character varying        | —     | NOT NULL                            |             |
| percentage        | percentage        | numeric                  | —     | NOT NULL                            |             |
| is_active         | is_active         | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at        | created_at        | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(tenant_id, name)

> INDEX UNIQUE `discount_group_tenant_id_name_unique` (tenant_id, name) [btree]
> INDEX `idx_discount_group_tenant` (tenant_id) [btree]

> CHECK `discount_group_created_at_not_null`: created_at IS NOT NULL
> CHECK `discount_group_discount_group_id_not_null`: discount_group_id IS NOT NULL
> CHECK `discount_group_is_active_not_null`: is_active IS NOT NULL
> CHECK `discount_group_name_not_null`: name IS NOT NULL
> CHECK `discount_group_percentage_not_null`: percentage IS NOT NULL
> CHECK `discount_group_tenant_id_not_null`: tenant_id IS NOT NULL

### `document`

> _⚠ pending annotation_

| Column              | Business Name       | Type                     | Class | Constraints                         | Description |
| ------------------- | ------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| document_id         | document_id         | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id           | tenant_id           | uuid                     | —     | NOT NULL                            |             |
| company_id          | company_id          | uuid                     | —     | NOT NULL                            |             |
| document_type       | document_type       | char(1)                  | —     | NOT NULL                            |             |
| document_direction  | document_direction  | character varying        | —     | NOT NULL                            |             |
| document_no         | document_no         | character varying        | —     | NOT NULL                            |             |
| status              | status              | character varying        | —     | NOT NULL                            |             |
| customer_id         | customer_id         | uuid                     | —     |                                     |             |
| currency_id         | currency_id         | char(3)                  | —     |                                     |             |
| document_date       | document_date       | date                     | —     | NOT NULL                            |             |
| posting_date        | posting_date        | date                     | —     |                                     |             |
| total_net           | total_net           | numeric                  | —     |                                     |             |
| total_tax           | total_tax           | numeric                  | —     |                                     |             |
| total_gross         | total_gross         | numeric                  | —     |                                     |             |
| version_no          | version_no          | integer                  | —     | NOT NULL, DEFAULT 1                 |             |
| posted_at           | posted_at           | timestamp with time zone | —     |                                     |             |
| posted_by           | posted_by           | uuid                     | —     |                                     |             |
| cancelled_at        | cancelled_at        | timestamp with time zone | —     |                                     |             |
| storno_document_id  | storno_document_id  | uuid                     | —     |                                     |             |
| custom_attributes   | custom_attributes   | jsonb                    | —     |                                     |             |
| created_at          | created_at          | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| updated_at          | updated_at          | timestamp with time zone | —     |                                     |             |
| transaction_id      | transaction_id      | uuid                     | —     | NOT NULL                            |             |
| parent_document_id  | parent_document_id  | uuid                     | —     |                                     |             |
| document_group_id   | document_group_id   | uuid                     | —     |                                     |             |
| archived_at         | archived_at         | timestamp with time zone | —     |                                     |             |
| billing_address     | billing_address     | jsonb                    | —     |                                     |             |
| delivery_address    | delivery_address    | jsonb                    | —     |                                     |             |
| delivery_address_id | delivery_address_id | uuid                     | —     |                                     |             |
| payment_term_id     | payment_term_id     | uuid                     | —     |                                     |             |
| shipping_method_id  | shipping_method_id  | uuid                     | —     |                                     |             |
| document_type_id    | document_type_id    | uuid                     | —     |                                     |             |
| warehouse_id        | warehouse_id        | uuid                     | —     |                                     |             |
| target_warehouse_id | target_warehouse_id | uuid                     | —     |                                     |             |

> UNIQUE(tenant_id, company_id, document_no)
> UNIQUE(tenant_id, document_id)
> UNIQUE(tenant_id, document_id)

> INDEX UNIQUE `document_tenant_id_company_id_document_no_unique` (tenant_id, company_id, document_no) [btree]
> INDEX UNIQUE `document_tenant_id_document_id_key` (tenant_id, document_id) [btree]
> INDEX UNIQUE `document_tenant_id_document_id_unique` (tenant_id, document_id) [btree]
> INDEX `idx_document_company` (tenant_id, company_id) [btree]
> INDEX `idx_document_customer` (tenant_id, customer_id) [btree]
> INDEX `idx_document_delivery_address` (tenant_id, delivery_address_id) [btree]
> INDEX `idx_document_group` (document_group_id) [btree]
> INDEX `idx_document_group_type` (document_group_id, document_type_id) [btree]
> INDEX `idx_document_parent` (parent_document_id) [btree]
> INDEX `idx_document_payment_term` (payment_term_id) [btree]
> INDEX `idx_document_posted_at` (tenant_id, posted_at) [btree]
> INDEX `idx_document_shipping_method` (shipping_method_id) [btree]
> INDEX `idx_document_tenant` (tenant_id) [btree]
> INDEX `idx_document_transaction` (tenant_id, transaction_id) [btree]
> INDEX `idx_document_type_status` (tenant_id, document_type, status) [btree]
> INDEX `idx_document_warehouse` (warehouse_id) [btree]

> CHECK `chk_document_type`: (document_type = ANY (ARRAY['N'::bpchar, 'A'::bpchar, 'L'::bpchar, 'R'::bpchar, 'G'::bpchar, 'b'::bpchar, 'l'::bpchar, 'r'::bpchar, 'g'::bpchar, 'Z'::bpchar, 'E'::bpchar, 'V'::bpchar, 'q'::bpchar, 'p'::bpchar, 'U'::bpchar]))
> CHECK `document_company_id_not_null`: company_id IS NOT NULL
> CHECK `document_created_at_not_null`: created_at IS NOT NULL
> CHECK `document_document_date_not_null`: document_date IS NOT NULL
> CHECK `document_document_direction_not_null`: document_direction IS NOT NULL
> CHECK `document_document_id_not_null`: document_id IS NOT NULL
> CHECK `document_document_no_not_null`: document_no IS NOT NULL
> CHECK `document_document_type_not_null`: document_type IS NOT NULL
> CHECK `document_status_not_null`: status IS NOT NULL
> CHECK `document_tenant_id_not_null`: tenant_id IS NOT NULL
> CHECK `document_transaction_id_not_null`: transaction_id IS NOT NULL
> CHECK `document_version_no_not_null`: version_no IS NOT NULL

### `document_group`

> _⚠ pending annotation_

| Column                     | Business Name              | Type                     | Class | Constraints                         | Description |
| -------------------------- | -------------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| document_group_id          | document_group_id          | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id                  | tenant_id                  | uuid                     | —     | NOT NULL                            |             |
| name                       | name                       | character varying        | —     | NOT NULL                            |             |
| created_at                 | created_at                 | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| number_sequence_id         | number_sequence_id         | uuid                     | —     |                                     |             |
| description                | description                | text                     | —     |                                     |             |
| default_warehouse_id       | default_warehouse_id       | uuid                     | —     |                                     |             |
| default_tax_code_id        | default_tax_code_id        | uuid                     | —     |                                     |             |
| default_sales_account_id   | default_sales_account_id   | uuid                     | —     |                                     |             |
| default_cost_account_id    | default_cost_account_id    | uuid                     | —     |                                     |             |
| is_active                  | is_active                  | boolean                  | —     | DEFAULT true                        |             |
| sort_order                 | sort_order                 | integer                  | —     | DEFAULT 0                           |             |
| updated_at                 | updated_at                 | timestamp with time zone | —     |                                     |             |
| default_payment_term_id    | default_payment_term_id    | uuid                     | —     |                                     |             |
| default_shipping_method_id | default_shipping_method_id | uuid                     | —     |                                     |             |
| require_serial_tracking    | require_serial_tracking    | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| require_batch_tracking     | require_batch_tracking     | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| document_type              | document_type              | varchar(1)               | —     | NOT NULL                            |             |
| group_number               | group_number               | integer                  | —     | NOT NULL                            |             |
| direction                  | direction                  | varchar(20)              | —     |                                     |             |
| next_group_id              | next_group_id              | uuid                     | —     |                                     |             |
| company_id                 | company_id                 | uuid                     | —     |                                     |             |

> UNIQUE(tenant_id, document_group_id)
> UNIQUE(tenant_id, document_group_id)
> UNIQUE(tenant_id, document_type, group_number)

> INDEX UNIQUE `document_group_tenant_id_document_group_id_key` (tenant_id, document_group_id) [btree]
> INDEX UNIQUE `document_group_tenant_id_document_group_id_unique` (tenant_id, document_group_id) [btree]
> INDEX UNIQUE `document_group_tenant_id_document_type_group_number_unique` (tenant_id, document_type, group_number) [btree]
> INDEX `idx_document_group_company` (company_id) [btree]
> INDEX `idx_document_group_tenant` (tenant_id) [btree]

> CHECK `document_group_created_at_not_null`: created_at IS NOT NULL
> CHECK `document_group_document_group_id_not_null`: document_group_id IS NOT NULL
> CHECK `document_group_document_type_not_null`: document_type IS NOT NULL
> CHECK `document_group_group_number_check`: ((group_number >= 0) AND (group_number <= 99))
> CHECK `document_group_group_number_not_null`: group_number IS NOT NULL
> CHECK `document_group_name_not_null`: name IS NOT NULL
> CHECK `document_group_require_batch_tracking_not_null`: require_batch_tracking IS NOT NULL
> CHECK `document_group_require_serial_tracking_not_null`: require_serial_tracking IS NOT NULL
> CHECK `document_group_tenant_id_not_null`: tenant_id IS NOT NULL

### `document_line`

> _⚠ pending annotation_

| Column                | Business Name         | Type                     | Class | Constraints                         | Description |
| --------------------- | --------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| document_line_id      | document_line_id      | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id             | tenant_id             | uuid                     | —     | NOT NULL                            |             |
| document_id           | document_id           | uuid                     | —     | NOT NULL                            |             |
| line_no               | line_no               | integer                  | —     | NOT NULL                            |             |
| article_id            | article_id            | uuid                     | —     |                                     |             |
| article_text_snapshot | article_text_snapshot | character varying        | —     |                                     |             |
| quantity              | quantity              | numeric                  | —     | NOT NULL                            |             |
| unit                  | unit                  | character varying        | —     |                                     |             |
| net_price             | net_price             | numeric                  | —     | NOT NULL                            |             |
| discount_percentage   | discount_percentage   | numeric                  | —     |                                     |             |
| tax_code_id           | tax_code_id           | uuid                     | —     |                                     |             |
| tax_amount            | tax_amount            | numeric                  | —     |                                     |             |
| line_total_net        | line_total_net        | numeric                  | —     |                                     |             |
| warehouse_id          | warehouse_id          | uuid                     | —     |                                     |             |
| cost_center_id        | cost_center_id        | uuid                     | —     |                                     |             |
| created_at            | created_at            | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| transaction_id        | transaction_id        | uuid                     | —     |                                     |             |
| movement_type         | movement_type         | char(1)                  | —     |                                     |             |
| line_type             | line_type             | varchar(20)              | —     | NOT NULL, DEFAULT article           |             |

> UNIQUE(tenant_id, document_id, line_no)
> UNIQUE(tenant_id, document_line_id)
> UNIQUE(tenant_id, document_line_id)

> INDEX UNIQUE `document_line_tenant_id_document_id_line_no_unique` (tenant_id, document_id, line_no) [btree]
> INDEX UNIQUE `document_line_tenant_id_document_line_id_key` (tenant_id, document_line_id) [btree]
> INDEX UNIQUE `document_line_tenant_id_document_line_id_unique` (tenant_id, document_line_id) [btree]
> INDEX `idx_document_line_article` (article_id) [btree]
> INDEX `idx_document_line_document` (document_id) [btree]
> INDEX `idx_document_line_tenant` (tenant_id) [btree]
> INDEX `idx_document_line_tx` (tenant_id, transaction_id) [btree]

> CHECK `chk_article_line_requires_article_id`: (((line_type)::text = 'comment'::text) OR (article_id IS NOT NULL))
> CHECK `chk_document_line_movement_type`: ((movement_type = ANY (ARRAY['N'::bpchar, 'A'::bpchar, 'L'::bpchar, 'R'::bpchar, 'G'::bpchar, 'b'::bpchar, 'l'::bpchar, 'r'::bpchar, 'g'::bpchar, 'Z'::bpchar, 'E'::bpchar, 'V'::bpchar, 'q'::bpchar, 'p'::bpchar, 'U'::bpchar])) OR (movement_type IS NULL))
> CHECK `document_line_created_at_not_null`: created_at IS NOT NULL
> CHECK `document_line_document_id_not_null`: document_id IS NOT NULL
> CHECK `document_line_document_line_id_not_null`: document_line_id IS NOT NULL
> CHECK `document_line_line_no_not_null`: line_no IS NOT NULL
> CHECK `document_line_line_type_check`: ((line_type)::text = ANY ((ARRAY['article'::character varying, 'comment'::character varying, 'production_output'::character varying, 'production_input'::character varying, 'bom_component'::character varying])::text[]))
> CHECK `document_line_line_type_not_null`: line_type IS NOT NULL
> CHECK `document_line_net_price_not_null`: net_price IS NOT NULL
> CHECK `document_line_quantity_not_null`: quantity IS NOT NULL
> CHECK `document_line_tenant_id_not_null`: tenant_id IS NOT NULL

### `document_line_tracking`

> _⚠ pending annotation_

| Column           | Business Name    | Type                     | Class | Constraints                         | Description |
| ---------------- | ---------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| tracking_id      | tracking_id      | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id        | tenant_id        | uuid                     | —     | NOT NULL                            |             |
| document_line_id | document_line_id | uuid                     | —     | NOT NULL                            |             |
| serial_number_id | serial_number_id | uuid                     | —     |                                     |             |
| batch_no         | batch_no         | character varying        | —     |                                     |             |
| qty              | qty              | numeric                  | —     | NOT NULL                            |             |
| created_at       | created_at       | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> CHECK `document_line_tracking_check`: (((serial_number_id IS NOT NULL) AND (batch_no IS NULL)) OR ((serial_number_id IS NULL) AND (batch_no IS NOT NULL)))
> CHECK `document_line_tracking_created_at_not_null`: created_at IS NOT NULL
> CHECK `document_line_tracking_document_line_id_not_null`: document_line_id IS NOT NULL
> CHECK `document_line_tracking_qty_not_null`: qty IS NOT NULL
> CHECK `document_line_tracking_tenant_id_not_null`: tenant_id IS NOT NULL
> CHECK `document_line_tracking_tracking_id_not_null`: tracking_id IS NOT NULL

### `document_type`

> _⚠ pending annotation_

| Column                | Business Name         | Type                     | Class | Constraints                         | Description |
| --------------------- | --------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| document_type_id      | document_type_id      | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id             | tenant_id             | uuid                     | —     | NOT NULL                            |             |
| code                  | code                  | varchar(20)              | —     | NOT NULL                            |             |
| name                  | name                  | varchar(100)             | —     | NOT NULL                            |             |
| movement_type         | movement_type         | char(1)                  | —     | NOT NULL                            |             |
| next_document_type_id | next_document_type_id | uuid                     | —     |                                     |             |
| requires_warehouse    | requires_warehouse    | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| requires_cost_center  | requires_cost_center  | boolean                  | —     | NOT NULL, DEFAULT false             |             |
| is_active             | is_active             | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| sort_order            | sort_order            | integer                  | —     | NOT NULL, DEFAULT 0                 |             |
| created_at            | created_at            | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| updated_at            | updated_at            | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(tenant_id, code)
> UNIQUE(tenant_id, document_type_id)
> UNIQUE(tenant_id, document_type_id)

> INDEX UNIQUE `document_type_tenant_id_code_unique` (tenant_id, code) [btree]
> INDEX UNIQUE `document_type_tenant_id_document_type_id_key` (tenant_id, document_type_id) [btree]
> INDEX UNIQUE `document_type_tenant_id_document_type_id_unique` (tenant_id, document_type_id) [btree]
> INDEX `idx_document_type_tenant` (tenant_id) [btree]

> CHECK `document_type_code_not_null`: code IS NOT NULL
> CHECK `document_type_created_at_not_null`: created_at IS NOT NULL
> CHECK `document_type_document_type_id_not_null`: document_type_id IS NOT NULL
> CHECK `document_type_is_active_not_null`: is_active IS NOT NULL
> CHECK `document_type_movement_type_check`: (movement_type = ANY (ARRAY['N'::bpchar, 'A'::bpchar, 'L'::bpchar, 'R'::bpchar, 'G'::bpchar, 'b'::bpchar, 'l'::bpchar, 'r'::bpchar, 'g'::bpchar, 'Z'::bpchar, 'E'::bpchar, 'V'::bpchar, 'q'::bpchar, 'p'::bpchar, 'U'::bpchar]))
> CHECK `document_type_movement_type_not_null`: movement_type IS NOT NULL
> CHECK `document_type_name_not_null`: name IS NOT NULL
> CHECK `document_type_requires_cost_center_not_null`: requires_cost_center IS NOT NULL
> CHECK `document_type_requires_warehouse_not_null`: requires_warehouse IS NOT NULL
> CHECK `document_type_sort_order_not_null`: sort_order IS NOT NULL
> CHECK `document_type_tenant_id_not_null`: tenant_id IS NOT NULL
> CHECK `document_type_updated_at_not_null`: updated_at IS NOT NULL

### `entity_commands`

> _⚠ pending annotation_

| Column           | Business Name    | Type                     | Class | Constraints                         | Description |
| ---------------- | ---------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| command_id       | command_id       | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| scope            | scope            | character varying        | —     | NOT NULL, DEFAULT global            |             |
| organization_id  | organization_id  | uuid                     | —     |                                     |             |
| tenant_id        | tenant_id        | uuid                     | —     |                                     |             |
| entity_name      | entity_name      | character varying        | —     | NOT NULL                            |             |
| command_key      | command_key      | character varying        | —     | NOT NULL                            |             |
| handlerkey       | handlerkey       | character varying        | —     |                                     |             |
| label            | label            | jsonb                    | —     | NOT NULL                            |             |
| description      | description      | jsonb                    | —     |                                     |             |
| http_method      | http_method      | character varying        | —     | NOT NULL, DEFAULT POST              |             |
| route_pattern    | route_pattern    | character varying        | —     | NOT NULL                            |             |
| entity_id_param  | entity_id_param  | character varying        | —     |                                     |             |
| parent_entity    | parent_entity    | character varying        | —     |                                     |             |
| parent_id_source | parent_id_source | character varying        | —     |                                     |             |
| input_schema     | input_schema     | jsonb                    | —     | NOT NULL, DEFAULT {}                |             |
| server_managed   | server_managed   | jsonb                    | —     | NOT NULL, DEFAULT []                |             |
| ui_placement     | ui_placement     | character varying        | —     |                                     |             |
| ui_icon          | ui_icon          | character varying        | —     |                                     |             |
| ui_shortcut      | ui_shortcut      | character varying        | —     |                                     |             |
| ui_confirm       | ui_confirm       | jsonb                    | —     |                                     |             |
| writes_tables    | writes_tables    | jsonb                    | —     | NOT NULL, DEFAULT []                |             |
| side_effects     | side_effects     | jsonb                    | —     | NOT NULL, DEFAULT []                |             |
| min_role         | min_role         | character varying        | —     | NOT NULL, DEFAULT tenant_user       |             |
| visibility       | visibility       | character varying        | —     | NOT NULL, DEFAULT tenant            |             |
| command_state    | command_state    | character varying        | —     | NOT NULL, DEFAULT published         |             |
| sort_order       | sort_order       | integer                  | —     | NOT NULL, DEFAULT 0                 |             |
| created_at       | created_at       | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(scope, organization_id, tenant_id, entity_name, command_key)

> INDEX UNIQUE `entity_commands_scope_organization_id_tenant_id_entity_name_com` (scope, organization_id, tenant_id, entity_name, command_key) [btree]
> INDEX `idx_entity_commands_entity` (entity_name, command_state) [btree]
> INDEX `idx_entity_commands_org` (organization_id) [btree]
> INDEX `idx_entity_commands_tenant` (tenant_id) [btree]

> CHECK `entity_commands_command_id_not_null`: command_id IS NOT NULL
> CHECK `entity_commands_command_key_not_null`: command_key IS NOT NULL
> CHECK `entity_commands_command_state_not_null`: command_state IS NOT NULL
> CHECK `entity_commands_created_at_not_null`: created_at IS NOT NULL
> CHECK `entity_commands_entity_name_not_null`: entity_name IS NOT NULL
> CHECK `entity_commands_http_method_not_null`: http_method IS NOT NULL
> CHECK `entity_commands_input_schema_not_null`: input_schema IS NOT NULL
> CHECK `entity_commands_label_not_null`: label IS NOT NULL
> CHECK `entity_commands_min_role_not_null`: min_role IS NOT NULL
> CHECK `entity_commands_route_pattern_not_null`: route_pattern IS NOT NULL
> CHECK `entity_commands_scope_not_null`: scope IS NOT NULL
> CHECK `entity_commands_server_managed_not_null`: server_managed IS NOT NULL
> CHECK `entity_commands_side_effects_not_null`: side_effects IS NOT NULL
> CHECK `entity_commands_sort_order_not_null`: sort_order IS NOT NULL
> CHECK `entity_commands_visibility_not_null`: visibility IS NOT NULL
> CHECK `entity_commands_writes_tables_not_null`: writes_tables IS NOT NULL

### `fact_sales_event`

> _⚠ pending annotation_

| Column                  | Business Name           | Type                     | Class | Constraints                         | Description |
| ----------------------- | ----------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| fact_sales_event_id     | fact_sales_event_id     | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id               | tenant_id               | uuid                     | —     | NOT NULL                            |             |
| company_id              | company_id              | uuid                     | —     |                                     |             |
| source_document_id      | source_document_id      | uuid                     | —     |                                     |             |
| source_document_line_id | source_document_line_id | uuid                     | —     |                                     |             |
| customer_id             | customer_id             | uuid                     | —     |                                     |             |
| article_id              | article_id              | uuid                     | —     |                                     |             |
| event_type              | event_type              | character varying        | —     |                                     |             |
| quantity_delta          | quantity_delta          | numeric                  | —     | NOT NULL                            |             |
| amount_net_delta        | amount_net_delta        | numeric                  | —     | NOT NULL                            |             |
| booking_period          | booking_period          | date                     | —     | NOT NULL                            |             |
| created_at              | created_at              | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| transaction_id          | transaction_id          | uuid                     | —     |                                     |             |

> INDEX `idx_fact_sales_article` (tenant_id, article_id) [btree]
> INDEX `idx_fact_sales_customer` (tenant_id, customer_id) [btree]
> INDEX `idx_fact_sales_period` (tenant_id, booking_period) [btree]
> INDEX `idx_fact_sales_tenant` (tenant_id) [btree]
> INDEX `idx_fact_sales_tx` (tenant_id, transaction_id) [btree]

> CHECK `fact_sales_event_amount_net_delta_not_null`: amount_net_delta IS NOT NULL
> CHECK `fact_sales_event_booking_period_not_null`: booking_period IS NOT NULL
> CHECK `fact_sales_event_created_at_not_null`: created_at IS NOT NULL
> CHECK `fact_sales_event_fact_sales_event_id_not_null`: fact_sales_event_id IS NOT NULL
> CHECK `fact_sales_event_quantity_delta_not_null`: quantity_delta IS NOT NULL
> CHECK `fact_sales_event_tenant_id_not_null`: tenant_id IS NOT NULL

### `gl_account`

> _⚠ pending annotation_

| Column        | Business Name | Type                     | Class | Constraints                         | Description |
| ------------- | ------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| gl_account_id | gl_account_id | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id     | tenant_id     | uuid                     | —     | NOT NULL                            |             |
| company_id    | company_id    | uuid                     | —     |                                     |             |
| account_no    | account_no    | character varying        | —     | NOT NULL                            |             |
| name          | name          | character varying        | —     | NOT NULL                            |             |
| account_type  | account_type  | character varying        | —     | NOT NULL                            |             |
| is_active     | is_active     | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at    | created_at    | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(tenant_id, account_no)
> UNIQUE(tenant_id, gl_account_id)

> INDEX UNIQUE `gl_account_tenant_id_account_no_unique` (tenant_id, account_no) [btree]
> INDEX UNIQUE `gl_account_tenant_id_gl_account_id_key` (tenant_id, gl_account_id) [btree]
> INDEX `idx_gl_account_tenant` (tenant_id) [btree]

> CHECK `gl_account_account_no_not_null`: account_no IS NOT NULL
> CHECK `gl_account_account_type_not_null`: account_type IS NOT NULL
> CHECK `gl_account_created_at_not_null`: created_at IS NOT NULL
> CHECK `gl_account_gl_account_id_not_null`: gl_account_id IS NOT NULL
> CHECK `gl_account_is_active_not_null`: is_active IS NOT NULL
> CHECK `gl_account_name_not_null`: name IS NOT NULL
> CHECK `gl_account_tenant_id_not_null`: tenant_id IS NOT NULL

### `helper_table_registry`

> _⚠ pending annotation_

| Column           | Business Name    | Type                     | Class | Constraints             | Description |
| ---------------- | ---------------- | ------------------------ | ----- | ----------------------- | ----------- |
| table_name       | table_name       | character varying        | PK    | NOT NULL                |             |
| label            | label            | jsonb                    | —     | NOT NULL                |             |
| pk_column        | pk_column        | character varying        | —     | NOT NULL                |             |
| display_column   | display_column   | character varying        | —     | NOT NULL                |             |
| display_is_i18n  | display_is_i18n  | boolean                  | —     | NOT NULL, DEFAULT false |             |
| code_column      | code_column      | character varying        | —     |                         |             |
| is_tenant_scoped | is_tenant_scoped | boolean                  | —     | NOT NULL, DEFAULT false |             |
| default_filter   | default_filter   | jsonb                    | —     |                         |             |
| sort_column      | sort_column      | character varying        | —     | NOT NULL                |             |
| created_at       | created_at       | timestamp with time zone | —     | NOT NULL, DEFAULT now() |             |
| value_column     | value_column     | character varying        | —     |                         |             |

> CHECK `helper_table_registry_created_at_not_null`: created_at IS NOT NULL
> CHECK `helper_table_registry_display_column_not_null`: display_column IS NOT NULL
> CHECK `helper_table_registry_display_is_i18n_not_null`: display_is_i18n IS NOT NULL
> CHECK `helper_table_registry_is_tenant_scoped_not_null`: is_tenant_scoped IS NOT NULL
> CHECK `helper_table_registry_label_not_null`: label IS NOT NULL
> CHECK `helper_table_registry_pk_column_not_null`: pk_column IS NOT NULL
> CHECK `helper_table_registry_sort_column_not_null`: sort_column IS NOT NULL
> CHECK `helper_table_registry_table_name_not_null`: table_name IS NOT NULL

### `import_batch`

> _⚠ pending annotation_

| Column              | Business Name       | Type                     | Class | Constraints                         | Description |
| ------------------- | ------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| batch_id            | batch_id            | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id           | tenant_id           | uuid                     | —     | NOT NULL                            |             |
| connector_id        | connector_id        | uuid                     | —     |                                     |             |
| atomicity_mode      | atomicity_mode      | character varying        | —     | NOT NULL                            |             |
| status              | status              | character varying        | —     | NOT NULL, DEFAULT pending           |             |
| is_rerun            | is_rerun            | boolean                  | —     | NOT NULL, DEFAULT false             |             |
| source_batch_id     | source_batch_id     | uuid                     | —     |                                     |             |
| posted_entity_count | posted_entity_count | integer                  | —     | NOT NULL, DEFAULT 0                 |             |
| error_summary       | error_summary       | jsonb                    | —     |                                     |             |
| created_at          | created_at          | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| processed_at        | processed_at        | timestamp with time zone | —     |                                     |             |
| target_entity       | target_entity       | character varying        | —     |                                     |             |
| target_command_key  | target_command_key  | character varying        | —     |                                     |             |

> CHECK `import_batch_atomicity_mode_check`: ((atomicity_mode)::text = ANY ((ARRAY['file'::character varying, 'entity'::character varying, 'run'::character varying])::text[]))
> CHECK `import_batch_atomicity_mode_not_null`: atomicity_mode IS NOT NULL
> CHECK `import_batch_batch_id_not_null`: batch_id IS NOT NULL
> CHECK `import_batch_created_at_not_null`: created_at IS NOT NULL
> CHECK `import_batch_is_rerun_not_null`: is_rerun IS NOT NULL
> CHECK `import_batch_posted_entity_count_not_null`: posted_entity_count IS NOT NULL
> CHECK `import_batch_status_check`: ((status)::text = ANY ((ARRAY['pending'::character varying, 'validating'::character varying, 'approved'::character varying, 'posted'::character varying, 'failed'::character varying, 'rejected'::character varying])::text[]))
> CHECK `import_batch_status_not_null`: status IS NOT NULL
> CHECK `import_batch_tenant_id_not_null`: tenant_id IS NOT NULL

### `import_row`

> _⚠ pending annotation_

| Column        | Business Name | Type                     | Class | Constraints                         | Description |
| ------------- | ------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| row_id        | row_id        | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id     | tenant_id     | uuid                     | —     | NOT NULL                            |             |
| batch_id      | batch_id      | uuid                     | —     | NOT NULL                            |             |
| target_entity | target_entity | character varying        | —     | NOT NULL                            |             |
| payload       | payload       | jsonb                    | —     | NOT NULL                            |             |
| status        | status        | character varying        | —     | NOT NULL, DEFAULT pending           |             |
| error_detail  | error_detail  | jsonb                    | —     |                                     |             |
| posted_at     | posted_at     | timestamp with time zone | —     |                                     |             |

> CHECK `import_row_batch_id_not_null`: batch_id IS NOT NULL
> CHECK `import_row_payload_not_null`: payload IS NOT NULL
> CHECK `import_row_row_id_not_null`: row_id IS NOT NULL
> CHECK `import_row_status_check`: ((status)::text = ANY ((ARRAY['pending'::character varying, 'posted'::character varying, 'failed'::character varying])::text[]))
> CHECK `import_row_status_not_null`: status IS NOT NULL
> CHECK `import_row_target_entity_not_null`: target_entity IS NOT NULL
> CHECK `import_row_tenant_id_not_null`: tenant_id IS NOT NULL

### `incoterm`

> _⚠ pending annotation_

| Column      | Business Name | Type                     | Class | Constraints                         | Description |
| ----------- | ------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| incoterm_id | incoterm_id   | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| code        | code          | char(3)                  | —     | NOT NULL                            |             |
| name        | name          | character varying        | —     | NOT NULL                            |             |
| created_at  | created_at    | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(code)

> INDEX UNIQUE `incoterm_code_key` (code) [btree]

> CHECK `incoterm_code_not_null`: code IS NOT NULL
> CHECK `incoterm_created_at_not_null`: created_at IS NOT NULL
> CHECK `incoterm_incoterm_id_not_null`: incoterm_id IS NOT NULL
> CHECK `incoterm_name_not_null`: name IS NOT NULL

### `industry`

> _⚠ pending annotation_

| Column            | Business Name     | Type                     | Class | Constraints                         | Description |
| ----------------- | ----------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| industry_id       | industry_id       | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id         | tenant_id         | uuid                     | —     | NOT NULL                            |             |
| name              | name              | jsonb                    | —     | NOT NULL                            |             |
| is_active         | is_active         | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at        | created_at        | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| custom_attributes | custom_attributes | jsonb                    | —     |                                     |             |

> UNIQUE(tenant_id, name)

> INDEX `idx_industry_tenant` (tenant_id) [btree]
> INDEX UNIQUE `industry_tenant_id_name_unique` (tenant_id, name) [btree]

> CHECK `industry_created_at_not_null`: created_at IS NOT NULL
> CHECK `industry_industry_id_not_null`: industry_id IS NOT NULL
> CHECK `industry_is_active_not_null`: is_active IS NOT NULL
> CHECK `industry_name_not_null`: name IS NOT NULL
> CHECK `industry_tenant_id_not_null`: tenant_id IS NOT NULL

### `inventory_balance`

> _⚠ pending annotation_

| Column                | Business Name         | Type                     | Class | Constraints                         | Description |
| --------------------- | --------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| inventory_balance_id  | inventory_balance_id  | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id             | tenant_id             | uuid                     | —     | NOT NULL                            |             |
| company_id            | company_id            | uuid                     | —     |                                     |             |
| warehouse_id          | warehouse_id          | uuid                     | —     | NOT NULL                            |             |
| article_id            | article_id            | uuid                     | —     | NOT NULL                            |             |
| on_hand_qty           | on_hand_qty           | numeric                  | —     | NOT NULL, DEFAULT 0                 |             |
| reserved_qty          | reserved_qty          | numeric                  | —     | NOT NULL, DEFAULT 0                 |             |
| as_of_at              | as_of_at              | timestamp with time zone | —     |                                     |             |
| created_at            | created_at            | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| available_qty         | available_qty         | numeric                  | —     |                                     |             |
| expected_purchase_qty | expected_purchase_qty | numeric                  | —     | NOT NULL, DEFAULT 0                 |             |
| gld_purchase          | gld_purchase          | numeric                  | —     |                                     |             |
| gld_cost              | gld_cost              | numeric                  | —     |                                     |             |

> UNIQUE(tenant_id, warehouse_id, article_id)

> INDEX `idx_inv_balance_lookup` (tenant_id, warehouse_id, article_id) [btree]
> INDEX `idx_inv_balance_tenant` (tenant_id) [btree]
> INDEX UNIQUE `inventory_balance_tenant_id_warehouse_id_article_id_unique` (tenant_id, warehouse_id, article_id) [btree]

> CHECK `inventory_balance_article_id_not_null`: article_id IS NOT NULL
> CHECK `inventory_balance_created_at_not_null`: created_at IS NOT NULL
> CHECK `inventory_balance_expected_purchase_qty_not_null`: expected_purchase_qty IS NOT NULL
> CHECK `inventory_balance_inventory_balance_id_not_null`: inventory_balance_id IS NOT NULL
> CHECK `inventory_balance_on_hand_qty_not_null`: on_hand_qty IS NOT NULL
> CHECK `inventory_balance_reserved_qty_not_null`: reserved_qty IS NOT NULL
> CHECK `inventory_balance_tenant_id_not_null`: tenant_id IS NOT NULL
> CHECK `inventory_balance_warehouse_id_not_null`: warehouse_id IS NOT NULL

### `inventory_movement`

> _⚠ pending annotation_

| Column                  | Business Name           | Type                     | Class | Constraints                         | Description |
| ----------------------- | ----------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| inventory_movement_id   | inventory_movement_id   | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id               | tenant_id               | uuid                     | —     | NOT NULL                            |             |
| company_id              | company_id              | uuid                     | —     |                                     |             |
| warehouse_id            | warehouse_id            | uuid                     | —     | NOT NULL                            |             |
| article_id              | article_id              | uuid                     | —     | NOT NULL                            |             |
| movement_type           | movement_type           | char(1)                  | —     | NOT NULL                            |             |
| qty_delta               | qty_delta               | numeric                  | —     |                                     |             |
| movement_date           | movement_date           | timestamp with time zone | —     | NOT NULL                            |             |
| source_document_id      | source_document_id      | uuid                     | —     |                                     |             |
| source_document_line_id | source_document_line_id | uuid                     | —     |                                     |             |
| created_at              | created_at              | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| transaction_id          | transaction_id          | uuid                     | —     |                                     |             |
| absolute_qty            | absolute_qty            | numeric                  | —     |                                     |             |
| reference_text          | reference_text          | character varying        | —     |                                     |             |
| serial_number_id        | serial_number_id        | uuid                     | —     |                                     |             |
| batch_no                | batch_no                | character varying        | —     |                                     |             |

> INDEX `idx_inv_movement_date` (tenant_id, movement_date) [btree]
> INDEX `idx_inv_movement_inventory_anchor` (tenant_id, warehouse_id, article_id, movement_date) [btree]
> INDEX `idx_inv_movement_lookup` (tenant_id, warehouse_id, article_id, movement_date) [btree]
> INDEX `idx_inv_movement_tenant` (tenant_id) [btree]
> INDEX `idx_inv_movement_tx` (tenant_id, transaction_id) [btree]
> INDEX `idx_inv_movement_warehouse_article` (tenant_id, warehouse_id, article_id) [btree]
> INDEX `idx_inventory_movement_batch_balance` (tenant_id, warehouse_id, article_id, batch_no) [btree]

> CHECK `chk_inventory_movement_qty_logic`: (((movement_type = 'V'::bpchar) AND (absolute_qty IS NOT NULL)) OR ((movement_type <> 'V'::bpchar) AND (qty_delta IS NOT NULL) AND (absolute_qty IS NULL)))
> CHECK `chk_inventory_movement_type`: (movement_type = ANY (ARRAY['N'::bpchar, 'A'::bpchar, 'L'::bpchar, 'R'::bpchar, 'G'::bpchar, 'b'::bpchar, 'l'::bpchar, 'r'::bpchar, 'g'::bpchar, 'Z'::bpchar, 'E'::bpchar, 'V'::bpchar, 'q'::bpchar, 'p'::bpchar, 'U'::bpchar]))
> CHECK `inventory_movement_article_id_not_null`: article_id IS NOT NULL
> CHECK `inventory_movement_created_at_not_null`: created_at IS NOT NULL
> CHECK `inventory_movement_inventory_movement_id_not_null`: inventory_movement_id IS NOT NULL
> CHECK `inventory_movement_movement_date_not_null`: movement_date IS NOT NULL
> CHECK `inventory_movement_movement_type_not_null`: movement_type IS NOT NULL
> CHECK `inventory_movement_tenant_id_not_null`: tenant_id IS NOT NULL
> CHECK `inventory_movement_warehouse_id_not_null`: warehouse_id IS NOT NULL

### `journal_entry`

> _⚠ pending annotation_

| Column             | Business Name      | Type                     | Class | Constraints                         | Description |
| ------------------ | ------------------ | ------------------------ | ----- | ----------------------------------- | ----------- |
| journal_entry_id   | journal_entry_id   | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id          | tenant_id          | uuid                     | —     | NOT NULL                            |             |
| company_id         | company_id         | uuid                     | —     | NOT NULL                            |             |
| posting_date       | posting_date       | date                     | —     | NOT NULL                            |             |
| source_document_id | source_document_id | uuid                     | —     |                                     |             |
| description        | description        | character varying        | —     |                                     |             |
| created_at         | created_at         | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(tenant_id, journal_entry_id)

> INDEX `idx_journal_entry_company` (tenant_id, company_id) [btree]
> INDEX `idx_journal_entry_date` (tenant_id, posting_date) [btree]
> INDEX `idx_journal_entry_document` (source_document_id) [btree]
> INDEX `idx_journal_entry_tenant` (tenant_id) [btree]
> INDEX UNIQUE `journal_entry_tenant_id_journal_entry_id_key` (tenant_id, journal_entry_id) [btree]

> CHECK `journal_entry_company_id_not_null`: company_id IS NOT NULL
> CHECK `journal_entry_created_at_not_null`: created_at IS NOT NULL
> CHECK `journal_entry_journal_entry_id_not_null`: journal_entry_id IS NOT NULL
> CHECK `journal_entry_posting_date_not_null`: posting_date IS NOT NULL
> CHECK `journal_entry_tenant_id_not_null`: tenant_id IS NOT NULL

### `journal_line`

> _⚠ pending annotation_

| Column           | Business Name    | Type                     | Class | Constraints                         | Description |
| ---------------- | ---------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| journal_line_id  | journal_line_id  | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id        | tenant_id        | uuid                     | —     | NOT NULL                            |             |
| company_id       | company_id       | uuid                     | —     | NOT NULL                            |             |
| journal_entry_id | journal_entry_id | uuid                     | —     | NOT NULL                            |             |
| gl_account_id    | gl_account_id    | uuid                     | —     | NOT NULL                            |             |
| debit_amount     | debit_amount     | numeric                  | —     | NOT NULL, DEFAULT 0                 |             |
| credit_amount    | credit_amount    | numeric                  | —     | NOT NULL, DEFAULT 0                 |             |
| created_at       | created_at       | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> INDEX `idx_journal_line_account` (gl_account_id) [btree]
> INDEX `idx_journal_line_entry` (journal_entry_id) [btree]
> INDEX `idx_journal_line_tenant` (tenant_id) [btree]

> CHECK `chk_debit_or_credit`: (((debit_amount > (0)::numeric) AND (credit_amount = (0)::numeric)) OR ((credit_amount > (0)::numeric) AND (debit_amount = (0)::numeric)))
> CHECK `journal_line_company_id_not_null`: company_id IS NOT NULL
> CHECK `journal_line_created_at_not_null`: created_at IS NOT NULL
> CHECK `journal_line_credit_amount_not_null`: credit_amount IS NOT NULL
> CHECK `journal_line_debit_amount_not_null`: debit_amount IS NOT NULL
> CHECK `journal_line_gl_account_id_not_null`: gl_account_id IS NOT NULL
> CHECK `journal_line_journal_entry_id_not_null`: journal_entry_id IS NOT NULL
> CHECK `journal_line_journal_line_id_not_null`: journal_line_id IS NOT NULL
> CHECK `journal_line_tenant_id_not_null`: tenant_id IS NOT NULL

### `modules`

> _⚠ pending annotation_

| Column    | Business Name | Type              | Class | Constraints                         | Description |
| --------- | ------------- | ----------------- | ----- | ----------------------------------- | ----------- |
| module_id | module_id     | uuid              | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| slug      | slug          | character varying | —     | NOT NULL                            |             |
| label     | label         | jsonb             | —     | NOT NULL                            |             |

> UNIQUE(slug)

> INDEX UNIQUE `modules_slug_key` (slug) [btree]

> CHECK `modules_label_not_null`: label IS NOT NULL
> CHECK `modules_module_id_not_null`: module_id IS NOT NULL
> CHECK `modules_slug_not_null`: slug IS NOT NULL

### `number_sequence`

> _⚠ pending annotation_

| Column             | Business Name      | Type                     | Class | Constraints                         | Description |
| ------------------ | ------------------ | ------------------------ | ----- | ----------------------------------- | ----------- |
| number_sequence_id | number_sequence_id | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id          | tenant_id          | uuid                     | —     | NOT NULL                            |             |
| company_id         | company_id         | uuid                     | —     | NOT NULL                            |             |
| prefix             | prefix             | varchar(10)              | —     | NOT NULL                            |             |
| next_value         | next_value         | integer                  | —     | NOT NULL, DEFAULT 1                 |             |
| padding            | padding            | integer                  | —     | NOT NULL, DEFAULT 5                 |             |
| created_at         | created_at         | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| updated_at         | updated_at         | timestamp with time zone | —     |                                     |             |

> UNIQUE(tenant_id, company_id, prefix)
> UNIQUE(tenant_id, number_sequence_id)

> INDEX `idx_number_sequence_tenant` (tenant_id) [btree]
> INDEX `idx_number_sequence_tenant_company` (tenant_id, company_id) [btree]
> INDEX UNIQUE `number_sequence_tenant_id_company_id_prefix_unique` (tenant_id, company_id, prefix) [btree]
> INDEX UNIQUE `number_sequence_tenant_id_number_sequence_id_unique` (tenant_id, number_sequence_id) [btree]

> CHECK `number_sequence_company_id_not_null`: company_id IS NOT NULL
> CHECK `number_sequence_created_at_not_null`: created_at IS NOT NULL
> CHECK `number_sequence_next_value_not_null`: next_value IS NOT NULL
> CHECK `number_sequence_number_sequence_id_not_null`: number_sequence_id IS NOT NULL
> CHECK `number_sequence_padding_not_null`: padding IS NOT NULL
> CHECK `number_sequence_prefix_not_null`: prefix IS NOT NULL
> CHECK `number_sequence_tenant_id_not_null`: tenant_id IS NOT NULL

### `organization`

> _⚠ pending annotation_

| Column          | Business Name   | Type                     | Class | Constraints                         | Description |
| --------------- | --------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| organization_id | organization_id | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| slug            | slug            | varchar(63)              | —     | NOT NULL                            |             |
| name            | name            | character varying        | —     | NOT NULL                            |             |
| is_active       | is_active       | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at      | created_at      | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(slug)

> INDEX UNIQUE `organization_slug_key` (slug) [btree]

> CHECK `organization_created_at_not_null`: created_at IS NOT NULL
> CHECK `organization_is_active_not_null`: is_active IS NOT NULL
> CHECK `organization_name_not_null`: name IS NOT NULL
> CHECK `organization_organization_id_not_null`: organization_id IS NOT NULL
> CHECK `organization_slug_not_null`: slug IS NOT NULL

### `payment_term`

> _⚠ pending annotation_

| Column              | Business Name       | Type                     | Class | Constraints                         | Description |
| ------------------- | ------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| payment_term_id     | payment_term_id     | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id           | tenant_id           | uuid                     | —     | NOT NULL                            |             |
| name                | name                | jsonb                    | —     | NOT NULL                            |             |
| net_days            | net_days            | integer                  | —     | NOT NULL                            |             |
| discount_days       | discount_days       | integer                  | —     |                                     |             |
| discount_percentage | discount_percentage | numeric                  | —     |                                     |             |
| is_active           | is_active           | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at          | created_at          | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| custom_attributes   | custom_attributes   | jsonb                    | —     |                                     |             |

> UNIQUE(tenant_id, name)
> UNIQUE(tenant_id, payment_term_id)

> INDEX `idx_payment_term_tenant` (tenant_id) [btree]
> INDEX UNIQUE `payment_term_tenant_id_name_unique` (tenant_id, name) [btree]
> INDEX UNIQUE `payment_term_tenant_id_payment_term_id_key` (tenant_id, payment_term_id) [btree]

> CHECK `payment_term_created_at_not_null`: created_at IS NOT NULL
> CHECK `payment_term_is_active_not_null`: is_active IS NOT NULL
> CHECK `payment_term_name_not_null`: name IS NOT NULL
> CHECK `payment_term_net_days_not_null`: net_days IS NOT NULL
> CHECK `payment_term_payment_term_id_not_null`: payment_term_id IS NOT NULL
> CHECK `payment_term_tenant_id_not_null`: tenant_id IS NOT NULL

### `postal_code`

> _⚠ pending annotation_

| Column         | Business Name  | Type                     | Class | Constraints                         | Description |
| -------------- | -------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| postal_code_id | postal_code_id | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| country_code   | country_code   | varchar(2)               | —     | NOT NULL                            |             |
| plz            | plz            | character varying        | —     | NOT NULL                            |             |
| city           | city           | character varying        | —     | NOT NULL                            |             |
| state          | state          | character varying        | —     |                                     |             |
| created_at     | created_at     | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(country_code, plz, city, state)

> INDEX `idx_postal_code_lookup` (country_code, plz) [btree]
> INDEX UNIQUE `postal_code_country_code_plz_city_state_unique` (country_code, plz, city, state) [btree]

> CHECK `postal_code_city_not_null`: city IS NOT NULL
> CHECK `postal_code_country_code_not_null`: country_code IS NOT NULL
> CHECK `postal_code_created_at_not_null`: created_at IS NOT NULL
> CHECK `postal_code_plz_not_null`: plz IS NOT NULL
> CHECK `postal_code_postal_code_id_not_null`: postal_code_id IS NOT NULL

### `price_list`

> _⚠ pending annotation_

| Column        | Business Name | Type                     | Class | Constraints                         | Description |
| ------------- | ------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| price_list_id | price_list_id | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id     | tenant_id     | uuid                     | —     | NOT NULL                            |             |
| name          | name          | character varying        | —     | NOT NULL                            |             |
| currency_id   | currency_id   | char(3)                  | —     | NOT NULL                            |             |
| is_net        | is_net        | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| is_active     | is_active     | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at    | created_at    | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(tenant_id, name)
> UNIQUE(tenant_id, price_list_id)

> INDEX `idx_price_list_tenant` (tenant_id) [btree]
> INDEX UNIQUE `price_list_tenant_id_name_unique` (tenant_id, name) [btree]
> INDEX UNIQUE `price_list_tenant_id_price_list_id_key` (tenant_id, price_list_id) [btree]

> CHECK `price_list_created_at_not_null`: created_at IS NOT NULL
> CHECK `price_list_currency_id_not_null`: currency_id IS NOT NULL
> CHECK `price_list_is_active_not_null`: is_active IS NOT NULL
> CHECK `price_list_is_net_not_null`: is_net IS NOT NULL
> CHECK `price_list_name_not_null`: name IS NOT NULL
> CHECK `price_list_price_list_id_not_null`: price_list_id IS NOT NULL
> CHECK `price_list_tenant_id_not_null`: tenant_id IS NOT NULL

### `price_list_item`

> _⚠ pending annotation_

| Column             | Business Name      | Type                     | Class | Constraints                         | Description |
| ------------------ | ------------------ | ------------------------ | ----- | ----------------------------------- | ----------- |
| price_list_item_id | price_list_item_id | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id          | tenant_id          | uuid                     | —     | NOT NULL                            |             |
| price_list_id      | price_list_id      | uuid                     | —     | NOT NULL                            |             |
| article_id         | article_id         | uuid                     | —     | NOT NULL                            |             |
| price              | price              | numeric                  | —     | NOT NULL                            |             |
| valid_from         | valid_from         | date                     | —     |                                     |             |
| valid_to           | valid_to           | date                     | —     |                                     |             |
| created_at         | created_at         | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(tenant_id, price_list_id, article_id, valid_from)

> INDEX `idx_price_list_item_lookup` (price_list_id, article_id, valid_from) [btree]
> INDEX `idx_price_list_item_tenant` (tenant_id) [btree]
> INDEX UNIQUE `price_list_item_tenant_id_price_list_id_article_id_valid_from_u` (tenant_id, price_list_id, article_id, valid_from) [btree]

> CHECK `price_list_item_article_id_not_null`: article_id IS NOT NULL
> CHECK `price_list_item_created_at_not_null`: created_at IS NOT NULL
> CHECK `price_list_item_price_list_id_not_null`: price_list_id IS NOT NULL
> CHECK `price_list_item_price_list_item_id_not_null`: price_list_item_id IS NOT NULL
> CHECK `price_list_item_price_not_null`: price IS NOT NULL
> CHECK `price_list_item_tenant_id_not_null`: tenant_id IS NOT NULL

### `production_order`

> _⚠ pending annotation_

| Column              | Business Name       | Type                     | Class | Constraints                         | Description |
| ------------------- | ------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| production_order_id | production_order_id | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id           | tenant_id           | uuid                     | —     | NOT NULL                            |             |
| company_id          | company_id          | uuid                     | —     |                                     |             |
| order_no            | order_no            | varchar(50)              | —     | NOT NULL                            |             |
| article_id          | article_id          | uuid                     | —     |                                     |             |
| quantity            | quantity            | integer                  | —     | NOT NULL, DEFAULT 0                 |             |
| status              | status              | varchar(20)              | —     | NOT NULL, DEFAULT planned           |             |
| planned_start_date  | planned_start_date  | date                     | —     |                                     |             |
| planned_end_date    | planned_end_date    | date                     | —     |                                     |             |
| actual_start_date   | actual_start_date   | date                     | —     |                                     |             |
| actual_end_date     | actual_end_date     | date                     | —     |                                     |             |
| is_active           | is_active           | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at          | created_at          | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| updated_at          | updated_at          | timestamp with time zone | —     |                                     |             |

> UNIQUE(tenant_id, order_no)

> INDEX `idx_production_order_article` (article_id) [btree]
> INDEX `idx_production_order_status` (status) [btree]
> INDEX `idx_production_order_tenant` (tenant_id) [btree]
> INDEX UNIQUE `production_order_tenant_id_order_no_unique` (tenant_id, order_no) [btree]

> CHECK `production_order_created_at_not_null`: created_at IS NOT NULL
> CHECK `production_order_is_active_not_null`: is_active IS NOT NULL
> CHECK `production_order_order_no_not_null`: order_no IS NOT NULL
> CHECK `production_order_production_order_id_not_null`: production_order_id IS NOT NULL
> CHECK `production_order_quantity_not_null`: quantity IS NOT NULL
> CHECK `production_order_status_not_null`: status IS NOT NULL
> CHECK `production_order_tenant_id_not_null`: tenant_id IS NOT NULL

### `schema_annotations`

> _⚠ pending annotation_

| Column          | Business Name   | Type                     | Class | Constraints             | Description |
| --------------- | --------------- | ------------------------ | ----- | ----------------------- | ----------- |
| table_name      | table_name      | character varying        | —     | NOT NULL                |             |
| column_name     | column_name     | character varying        | —     | NOT NULL, DEFAULT       |             |
| business_name   | business_name   | character varying        | —     | NOT NULL                |             |
| description     | description     | text                     | —     | NOT NULL                |             |
| data_class      | data_class      | character varying        | —     | NOT NULL                |             |
| module_id       | module_id       | uuid                     | —     |                         |             |
| mandatory_for   | mandatory_for   | jsonb                    | —     | NOT NULL, DEFAULT []    |             |
| locked_for      | locked_for      | jsonb                    | —     | NOT NULL, DEFAULT []    |             |
| ai_generated_at | ai_generated_at | timestamp with time zone | —     |                         |             |
| human_override  | human_override  | boolean                  | —     | NOT NULL, DEFAULT false |             |

> UNIQUE(table_name, column_name)

> INDEX UNIQUE `schema_annotations_table_name_column_name_unique` (table_name, column_name) [btree]

> CHECK `schema_annotations_business_name_not_null`: business_name IS NOT NULL
> CHECK `schema_annotations_column_name_not_null`: column_name IS NOT NULL
> CHECK `schema_annotations_data_class_not_null`: data_class IS NOT NULL
> CHECK `schema_annotations_description_not_null`: description IS NOT NULL
> CHECK `schema_annotations_human_override_not_null`: human_override IS NOT NULL
> CHECK `schema_annotations_locked_for_not_null`: locked_for IS NOT NULL
> CHECK `schema_annotations_mandatory_for_not_null`: mandatory_for IS NOT NULL
> CHECK `schema_annotations_table_name_not_null`: table_name IS NOT NULL

### `serial_number`

> _⚠ pending annotation_

| Column               | Business Name        | Type                     | Class | Constraints                         | Description |
| -------------------- | -------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| serial_number_id     | serial_number_id     | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id            | tenant_id            | uuid                     | —     | NOT NULL                            |             |
| article_id           | article_id           | uuid                     | —     | NOT NULL                            |             |
| serial_no            | serial_no            | character varying        | —     | NOT NULL                            |             |
| status               | status               | character varying        | —     | NOT NULL, DEFAULT in_stock          |             |
| created_movement_id  | created_movement_id  | uuid                     | —     |                                     |             |
| consumed_movement_id | consumed_movement_id | uuid                     | —     |                                     |             |
| created_at           | created_at           | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(tenant_id, article_id, serial_no)
> UNIQUE(tenant_id, serial_number_id)

> INDEX UNIQUE `serial_number_tenant_id_article_id_serial_no_unique` (tenant_id, article_id, serial_no) [btree]
> INDEX UNIQUE `serial_number_tenant_id_serial_number_id_key` (tenant_id, serial_number_id) [btree]

> CHECK `serial_number_article_id_not_null`: article_id IS NOT NULL
> CHECK `serial_number_created_at_not_null`: created_at IS NOT NULL
> CHECK `serial_number_serial_no_not_null`: serial_no IS NOT NULL
> CHECK `serial_number_serial_number_id_not_null`: serial_number_id IS NOT NULL
> CHECK `serial_number_status_check`: ((status)::text = ANY ((ARRAY['in_stock'::character varying, 'reserved'::character varying, 'sold'::character varying])::text[]))
> CHECK `serial_number_status_not_null`: status IS NOT NULL
> CHECK `serial_number_tenant_id_not_null`: tenant_id IS NOT NULL

### `session`

> _⚠ pending annotation_

| Column     | Business Name | Type                        | Class | Constraints             | Description |
| ---------- | ------------- | --------------------------- | ----- | ----------------------- | ----------- |
| id         | id            | text                        | PK    | NOT NULL                |             |
| expires_at | expires_at    | timestamp without time zone | —     | NOT NULL                |             |
| token      | token         | text                        | —     | NOT NULL                |             |
| created_at | created_at    | timestamp without time zone | —     | NOT NULL, DEFAULT now() |             |
| updated_at | updated_at    | timestamp without time zone | —     | NOT NULL                |             |
| ip_address | ip_address    | text                        | —     |                         |             |
| user_agent | user_agent    | text                        | —     |                         |             |
| user_id    | user_id       | text                        | —     | NOT NULL                |             |

> UNIQUE(token)

> INDEX UNIQUE `session_token_key` (token) [btree]
> INDEX `session_userId_idx` (user_id) [btree]

> CHECK `session_created_at_not_null`: created_at IS NOT NULL
> CHECK `session_expires_at_not_null`: expires_at IS NOT NULL
> CHECK `session_id_not_null`: id IS NOT NULL
> CHECK `session_token_not_null`: token IS NOT NULL
> CHECK `session_updated_at_not_null`: updated_at IS NOT NULL
> CHECK `session_user_id_not_null`: user_id IS NOT NULL

### `shipping_method`

> _⚠ pending annotation_

| Column                | Business Name         | Type                     | Class | Constraints                         | Description |
| --------------------- | --------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| shipping_method_id    | shipping_method_id    | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id             | tenant_id             | uuid                     | —     | NOT NULL                            |             |
| name                  | name                  | jsonb                    | —     | NOT NULL                            |             |
| tracking_url_template | tracking_url_template | character varying        | —     |                                     |             |
| is_active             | is_active             | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at            | created_at            | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| custom_attributes     | custom_attributes     | jsonb                    | —     |                                     |             |

> UNIQUE(tenant_id, name)
> UNIQUE(tenant_id, shipping_method_id)

> INDEX `idx_shipping_method_tenant` (tenant_id) [btree]
> INDEX UNIQUE `shipping_method_tenant_id_name_unique` (tenant_id, name) [btree]
> INDEX UNIQUE `shipping_method_tenant_id_shipping_method_id_key` (tenant_id, shipping_method_id) [btree]

> CHECK `shipping_method_created_at_not_null`: created_at IS NOT NULL
> CHECK `shipping_method_is_active_not_null`: is_active IS NOT NULL
> CHECK `shipping_method_name_not_null`: name IS NOT NULL
> CHECK `shipping_method_shipping_method_id_not_null`: shipping_method_id IS NOT NULL
> CHECK `shipping_method_tenant_id_not_null`: tenant_id IS NOT NULL

### `system_settings`

> _⚠ pending annotation_

| Column          | Business Name   | Type                     | Class | Constraints                         | Description |
| --------------- | --------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| setting_id      | setting_id      | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| scope           | scope           | character varying        | —     | NOT NULL                            |             |
| organization_id | organization_id | uuid                     | —     |                                     |             |
| tenant_id       | tenant_id       | uuid                     | —     |                                     |             |
| key             | key             | character varying        | —     | NOT NULL                            |             |
| value           | value           | jsonb                    | —     | NOT NULL                            |             |
| created_at      | created_at      | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| updated_at      | updated_at      | timestamp with time zone | —     |                                     |             |

> INDEX UNIQUE `uq_settings_global` (key) [btree]
> INDEX UNIQUE `uq_settings_org` (organization_id, key) [btree]
> INDEX UNIQUE `uq_settings_tenant` (tenant_id, key) [btree]

> CHECK `system_settings_created_at_not_null`: created_at IS NOT NULL
> CHECK `system_settings_key_not_null`: key IS NOT NULL
> CHECK `system_settings_scope_not_null`: scope IS NOT NULL
> CHECK `system_settings_setting_id_not_null`: setting_id IS NOT NULL
> CHECK `system_settings_value_not_null`: value IS NOT NULL

### `tax_class`

> _⚠ pending annotation_

| Column            | Business Name     | Type                     | Class | Constraints                         | Description |
| ----------------- | ----------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| tax_class_id      | tax_class_id      | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id         | tenant_id         | uuid                     | —     | NOT NULL                            |             |
| code              | code              | character varying        | —     | NOT NULL                            |             |
| name              | name              | jsonb                    | —     | NOT NULL                            |             |
| is_active         | is_active         | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at        | created_at        | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| custom_attributes | custom_attributes | jsonb                    | —     |                                     |             |

> UNIQUE(tenant_id, code)

> INDEX `idx_tax_class_tenant` (tenant_id) [btree]
> INDEX UNIQUE `tax_class_tenant_id_code_unique` (tenant_id, code) [btree]

> CHECK `tax_class_code_not_null`: code IS NOT NULL
> CHECK `tax_class_created_at_not_null`: created_at IS NOT NULL
> CHECK `tax_class_is_active_not_null`: is_active IS NOT NULL
> CHECK `tax_class_name_not_null`: name IS NOT NULL
> CHECK `tax_class_tax_class_id_not_null`: tax_class_id IS NOT NULL
> CHECK `tax_class_tenant_id_not_null`: tenant_id IS NOT NULL

### `tax_code`

> _⚠ pending annotation_

| Column      | Business Name | Type                     | Class | Constraints                         | Description |
| ----------- | ------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| tax_code_id | tax_code_id   | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id   | tenant_id     | uuid                     | —     | NOT NULL                            |             |
| code        | code          | character varying        | —     | NOT NULL                            |             |
| description | description   | character varying        | —     |                                     |             |
| tax_rate    | tax_rate      | numeric                  | —     | NOT NULL                            |             |
| is_active   | is_active     | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at  | created_at    | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(tenant_id, code)
> UNIQUE(tenant_id, tax_code_id)

> INDEX `idx_tax_code_tenant` (tenant_id) [btree]
> INDEX UNIQUE `tax_code_tenant_id_code_unique` (tenant_id, code) [btree]
> INDEX UNIQUE `tax_code_tenant_id_tax_code_id_key` (tenant_id, tax_code_id) [btree]

> CHECK `tax_code_code_not_null`: code IS NOT NULL
> CHECK `tax_code_created_at_not_null`: created_at IS NOT NULL
> CHECK `tax_code_is_active_not_null`: is_active IS NOT NULL
> CHECK `tax_code_tax_code_id_not_null`: tax_code_id IS NOT NULL
> CHECK `tax_code_tax_rate_not_null`: tax_rate IS NOT NULL
> CHECK `tax_code_tenant_id_not_null`: tenant_id IS NOT NULL

### `tax_rule`

> _⚠ pending annotation_

| Column                | Business Name         | Type                     | Class | Constraints                         | Description |
| --------------------- | --------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| tax_rule_id           | tax_rule_id           | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id             | tenant_id             | uuid                     | —     | NOT NULL                            |             |
| customer_tax_class_id | customer_tax_class_id | uuid                     | —     |                                     |             |
| article_tax_class_id  | article_tax_class_id  | uuid                     | —     |                                     |             |
| country_code          | country_code          | char(2)                  | —     |                                     |             |
| tax_code_id           | tax_code_id           | uuid                     | —     | NOT NULL                            |             |
| valid_from            | valid_from            | date                     | —     | NOT NULL                            |             |
| valid_to              | valid_to              | date                     | —     |                                     |             |
| created_at            | created_at            | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> INDEX `idx_tax_rule_lookup` (tenant_id, customer_tax_class_id, article_tax_class_id, country_code, valid_from) [btree]
> INDEX `idx_tax_rule_tenant` (tenant_id) [btree]

> CHECK `tax_rule_created_at_not_null`: created_at IS NOT NULL
> CHECK `tax_rule_tax_code_id_not_null`: tax_code_id IS NOT NULL
> CHECK `tax_rule_tax_rule_id_not_null`: tax_rule_id IS NOT NULL
> CHECK `tax_rule_tenant_id_not_null`: tenant_id IS NOT NULL
> CHECK `tax_rule_valid_from_not_null`: valid_from IS NOT NULL

### `tenant`

> _⚠ pending annotation_

| Column          | Business Name   | Type                     | Class | Constraints                         | Description |
| --------------- | --------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| tenant_id       | tenant_id       | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| organization_id | organization_id | uuid                     | —     | NOT NULL                            |             |
| slug            | slug            | varchar(63)              | —     | NOT NULL                            |             |
| name            | name            | character varying        | —     | NOT NULL                            |             |
| is_base         | is_base         | boolean                  | —     | NOT NULL, DEFAULT false             |             |
| is_active       | is_active       | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at      | created_at      | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(slug)

> INDEX `idx_tenant_organization` (organization_id) [btree]
> INDEX UNIQUE `tenant_slug_key` (slug) [btree]
> INDEX UNIQUE `uq_single_base_tenant` (is_base) [btree]

> CHECK `tenant_created_at_not_null`: created_at IS NOT NULL
> CHECK `tenant_is_active_not_null`: is_active IS NOT NULL
> CHECK `tenant_is_base_not_null`: is_base IS NOT NULL
> CHECK `tenant_name_not_null`: name IS NOT NULL
> CHECK `tenant_organization_id_not_null`: organization_id IS NOT NULL
> CHECK `tenant_slug_not_null`: slug IS NOT NULL
> CHECK `tenant_tenant_id_not_null`: tenant_id IS NOT NULL

### `tenant_connector`

> _⚠ pending annotation_

| Column              | Business Name       | Type                     | Class | Constraints                         | Description |
| ------------------- | ------------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| tenant_connector_id | tenant_connector_id | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id           | tenant_id           | uuid                     | —     | NOT NULL                            |             |
| connector_id        | connector_id        | uuid                     | —     | NOT NULL                            |             |
| credentials         | credentials         | jsonb                    | —     | NOT NULL, DEFAULT {}                |             |
| is_active           | is_active           | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at          | created_at          | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| updated_at          | updated_at          | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(tenant_id, tenant_connector_id)

> INDEX UNIQUE `tenant_connector_tenant_id_tenant_connector_id_key` (tenant_id, tenant_connector_id) [btree]

> CHECK `tenant_connector_connector_id_not_null`: connector_id IS NOT NULL
> CHECK `tenant_connector_created_at_not_null`: created_at IS NOT NULL
> CHECK `tenant_connector_credentials_not_null`: credentials IS NOT NULL
> CHECK `tenant_connector_is_active_not_null`: is_active IS NOT NULL
> CHECK `tenant_connector_tenant_connector_id_not_null`: tenant_connector_id IS NOT NULL
> CHECK `tenant_connector_tenant_id_not_null`: tenant_id IS NOT NULL
> CHECK `tenant_connector_updated_at_not_null`: updated_at IS NOT NULL

### `tenant_connector_mapping`

> _⚠ pending annotation_

| Column              | Business Name       | Type              | Class | Constraints                          | Description |
| ------------------- | ------------------- | ----------------- | ----- | ------------------------------------ | ----------- |
| mapping_id          | mapping_id          | uuid              | PK    | NOT NULL, DEFAULT gen_random_uuid()  |             |
| tenant_id           | tenant_id           | uuid              | —     | NOT NULL                             |             |
| tenant_connector_id | tenant_connector_id | uuid              | —     | NOT NULL                             |             |
| source_field        | source_field        | character varying | —     | NOT NULL                             |             |
| target_table        | target_table        | character varying | —     | NOT NULL                             |             |
| target_column       | target_column       | character varying | —     | NOT NULL                             |             |
| transform           | transform           | jsonb             | —     | NOT NULL, DEFAULT {"type": "direct"} |             |
| default_value       | default_value       | jsonb             | —     |                                      |             |

> UNIQUE(tenant_connector_id, source_field)

> INDEX UNIQUE `tenant_connector_mapping_tenant_connector_id_source_field_uniqu` (tenant_connector_id, source_field) [btree]

> CHECK `tenant_connector_mapping_mapping_id_not_null`: mapping_id IS NOT NULL
> CHECK `tenant_connector_mapping_source_field_not_null`: source_field IS NOT NULL
> CHECK `tenant_connector_mapping_target_column_not_null`: target_column IS NOT NULL
> CHECK `tenant_connector_mapping_target_table_not_null`: target_table IS NOT NULL
> CHECK `tenant_connector_mapping_tenant_connector_id_not_null`: tenant_connector_id IS NOT NULL
> CHECK `tenant_connector_mapping_tenant_id_not_null`: tenant_id IS NOT NULL
> CHECK `tenant_connector_mapping_transform_not_null`: transform IS NOT NULL

### `tenant_fields`

> _⚠ pending annotation_

| Column            | Business Name     | Type                     | Class | Constraints                         | Description |
| ----------------- | ----------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| field_id          | field_id          | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| scope             | scope             | character varying        | —     | NOT NULL, DEFAULT tenant            |             |
| organization_id   | organization_id   | uuid                     | —     |                                     |             |
| tenant_id         | tenant_id         | uuid                     | —     |                                     |             |
| entity_name       | entity_name       | character varying        | —     | NOT NULL                            |             |
| field_name        | field_name        | character varying        | —     | NOT NULL                            |             |
| field_type        | field_type        | character varying        | —     | NOT NULL                            |             |
| is_required       | is_required       | boolean                  | —     | NOT NULL, DEFAULT false             |             |
| custom_attributes | custom_attributes | jsonb                    | —     |                                     |             |
| created_at        | created_at        | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| label             | label             | jsonb                    | —     |                                     |             |
| help_text         | help_text         | jsonb                    | —     |                                     |             |
| is_visible        | is_visible        | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| display_order     | display_order     | integer                  | —     |                                     |             |
| import_column     | import_column     | text                     | —     |                                     |             |
| import_type       | import_type       | text                     | —     |                                     |             |
| import_required   | import_required   | boolean                  | —     | NOT NULL, DEFAULT false             |             |
| import_transform  | import_transform  | text                     | —     |                                     |             |
| group_id          | group_id          | character varying        | —     |                                     |             |
| lookup_table      | lookup_table      | character varying        | —     |                                     |             |
| lookup_filter     | lookup_filter     | jsonb                    | —     |                                     |             |

> INDEX UNIQUE `uq_fields_global` (entity_name, field_name) [btree]
> INDEX UNIQUE `uq_fields_org` (organization_id, entity_name, field_name) [btree]
> INDEX UNIQUE `uq_fields_tenant` (tenant_id, entity_name, field_name) [btree]

> CHECK `tenant_fields_created_at_not_null`: created_at IS NOT NULL
> CHECK `tenant_fields_entity_name_not_null`: entity_name IS NOT NULL
> CHECK `tenant_fields_field_id_not_null`: field_id IS NOT NULL
> CHECK `tenant_fields_field_name_not_null`: field_name IS NOT NULL
> CHECK `tenant_fields_field_type_not_null`: field_type IS NOT NULL
> CHECK `tenant_fields_import_required_not_null`: import_required IS NOT NULL
> CHECK `tenant_fields_is_required_not_null`: is_required IS NOT NULL
> CHECK `tenant_fields_is_visible_not_null`: is_visible IS NOT NULL
> CHECK `tenant_fields_scope_not_null`: scope IS NOT NULL

### `tenant_groups`

> _⚠ pending annotation_

| Column            | Business Name     | Type                     | Class | Constraints                         | Description |
| ----------------- | ----------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| group_id          | group_id          | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| scope             | scope             | character varying        | —     | NOT NULL, DEFAULT tenant            |             |
| organization_id   | organization_id   | uuid                     | —     |                                     |             |
| tenant_id         | tenant_id         | uuid                     | —     |                                     |             |
| entity_name       | entity_name       | character varying        | —     | NOT NULL                            |             |
| group_key         | group_key         | character varying        | —     | NOT NULL                            |             |
| label             | label             | jsonb                    | —     | NOT NULL                            |             |
| display_order     | display_order     | integer                  | —     | NOT NULL, DEFAULT 0                 |             |
| is_visible        | is_visible        | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| custom_attributes | custom_attributes | jsonb                    | —     |                                     |             |
| created_at        | created_at        | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> INDEX UNIQUE `uq_groups_global` (entity_name, group_key) [btree]
> INDEX UNIQUE `uq_groups_org` (organization_id, entity_name, group_key) [btree]
> INDEX UNIQUE `uq_groups_tenant` (tenant_id, entity_name, group_key) [btree]

> CHECK `tenant_groups_created_at_not_null`: created_at IS NOT NULL
> CHECK `tenant_groups_display_order_not_null`: display_order IS NOT NULL
> CHECK `tenant_groups_entity_name_not_null`: entity_name IS NOT NULL
> CHECK `tenant_groups_group_id_not_null`: group_id IS NOT NULL
> CHECK `tenant_groups_group_key_not_null`: group_key IS NOT NULL
> CHECK `tenant_groups_is_visible_not_null`: is_visible IS NOT NULL
> CHECK `tenant_groups_label_not_null`: label IS NOT NULL
> CHECK `tenant_groups_scope_not_null`: scope IS NOT NULL

### `tenant_layouts`

> _⚠ pending annotation_

| Column            | Business Name     | Type                     | Class | Constraints                         | Description |
| ----------------- | ----------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| layout_id         | layout_id         | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| scope             | scope             | character varying        | —     | NOT NULL, DEFAULT tenant            |             |
| organization_id   | organization_id   | uuid                     | —     |                                     |             |
| tenant_id         | tenant_id         | uuid                     | —     |                                     |             |
| entity_name       | entity_name       | character varying        | —     | NOT NULL                            |             |
| layout_key        | layout_key        | character varying        | —     | NOT NULL                            |             |
| layout_definition | layout_definition | jsonb                    | —     | NOT NULL                            |             |
| created_at        | created_at        | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> INDEX UNIQUE `uq_layouts_global` (entity_name, layout_key) [btree]
> INDEX UNIQUE `uq_layouts_org` (organization_id, entity_name, layout_key) [btree]
> INDEX UNIQUE `uq_layouts_tenant` (tenant_id, entity_name, layout_key) [btree]

> CHECK `tenant_layouts_created_at_not_null`: created_at IS NOT NULL
> CHECK `tenant_layouts_entity_name_not_null`: entity_name IS NOT NULL
> CHECK `tenant_layouts_layout_definition_not_null`: layout_definition IS NOT NULL
> CHECK `tenant_layouts_layout_id_not_null`: layout_id IS NOT NULL
> CHECK `tenant_layouts_layout_key_not_null`: layout_key IS NOT NULL
> CHECK `tenant_layouts_scope_not_null`: scope IS NOT NULL

### `tenant_rules`

> _⚠ pending annotation_

| Column          | Business Name   | Type                     | Class | Constraints                         | Description |
| --------------- | --------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| rule_id         | rule_id         | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| scope           | scope           | character varying        | —     | NOT NULL, DEFAULT tenant            |             |
| organization_id | organization_id | uuid                     | —     |                                     |             |
| tenant_id       | tenant_id       | uuid                     | —     |                                     |             |
| entity_name     | entity_name     | character varying        | —     | NOT NULL                            |             |
| hook_name       | hook_name       | character varying        | —     | NOT NULL                            |             |
| rule_state      | rule_state      | character varying        | —     | NOT NULL, DEFAULT draft             |             |
| rule_definition | rule_definition | jsonb                    | —     | NOT NULL                            |             |
| created_at      | created_at      | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| rule_source     | rule_source     | text                     | —     |                                     |             |

> INDEX UNIQUE `uq_rules_global` (entity_name, hook_name) [btree]
> INDEX UNIQUE `uq_rules_org` (organization_id, entity_name, hook_name) [btree]
> INDEX UNIQUE `uq_rules_tenant` (tenant_id, entity_name, hook_name) [btree]

> CHECK `tenant_rules_created_at_not_null`: created_at IS NOT NULL
> CHECK `tenant_rules_entity_name_not_null`: entity_name IS NOT NULL
> CHECK `tenant_rules_hook_name_not_null`: hook_name IS NOT NULL
> CHECK `tenant_rules_rule_definition_not_null`: rule_definition IS NOT NULL
> CHECK `tenant_rules_rule_id_not_null`: rule_id IS NOT NULL
> CHECK `tenant_rules_rule_state_not_null`: rule_state IS NOT NULL
> CHECK `tenant_rules_scope_not_null`: scope IS NOT NULL

### `unit`

> _⚠ pending annotation_

| Column            | Business Name     | Type                     | Class | Constraints                         | Description |
| ----------------- | ----------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| unit_id           | unit_id           | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id         | tenant_id         | uuid                     | —     | NOT NULL                            |             |
| code              | code              | varchar(10)              | —     | NOT NULL                            |             |
| name              | name              | jsonb                    | —     | NOT NULL                            |             |
| is_active         | is_active         | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at        | created_at        | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |
| custom_attributes | custom_attributes | jsonb                    | —     |                                     |             |

> UNIQUE(tenant_id, code)

> INDEX `idx_unit_tenant` (tenant_id) [btree]
> INDEX UNIQUE `unit_tenant_id_code_unique` (tenant_id, code) [btree]

> CHECK `unit_code_not_null`: code IS NOT NULL
> CHECK `unit_created_at_not_null`: created_at IS NOT NULL
> CHECK `unit_is_active_not_null`: is_active IS NOT NULL
> CHECK `unit_name_not_null`: name IS NOT NULL
> CHECK `unit_tenant_id_not_null`: tenant_id IS NOT NULL
> CHECK `unit_unit_id_not_null`: unit_id IS NOT NULL

### `user`

> _⚠ pending annotation_

| Column         | Business Name  | Type                        | Class | Constraints             | Description |
| -------------- | -------------- | --------------------------- | ----- | ----------------------- | ----------- |
| id             | id             | text                        | PK    | NOT NULL                |             |
| name           | name           | text                        | —     | NOT NULL                |             |
| email          | email          | text                        | —     | NOT NULL                |             |
| email_verified | email_verified | boolean                     | —     | NOT NULL, DEFAULT false |             |
| image          | image          | text                        | —     |                         |             |
| created_at     | created_at     | timestamp without time zone | —     | NOT NULL, DEFAULT now() |             |
| updated_at     | updated_at     | timestamp without time zone | —     | NOT NULL, DEFAULT now() |             |

> UNIQUE(email)

> INDEX UNIQUE `user_email_key` (email) [btree]

> CHECK `user_created_at_not_null`: created_at IS NOT NULL
> CHECK `user_email_not_null`: email IS NOT NULL
> CHECK `user_email_verified_not_null`: email_verified IS NOT NULL
> CHECK `user_id_not_null`: id IS NOT NULL
> CHECK `user_name_not_null`: name IS NOT NULL
> CHECK `user_updated_at_not_null`: updated_at IS NOT NULL

### `user_tenant`

> _⚠ pending annotation_

| Column    | Business Name | Type              | Class | Constraints | Description |
| --------- | ------------- | ----------------- | ----- | ----------- | ----------- |
| user_id   | user_id       | uuid              | —     | NOT NULL    |             |
| tenant_id | tenant_id     | uuid              | —     | NOT NULL    |             |
| role      | role          | character varying | —     | NOT NULL    |             |

> UNIQUE(user_id, tenant_id)

> INDEX `idx_user_tenant_tenant` (tenant_id) [btree]
> INDEX `idx_user_tenant_user` (user_id) [btree]
> INDEX UNIQUE `user_tenant_user_id_tenant_id_unique` (user_id, tenant_id) [btree]

> CHECK `user_tenant_role_not_null`: role IS NOT NULL
> CHECK `user_tenant_tenant_id_not_null`: tenant_id IS NOT NULL
> CHECK `user_tenant_user_id_not_null`: user_id IS NOT NULL

### `verification`

> _⚠ pending annotation_

| Column     | Business Name | Type                        | Class | Constraints             | Description |
| ---------- | ------------- | --------------------------- | ----- | ----------------------- | ----------- |
| id         | id            | text                        | PK    | NOT NULL                |             |
| identifier | identifier    | text                        | —     | NOT NULL                |             |
| value      | value         | text                        | —     | NOT NULL                |             |
| expires_at | expires_at    | timestamp without time zone | —     | NOT NULL                |             |
| created_at | created_at    | timestamp without time zone | —     | NOT NULL, DEFAULT now() |             |
| updated_at | updated_at    | timestamp without time zone | —     | NOT NULL, DEFAULT now() |             |

> INDEX `verification_identifier_idx` (identifier) [btree]

> CHECK `verification_created_at_not_null`: created_at IS NOT NULL
> CHECK `verification_expires_at_not_null`: expires_at IS NOT NULL
> CHECK `verification_id_not_null`: id IS NOT NULL
> CHECK `verification_identifier_not_null`: identifier IS NOT NULL
> CHECK `verification_updated_at_not_null`: updated_at IS NOT NULL
> CHECK `verification_value_not_null`: value IS NOT NULL

### `warehouse`

> _⚠ pending annotation_

| Column       | Business Name | Type                     | Class | Constraints                         | Description |
| ------------ | ------------- | ------------------------ | ----- | ----------------------------------- | ----------- |
| warehouse_id | warehouse_id  | uuid                     | PK    | NOT NULL, DEFAULT gen_random_uuid() |             |
| tenant_id    | tenant_id     | uuid                     | —     | NOT NULL                            |             |
| company_id   | company_id    | uuid                     | —     |                                     |             |
| code         | code          | character varying        | —     | NOT NULL                            |             |
| name         | name          | character varying        | —     | NOT NULL                            |             |
| is_active    | is_active     | boolean                  | —     | NOT NULL, DEFAULT true              |             |
| created_at   | created_at    | timestamp with time zone | —     | NOT NULL, DEFAULT now()             |             |

> UNIQUE(tenant_id, code)
> UNIQUE(tenant_id, warehouse_id)
> UNIQUE(tenant_id, warehouse_id)

> INDEX `idx_warehouse_tenant` (tenant_id) [btree]
> INDEX UNIQUE `warehouse_tenant_id_code_unique` (tenant_id, code) [btree]
> INDEX UNIQUE `warehouse_tenant_id_warehouse_id_key` (tenant_id, warehouse_id) [btree]
> INDEX UNIQUE `warehouse_tenant_id_warehouse_id_unique` (tenant_id, warehouse_id) [btree]

> CHECK `warehouse_code_not_null`: code IS NOT NULL
> CHECK `warehouse_created_at_not_null`: created_at IS NOT NULL
> CHECK `warehouse_is_active_not_null`: is_active IS NOT NULL
> CHECK `warehouse_name_not_null`: name IS NOT NULL
> CHECK `warehouse_tenant_id_not_null`: tenant_id IS NOT NULL
> CHECK `warehouse_warehouse_id_not_null`: warehouse_id IS NOT NULL
