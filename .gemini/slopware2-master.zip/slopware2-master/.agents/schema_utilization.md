# Schema Utilization — Slopware v2

> Generated: 2026-05-07
> Tables: 63 total | 7 mapped | 49 unmapped

---

## METADATA / SYSTEM (interner Mechanismus)

| Tabelle                 | Drizzle | Domain CRUD | UI         | Status               |
| ----------------------- | ------- | ----------- | ---------- | -------------------- |
| `account`               | ✅      | ❌          | ❌         | Auth-only, kein CRUD |
| `session`               | ✅      | ❌          | ❌         | Auth-only, kein CRUD |
| `user`                  | ✅      | ❌          | ❌         | Auth-only, kein CRUD |
| `verification`          | ✅      | ❌          | ❌         | Auth-only, kein CRUD |
| `organization`          | ✅      | ❌          | ✅ (Admin) | Read-only UI         |
| `tenant`                | ✅      | ❌          | ✅ (Admin) | Read-only UI         |
| `app_user`              | ✅      | ❌          | ✅ (Admin) | Read-only UI         |
| `user_tenant`           | ✅      | ❌          | ❌         | **UNMAPPED UI**      |
| `modules`               | ✅      | ❌          | ❌         | **UNMAPPED**         |
| `system_settings`       | ✅      | ❌          | ❌         | **UNMAPPED**         |
| `entity_commands`       | ✅      | ❌          | ❌         | **UNMAPPED**         |
| `tenant_fields`         | ✅      | ❌          | ❌         | **UNMAPPED**         |
| `tenant_groups`         | ✅      | ❌          | ❌         | **UNMAPPED**         |
| `tenant_layouts`        | ✅      | ❌          | ❌         | **UNMAPPED**         |
| `tenant_rules`          | ✅      | ❌          | ❌         | **UNMAPPED**         |
| `helper_table_registry` | ✅      | ❌          | ❌         | **UNMAPPED**         |
| `schema_annotations`    | ✅      | ❌          | ❌         | **UNMAPPED**         |

## MASTER DATA — Referenzdaten

| Tabelle       | Drizzle | Domain CRUD | UI  | Status       |
| ------------- | ------- | ----------- | --- | ------------ |
| `country`     | ✅      | ❌          | ❌  | **UNMAPPED** |
| `currency`    | ✅      | ❌          | ❌  | **UNMAPPED** |
| `unit`        | ✅      | ❌          | ❌  | **UNMAPPED** |
| `postal_code` | ✅      | ❌          | ❌  | **UNMAPPED** |
| `incoterm`    | ✅      | ❌          | ❌  | **UNMAPPED** |
| `industry`    | ✅      | ❌          | ❌  | **UNMAPPED** |

## MASTER DATA — Stammdaten

| Tabelle                      | Drizzle | Domain CRUD | UI         | Status                |
| ---------------------------- | ------- | ----------- | ---------- | --------------------- |
| `company`                    | ✅      | ✅ R+P      | ✅ (Admin) | **FULL**              |
| `address_category`           | ✅      | ❌          | ❌         | **UNMAPPED**          |
| `address`                    | ✅      | ✅ R+P      | ❌         | Domain CRUD, keine UI |
| `address_contact`            | ✅      | ❌          | ❌         | **UNMAPPED**          |
| `address_seq`                | ✅      | ❌          | ❌         | **UNMAPPED**          |
| `article_group`              | ✅      | ✅ R+P      | ❌         | Domain CRUD, keine UI |
| `warehouse`                  | ✅      | ✅ R+P      | ❌         | Domain CRUD, keine UI |
| `article`                    | ✅      | ✅ R+P      | ❌         | Domain CRUD, keine UI |
| `article_bom`                | ✅      | ❌          | ❌         | **UNMAPPED**          |
| `bank_account`               | ✅      | ❌          | ❌         | **UNMAPPED**          |
| `payment_term`               | ✅      | ❌          | ❌         | **UNMAPPED**          |
| `shipping_method`            | ✅      | ❌          | ❌         | **UNMAPPED**          |
| `price_list`                 | ✅      | ✅ Read     | ❌         | Read-only, keine UI   |
| `price_list_item`            | ✅      | ❌          | ❌         | **UNMAPPED**          |
| `discount_group`             | ✅      | ❌          | ❌         | **UNMAPPED**          |
| `tax_class`                  | ✅      | ❌          | ❌         | **UNMAPPED**          |
| `tax_code`                   | ✅      | ✅ Read     | ❌         | Read-only, keine UI   |
| `tax_rule`                   | ✅      | ❌          | ❌         | **UNMAPPED**          |
| `cost_center`                | ✅      | ✅ R+P      | ❌         | Domain CRUD, keine UI |
| `gl_account`                 | ✅      | ❌          | ❌         | **UNMAPPED**          |
| `account_determination_rule` | ✅      | ❌          | ❌         | **UNMAPPED**          |
| `fiscal_period`              | ✅      | ❌          | ❌         | **UNMAPPED**          |

## TRANSACTION

| Tabelle                  | Drizzle | Domain CRUD | UI  | Status                |
| ------------------------ | ------- | ----------- | --- | --------------------- |
| `document_type`          | ✅      | ❌          | ❌  | **UNMAPPED**          |
| `number_sequence`        | ✅      | ❌          | ❌  | **UNMAPPED**          |
| `document_group`         | ✅      | ❌          | ❌  | **UNMAPPED**          |
| `document`               | ✅      | ✅ Read     | ❌  | Read-only, keine UI   |
| `document_line`          | ✅      | ✅ Read     | ❌  | Read-only, keine UI   |
| `serial_number`          | ✅      | ❌          | ❌  | **UNMAPPED**          |
| `document_line_tracking` | ✅      | ❌          | ❌  | **UNMAPPED**          |
| `inventory_balance`      | ✅      | ✅ Read     | ❌  | Read-only, keine UI   |
| `inventory_movement`     | ✅      | ✅ Read     | ❌  | Read-only, keine UI   |
| `journal_entry`          | ✅      | ✅ Read     | ❌  | Read-only, keine UI   |
| `journal_line`           | ✅      | ❌          | ❌  | **UNMAPPED**          |
| `fact_sales_event`       | ✅      | ❌          | ❌  | **UNMAPPED**          |
| `fact_purchase_event`    | ✅      | ❌          | ❌  | **UNMAPPED**          |
| `delivery_address`       | ✅      | ❌          | ❌  | **UNMAPPED**          |
| `production_order`       | ✅      | ✅ R+P      | ❌  | Domain CRUD, keine UI |

## CONNECTOR / IMPORT

| Tabelle                    | Drizzle | Domain CRUD | UI         | Status       |
| -------------------------- | ------- | ----------- | ---------- | ------------ |
| `connector_definition`     | ✅      | ❌          | ✅ (Admin) | Read-only UI |
| `tenant_connector`         | ✅      | ❌          | ❌         | **UNMAPPED** |
| `tenant_connector_mapping` | ✅      | ❌          | ❌         | **UNMAPPED** |
| `import_batch`             | ✅      | ❌          | ❌         | **UNMAPPED** |
| `import_row`               | ✅      | ❌          | ❌         | **UNMAPPED** |

---

## Summary

| Kategorie            | Tabellen                                                                                                                   | Full CRUD | Read-only | Komplett unmapped |
| -------------------- | -------------------------------------------------------------------------------------------------------------------------- | --------- | --------- | ----------------- |
| Auth (4)             | user, session, account, verification                                                                                       | 0         | 0         | 4 (Auth-intern)   |
| System/Metadata (13) | org, tenant, app_user, user_tenant, modules, settings, fields, groups, layouts, rules, commands, registry, annotations     | 0         | 0         | 10                |
| Referenzdaten (6)    | country, currency, unit, postal_code, incoterm, industry                                                                   | 0         | 0         | 6                 |
| Stammdaten (20)      | company, address*, article*, warehouse, bank, payment, shipping, price*, discount, tax*, cost_center, gl, acct_det, fiscal | 1         | 3         | 16                |
| Transaction (15)     | document*, serial, tracking, inventory*, journal*, fact*, delivery, production                                             | 1         | 5         | 9                 |
| Connector (5)        | connector_def, tenant_connector, mapping, import_batch, import_row                                                         | 0         | 0         | 4                 |
| **TOTAL**            | **63**                                                                                                                     | **3**     | **8**     | **49**            |

**7 gemappt** (Drizzle + Domain und/oder UI), **49 komplett unmapped** (nur DB-Schema, kein Domain CRUD, keine UI).
Die gemappten Tabellen haben zudem keine Benutzungs-UI — nur die 6 Admin-Routen zeigen mock data.
