# Tenant-Context Runtime Pattern

## Overview

Slopware uses PostgreSQL session variables to enforce tenant isolation at the database level.
The active tenant is stored in `app.tenant_id` and read by RLS policies via `current_setting('app.tenant_id', true)`.

## Setting Tenant Context

### In Application Code (Connection Pool)

Use `SET SESSION` for pooled connections. The setting persists for the lifetime of the connection.

```ts
await sql.unsafe(`SET SESSION app.tenant_id TO '${tenantId}'`);
```

### In Transactions

Use `SET LOCAL` for transaction-scoped context. The setting is rolled back with the transaction.

```ts
await sql.begin(async (tx) => {
  await tx.unsafe(`SET LOCAL app.tenant_id = '${tenantId}'`);
  // all queries in this transaction see the tenant context
});
```

**Prefer `SET LOCAL` inside transactions** to avoid connection-pooling drift where a reused connection retains a stale tenant ID.

## Reading Tenant Context (RLS Policies)

All RLS policies read the tenant context using this pattern:

```sql
current_setting('app.tenant_id', true)
```

The second argument (`true`) returns an empty string instead of throwing when the setting is not set.

Full policy expression for tenant-scoped tables:

```sql
tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid
```

For scoped metadata tables (global/organization/tenant):

```sql
scope = 'global'
OR (scope = 'organization' AND organization_id = (
  SELECT organization_id FROM tenant WHERE tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid LIMIT 1
))
OR (scope = 'tenant' AND tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
```

## Drizzle Schema Pattern

In Drizzle schema files, use `onConflict` with `using` and `withCheck` for RLS:

```ts
import { pgTable, uuid, varchar, text } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const article = pgTable(
  "article",
  {
    articleId: uuid("article_id").primaryKey(),
    tenantId: uuid("tenant_id").notNull(),
    articleNo: varchar("article_no").notNull(),
    name: varchar("name").notNull(),
  },
  (table) => ({
    rls: {
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
      withCheck: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    },
  }),
);
```

## Test Pattern

### Setup

Tests use `@testcontainers/postgresql` to spin up an isolated PostgreSQL 18 container.
The `global-setup.ts` runs migrations, creates `app_user`, applies grants, and seeds data.

### Tenant Context in Tests

```ts
import { getTestSql, setTenantContext } from "./test-helper";

const sql = getTestSql();
await setTenantContext(sql, TENANT_A1_UUID);
// queries now run as tenant A1
```

For transaction-scoped tests use `sql.begin()` + `SET LOCAL`:

```ts
await sql.begin(async (tx) => {
  await tx.unsafe(`SET LOCAL app.tenant_id = '${TENANT_UUID}'`);
  await tx.unsafe("DELETE FROM some_table WHERE ...");
});
```

## Key Rules

1. **Never trust client input** for `tenant_id` — always derive from session/membership
2. **Always set tenant context** before queries on tenant-scoped tables
3. **Use `SET LOCAL` in transactions** to avoid pool drift
4. **Every tenant-scoped table** must have RLS enabled with matching policies
5. **Composite FKs** must include `tenant_id` to prevent cross-tenant references at DB level
6. **`app_user` role** must be `NOSUPERUSER` — superusers bypass RLS

## Constants

| Constant      | UUID                                   | Description            |
| ------------- | -------------------------------------- | ---------------------- |
| `BASE_TENANT` | `00000000-0000-0000-0000-000000000002` | Global metadata tenant |

## Test Fixtures

| Fixture          | UUID                                   | Description         |
| ---------------- | -------------------------------------- | ------------------- |
| `TEST_ORG_A`     | `10000000-0000-0000-0000-000000000001` | Test Organization A |
| `TEST_TENANT_A1` | `10000000-0000-0000-0000-000000000011` | Test Tenant A1      |
| `TEST_TENANT_A2` | `10000000-0000-0000-0000-000000000012` | Test Tenant A2      |
| `TEST_ORG_B`     | `20000000-0000-0000-0000-000000000001` | Test Organization B |
| `TEST_TENANT_B1` | `20000000-0000-0000-0000-000000000011` | Test Tenant B1      |
