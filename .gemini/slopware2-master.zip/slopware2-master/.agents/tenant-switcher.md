# PRD: TenantSwitcher in UserPanel

## Problem Statement

The application is a multi-tenant platform, but currently, the user cannot switch between tenants they have access to. The UI has a template for a tenant switcher, but it uses hardcoded data and has no functional backend connection. Users need a way to move between their assigned tenants seamlessly without re-logging.

## Proposed Solution

Implement a functional TenantSwitcher in the `UserPanel` (within `WorkspaceLayout`). The active tenant will be persisted via a secure `sw_active_tenant_id` cookie. A new server function will handle the switch request, validating access before updating the cookie. The frontend will revalidate all data upon a successful switch.

## User Stories

1. As a user, I want to see a list of all active tenants I belong to in my user profile menu.
2. As a user, I want to see which tenant is currently active.
3. As a user, I want to click on another tenant to switch my entire workspace context to that tenant.
4. As a user, I want my tenant selection to persist across browser reloads.

## Non-Goals

- Allowing switching to tenants the user has no membership for (even for system admins, unless they explicitly use an admin impersonation feature, which is out of scope here).
- Managing tenant memberships or roles (this is part of the Admin module).
- Switching Organizations (this is a higher-level change not covered by this switcher).

## Implementation Decisions

- **Persistence:** Using an `HttpOnly` cookie (`sw_active_tenant_id`). This ensures the tenant context is available during SSR and is more secure than local storage. It also prevents "tenant spoofing" via URL parameters, adhering to Core Spec **K4**.
- **Validation:** All tenant switches are validated server-side. The server function `switchActiveTenantFn` checks if the user has a valid `user_tenant` record for the requested ID.
- **Refresh Strategy:** Using `router.invalidate()` after a switch. This is the cleanest way in TanStack Start to ensure all loaders (which rely on the tenant context) are re-run.
- **Defaulting:** If no cookie is present, `resolveServerContext` falls back to the user's `last_company_id` (if implemented) or the first available membership.

## Module Map

- `apps/web/src/server/admin-tenants.ts`:
  - `switchActiveTenantFn`: New server function to validate and set the tenant cookie.
- `apps/web/src/server/auth-bridge.ts`:
  - `resolveServerContext`: Modified to read the `sw_active_tenant_id` cookie from headers.
- `apps/web/src/features/workspace/WorkspaceLayout.tsx`:
  - Refactor the User Menu to use dynamic `memberships` from `checkAdminFn`.
  - Implement the `handleTenantSwitch` logic.
- `apps/web/src/server/constants.ts` (or similar):
  - Define `TENANT_COOKIE_NAME = "sw_active_tenant_id"`.

## Technical Details

### Server Function: `switchActiveTenantFn`

- Input: `tenantId: string`
- Middleware: `authMiddleware`
- Logic:
  1. Resolve memberships for the user.
  2. Verify if `tenantId` is in the memberships (or user is system admin).
  3. Set `sw_active_tenant_id` cookie (max-age: 30 days, HttpOnly, SameSite=Lax).
  4. Return success.

### Context Resolution: `resolveServerContext`

- Extract cookie `sw_active_tenant_id` from the request headers.
- If present, validate against user's memberships.
- Use validated cookie ID as the primary tenant source.

### UI: `WorkspaceLayout`

- Use the `memberships` returned by `checkAdminFn` (which is already called in `useEffect`).
- Store the list in state or use it directly from the result.
- Render a list of buttons in the dropdown.
- Show a checkmark for the tenant matching the current context's `tenantId`.

## Open Questions

- Should we show the organization name alongside the tenant name if the user belongs to multiple organizations? (Decision: Keep it simple for now, just Tenant Name).
