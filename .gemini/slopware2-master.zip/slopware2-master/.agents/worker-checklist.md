# Worker Checklist — Lies NUR diese Datei zu Start

## Read Order (SELEKTIV, nicht blind)

1. `plan/task.md` — deine Aufgabe (IMMER)
2. `plan/blockers.md` — offene Blocker (IMMER)
3. Code-Files die du änderst (IMMER)
4. `.agents/03_design_rules.md` — NUR bei UI-Code
5. `.agents/rules.md` — NUR bei Unklarheiten (lookup, nicht full read)

## Commands

`vp check` (lint+typecheck) | `vp test` | `pnpm db generate && pnpm db migrate`

## Mandatory Patterns

- Server Fn: `createServerFn` + `authMiddleware` + `Fn` suffix
- Query: `useQuery` wrapping `*Fn`. Mutation: `useMutation` wrapping `*Fn`
- State: `useWorkspaceContext()` — never props
- Design: `.sw-root` scoped. `var(--sw-*)` CSS vars. No hex colors, no inline styles
- Table/Form: `EntityDataTable` + `CrudDialog`. No custom implementations
- View: `views/[prefix]/[prefix]-[suffix]-view.tsx`. `export default`, no props
- DB: RLS + `tenant_id` index. Domain commands for writes. No raw SQL from UI
- File writes: < 30 lines/write. < 20 lines/edit. Chunk large files

## Hard Constraints

- `authMiddleware` on ALL protected server functions
- No shadcn/Tailwind inside `.sw-root`
- Static imports only for server functions
- No hard delete → `deactivateEntity`
- i18n: `t(key)` only, no inline strings

## Definition of Done (ALL 5)

1. Code written + all PRD stories implemented
2. Tests written + `vp test` green (L2/L3)
3. `vp check` = 0 errors
4. Atomic commit with conventional message
5. Archive to `plan/done/<slug>.md` — MUST include Affected Files list

## Affected Files (CRITICAL for traceability)

In the archive, list EVERY file you touched with what changed:

- `path/to/file.ts` — new / modified / deleted / test
- Include test files, config files, and imports

## Blocker Reporting

Problem → `plan/blockers.md` → commit what you can → task.md → blocked
