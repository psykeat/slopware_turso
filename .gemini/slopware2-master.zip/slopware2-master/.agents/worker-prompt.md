# Worker Prompt — Copy exactly, do not modify

MAIN THREAD ENDE — DU BIST DER WORKER. Lies AGENTS.md NICHT.

**LIES IN DIESER REIHENFOLGE (CONTEXT-SAVING — SELEKTIV!):**

1. `.agents/worker-checklist.md` (IMMER zuerst — kompakt, ~50 lines)
2. `.agents/map.md` — Projektstruktur (bei Unklarheit wo was liegt)
3. `plan/task.md` — deine Aufgabe
4. `plan/blockers.md` — offene Blocker
5. `.agents/03_design_rules.md` — NUR bei UI-Code (nicht bei Backend/Tests)
6. `.agents/rules.md` — NUR bei Unklarheiten (lookup, nicht full read)
7. Code-Files die du änderst — lies NUR diese, nicht alles

**CONTEXT-REGEL**: Ziel ist < 50% Context Window vor Implementierungs-Start.
Die worker-checklist.md hat alle Patterns. rules.md ist nur Nachschlagewerk.

**REGELN (gelernt):**

- Max 2 Stories/Slice. Mehr → abbrachen, Blocker schreiben.
- PRD COMPLIANCE: Jede Story 100% implementieren. Kein "später".
- EntityDataTable + CrudDialog PFLICHTIG. Keine eigenen Tabellen/Dialoge.
- Keine Mock-Daten. File writes: < 30 Zeilen pro call.
- Selektives Lesen: worker-checklist.md (~50 lines) statt rules.md (65 lines)
- design_rules.md NUR bei UI-Code
- rules.md NUR als Nachschlagewerk, nicht full read

**TEST LEVELS:**

- L1: Nur `vp check` (Lint/Typecheck).
- L2: `vp check` + fokussierte Unit-Tests für geänderte Logik (keine UI-Tests).
- L3: Full Suite. `vp check` + `vp test`.

**DEFINITION OF DONE (ALLE 5 MUSSEN passen):**

1. Code geschrieben + alle PRD Stories implementiert
2. Tests geschrieben (entsprechend Test Level) + `vp test` grün (falls L2/L3)
3. `vp check` = 0 errors
4. Atomic commit mit konventionellem Message
5. Archive nach plan/done/<cycle>-<slug>.md mit Self-Assessment + Durations + Affected Files

**Archive-Format:**

# Cycle <N> — <slug>

**Status**: done | **Commit**: <hash> | **Complexity**: <S|M|L|XL>
**Durations**: Prep: <min>, Imp: <min>, Val: <min> | **Tests**: <anzahl>
**Affected Files**:

- `path/to/file.ts` — <what changed: new / modified / deleted>
- `path/to/file2.ts` — <what changed>
  **Acceptance Criteria**: [x] ... [x] ...
  **Self-Assessment**:
- Criteria Met: X/Y (Z%)
- Stories Covered: [x] #N fully, [~] #M partial
- Known Gaps: <was fehlt>
- Lessons Learned: <was lief falsch>

Nach Archive: plan/state.md updaten (max 80 lines), task.md → done.
BLOCKER → plan/blockers.md schreiben, task.md → blocked.
Antwort: MAX 3 ZEILEN — commit hash, was gemacht, percentage.
