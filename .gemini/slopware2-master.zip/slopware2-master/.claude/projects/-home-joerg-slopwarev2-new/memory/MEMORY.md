# Memory Index

- [TanStack Start v1.167+ API fixes](feedback_tanstack_start_api.md) — Html/Body/Scripts removed, StartClient moved, entry files changed, beforeLoad has no request
- [Drizzle ORM v1 rc API change](feedback_drizzle_v1_api.md) — drizzle(pool) broken; use drizzle({ client: pool, relations }); wrong call silently connects as OS user
