---
name: Drizzle ORM v1.0.0-rc.2 API change — postgres-js driver
description: drizzle(pool) no longer works in v1 rc; must use drizzle({ client: pool, relations })
type: feedback
---

In drizzle-orm v1.0.0-rc.2, the postgres-js `drizzle()` function changed its signature.

Old (broken): `drizzle(pool)` or `drizzle(pool, { schema })`
New (correct): `drizzle({ client: pool, relations: authRelations })`

**Why it broke silently:** The new `drizzle()` destructures `{ client, connection }` from its first argument. A raw postgres.js pool has neither, so it falls through to `pgClient(undefined)` — creating a brand new connection using OS-user defaults (user "joerg", no password). This causes `password authentication failed for user "joerg"` at query time, even though the pool was created with the correct DATABASE_URL.

**Schema vs relations:** In v1, `DrizzlePgConfig` omits `schema`. Pass `relations` (from `defineRelations`) instead. The `db.query.user` API is populated from the relations object, not a schema map.

**How to apply:** Any time `drizzle-orm` is upgraded toward v1, check the `db` creation call in `packages/db/src/index.ts`. The `db.$client` property still works correctly once the client is passed via `{ client: pool }`.
