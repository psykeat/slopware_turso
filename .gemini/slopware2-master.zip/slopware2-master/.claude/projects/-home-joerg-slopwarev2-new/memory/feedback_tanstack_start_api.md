---
name: TanStack Start v1.167+ API migration fixes
description: Breaking API changes in @tanstack/react-start v1.167+ that affected the slopware web app
type: feedback
---

The following @tanstack/react-start v1.167+ API changes broke the app and were fixed:

1. `Html`, `Body`, `Head`, `Meta`, `Scripts` no longer exported from `@tanstack/react-start`. Use plain `<html>`/`<head>`/`<body>` elements + `HeadContent` and `Scripts` from `@tanstack/react-router`.

2. `StartClient` moved to `@tanstack/react-start/client`. Import `hydrateStart` instead and call it with no args.

3. `entry-server.tsx`: `createStartHandler({ createRouter, renderHandler })` is gone. New form: `createStartHandler({ handler: defaultStreamHandler })` — router is auto-wired by the Vite plugin.

4. `ScrollRestoration` component is deprecated. Use `scrollRestoration: true` in `createRouter()` instead (already set in router.tsx).

5. `beforeLoad` context no longer has `request`. Use `_getUser()` from `@repo/auth/functions` (which calls `getRequest()` internally) instead of `auth.api.getSession({ headers: request.headers })`.

**Why:** TanStack Start restructured its package exports and SSR APIs in v1.167. These patterns would appear in any new route or entry file written against older docs.

**How to apply:** When adding new routes with auth guards, always use `_getUser()` in `beforeLoad`. Never import `Html/Body/Head/Meta` from `@tanstack/react-start`.
