---
name: to-opencode
description: Break a plan, spec, or PRD into independently-grabbable vertical slices and append them to a local queue file (e.g. plan/queue.md). Use when user wants to convert a plan into implementation slices without a remote issue tracker.
---

# To OpenCode

Break a plan into independently-grabbable vertical slices and append them to a local queue file.

## Process

### 1. Gather context

Work from whatever is already in the conversation context. If the user passes a file path as an argument, read it as the source plan/PRD. If no argument is given, use the current conversation context.

### 2. Explore the codebase (optional)

If you have not already explored the codebase, do so to understand the current state of the code. Slice titles and descriptions should use the project's domain glossary vocabulary and respect any ADRs in the area you're touching.

### 3. Determine the target queue file and current slice numbering

The user passes the target queue file as an argument (e.g. `plan/queue.md`). Read the file if it exists to find the highest existing slice number — new slices continue from there. If the file does not exist, start at #1.

### 3b. Read learned rules from metrics (if exists)

Read `plan/metrics.md` if it exists. Extract any **LEARNED RULES** (e.g. "Max 2 Stories pro Slice"). Apply these rules when drafting slices. If metrics.md says a certain slice size failed before, avoid that size.

### 4. Draft vertical slices — PRD Coverage First (CRITICAL)

**BEFORE drafting slices, extract ALL user stories from the PRD.** Every story must be covered by exactly one slice. No story may be orphaned.

**STORY COVERAGE RULES (hard):**

- Each slice covers **max 2 user stories**. Never bundle 5+ stories into one slice.
- Every slice's acceptance criteria must **explicitly reference the story number(s)** it covers
- If a story says "Feld X, Y, Z" — the slice acceptance criteria must list each field explicitly
- If a story says "Button tut A" — the slice must include the button, the handler, and the observable outcome
- A slice that says "header fields" without listing them is **invalid** — reject and rewrite

**TRACER BULLET RULES:**

- Each slice delivers a narrow but COMPLETE path through every layer (schema, domain, server functions, UI, tests)
- A completed slice is demoable or verifiable on its own
- Prefer many thin slices over few thick ones
- **NO horizontal slices**: A slice that only does backend (no UI) or only UI (no backend) is invalid unless it's a pure infrastructure slice (migration, seed, encryption)

**PRD GAP CHECK (before quiz):**
After drafting slices, verify:

1. Count all user stories in the PRD
2. Map each story to its slice
3. Report any unmapped stories — these are GAPS that must be filled before proceeding
4. If gap > 0: ask user to approve gap resolution before appending to queue

### 5. Quiz the user

Present the proposed breakdown as a numbered list. For each slice show:

- **Title**: short descriptive name
- **Type**: HITL / AFK
- **Blocked by**: which other slices must complete first (use #N references)
- **User stories covered**: which user stories this addresses (if the source material has them)

**PRD COVERAGE TABLE (mandatory):**
Show a table mapping every user story from the PRD to its slice. Any unmapped story must be flagged as GAP.

| Story # | Story Title | Slice # | Status    |
| ------- | ----------- | ------- | --------- |
| 1       | ...         | #1      | ✅ mapped |
| 5       | ...         | #3      | ✅ mapped |
| 11      | ...         | —       | ❌ GAP    |

Ask the user:

- Does the granularity feel right? (too coarse / too fine)
- Are the dependency relationships correct?
- Should any slices be merged or split further?
- Are the correct slices marked as HITL and AFK?
- **Are all user stories mapped? If not, which gaps need resolution?**

Iterate until the user approves the breakdown AND all stories are mapped.

### 6. Append to the queue file

**IMPORTANT: Always append — never overwrite the existing file content.**

Read the current file content first to determine:

- The highest existing slice number (to continue numbering)
- Whether the `## Slices` and `## Slice Details` sections already exist

Then append the new slices using this format:

<queue-format>
If the file is new or empty, write this header first:

```
# Task Queue

Generated from PRD: <plan name>

## Format

Each slice: `[ ] #<N> <title> | <HITL|AFK> | Blocked by: <#N or none>`

## Slices

```

Then append one summary line per slice under `## Slices`:

```
[ ] #<N> <title> | <HITL|AFK> | Blocked by: <#M or none>
```

Then append the detail block under `## Slice Details`:

```
### #<N> <title>

**User Stories Covered**: [Story #X, Story #Y] — copy exact story text from PRD

**What to build**: A concise description of the end-to-end behavior. Describe what a user can do after this slice is complete. Avoid specific file paths — they go stale. Exception: prototype snippets that encode a decision (state machine, schema shape) may be inlined; note they came from a prototype.

**Acceptance criteria**

- [ ] [Story #X] Criterion 1 — explicitly references the story requirement
- [ ] [Story #X] Criterion 2 — explicitly references the story requirement
- [ ] [Story #Y] Criterion 1 — explicitly references the story requirement

**Tests**: What to test and prior art in the codebase for test structure.

---
```

**ACCEPTANCE CRITERIA RULES (CRITICAL):**

- Every criterion must be prefixed with `[Story #N]` to show which story it fulfills
- Criteria must be SPECIFIC: "Button 'Neuer Beleg' exists" not "create functionality exists"
- Criteria must list ALL fields from the story: "Typ, Gruppe, Datum, Kunde, Währung, Lager fields exist" not "header fields exist"
- Criteria must be VERIFIABLE: a human can check the box by looking at the code/UI
- If a criterion says "split layout" or "header fields" without specifics — it's INVALID

</queue-format>

When appending to an existing file:

- Add the new summary lines under the existing `## Slices` section
- Add the new detail blocks under the existing `## Slice Details` section
- Do not modify or remove any existing content
- Use the Edit tool to insert at the correct positions, or rewrite the full file with existing content preserved and new content appended
