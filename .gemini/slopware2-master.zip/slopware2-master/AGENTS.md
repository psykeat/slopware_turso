# Slopware v2 — Autonomous Evolution Mission

**Goal**: Maintain and extend Slopware v2 — autonomous, iterative, and high-quality.

## FALLBACK — Direct Questions (OVERRIDES everything below)

**IF** the user asks a direct question, requests debugging, asks for explanation, or gives a non-queue task:

1. **SKIP** the entire dispatcher/worker chain
2. Act as a normal agent: read relevant files, analyze, answer directly
3. Keep responses concise (< 4 lines unless asked for detail)
4. Do NOT spawn subagents, do NOT write to plan/task.md, do NOT archive

**Trigger phrases**: "why", "how", "explain", "debug", "fix", "what is", direct code questions, "improve", or any question not phrased as "implement slice X" / "continue queue" / "next task"

**Only enter dispatcher mode** when user explicitly says: "continue queue", "next slice", "dispatch", or references plan/queue.md

## SUCCESS CRITERIA

- 100% PRD Story Coverage (jede User Story aus der PRD ist in einem Slice abgebildet und implementiert)
- 100% Feature Coverage (alle Features aus altem Projekt implementiert)
- Tests: alle bestanden, `vp test` grün
- Code Quality: `vp check` = 0 errors, 0 warnings
- `plan/state.md` enthält: `STATUS: "MISSION COMPLETE"`

## QUALITY GATE (BEFORE COMPLETING MAJOR SLICES)

BEFORE completing a significant feature slice:

1. Read the PRD file (e.g., `plan/documents.md`)
2. Extract all relevant user story numbers
3. For each story, verify the archived task in `plan/done/` contains the story's acceptance criteria as `[x]`
4. If ANY story is unmapped or unverified: DO NOT mark as complete — write gap to `plan/blockers.md`

## DEVELOPMENT CHAIN

```
to-prd    → plan/task.md              (PRD document)
to-issues → plan/queue.md             (ordered slice backlog)
dispatcher→ reads queue, pops top     → plan/task.md → spawn worker
worker    → implements + tests        → vp check, vp test
worker    → archives to plan/done/    → permanent implementation record
dispatcher→ reads plan/done/          → updates state, picks next slice
```

## MAIN THREAD — DISPATCHER ONLY (CRITICAL)

WHILE `plan/state.md` does NOT contain `MISSION COMPLETE`:

### Blocker Recovery (BEFORE picking next slice)

Lies `plan/blockers.md`. Falls offene Blocker existieren:

1. Versuche den Blocker zu fixen (Config, Dependencies, Tool-Fehler)
2. Update `plan/blockers.md` → setze Blocker auf `[FIXED]` oder `[UNRESOLVABLE]`
3. Falls `[FIXED]`: respawn denselben slice (setze `[ ]` in queue.md, markiere vorherigen `[retry]`)
4. Falls `[UNRESOLVABLE]`: skip slice, markiere `[skip]` in queue.md, warte max 3 Retries pro Blocker
5. Falls Blocker gelöst oder 3+ Retries: fahre mit nächstem Slice fort

**AUTO-RESIZE bei Worker-Crash** (kein Commit, kein Archive):

- Lies `plan/task.md` → zähle Stories im Slice
- Wenn > 2 Stories: splitte Slice in 2 Slices (max 2 Stories pro Teil), schreibe beide nach queue.md
- Wenn ≤ 2 Stories: Slice war schon klein → Problem ist anders, versuche mit reduziertem Scope (nur 1 Story)
- Markiere gecrashten Slice `[retry]`, setze neuen Slice `[ ]`

### Normal Dispatch

1. Lies `plan/metrics.md` → wende gelernte Regeln an (z.B. max 2 Stories/Slice)
2. Lies `plan/queue.md` → nimm top `[ ]` slice mit erfüllten Blockern
3. **Slice-Validierung**: Wenn Slice > 2 Stories: splitte in 2 Slices, schreibe neuen Slice nach queue.md
4. Falls `plan/queue.md` leer oder nicht vorhanden: lies `plan/state.md` + `plan/feature-matrix.md` → bestimme nächsten Task selbst
5. Schreibe `plan/task.md` → Aufgabe, Files, Deliverables, **Complexity**, **Test Level** (max 40 Zeilen)
6. Mark slice `[x]` in `plan/queue.md` (falls zutreffend)
7. Lies `.agents/worker-prompt.md` → kopiere Inhalt als Subagent Prompt
8. Spawn EINEN `general` Subagent mit dem Prompt → **STOP, nichts weiter**

**VERBOTEN im Haupt-Thread:**

- Keine Code-Dateien lesen
- Keine Bash-Befehle ausführen
- Keine Analyse, keine Verifikation
- Kein AGENTS.md lesen (außer zu Start)

## SELF-IMPROVEMENT LOOP (automatisch, kein manueller Input)

Nach jedem abgeschlossenen Cycle (Worker archiviert nach `plan/done/`):

### Dispatcher: Cycle Retrospective (BEFORE picking next slice)

Lies `plan/done/<last-cycle>.md` und `plan/metrics.md`. Berechne:

1. **Slice-Fit**: Anzahl Acceptance Criteria im Slice vs. tatsaechlich als `[x]` im Archive
   - Wenn < 80%: naechste Slices kleiner machen (max 3 Criteria)
   - Wenn > 95% und Worker hatte Kapazitaet: Slices duerfen groesser sein
2. **Story-Coverage**: Stories im Slice vs. Stories 100% implementiert
   - Wenn Story nur teilweise: Slice muss respawned werden, nicht naechster Slice
3. **Test-Qualitaet**: `vp test` pass/fail, Anzahl Tests pro Cycle
   - Wenn 0 Tests: Worker hat Tests vergessen → naechster Slice muss Tests explizit fordern
4. **Blocker-Frequenz**: Wie oft derselbe Blocker auftritt
   - Wenn 2x gleich: Prozess anpassen (z.B. Dependency in Slice aufnehmen statt als Blocker)

Schreibe Metriken nach `plan/metrics.md` (max 40 Zeilen):

```
## Cycle <N> — <date>
Slice-Fit: X/Y criteria (Z%)
Story-Coverage: X/Y stories (Z%)
Tests: N added, vp test: pass/fail
Blocker: none / <description>
Process-Adjustment: <what changed for next slice>
```

### Worker: Self-Assessment (BEFORE archive)

Im Archive (`plan/done/<slug>.md`) MUSS ein Self-Assessment-Block stehen:

```
**Self-Assessment**:
- Criteria Met: X/Y (Z%)
- Stories Covered: [x] #N fully, [~] #M partial, [ ] #K not started
- Known Gaps: <was fehlt noch, falls nicht 100%>
- Lessons Learned: <was lief falsch, was sollte anders sein>
```

**Wenn Known Gaps > 0**: Worker schreibt Gap als Blocker in `plan/blockers.md`. Dispatcher respawned denselben Slice.

### Dispatcher: Process Adaptation (automatisch)

**CRITICAL: Lernregeln zurueckschreiben!** Nach dem Lesen von `plan/metrics.md`:

1. Wenn 2x Slice-Fit < 80%: Update `.agents/worker-prompt.md` → strengere Regeln
2. Wenn 2x Story-Coverage < 100%: Update `.agents/worker-prompt.md` → "SLICE SCOPE (gelernt)" hinzufügen
3. Wenn 2x vp test fail: Update `.agents/worker-prompt.md` → "TESTS FIRST" hinzufügen
4. Wenn 3x gleicher Blocker: Aendere AGENTS.md Guardrails (nicht nur metrics.md)

**Ohne Schritt 1-4 ist der Loop wertlos.** Der Dispatcher MUSS `.agents/worker-prompt.md` updaten wenn ein Muster erkannt wird.

## GUARDRAILS (hart)

- ❌ NIE ohne Tests committen
- ❌ Atomic Changes only (1 Feature pro Subagent-Cycle)
- ✅ `plan/state.md` max 80 lines, `plan/task.md` max 40 lines
- ✅ `plan/metrics.md` max 40 lines
- ✅ Subagent response max 3 Zeilen
- ✅ Worker archiviert IMMER nach `plan/done/<slug>.md` vor Cycle-Ende

## Stack, Commands, Key Patterns, Specs

→ `.agents/rules.md` (geladen via opencode.json instructions)
