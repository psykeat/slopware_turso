# Communication Rules

NO conversational filler. NO apologies. NO "I will now...".
Reply with the absolute minimum amount of text needed.
Use bullet points. Do not over-explain.
Output ONLY code changes or requested data, without preamble.

# Slopware — Agent Guide

Multi-tenant ERP. pnpm monorepo. TanStack Start + React + Vite. PostgreSQL 16+. Better Auth. Drizzle ORM.

---

## Dev Commands

```bash
sh dev.sh          # Start everything (PostgreSQL + migrations + all servers)
sh dev.sh web      # Web app only
pnpm lint          # Typecheck + lint
vp check           # Format + lint + typecheck (run before committing)
vp test            # Run tests (packages/domain/src/__tests__/)
pnpm db generate   # Generate Drizzle migration
pnpm db migrate    # Run pending migrations
```

---

## Module Map

### Backend / Domain

| File                                                     | What it gives you                                                 |
| -------------------------------------------------------- | ----------------------------------------------------------------- |
| `packages/domain/src/runtime/tenant-runtime.ts`          | `withTenant(tenantId, fn)`, `SYSTEM_ORG_ID`, `BASE_TENANT_ID`     |
| `packages/domain/src/entities/registry.ts`               | `ENTITY_REGISTRY` — the authoritative entity map                  |
| `packages/domain/src/queries/entity-read-service.ts`     | `listEntity`, `getEntityById`                                     |
| `packages/domain/src/commands/entity-command-service.ts` | `createEntity`, `patchEntity`, `deleteEntity`, `deactivateEntity` |
| `packages/domain/src/metadata/effective-service.ts`      | `getEffectiveFields`, `getEffectiveLayout`                        |
| `packages/domain/src/lookups/helper-table-service.ts`    | `listHelperTables`, `getHelperTableItems`                         |
| `packages/db/src/index.ts`                               | `db` — Drizzle client                                             |

### Server Functions (UI → Server bridge)

All live in `apps/web/src/server/server-functions.ts`. Named with `Fn` suffix.

| Function                                 | Purpose                                 |
| ---------------------------------------- | --------------------------------------- |
| `listEntityFn`                           | List any registered entity              |
| `getEntityFn`                            | Get single record by ID                 |
| `createEntityFn`                         | Create record via domain command        |
| `updateEntityFn`                         | Patch record via domain command         |
| `deleteEntityFn`                         | Delete/deactivate record                |
| `getEffectiveFieldsFn`                   | Fetch metadata-driven field definitions |
| `lookupHelperTableFn`                    | Fetch lookup values for dropdowns       |
| `listDocumentsFn` / `listDocumentTreeFn` | Document-specific queries               |

Auth helpers (note `$` prefix, not `Fn`): `$getUser`, `authMiddleware` from `packages/auth/src/tanstack/`.

### Workspace UI

| File                                       | What it gives you                               |
| ------------------------------------------ | ----------------------------------------------- |
| `features/workspace/registry.tsx`          | `ENTITY_REGISTRY` (UI side), `ICONS` map        |
| `features/workspace/view-registry.ts`      | `VIEW_REGISTRY` — all addressable views         |
| `features/workspace/view-resolver.tsx`     | `resolveView(key)` — renders view by key        |
| `features/workspace/workspace-context.tsx` | `useWorkspaceContext()` — all workspace state   |
| `features/workspace/workspace-presets.ts`  | Workspace layout definitions                    |
| `features/workspace/i18n.ts`               | `t(key, lang)` — translation function           |
| `features/workspace/metadata-renderers.ts` | `effective_fields` → grid columns / form fields |

### UI Components

| Task                  | Component            | Path                                          |
| --------------------- | -------------------- | --------------------------------------------- |
| Tabular list          | `EntityDataTable`    | `components/data-table/entity-data-table.tsx` |
| Create / edit record  | `CrudDialog`         | `components/crud-dialog.tsx`                  |
| Standard list pane    | `ListPanelAdapter`   | `components/panels/list-panel-adapter.tsx`    |
| Standard detail pane  | `DetailPanelAdapter` | `components/panels/detail-panel-adapter.tsx`  |
| Sub-positions / lines | `LinesPanelAdapter`  | `components/panels/lines-panel-adapter.tsx`   |

**Never build custom table or form implementations.** Use the components above.

---

## Decision Table

| What do you need?                         | Use                                                                                |
| ----------------------------------------- | ---------------------------------------------------------------------------------- |
| Show a list of records                    | `EntityDataTable` + `listEntityFn`                                                 |
| Create / edit any entity                  | `CrudDialog` (reads `effective_fields` automatically)                              |
| Add a workspace view with no custom logic | `kind: "generic"` entry in `VIEW_REGISTRY` — no file needed                        |
| Add a workspace view with custom logic    | New file `views/[prefix]/[prefix]-[suffix]-view.tsx`, `kind: "custom"` in registry |
| Read workspace state in a view            | `useWorkspaceContext()` — never props                                              |
| Write a server function                   | `createServerFn` + `authMiddleware` in `server-functions.ts`                       |
| Query data in a component                 | `useQuery` wrapping a `*Fn` server function                                        |
| Mutate data in a component                | `useMutation` wrapping a `*Fn` server function                                     |
| Add a new entity to the system            | See Golden Path below                                                              |

---

## Golden Paths

### New workspace view

1. Decide `kind`:
   - Just a table of a registered entity → `kind: "generic"`, add entry to `VIEW_REGISTRY`, done.
   - Custom UI → create `views/[prefix]/[prefix]-[suffix]-view.tsx`
2. Custom view file: `export default function MyView() { ... }` — no props, use `useWorkspaceContext()` for state
3. Add entry to `VIEW_REGISTRY` in `view-registry.ts` with `kind: "custom"`
4. If the view needs a workspace slot, add it to the preset in `workspace-presets.ts`

Key `document:lines` → file `views/document/document-lines-view.tsx` (prefix = folder, suffix = rest of filename).

### New entity (full stack)

1. **DB**: Add table with `tenant_id`, RLS policy, `tenant_id` index → `pnpm db generate && pnpm db migrate`
2. **Domain registry**: Add to `packages/domain/src/entities/registry.ts`
3. **Metadata**: Seed default fields in `tenant_fields` via migration or seed script
4. **Queries / Commands**: Add to `packages/domain/src/queries/` and `commands/` if non-generic logic needed
5. **UI**: Add entry to `features/workspace/registry.tsx` (ENTITY_REGISTRY) with `category`, `group`, `icon`, labels
6. **Workspace view**: Generic → VIEW_REGISTRY only. Custom → new view file

### New server function

```ts
// apps/web/src/server/server-functions.ts
export const myThingFn = createServerFn({ method: "POST", strict: false })
  .middleware([authMiddleware])
  .validator(z.object({ ... }))
  .handler(async ({ data, context }) => {
    return withTenant(context.tenantId, async (sql) => {
      // domain logic here
    });
  });
```

---

## Hard Constraints

- **PostgreSQL is source of truth.** No alternative persistence for core objects.
- **All tenant-scoped tables need RLS + `tenant_id` index.** No exceptions.
- **Never read raw metadata tables.** Only `effective_*` views/functions.
- **Never write raw SQL from AI or UI.** Use domain commands (`createEntity`, `patchEntity`, etc.).
- **No hard delete for master data.** Use `deactivateEntity`.
- **`authMiddleware` on every protected server function.** Even inside `_auth` routes.
- **Static imports only** for server functions — never dynamic imports.
- **No shadcn/Tailwind inside `.sw-root`.** Use `var(--sw-*)` CSS variables and `sw-` classes.
- **No inline hex colors in JSX.** Use `var(--accent)`, `var(--border)`, etc.
- **No new custom table/form components.** Use `EntityDataTable`, `CrudDialog`.

---

## Design Tokens (quick ref)

```
Fonts:   DM Sans (UI), DM Mono (data/mono)
Colors:  var(--bg), var(--bg-pane), var(--border), var(--text-primary), var(--text-muted)
         var(--accent), var(--accent-dark), var(--danger)
Badges:  .badge-green  .badge-blue  .badge-orange  .badge-red
Radius:  var(--radius-sm) = 4px   var(--radius) = 8px
Heights: header 48px, pane-tabbar 32px, statusbar 24px, button 26px
Font sizes (px): section-label 9.5, table-body 12, body 13, detail-title 18, kpi-value 22
```

---

## Auth

```ts
import { authMiddleware } from "@repo/auth/tanstack/middleware";
import { $getUser } from "@repo/auth/tanstack/functions";
import { authQueryOptions } from "@repo/auth/tanstack/queries";
```

`VITE_BASE_URL` in `.env` must match the running dev server URL.

---

## Deep Dives (load only when needed)

| Topic                                      | File                                    |
| ------------------------------------------ | --------------------------------------- |
| TanStack routes, loaders, server functions | `.agents/tanstack-patterns.md`          |
| Auth guards, login flow                    | `.agents/auth.md`                       |
| RLS, withTenant, multi-tenant isolation    | `.agents/tenant-context.md`             |
| DB schema, migrations                      | `.agents/schema.md`                     |
| Metadata fields, effective views           | `.agents/01_metadata_spec.md`           |
| Workspace panels, routing model            | `.agents/02_workspace_architecture.md`  |
| TypeScript edge cases                      | `.agents/typescript.md`                 |
| Implementation patterns / SOPs             | `.agents/04_implementation_patterns.md` |

---

<!-- fallow:setup-hooks:start -->

## Fallow local gate

Before any `git commit` or `git push`, run `fallow audit --format json --quiet --explain`. If the verdict is `fail`, fix the reported findings before retrying. Treat JSON runtime errors like `{ "error": true, ... }` as non-blocking.

Audit defaults to `gate=new-only`: only findings introduced by the current changeset affect the verdict. Inherited findings on touched files are reported under `attribution` and annotated with `introduced: false`, but do not block the commit. Set `[audit] gate = "all"` in `fallow.toml` to gate every finding in changed files.

<!-- fallow:setup-hooks:end -->
