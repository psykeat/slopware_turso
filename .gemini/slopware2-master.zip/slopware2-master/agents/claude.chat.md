▐▛███▜▌ Claude Code v2.1.133
▝▜█████▛▘ Sonnet 4.6 · Claude Pro
▘▘ ▝▝ ~/slopwarev2/new

✻ Conversation compacted (ctrl+o for history)

⎿  Read apps/web/src/features/workspace/views/settings/settings-main-view.tsx (251 lines)
⎿  Referenced file apps/web/src/features/workspace/workspace.tsx
⎿  Read apps/web/src/features/workspace/view-resolver.tsx (100 lines)
⎿  Read apps/web/src/features/workspace/views/meta/meta-admin-view.tsx (257 lines)
⎿  Read apps/web/src/features/workspace/views/meta/meta-registry-view.tsx (77 lines)
⎿  Skills restored (to-prd, grill-me)

● Let me check what legacy files exist to clean up.

Searched for 6 patterns, read 1 file, listed 1 directory (ctrl+o to expand)

● No active imports. Deleting the four legacy files now.

● Bash(rm /home/joerg/slopwarev2/new/apps/web/src/features/workspace/views/list-
view.tsx \
 /home/joerg/slopwarev2/new/apps/web/src/features/workspace/views/detail
-v…)
⎿  Done

● Bash(rmdir /home/joerg/slopwarev2/new/apps/web/src/features/workspace/componen
ts/admin \

      /home/joerg/slopwarev2/new/apps/web/src/features/workspace/components…)

⎿  done

● Now update the agent documentation with the new view convention rule.

Read 1 file (ctrl+o to expand)

● Update(.agents/04_implementation_patterns.md)
⎿  Added 20 lines
32  
 33 Legacy-Pfade (manuelle `ListView` in `workspace.tsx`) sind entf
ernt und dürfen nicht wieder eingeführt werden.
34  
 35 +## View Convention (Convention over Configuration)  
 36 +  
 37 +Jeder adressierbare View folgt dem Muster `[prefix]:[suffix]` → + Datei `views/[prefix]/[prefix]-[suffix]-view.tsx`.  
 38 +  
 39 +Beispiele:  
 40 +- `document:lines` → `views/document/document-lines-view.tsx`  
 41 +- `meta:admin` → `views/meta/meta-admin-view.tsx`  
 42 +- `settings:main` → `views/settings/settings-main-view.tsx`  
 43 +  
 44 +**Regeln:**  
 45 +1. Die Datei muss einen `export default`-React-Komponenten habe
+n (kein Named Export).  
 46 +2. State wird ausschließlich über `useWorkspaceContext()` bezog
+en — keine Props.  
 47 +3. Die `VIEW_REGISTRY` (`view-registry.ts`) unterscheidet `kind
         +: "generic" | "custom" | "dashboard"`:  
 48 + - `generic`: Kein File — der `GenericView`-Fallback in `view
         +-resolver.tsx` rendert `EntityDataTable` direkt.  
 49 + - `custom`: File ist **Pflicht** — fehlende Datei wirft eine
+n Startup-Fehler.  
 50 + - `dashboard`: Spezialfall, derzeit inline in `workspace.tsx
         +`.  
 51 +4. Neue View anlegen → Datei in `views/[prefix]/` erstellen, Ei
+ntrag in `VIEW_REGISTRY` hinzufügen — `workspace.tsx` bleibt un
+verändert.  
 52 +  
 53 +Wenn du `[prefix]:[suffix]` in einem Snapshot siehst, liegt die + Datei **garantiert** unter `views/[prefix]/[prefix]-[suffix]-v
         +iew.tsx`.  
 54 +  
 55 ## Registry-Verantwortung
56  
 57 - **Domain Registry** (`ENTITY_REGISTRY`): Fachliche Wahrheit —
Tabelle, Scope, Capabilities, CRUD-Fähigkeit

● Now run a final lint check to confirm everything is clean.

● Bash(pnpm lint 2>&1 | tail -30)
⎿   :
^^^|^^^
:
… +21 lines (ctrl+o to expand)
⎿  (timeout 2m)

● Only the pre-existing TS2554 in server-functions.ts — no new errors. The
deleted files caused no regressions.

Cleanup complete:

- Deleted 4 legacy files: components/admin/admin-system-view.tsx,
  components/settings/settings-view.tsx, views/list-view.tsx,
  views/detail-view.tsx (plus their now-empty directories)
- Updated .agents/04_implementation_patterns.md with the View Convention
  section — agents now know that [prefix]:[suffix] always maps to
  views/[prefix]/[prefix]-[suffix]-view.tsx

The refactor is fully done. Adding a new view now means: create
views/[prefix]/[prefix]-[suffix]-view.tsx with a default export that uses
useWorkspaceContext(), add an entry to VIEW_REGISTRY — workspace.tsx stays
untouched.

✻ Churned for 17m 50s

❯ update @.agents/00_core_architecture.md and @.agents/03_design_rules.md to  
 reflect these changes  
 ⎿  Read .agents/00_core_architecture.md (266 lines)
⎿  Read .agents/03_design_rules.md (83 lines)

● Update(.agents/00_core_architecture.md)
⎿  Added 19 lines, removed 1 line
134  
 135 Kerninvarianten: adressierbare split-panel Workspaces (1–3 Pan
es), URL-/Search-Param-getriebener State (bookmarkbar, reload-
stabil), Inter-Panel-Navigation über Intents, Mutationen nur ü
ber Commands. Generic UI (`ListPanelAdapter`, `DetailPanelAdap
           ter`, Grid `components/grid/`) ist Leitprinzip — Spezialpanels
sind begründungspflichtige Ausnahmen. Mehrsprachigkeit über J
SONB `{de, en}` in Metadaten-Labels und `i18n-string`-Feldtyp.
136  
 137 -→ Vollständige Spezifikation: `.agents/02_workspace_architectu
          -re.md`  
 137 +### View-Routing (Convention over Configuration)  
 138  
 139 +Views folgen einer strikten Dateikonvention. Der View-Key `[pr
          +efix]:[suffix]` leitet den Dateipfad deterministisch ab:  
 140 +  
 141 +`                                                           
      142 +views/[prefix]/[prefix]-[suffix]-view.tsx                     
      143 +`  
 144 +  
 145 +Beispiele: `document:lines` → `views/document/document-lines-v
          +iew.tsx`, `meta:admin` → `views/meta/meta-admin-view.tsx`.  
 146 +  
 147 +Schlüsselmodule:  
 148 +- **`view-registry.ts`** — `VIEW_REGISTRY` mit Feldern `key`, +`kind: "generic"|"custom"|"dashboard"`, `entity?`, `panelType?
          +` und Labels  
 149 +- **`view-resolver.tsx`** — löst `key → React.ReactNode` per `
          +import.meta.glob`; wirft Startup-Fehler für fehlende `kind: "c
          +ustom"`-Dateien; rendert `EntityDataTable` generisch für `kind
          +: "generic"`  
 150 +- **`workspace-context.tsx`** — `WorkspaceContext` + `useWorks
          +paceContext()`; ersetzt Prop-Drilling in allen View-Komponente
+n  
 151 +- **`workspace-presets.ts`** — Workspace-Presets (Layout, Pane
+s) ausgelagert aus `workspace.tsx`  
 152 +  
 153 +Alle Custom-Views sind `export default`-Komponenten ohne Props
+; State kommt ausschließlich über `useWorkspaceContext()`.  
 154 +  
 155 +→ Vollständige Spezifikation: `.agents/02_workspace_architectu
          +re.md`, Implementierungsregeln: `.agents/04_implementation_pat
          +terns.md`  
 156 +  
 157 ## 8. Schichtenmodell
158  
 159 ### 8.1 App-Schicht

● Update(.agents/03_design_rules.md)
⎿  Added 5 lines, removed 3 lines
62 ## 🚦 Routing & State Invarianten
63  
 64 1. **Hash-Format**: `#ws=<workspaceId>&pane1=<viewKey>&pane2=..
          .`
65 -2. **Registry-First**: Jede View MUSS in der `VIEW_REGISTRY` re
-gistriert sein.  
 66 -3. **Intent-Dispatch**: Navigation zwischen Panels erfolgt via -`ctx.dispatchIntent({ action: 'openRecord', ... })`.  
 67 -4. **i18n-Only**: Absolutes Verbot von Inline-Strings. Nutze `t
         -(key)`. Domain-Labels kommen direkt aus der Registry (`label_de
         -` / `label_en`).  
 65 +2. **Registry-First**: Jede View MUSS in `view-registry.ts` (`V
         +IEW_REGISTRY`) registriert sein. Die Registry unterscheidet `ki
         +nd: "generic" | "custom" | "dashboard"`.  
 66 +3. **View-Datei-Konvention**: Für `kind: "custom"` muss die Dat
+ei `views/[prefix]/[prefix]-[suffix]-view.tsx` existieren (`exp
         +ort default`, keine Props). Fehlende Dateien werfen einen Start
+up-Fehler. Für `kind: "generic"` ist keine Datei nötig — `view-
         +resolver.tsx` rendert `EntityDataTable` generisch.  
 67 +4. **WorkspaceContext**: Views dürfen keinen State als Props em
+pfangen. Workspace-State (selektierte Zeilen, Sprache, Filter,
+Toast) kommt ausschließlich über `useWorkspaceContext()` aus `w
         +orkspace-context.tsx`.  
 68 +5. **Intent-Dispatch**: Navigation zwischen Panels erfolgt via +`ctx.dispatchIntent({ action: 'openRecord', ... })`.  
 69 +6. **i18n-Only**: Absolutes Verbot von Inline-Strings. Nutze `t
         +(key)`. Domain-Labels kommen direkt aus der Registry (`label_de
         +` / `label_en`).  
 70  
 71 ## 🚫 Hard Don'ts (Sofortiger Fehler)
72

● Both files updated:

- 00_core_architecture.md §7: Added a "View-Routing" subsection documenting
  the [prefix]:[suffix] → file convention, and naming all four new modules
  (view-registry.ts, view-resolver.tsx, workspace-context.tsx,
  workspace-presets.ts) with their roles.
- 03_design_rules.md Routing rules: Expanded from 4 to 6 rules — rule 2 now
  names view-registry.ts and the kind enum, rule 3 states the file convention
  and startup assertion, rule 4 mandates useWorkspaceContext() over props.

✻ Cooked for 41s

❯ wie können wir die doku vereinfachen das die entwicklung für ki coder wie  
 dich eindeutiger wird? weniger architektur nehm ich an?

● Meine ehrliche Einschätzung: Das Problem ist nicht primär die Menge, sondern
das Format.

Was mir als KI wenig hilft:

- Prinzipien-Listen (K1–K16) — ich weiß warum Multi-Tenancy wichtig ist, ich
  brauche den konkreten Call
- Prosa-Architektur — "Die Domain-Schicht enthält..." sagt mir nicht, welche
  Datei ich öffnen soll
- Verteilt über 6+ Dateien — ich lese nur was ich explizit lade

Was mir tatsächlich hilft:

- Konkrete Dateipfade + Exports: import { withTenant } from
  "packages/domain/src/runtime/tenant-runtime"
- Entscheidungsbäume: "Neue Liste? → EntityDataTable. Custom Logik? → Custom
  View nach Convention"
- Anti-Patterns explizit benannt: "NICHT ListView selbst bauen"
- Rezepte: "Neue Entity in 5 Schritten"

Mein Vorschlag: Ein einziges AGENT.md (oder CLAUDE.md-Erweiterung) das
ausschließlich aus:

1. Modul-Map (Datei → Zweck, eine Zeile pro Eintrag)
2. Golden Paths als nummerierte Schritt-Listen
3. Entscheidungstabellen ("Aufgabe → Komponente → Pfad")
4. Constraint-Liste (die K-Regeln komprimiert auf 5–8 Zeilen)

Die tiefe Architektur-Prosa in 00_core_architecture.md würde dabei auf
Referenz degradiert — nur laden wenn wirklich nötig.

Willst du das so angehen? Ich würde die bestehenden Docs nicht löschen,
sondern CLAUDE.md als primären Einstiegspunkt für Agenten umschreiben — die
Detaildocs bleiben als Nachschlagewerk.

✻ Baked for 19s
❯ ja

● Let me read the current CLAUDE.md and key files to get accurate paths before
rewriting.

Searched for 1 pattern, read 1 file, listed 4 directories (ctrl+o to expand)

● Now I have everything I need. Rewriting CLAUDE.md from scratch.

● Write(CLAUDE.md)
⎿  Added 136 lines, removed 139 lines
1 -# Slopware — Claude Guide  
 1 +# Slopware — Agent Guide  
 2  
 3 -Multi-tenant ERP platform. pnpm monorepo. TanStack Start + Rea
-ct + Vite. PostgreSQL 16+. Better Auth. Drizzle ORM. Tailwind
-v4 + custom `--sw-*` design system.  
 3 +Multi-tenant ERP. pnpm monorepo. TanStack Start + React + Vite
+. PostgreSQL 16+. Better Auth. Drizzle ORM.  
 4  
 5 ---
6  
 7 -## Packages  
 8 -  
 9 -| Path | Purpose

- |  
   10 -| ---------------------- | -----------------------------------
  -------------------------- |  
   11 -| `apps/web` | TanStack Start app (routes, UI, ser
  -ver functions) |  
   12 -| `packages/auth` | Better Auth config, client, tanstac
  -k helpers |  
   13 -| `packages/db` | Drizzle schema, migrations, DB clie
  -nt, effective\_\* views |  
   14 -| `packages/ui` | shadcn/ui components, Tailwind base - |  
   15 -| `packages/domain` | Domain logic: queries, commands, en
  -tities, metadata, lookups |  
   16 -| `packages/api` | HTTP handlers: entity, command, loo
  -kup, metadata endpoints |  
   17 -| `packages/shared` | Shared workspace types, schemas, co
  -decs |  
   18 -| `packages/integration` | Integration service: connectors, JW
  -T, crypto |  
   19 -  
   20 ----  
   21 -  
   7 ## Dev Commands
  8  
   9 `bash
       25 -sh dev.sh              # Start everything (PostgreSQL + migrat
          -ions + all dev servers)                                       
       26 -sh dev.sh web          # Start only the web app               
       27 -pnpm lint              # Type-check + lint (prefer over buildi
          -ng)                                                           
       28 -pnpm db generate       # Generate Drizzle migration           
       29 -pnpm db migrate        # Run pending migrations               
       30 -vp check               # Format, lint, and type-check via Vite
          -+ (use before committing)                                     
       31 -vp fmt                 # Format only (runs automatically on co
          -mmit)                                                         
       32 -vp test                # Run tests                            
       33 -vp install             # Install dependencies (run after pulli
          -ng remote changes)                                            
       10 +sh dev.sh          # Start everything (PostgreSQL + migrations
          + + all servers)                                               
       11 +sh dev.sh web      # Web app only                             
       12 +pnpm lint          # Typecheck + lint                         
       13 +vp check           # Format + lint + typecheck (run before com
          +mitting)                                                      
       14 +vp test            # Run tests (packages/domain/src/__tests__/
          +)                                                             
       15 +pnpm db generate   # Generate Drizzle migration               
       16 +pnpm db migrate    # Run pending migrations                   
       17  `
  18  
   36 -Don't run `pnpm build` unless debugging bundler/production iss
  -ues. `vp check` is the standard validation command (format + l
  -int + typecheck). `pnpm lint` runs typecheck only. Formatting
  -runs automatically on commit via Oxfmt pre-commit hooks. Tests - exist in `packages/domain/src/__tests__/` — run with `vp test
          -`.  
   37 -  
   19 ---
  20  
   40 -## UI Components  
   21 +## Module Map  
   22  
   42 -- Add shadcn primitives: `pnpm ui add <component>`  
   43 -- UI icons: `lucide-react` — always use `Icon` suffix (e.g. `i
          -mport { Loader2Icon } from "lucide-react"`)  
   44 -- Brand icons: `@icons-pack/react-simple-icons` (e.g. `SiGithu
          -b`)  
   45 -- Package versions: use shared pnpm catalog via `catalog:` in -`package.json`  
   23 +### Backend / Domain  
   24  
   47 ----  
   25 +| File | What it gives you |  
   26 +|------|-------------------|  
   27 +| `packages/domain/src/runtime/tenant-runtime.ts` | `withTenan
          +t(tenantId, fn)`, `SYSTEM_ORG_ID`, `BASE_TENANT_ID` |  
   28 +| `packages/domain/src/entities/registry.ts` | `ENTITY_REGISTR
          +Y` — the authoritative entity map |  
   29 +| `packages/domain/src/queries/entity-read-service.ts` | `list
          +Entity`, `getEntityById` |  
   30 +| `packages/domain/src/commands/entity-command-service.ts` | `
          +createEntity`, `patchEntity`, `deleteEntity`, `deactivateEntit
          +y` |  
   31 +| `packages/domain/src/metadata/effective-service.ts` | `getEf
          +fectiveFields`, `getEffectiveLayout` |  
   32 +| `packages/domain/src/lookups/helper-table-service.ts` | `lis
          +tHelperTables`, `getHelperTableItems` |  
   33 +| `packages/db/src/index.ts` | `db` — Drizzle client |  
   34  
   49 -## App Structure  
   35 +### Server Functions (UI → Server bridge)  
   36  
   51 -`                                                           
       52 -apps/web/src/                                                 
       53 -  routes/                                                     
       54 -    __root.tsx              # HTML shell, ThemeProvider, TanSt
          -ack Devtools                                                  
       55 -    index.tsx               # Auth guard → workspace (/ requir
          -es auth → /login)                                             
       56 -    _auth/                  # Protected layout (beforeLoad che
          -cks session)                                                  
       57 -      route.tsx                                               
       58 -      app/index.tsx         # Workspace at /app               
       59 -    _guest/                 # Guest-only layout (redirects aut
          -hed users to /)                                               
       60 -      route.tsx             # Imports workspace.css, uses sw- 
          -design system                                                 
       61 -      login.tsx                                               
       62 -      signup.tsx                                              
       63 -    api/auth/$.ts           # Better Auth handler             
       64 -  features/                                                   
       65 -    workspace/              # Main workspace UI (sw- CSS desig
          -n system)                                                     
       66 -      workspace.tsx         # Top-level component — accepts us
          -er + onSignOut props                                          
       67 -      pane.tsx              # Split-pane container            
       68 -      registry.ts           # WORKSPACES, ENTITY_REGISTRY, VIE
          -W_REGISTRY, THEMES                                            
       69 -      workspace.css         # All --sw-* design tokens + compo
          -nent styles                                                   
       70 -      i18n.ts               # DE/EN translations              
       71 -      mock-data.ts          # Prototype data (replace with ser
          -ver functions)                                                
       72 -      metadata-renderers.ts # Converts effective_fields → Grid
          -Root columns / form fields                                    
       73 -      components/           # Panel adapters and grid         
       74 -        grid/               # GridRoot, GridTable, GridToolbar
          -, GridSearch, GridFooter, GridPagination                      
       75 -        list-panel-adapter.tsx                                
       76 -        detail-panel-adapter.tsx                              
       77 -        lines-panel-adapter.tsx                               
       78 -        crud-dialog.tsx                                       
       79 -      views/                # list-view, detail-views, kpi-vie
          -w, tree-view, etc.                                            
       80 -  server/                   # All $serverFunctions (*.server.t
          -s or this dir)                                                
       81 -    server-functions.ts     # Shared server function utilities
       82 -    adapters.ts             # DB/external adapters            
       83 -    context.ts              # Request context helpers         
       84 -`  
   37 +All live in `apps/web/src/server/server-functions.ts`. Named w
  +ith `Fn` suffix.  
   38  
   86 ----  
   39 +| Function | Purpose |  
   40 +|----------|---------|  
   41 +| `listEntityFn` | List any registered entity |  
   42 +| `getEntityFn` | Get single record by ID |  
   43 +| `createEntityFn` | Create record via domain command |  
   44 +| `updateEntityFn` | Patch record via domain command |  
   45 +| `deleteEntityFn` | Delete/deactivate record |  
   46 +| `getEffectiveFieldsFn` | Fetch metadata-driven field definit
  +ions |  
   47 +| `lookupHelperTableFn` | Fetch lookup values for dropdowns |
  48 +| `listDocumentsFn` / `listDocumentTreeFn` | Document-specific + queries |  
   49  
   88 -## Routing Conventions  
   50 +Auth helpers (note `$` prefix, not `Fn`): `$getUser`, `authMid
          +dleware` from `packages/auth/src/tanstack/`.  
   51  
   90 -- `_auth/**` — protected; `beforeLoad` redirects unauthenticat
  -ed users to `/login`  
   91 -- `_guest/**` — guest-only; `beforeLoad` redirects authenticat
  -ed users to `/`  
   92 -- `/` — workspace (auth-guarded via `beforeLoad`, not `_auth`
  -layout)  
   93 -- Workspace state lives in search params: `?ws=dashboard&p=pan
          -e1view,view2|pane2view&lang=de`  
   52 +### Workspace UI  
   53  
   95 ----  
   54 +| File | What it gives you |  
   55 +|------|-------------------|  
   56 +| `features/workspace/registry.tsx` | `ENTITY_REGISTRY` (UI si
  +de), `ICONS` map |  
   57 +| `features/workspace/view-registry.ts` | `VIEW_REGISTRY` — al
  +l addressable views |  
   58 +| `features/workspace/view-resolver.tsx` | `resolveView(key)`
  +— renders view by key |  
   59 +| `features/workspace/workspace-context.tsx` | `useWorkspaceCo
          +ntext()` — all workspace state |  
   60 +| `features/workspace/workspace-presets.ts` | Workspace layout + definitions |  
   61 +| `features/workspace/i18n.ts` | `t(key, lang)` — translation
  +function |  
   62 +| `features/workspace/metadata-renderers.ts` | `effective_fiel
          +ds` → grid columns / form fields |  
   63  
   97 -## Auth  
   64 +### UI Components  
   65  
   99 -- Config: `packages/auth/src/auth.ts` (Better Auth, Drizzle ad
  -apter)  
   100 -- Client: `packages/auth/src/auth-client.ts` (use in event han
  -dlers / effects only)  
   101 -- Server queries: `packages/auth/src/tanstack/functions.ts` → -`$getUser`  
   102 -- Query options: `packages/auth/src/tanstack/queries.ts` → `au
          -thQueryOptions()`  
   103 -- Middleware: `packages/auth/src/tanstack/middleware.ts` → `au
          -thMiddleware` (apply to ALL protected server functions)  
   104 -- Social providers (GitHub, Google) are optional — only regist
  -ered when env vars are set  
   105 -- `VITE_BASE_URL` must match the actual running dev server URL - (set in `.env`)  
   66 +| Task | Component | Path |  
   67 +|------|-----------|------|  
   68 +| Tabular list | `EntityDataTable` | `components/data-table/en
          +tity-data-table.tsx` |  
   69 +| Create / edit record | `CrudDialog` | `components/crud-dialo
          +g.tsx` |  
   70 +| Standard list pane | `ListPanelAdapter` | `components/panels
          +/list-panel-adapter.tsx` |  
   71 +| Standard detail pane | `DetailPanelAdapter` | `components/pa
          +nels/detail-panel-adapter.tsx` |  
   72 +| Sub-positions / lines | `LinesPanelAdapter` | `components/pa
          +nels/lines-panel-adapter.tsx` |  
   73  
   107 ----  
   74 +**Never build custom table or form implementations.** Use the
  +components above.  
   75  
   109 -## Design System  
   110 -  
   111 -The workspace uses a self-contained CSS design system scoped t
  -o `.sw-root`:  
   112 -  
   113 -- All tokens are `--sw-*` CSS variables (accent, bg, border, t
  -ext, fonts, spacing)  
   114 -- Components: `.sw-btn`, `.sw-datagrid`, `.sw-pane`, `.sw-head
          -er`, `.sw-statusbar`, etc.  
   115 -- Dark mode: `[data-dark="true"]` on `.sw-root`  
   116 -- Fonts: DM Sans (UI), DM Mono (mono)  
   117 -- **Do not use shadcn/Tailwind classes inside `.sw-root`** — u
  -se `--sw-*` vars and `sw-` classes  
   118 -  
   76 ---
  77  
   121 -## TypeScript  
   78 +## Decision Table  
   79  
   123 -- No type casting (`as`, manual generics, `satisfies`) — infer - from source  
   124 -- Generic params prefixed with `T` (e.g. `TArgs`, `TReturn`, `
          -TData`)  
   125 -- Server functions: auth/loader helpers use `$` prefix (e.g. `
          -$getUser`); domain server functions in `server-functions.ts` u
  -se `Fn` suffix (e.g. `listEntityFn`, `createEntityFn`)  
   126 -- Static imports only for server functions — never dynamic imp
  -orts  
   80 +| What do you need? | Use |  
   81 +|-------------------|-----|  
   82 +| Show a list of records | `EntityDataTable` + `listEntityFn`
  +|  
   83 +| Create / edit any entity | `CrudDialog` (reads `effective_fi
          +elds` automatically) |  
   84 +| Add a workspace view with no custom logic | `kind: "generic"
          +` entry in `VIEW_REGISTRY` — no file needed |  
   85 +| Add a workspace view with custom logic | New file `views/[pr
          +efix]/[prefix]-[suffix]-view.tsx`, `kind: "custom"` in registr
  +y |  
   86 +| Read workspace state in a view | `useWorkspaceContext()` — n
  +ever props |  
   87 +| Write a server function | `createServerFn` + `authMiddleware
          +` in `server-functions.ts` |  
   88 +| Query data in a component | `useQuery` wrapping a `*Fn` serv
  +er function |  
   89 +| Mutate data in a component | `useMutation` wrapping a `*Fn`
  +server function |  
   90 +| Add a new entity to the system | See Golden Path below |  
   91  
   92 ---
  93  
   130 -## Database / Domain Rules (summary)  
   94 +## Golden Paths  
   95  
   132 -- PostgreSQL is source of truth — no alternative persistence f
  -or core objects  
   133 -- All tenant-scoped tables require RLS + `tenant_id` index  
   134 -- Frontend/backend consume only `effective_*` views — never ra
  -w metadata tables  
   135 -- AI writes only via domain commands, never raw SQL  
   136 -- `SYSTEM_ORG_ID`: `00000000-0000-0000-0000-000000000001`  
   137 -- `BASE_TENANT_ID`: `00000000-0000-0000-0000-000000000002`  
   96 +### New workspace view  
   97  
   139 ----  
   98 +1. Decide `kind`:  
   99 + - Just a table of a registered entity → `kind: "generic"`,
  +add entry to `VIEW_REGISTRY`, done.  
   100 + - Custom UI → create `views/[prefix]/[prefix]-[suffix]-view
          +.tsx`  
   101 +2. Custom view file: `export default function MyView() { ... }
          +` — no props, use `useWorkspaceContext()` for state  
   102 +3. Add entry to `VIEW_REGISTRY` in `view-registry.ts` with `ki
          +nd: "custom"`  
   103 +4. If the view needs a workspace slot, add it to the preset in + `workspace-presets.ts`  
   104  
   141 -## TanStack Patterns  
   105 +Key `document:lines` → file `views/document/document-lines-vie
          +w.tsx` (prefix = folder, suffix = rest of filename).  
   106  
   143 -### Data Fetching  
   107 +### New entity (full stack)  
   108  
   145 -Always wrap server functions in TanStack Query — never call th
  -em directly from loaders. Use `context.queryClient.ensureQuery
          -Data(xyzQueryOptions())` in loaders. → `.agents/tanstack-patte
          -rns.md`  
   109 +1. **DB**: Add table with `tenant_id`, RLS policy, `tenant_id` + index → `pnpm db generate && pnpm db migrate`  
   110 +2. **Domain registry**: Add to `packages/domain/src/entities/r
          +egistry.ts`  
   111 +3. **Metadata**: Seed default fields in `tenant_fields` via mi
  +gration or seed script  
   112 +4. **Queries / Commands**: Add to `packages/domain/src/queries
          +/` and `commands/` if non-generic logic needed  
   113 +5. **UI**: Add entry to `features/workspace/registry.tsx` (ENT
  +ITY*REGISTRY) with `category`, `group`, `icon`, labels  
   114 +6. **Workspace view**: Generic → VIEW_REGISTRY only. Custom →
  +new view file  
   115  
   147 -### Server Functions  
   116 +### New server function  
   117  
   149 -- Domain server functions use `Fn` suffix, live in `apps/web/s
          -rc/server/` or `*.server.ts`files; auth helpers use`$`prefi
-x  
 150 -- Always static imports — never dynamic  
 151 -- Apply`authMiddleware`to every protected server function, e
-ven inside`_auth`routes  
 152 - →`.agents/tanstack-patterns.md`  
 118 +`ts  
   119 +// apps/web/src/server/server-functions.ts  
   120 +export const myThingFn = createServerFn({ method: "POST", stri
  +ct: false })  
   121 + .middleware([authMiddleware])  
   122 + .validator(z.object({ ... }))  
   123 + .handler(async ({ data, context }) => {  
   124 + return withTenant(context.tenantId, async (sql) => {  
   125 + // domain logic here  
   126 + });  
   127 + });  
   128 +` 
 129  
 154 -### Environment Shaking  
 130 +---  
 131  
 156 -Code inside`createServerFn`handlers → server bundle only. Co
-de outside → both bundles. Server-only imports (db, fs) must s
-tay inside handlers or`*.server.ts`files.  
 132 +## Hard Constraints  
 133  
 158 -### TanStack Docs  
 134 +- **PostgreSQL is source of truth.** No alternative persistenc
+e for core objects.  
 135 +- **All tenant-scoped tables need RLS +`tenant_id`index.** N
+o exceptions.  
 136 +- **Never read raw metadata tables.** Only`effective*_` views
          +/functions.                                                   
      137 +- **Never write raw SQL from AI or UI.** Use domain commands (
          +`createEntity`, `patchEntity`, etc.).                         
      138 +- **No hard delete for master data.** Use `deactivateEntity`. 
      139 +- **`authMiddleware`on every protected server function.** Eve
          +n inside`\_auth`routes.                                      
      140 +- **Static imports only** for server functions — never dynamic
          + imports.                                                     
      141 +- **No shadcn/Tailwind inside`.sw-root`.** Use `var(--sw-\_)`
          +CSS variables and`sw-`classes.                              
      142 +- **No inline hex colors in JSX.** Use`var(--accent)`, `var(-
  +-border)`, etc.                                               
      143 +- **No new custom table/form components.** Use `EntityDataTabl
  +e`, `CrudDialog`.                                             
      144  
      160 -Use `pnpm tanstack`to look up documentation. Always pass`--j
  -son`:                                                         
      145 +---                                                           
      146  
      162 -```bash                                                       
      163 -pnpm tanstack doc <lib> <path> [--docs-version v5] --json     
      164 -pnpm tanstack search-docs "<query>" [--library <lib>] [--frame
          -work react] --json                                            
      147 +## Design Tokens (quick ref)                                  
      148 +                                                              
      149  ```
      150 +Fonts:   DM Sans (UI), DM Mono (data/mono)                    
      151 +Colors:  var(--bg), var(--bg-pane), var(--border), var(--text-
          +primary), var(--text-muted)                                   
      152 +         var(--accent), var(--accent-dark), var(--danger)     
      153 +Badges:  .badge-green  .badge-blue  .badge-orange  .badge-red 
      154 +Radius:  var(--radius-sm) = 4px   var(--radius) = 8px         
      155 +Heights: header 48px, pane-tabbar 32px, statusbar 24px, button
          + 26px                                                         
      156 +Font sizes (px): section-label 9.5, table-body 12, body 13, de
          +tail-title 18, kpi-value 22                                   
      157 +```                                                           
      158  
      159  ---
      160  
      169 -## Detailed Specs                                             
      161 +## Auth                                                       
      162  
      171 -Load only when working in the relevant domain:                
      163 +```ts                                                         
      164 +import { authMiddleware } from "@repo/auth/tanstack/middleware
          +";                                                            
      165 +import { $getUser } from "@repo/auth/tanstack/functions";     
      166 +import { authQueryOptions } from "@repo/auth/tanstack/queries"
          +;                                                             
      167 +```                                                           
      168  
      173 -| Task                                   | Load               
          -                    |                                         
      174 -| -------------------------------------- | -------------------
          -------------------- |                                         
      175 -| New route, loader, server function     | `tanstack-patterns.
  -md`                |                                         
      176 -| Auth guards, middleware, login flow    |`auth.md`         
          -                    |                                         
      177 -| RLS, SET LOCAL, multi-tenant isolation |`tenant-context.md`          -                    |                                         
      178 -| DB schema, migrations, domain model    |`schema.md`, `00*co
  -re_architecture.md`|                                         
      179 -| Metadata fields, effective views       |`01_metadata_spec.m
  -d`                 |                                         
      180 -| Workspace panels, routing model        |`02_workspace_archi
  -tecture.md`        |                                         
      181 -| Generic entity CRUD, ListPanelAdapter  |`03_generic_entity*
  -crud.md`           |                                         
      182 -| Tenant switcher UI                     |`tenant-switcher.md -`                  |                                         
      183 -| Statistics module                      |`10*statistics_modu
  -le.md`             |                                         
      184 -| TypeScript edge cases                  |`typescript.md`   
          -                    |                                         
      185 -| Recurring implementation patterns      |`04_implementation*
  -patterns.md`        |                                         
      169 +`VITE*BASE_URL`in`.env`must match the running dev server UR
          +L.                                                            
      170  
      187 -All files live in`.agents/`.                                 
      171 +---                                                           
      172  
      173 +## Deep Dives (load only when needed)                         
      174 +                                                              
      175 +| Topic | File |                                              
      176 +|-------|------|                                              
      177 +| TanStack routes, loaders, server functions | `.agents/tansta
  +ck-patterns.md`|                                             
      178 +| Auth guards, login flow |`.agents/auth.md`|               
      179 +| RLS, withTenant, multi-tenant isolation |`.agents/tenant-co
  +ntext.md`|                                                   
      180 +| DB schema, migrations |`.agents/schema.md`|               
      181 +| Metadata fields, effective views |`.agents/01_metadata_spec
  +.md`|                                                        
      182 +| Workspace panels, routing model |`.agents/02_workspace_arch
  +itecture.md`|                                                
      183 +| TypeScript edge cases |`.agents/typescript.md`|           
      184 +| Implementation patterns / SOPs |`.agents/04_implementation*
  +patterns.md` |  
   185 +  
   186 ---
  187  
   188 <!-- fallow:setup-hooks:start -->

● Done. What changed and why:

Removed:

- K1–K16 architecture principles (compressed to 10 one-liner constraints)
- Prose descriptions of layers and modules
- Redundant package table (kept only what I actually reference)
- The "Detailed Specs" load-table got slimmed — referenced only docs that
  still exist and matter

Added:

- Module map with actual file paths and exported symbols — no more guessing
- Decision table — "what do you need → what to use", no prose
- Three golden paths as numbered steps (new view, new entity, new server
  function) — copy-paste-ready
- Server function template — concrete code, not description
- Design tokens quick-ref — copy-paste values instead of "consult the design
  doc"

The philosophical docs (00_core_architecture.md, 03_design_rules.md) stay as
reference but are no longer loaded by default. The agent now starts with the
map, not the manifesto.

✻ Crunched for 1m 17s
