# documents & document_line — Aktuelle Implementierung

## 1. Datenbanktabellen (Drizzle-Schema: `packages/db/src/schema/transaction.ts`)

### 1.1 `document_type`

| Spalte                  | Typ          | Beschreibung                                            |
| ----------------------- | ------------ | ------------------------------------------------------- |
| `document_type_id`      | uuid (PK)    |                                                         |
| `tenant_id`             | uuid         | RLS, FK → tenant                                        |
| `code`                  | varchar(20)  | N, A, L, R, G, b, l, r, g, V, Z, E, U (+ q, p reserved) |
| `name`                  | varchar(100) | Deutscher Name                                          |
| `movement_type`         | char(1)      | CHECK-Constraint: erlaubte Codes                        |
| `next_document_type_id` | uuid         | Wandlungsziel (N→A→L→R, b→l→r)                          |
| `requires_warehouse`    | boolean      |                                                         |
| `requires_cost_center`  | boolean      |                                                         |
| `is_active`             | boolean      |                                                         |
| `sort_order`            | integer      |                                                         |

**Unique**: (tenant_id, code)

### 1.2 `number_sequence`

| Spalte               | Typ         | Beschreibung                                                               |
| -------------------- | ----------- | -------------------------------------------------------------------------- |
| `number_sequence_id` | uuid (PK)   |                                                                            |
| `tenant_id`          | uuid        | RLS                                                                        |
| `company_id`         | uuid        |                                                                            |
| `prefix`             | varchar(10) | ANG-, AUF-, LIS-, RE-, GU-, BES-, WEL-, WER-, WEG-, INV-, ZUB-, ENT-, UMB- |
| `document_type`      | char(1)     | Verknüpfung zu document_type.code                                          |
| `next_value`         | integer     | Zähler                                                                     |
| `padding`            | integer     | 5 (default)                                                                |

**Unique**: (tenant_id, company_id, document_type)

### 1.3 `document_group`

| Spalte                       | Typ         | Beschreibung            |
| ---------------------------- | ----------- | ----------------------- |
| `document_group_id`          | uuid (PK)   |                         |
| `tenant_id`                  | uuid        | RLS                     |
| `company_id`                 | uuid        | nullable FK             |
| `name`                       | varchar     |                         |
| `document_type`              | varchar(1)  |                         |
| `group_number`               | integer     | CHECK 0-99              |
| `direction`                  | varchar(20) | outbound, inbound, null |
| `next_group_id`              | uuid        | Wandlungsvorschlag      |
| `default_warehouse_id`       | uuid        |                         |
| `default_tax_code_id`        | uuid        |                         |
| `default_payment_term_id`    | uuid        |                         |
| `default_shipping_method_id` | uuid        |                         |
| `require_serial_tracking`    | boolean     | default true            |
| `require_batch_tracking`     | boolean     | default true            |

**Unique**: (tenant_id, document_type, group_number)

### 1.4 `document`

| Spalte                | Typ       | Beschreibung                       |
| --------------------- | --------- | ---------------------------------- |
| `document_id`         | uuid (PK) |                                    |
| `tenant_id`           | uuid      | RLS                                |
| `company_id`          | uuid      | notNull, FK → company              |
| `document_type`       | char(1)   | CHECK-Constraint                   |
| `document_direction`  | varchar   | outbound, inbound, adjustment      |
| `document_no`         | varchar   | Format: PREFIX-00001               |
| `status`              | varchar   | draft, posted, archived, cancelled |
| `customer_id`         | uuid      | nullable                           |
| `currency_id`         | char(3)   | nullable                           |
| `document_date`       | date      | notNull                            |
| `posting_date`        | date      | nullable                           |
| `total_net`           | numeric   |                                    |
| `total_tax`           | numeric   |                                    |
| `total_gross`         | numeric   |                                    |
| `version_no`          | integer   | default 1                          |
| `posted_at`           | timestamp |                                    |
| `posted_by`           | uuid      | FK → app_user                      |
| `cancelled_at`        | timestamp |                                    |
| `storno_document_id`  | uuid      |                                    |
| `custom_attributes`   | jsonb     |                                    |
| `transaction_id`      | uuid      | notNull                            |
| `parent_document_id`  | uuid      |                                    |
| `document_group_id`   | uuid      | FK → document_group                |
| `document_type_id`    | uuid      | FK → document_type                 |
| `warehouse_id`        | uuid      |                                    |
| `target_warehouse_id` | uuid      |                                    |
| `archived_at`         | timestamp |                                    |
| `billing_address`     | jsonb     |                                    |
| `delivery_address`    | jsonb     |                                    |
| `delivery_address_id` | uuid      |                                    |
| `payment_term_id`     | uuid      |                                    |
| `shipping_method_id`  | uuid      |                                    |
| `is_paid`             | boolean   | default false                      |
| `paid_at`             | timestamp |                                    |
| `paid_amount`         | numeric   |                                    |
| `due_date`            | date      |                                    |

**Unique**: (tenant_id, company_id, document_no)

### 1.5 `document_line`

| Spalte                  | Typ         | Beschreibung                                                                   |
| ----------------------- | ----------- | ------------------------------------------------------------------------------ |
| `document_line_id`      | uuid (PK)   |                                                                                |
| `tenant_id`             | uuid        | RLS                                                                            |
| `document_id`           | uuid        | FK → document                                                                  |
| `line_no`               | integer     | notNull                                                                        |
| `article_id`            | uuid        | nullable                                                                       |
| `article_text_snapshot` | varchar     |                                                                                |
| `quantity`              | numeric     | notNull                                                                        |
| `unit`                  | varchar     |                                                                                |
| `net_price`             | numeric     | notNull                                                                        |
| `discount_percentage`   | numeric     |                                                                                |
| `tax_code_id`           | uuid        |                                                                                |
| `tax_amount`            | numeric     |                                                                                |
| `line_total_net`        | numeric     |                                                                                |
| `warehouse_id`          | uuid        |                                                                                |
| `cost_center_id`        | uuid        |                                                                                |
| `target_warehouse_id`   | uuid        |                                                                                |
| `transaction_id`        | uuid        |                                                                                |
| `movement_type`         | char(1)     |                                                                                |
| `line_type`             | varchar(20) | 'article', 'comment', 'production_output', 'production_input', 'bom_component' |

**Unique**: (tenant_id, document_id, line_no)
**CHECK**: line_type = 'comment' OR article_id IS NOT NULL

### 1.6 `document_line_tracking`

| Spalte             | Typ       | Beschreibung       |
| ------------------ | --------- | ------------------ |
| `tracking_id`      | uuid (PK) |                    |
| `tenant_id`        | uuid      | RLS                |
| `document_line_id` | uuid      | FK → document_line |
| `serial_number_id` | uuid      |                    |
| `batch_no`         | varchar   |                    |
| `qty`              | numeric   | notNull            |

**CHECK**: XOR(serial_number_id, batch_no)

### 1.7 `inventory_balance`

| Spalte                  | Typ       | Beschreibung                          |
| ----------------------- | --------- | ------------------------------------- |
| `inventory_balance_id`  | uuid (PK) |                                       |
| `tenant_id`             | uuid      | RLS                                   |
| `company_id`            | uuid      |                                       |
| `warehouse_id`          | uuid      | notNull                               |
| `article_id`            | uuid      | notNull                               |
| `on_hand_qty`           | numeric   | default 0                             |
| `reserved_qty`          | numeric   | default 0                             |
| `available_qty`         | numeric   | **MANUELL** (nicht Generated Column!) |
| `expected_purchase_qty` | numeric   | default 0                             |
| `gld_purchase`          | numeric   | gleitender Durchschnitt               |
| `gld_cost`              | numeric   |                                       |
| `as_of_at`              | timestamp |                                       |

**Unique**: (tenant_id, warehouse_id, article_id)

### 1.8 `inventory_movement`

| Spalte                    | Typ       | Beschreibung         |
| ------------------------- | --------- | -------------------- |
| `inventory_movement_id`   | uuid (PK) |                      |
| `tenant_id`               | uuid      | RLS                  |
| `company_id`              | uuid      |                      |
| `warehouse_id`            | uuid      | notNull              |
| `article_id`              | uuid      | notNull              |
| `movement_type`           | char(1)   | CHECK-Constraint     |
| `qty_delta`               | numeric   |                      |
| `absolute_qty`            | numeric   | nur für V (Inventur) |
| `movement_date`           | timestamp | notNull              |
| `source_document_id`      | uuid      |                      |
| `source_document_line_id` | uuid      |                      |
| `transaction_id`          | uuid      |                      |
| `serial_number_id`        | uuid      |                      |
| `batch_no`                | varchar   |                      |
| `reference_text`          | varchar   |                      |

**CHECK**: V ↔ absolute_qty IS NOT NULL, else qty_delta IS NOT NULL

### 1.9 `fact_sales_event`

| Spalte                    | Typ       | Beschreibung                      |
| ------------------------- | --------- | --------------------------------- |
| `fact_sales_event_id`     | uuid (PK) |                                   |
| `tenant_id`               | uuid      | RLS                               |
| `company_id`              | uuid      |                                   |
| `source_document_id`      | uuid      |                                   |
| `source_document_line_id` | uuid      |                                   |
| `customer_id`             | uuid      |                                   |
| `article_id`              | uuid      |                                   |
| `event_type`              | varchar   | 'original', 'correction'          |
| `quantity_delta`          | numeric   | notNull                           |
| `amount_net_delta`        | numeric   | notNull                           |
| `booking_period`          | date      | notNull                           |
| `fiscal_period_id`        | uuid      | FK → fiscal_period                |
| `cogs_delta`              | numeric   | COGS (Kosten des verkauften Guts) |
| `transaction_id`          | uuid      |                                   |

### 1.10 `fact_purchase_event`

| Spalte                    | Typ       | Beschreibung             |
| ------------------------- | --------- | ------------------------ |
| `fact_purchase_event_id`  | uuid (PK) |                          |
| `tenant_id`               | uuid      | RLS                      |
| `company_id`              | uuid      |                          |
| `source_document_id`      | uuid      |                          |
| `source_document_line_id` | uuid      |                          |
| `supplier_id`             | uuid      |                          |
| `article_id`              | uuid      |                          |
| `event_type`              | varchar   | 'original', 'correction' |
| `quantity_delta`          | numeric   | notNull                  |
| `amount_net_delta`        | numeric   | notNull                  |
| `avg_cost_before`         | numeric   |                          |
| `avg_cost_after`          | numeric   |                          |
| `booking_period`          | date      | notNull                  |
| `fiscal_period_id`        | uuid      |                          |
| `transaction_id`          | uuid      |                          |

### 1.11 `serial_number`

| Spalte                 | Typ       | Beschreibung                   |
| ---------------------- | --------- | ------------------------------ |
| `serial_number_id`     | uuid (PK) |                                |
| `tenant_id`            | uuid      | RLS                            |
| `article_id`           | uuid      | notNull                        |
| `serial_no`            | varchar   | notNull                        |
| `status`               | varchar   | 'in_stock', 'reserved', 'sold' |
| `created_movement_id`  | uuid      |                                |
| `consumed_movement_id` | uuid      |                                |

### 1.12 `delivery_address`

| Spalte                 | Typ       | Beschreibung  |
| ---------------------- | --------- | ------------- |
| `delivery_address_id`  | uuid (PK) |               |
| `tenant_id`            | uuid      | RLS           |
| `address_id`           | uuid      | FK → address  |
| `name`                 | varchar   |               |
| `address_line_1`       | varchar   | notNull       |
| `address_line_2`       | varchar   |               |
| `postal_code`          | varchar   | notNull       |
| `city`                 | varchar   | notNull       |
| `country_code`         | char(2)   | notNull       |
| `is_active`            | boolean   | default true  |
| `default_for_shipping` | boolean   | default false |
| `custom_attributes`    | jsonb     |               |

### 1.13 `journal_entry` + `journal_line`

Tabellen vorhanden, aber **noch nicht in posting-command integriert** (out of scope laut PRD).

---

## 2. Domain-Commands

### 2.1 `createDocument` (`packages/domain/src/commands/document-commands.ts`)

- **Transaktion**: `sql.begin()`
- **Nummernkreis**: Manuelles `SELECT ... FOR UPDATE` + `UPDATE next_value + 1` (statt PL/pgSQL-Funktion!)
- **Format**: `PREFIX-zeroPadded(nextValue)` → `ANG-00001`
- **Header-Insert**: Raw SQL, `gen_random_uuid()` für transaction_id
- **Lines-Insert**: **Sequenziell** (for-loop), nicht batch (wegen Postgres.js Numeric Handling)
- **Status**: `'draft'`

### 2.2 `updateDocument` (`packages/domain/src/commands/document-commands.ts`)

- **Guard**: Nur `status === 'draft'` erlaubt
- **Header-Update**: Dynamisches SQL (nur geänderte Felder)
- **Lines**: `DELETE FROM document_line WHERE document_id = $1` → dann neu insert
- **Berechnung**: `line_total_net = qty × price × (1 - discount/100)`, `tax_amount = lineNet × (taxCodeId ? 0.2 : 0)`
- **Totals**: `total_net`, `total_tax`, `total_gross` werden serverseitig berechnet
- **Version**: `version_no + 1`

### 2.3 `deleteDocument` (`packages/domain/src/commands/document-commands.ts`)

- **Guard**: R, r, G, g → 403 (credit memo protected)
- **Sonstige**: Direkt `DELETE FROM document` (CASCADE für document_lines)
- **Nicht in Transaktion** — einfacher DELETE

### 2.4 `convertDocument` (`packages/domain/src/commands/document-convert-storno.ts`)

- **Map**: `N→A`, `A→L`, `L→R`, `b→l`, `l→r` (hardcoded)
- **Override**: `targetGroupId` param oder `document_group.next_group_id`
- **Quellbeleg**: `status = 'archived'`, `archived_at = NOW()`
- **Zielbeleg**: Neuer Nummernkreis-Eintrag, `parent_document_id` = Quell-ID, `transaction_id` vererbt
- **Lines**: 1:1 Kopie

### 2.5 `stornoDocument` (`packages/domain/src/commands/document-convert-storno.ts`)

- **Guard**: Nur R, r + nur `status === 'posted'`
- **Storno-Typ**: R → G, r → g
- **Quellbeleg**: `status = 'cancelled'`, `cancelled_at = NOW()`
- **Storno-Beleg**: `storno_document_id` = Quell-ID, `parent_document_id` = Quell-ID
- **Lines**: 1:1 Kopie mit **positiven** Mengen

### 2.6 `postDocument` (`packages/domain/src/commands/posting-command.ts`)

**Größtes Modul** (~897 Zeilen). Komplexe Verbuchungslogik:

#### Guards

- 404: Document not found
- 409: Already posted (`posted_at IS NOT NULL`)
- 409: Fiscal period closed (für R, G, r, g)

#### Fiscal Period

- Auto-Generierung bei fehlendem Period (12 Monate, fiscal_year_start_month beachtet)
- R, G, r, g benötigen fiscal_period_id

#### Inventory-Buchung (L, b, l)

- **L** (Lieferschein): `on_hand -qty`, `inventory_movement` mit `issue`
- **b** (Bestellung): `expected_purchase +qty` (nicht reserved!)
- **l** (WE-Liefer): `on_hand +qty`, `expected_purchase -qty`
- Serial/Batch Tracking: Einzelne Movement-Einträge pro Tracking-Eintrag

#### Inventory-Adjustment (V, Z, E, U)

- **V** (Inventur): `on_hand = absolute_qty` (SET, nicht Delta!)
- **Z** (Zubuchung): `on_hand +qty`
- **E** (Entnahme): `on_hand -qty`
- **U** (Umlagerung): Zwei Einträge: Quelllager `-qty`, Ziellager `+qty`
- Guard: U → gleiche warehouse_id → 409 `SAME_WAREHOUSE`

#### Sales Event (R, G)

- `fact_sales_event` Insert mit `quantity_delta`, `amount_net_delta`, `cogs_delta`
- G: negativer Sign (correction)
- COGS: `gld_purchase × abs(qty_delta)`

#### Purchase Event (r, g)

- `fact_purchase_event` Insert
- **r**: Gleitender Durchschnitt (`gld_purchase`) Berechnung
- g: negativer Sign (correction)

#### Serial Number Tracking

- Consume (L, R, G): Status → 'sold', `consumed_movement_id` gesetzt
- Create (b, l, g, r): Status → 'in_stock', `created_movement_id` gesetzt
- G (Storno): Original-Serials zurück auf 'in_stock'

#### Due Date (R, r)

- Payment Term → `net_days` → `due_date = document_date + net_days`

#### Abschluss

- `status = 'posted'`, `posted_at = NOW()`, `posted_by = userId`
- `pg_notify('stats_refresh', tenantId)`

### 2.7 `seedDocumentDefaults` (`packages/domain/src/commands/seed-document-defaults.ts`)

- **13 Document Types**: N, A, L, R, G, b, l, r, g, V, Z, E, U
- **13 Document Groups**: Je eine "Standard"-Gruppe pro Type
- **13 Number Sequences**: Mit Präfixen und Padding=5
- **Links**: `next_document_type_id` und `next_group_id` werden nachträglich gesetzt

---

## 3. Server-Funktionen (`apps/web/src/server/server-functions.ts`)

| Funktion                   | Zeile | Methode | Beschreibung                         |
| -------------------------- | ----- | ------- | ------------------------------------ |
| `listDocumentsFn`          | 518   | GET     | Listet Dokumente mit Filterung       |
| `listDocumentTreeFn`       | 584   | GET     | Belegbaum für Sidebar                |
| `createDocumentFn`         | 1682  | POST    | Erzeugt neuen Beleg                  |
| `updateDocumentFn`         | 1723  | POST    | Aktualisiert Beleg + Lines           |
| `deleteDocumentFn`         | 1712  | POST    | Löscht Beleg                         |
| `postDocumentFn`           | 1752  | POST    | Bucht Beleg                          |
| `convertDocumentFn`        | 1775  | POST    | Wandelt Beleg                        |
| `getDocumentConvertInfoFn` | 1802  | GET     | Wandlungsinfo (Zieltyp, etc.)        |
| `stornoDocumentFn`         | 1845  | POST    | Erstellt Stornobeleg                 |
| `listDocumentTypesFn`      | 1862  | GET     | Listet Belegtypen                    |
| `listDocumentGroupsFn`     | 1885  | GET     | Listet Beleggruppen                  |
| `getCustomerDocumentsFn`   | 1978  | GET     | Kunde + letzte Belege + Jahresumsatz |

Alle mit `authMiddleware`.

---

## 4. UI-Komponenten

### 4.1 `document-lines-view.tsx` (1055 Zeilen)

**Location**: `apps/web/src/features/workspace/views/document/`

- **Lines Editor**: Tabellarischer Editor mit Artikel-Autocomplete, Menge, Preis, MwSt., Lager
- **Live-Kalkulation**: Clientseitig (netto, steuer, brutto)
- **Article Search**: `listEntityFn` mit ILIKE auf `article_no`
- **Pricing**: `resolveArticlePricingFn` → `net_price`, `tax_code_id`, `tax_rate`
- **Warehouse Dropdown**: Serverseitige Liste, clientseitiges Filtern
- **Comment Lines**: `line_type = 'comment'` (ohne Artikel)
- **Save**: `updateDocumentFn` (existing) / `createDocumentFn` (new)
- **Keyboard Navigation**: Tab durch Felder, Enter = bestätigen, Escape = abbrechen, Delete = Zeile löschen
- **Warehouse Diff Badge**: `≠` wenn Zeilen-Lager ≠ Header-Lager

### 4.2 `document-header-form.tsx`

**Location**: `apps/web/src/features/workspace/views/document/`

- Header-Felder: Belegdatum, Kunde, Währung, Beleggruppe, Lager
- Autocomplete für Kunde (Adresse + Name)
- Save: `createDocumentFn` (new) / `updateDocumentFn` (existing)
- Action Buttons: Buchen, Wandeln, Stornieren (statusabhängig)

### 4.3 `document-detail-view.tsx`

**Location**: `apps/web/src/features/workspace/views/document/`

- Split-View: Header-Form oben, Lines Editor unten
- Action-Buttons im Header

### 4.4 `document-tree-view.tsx`

**Location**: `apps/web/src/features/workspace/views/document/`

- Dreistufiger Belegbaum: Richtung → Typ → Gruppe
- `listDocumentTreeFn` für Daten
- Sidebar-Integration

### 4.5 `document-list-adapter.tsx`

**Location**: `apps/web/src/features/workspace/components/panels/`

- Belegliste mit Suche, Sortierung, Filterung
- Serverseitige Filterung nach Richtung, Typ, Gruppe

---

## 5. Abweichungen zur PRD (`plan/documents.md`)

### 5.1 Nummernkreis

| PRD                                    | Implementierung                            | Status                                                                        |
| -------------------------------------- | ------------------------------------------ | ----------------------------------------------------------------------------- |
| PL/pgSQL-Funktion `next_sequence_no()` | Manuelles SELECT FOR UPDATE + UPDATE in JS | **ABWEICHUNG**                                                                |
|                                        |                                            | Vorteil: kein DB-Deploy nötig. Risiko: kein atomarer Single-Statement-Zugriff |

### 5.2 Document Type Names

| PRD-Code | PRD-Name        | Implementierung-Name | Status           |
| -------- | --------------- | -------------------- | ---------------- |
| N        | Angebot         | Lieferschein         | **NAMENSFEHLER** |
| A        | Auftrag         | Angebot              | **NAMENSFEHLER** |
| L        | Lieferschein    | Rechnung             | **NAMENSFEHLER** |
| R        | Rechnung        | Gutschrift           | **NAMENSFEHLER** |
| G        | Gutschrift      | Gutschrift szabad    | **NAMENSFEHLER** |
| b        | Bestellung      | Beleg Einkauf        | ⚠️               |
| l        | WE-Lieferschein | Lieferschein Einkauf | ⚠️               |
| r        | WE-Rechnung     | Rechnung Einkauf     | ⚠️               |
| g        | WE-Gutschrift   | Gutschrift klein     | ⚠️               |
| V        | Inventurbuchung | Inventur             | OK               |
| Z        | Zubuchung       | Zwischeninventur     | ⚠️               |
| E        | Entnahme        | Eingang              | **NAMENSFEHLER** |
| U        | Umlagerung      | Umbuchung            | ⚠️               |

**Kritisch**: Die Namen in `seed-document-defaults.ts` sind komplett vertauscht (N=Lieferschein statt Angebot, etc.).

### 5.3 Number Sequence Prefixes

| PRD  | Implementierung | Status                       |
| ---- | --------------- | ---------------------------- |
| ANG- | AN              | **ABWEICHUNG**               |
| AUF- | LI              | **ABWEICHUNG** (vertauscht!) |
| LIS- | RE              | **ABWEICHUNG**               |
| RE-  | GU              | **ABWEICHUNG**               |
| GU-  | GS              | **ABWEICHUNG**               |
| BES- | BE              | ⚠️                           |
| WEL- | li              | ⚠️                           |
| WER- | re              | ⚠️                           |
| WEG- | gs              | ⚠️                           |
| INV- | IN              | ⚠️                           |
| ZUB- | ZI              | ⚠️                           |
| ENT- | EG              | ⚠️                           |
| UMB- | UB              | ⚠️                           |

**Kritisch**: Die Präfixe sind vertauscht (AN→Angebot, LI→Lieferschein, etc.), aber die Mapping-Logik ist inkonsistent.

### 5.4 Tax Rate Calculation

| PRD                                                                                   | Implementierung                                 | Status        |
| ------------------------------------------------------------------------------------- | ----------------------------------------------- | ------------- |
| Steuermatrix: `article.tax_class × address.tax_class × country → tax_rule → tax_rate` | `resolveArticlePricingFn` (server function)     | **PARTIELL**  |
|                                                                                       | Full matrix lookup noch nicht implementiert     | **GAP**       |
| Update-Command                                                                        | `taxRate = taxCodeId ? 0.2 : 0` (hardcoded 20%) | **HARDCODED** |

### 5.5 `available_qty`

| PRD                               | Implementierung                                | Status  |
| --------------------------------- | ---------------------------------------------- | ------- |
| Manuell gepflegt bei jedem Upsert | **Nicht gepflegt** in posting-command          | **GAP** |
|                                   | Spalte existiert, wird aber nicht aktualisiert |         |

### 5.6 Reservierung (Auftrag A)

| PRD                    | Implementierung                         | Status  |
| ---------------------- | --------------------------------------- | ------- |
| A: `reserved_qty +qty` | **NICHT implementiert**                 | **GAP** |
|                        | posting-command hat kein Handling für A |         |

### 5.7 `getNextNumber` Helper

- Separate Funktion in `posting-command.ts` (Zeile 861-897)
- Nutzt `prefix` statt `document_type` als Lookup-Schlüssel
- **Inkonsistent** mit `createDocument` (das `document_type` nutzt)

### 5.8 Payment Tracking

- Spalten `is_paid`, `paid_at`, `paid_amount`, `due_date` existieren
- `due_date` wird beim Posting von R/r gesetzt
- **Aber**: Payment-Tracking ist laut PRD out of scope → Spalten sind vorbereitet

---

## 6. Tests

| Datei                                                                                   | Beschreibung           |
| --------------------------------------------------------------------------------------- | ---------------------- |
| `packages/domain/src/__tests__/document-commands.test.ts`                               | CRUD-Tests             |
| `packages/domain/src/__tests__/document-convert-storno.test.ts`                         | Convert + Storno-Tests |
| `packages/domain/src/__tests__/posting-command.test.ts`                                 | Posting-Matrix-Tests   |
| `packages/domain/src/__tests__/seed-document-defaults.test.ts`                          | Seed-Tests             |
| `apps/web/src/features/workspace/__tests__/document-tree-view.test.ts`                  | Tree-View-Import-Tests |
| `apps/web/src/features/workspace/views/document/__tests__/document-lines-view.test.ts`  | Lines-View-Tests       |
| `apps/web/src/features/workspace/views/document/__tests__/document-header-form.test.ts` | Header-Form-Tests      |
| `apps/web/src/features/workspace/components/panels/__tests__/document-list.test.ts`     | List-Adapter-Tests     |

---

## 7. Refactor-Prioritäten

### Kritisch (P0)

1. **Document Type Names** korrigieren (seed-document-defaults.ts)
2. **Number Sequence Prefixes** korrigieren (PRD-konform)
3. **`available_qty`** in posting-command pflegen
4. **Reservierung (A)** implementieren

### Hoch (P1)

5. **Tax Rate Hardcode** (0.2) ersetzen → echte Steuermatrix
6. **Nummernkreis** vereinheitlichen (createDocument vs getNextNumber)
7. **PL/pgSQL-Funktion** evaluieren (vs. JS-Implementation)

### Mittel (P2)

8. **Naming**: `gld_purchase` → `avg_purchase_cost` (klarer)
9. **`getNextNumber`** aus posting-command entfernen (Duplikat)
10. **Production-Order** Tabelle: out of scope, kann entfernt werden
