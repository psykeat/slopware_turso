import { describe, it, expect, afterEach } from "vitest";

import { useHotkeyStore } from "../features/hotkeys/hotkey-store";

describe("hotkey-store", () => {
  afterEach(() => {
    useHotkeyStore.setState({
      scopeStack: [],
      registry: new Map(),
      inputSuppressed: false,
    });
  });

  it("pushScope adds to stack", () => {
    useHotkeyStore.getState().pushScope("layer-a");
    expect(useHotkeyStore.getState().scopeStack).toEqual(["layer-a"]);
  });

  it("peekScope returns topmost", () => {
    useHotkeyStore.getState().pushScope("layer-a");
    useHotkeyStore.getState().pushScope("layer-b");
    expect(useHotkeyStore.getState().peekScope()).toBe("layer-b");
  });

  it("popScope removes topmost matching scope", () => {
    const s = useHotkeyStore.getState();
    s.pushScope("layer-a");
    s.pushScope("layer-b");
    s.popScope("layer-b");
    expect(useHotkeyStore.getState().scopeStack).toEqual(["layer-a"]);
  });

  it("register and getTopHandlers work together", () => {
    const s = useHotkeyStore.getState();
    s.pushScope("layer-a");
    const handler = () => {};
    s.register("layer-a", { key: "j", handler, layerId: "layer-a" });
    const result = s.getTopHandlers("j");
    expect(result).toHaveLength(1);
    expect(result[0]).toBe(handler);
  });

  it("getTopHandlers only returns from topmost scope", () => {
    const s = useHotkeyStore.getState();
    s.pushScope("layer-a");
    s.pushScope("layer-b");
    const handlerA = () => {};
    const handlerB = () => {};
    s.register("layer-a", { key: "j", handler: handlerA, layerId: "layer-a" });
    s.register("layer-b", { key: "j", handler: handlerB, layerId: "layer-b" });
    expect(s.getTopHandlers("j")).toEqual([handlerB]);
  });

  it("unregister removes handler", () => {
    const s = useHotkeyStore.getState();
    s.pushScope("layer-a");
    const handler = () => {};
    s.register("layer-a", { key: "j", handler, layerId: "layer-a" });
    s.unregister("layer-a", "j");
    expect(s.getTopHandlers("j")).toHaveLength(0);
  });
});
