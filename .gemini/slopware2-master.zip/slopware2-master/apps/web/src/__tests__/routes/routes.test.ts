import { describe, it, expect } from "vitest";

describe("Route structure", () => {
  it("root route exists and exports Route", async () => {
    // @ts-expect-error dynamic route import
    const mod = await import("../index");
    expect(mod.Route).toBeDefined();
  });

  it("auth layout route exists and exports Route", async () => {
    // @ts-expect-error dynamic route import
    const mod = await import("../_auth+/route");
    expect(mod.Route).toBeDefined();
  });

  it("guest layout route exists and exports Route", async () => {
    // @ts-expect-error dynamic route import
    const mod = await import("../_guest/route");
    expect(mod.Route).toBeDefined();
  });
});

describe("Admin routes", () => {
  it("admin index route exists", async () => {
    // @ts-expect-error dynamic route import
    const mod = await import("../_auth+/admin/index");
    expect(mod.Route).toBeDefined();
  });

  it("admin users route exists", async () => {
    // @ts-expect-error dynamic route import
    const mod = await import("../_auth+/admin/users");
    expect(mod.Route).toBeDefined();
  });

  it("admin organizations route exists", async () => {
    // @ts-expect-error dynamic route import
    const mod = await import("../_auth+/admin/organizations");
    expect(mod.Route).toBeDefined();
  });

  it("admin tenants route exists", async () => {
    // @ts-expect-error dynamic route import
    const mod = await import("../_auth+/admin/tenants");
    expect(mod.Route).toBeDefined();
  });

  it("admin companies route exists", async () => {
    // @ts-expect-error dynamic route import
    const mod = await import("../_auth+/admin/companies");
    expect(mod.Route).toBeDefined();
  });

  it("admin integration route exists", async () => {
    // @ts-expect-error dynamic route import
    const mod = await import("../_auth+/admin/integration");
    expect(mod.Route).toBeDefined();
  });

  it("admin layout route exists", async () => {
    // @ts-expect-error dynamic route import
    const mod = await import("../_auth+/admin/route");
    expect(mod.Route).toBeDefined();
  });
});

describe("Guest routes", () => {
  it("login route exists", async () => {
    // @ts-expect-error dynamic route import
    const mod = await import("../_guest/login");
    expect(mod.Route).toBeDefined();
  });

  it("signup route exists", async () => {
    // @ts-expect-error dynamic route import
    const mod = await import("../_guest/signup");
    expect(mod.Route).toBeDefined();
  });
});

describe("App routes", () => {
  it("app index route exists", async () => {
    // @ts-expect-error dynamic route import
    const mod = await import("../_auth/app/index");
    expect(mod.Route).toBeDefined();
  });
});

describe("Root layout", () => {
  it("__root route exists", async () => {
    // @ts-expect-error dynamic route import
    const mod = await import("../__root");
    expect(mod.Route).toBeDefined();
  });
});
