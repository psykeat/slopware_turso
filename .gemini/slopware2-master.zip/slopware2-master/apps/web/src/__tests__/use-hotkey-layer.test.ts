import { describe, it, expect, beforeEach, afterEach } from "vitest";

import { useHotkeyStore } from "../features/hotkeys/hotkey-store";
import { useHotkeyLayer } from "../features/hotkeys/use-hotkey-layer";

describe("useHotkeyLayer", () => {
  beforeEach(() => {
    useHotkeyStore.setState({
      scopeStack: [],
      registry: new Map(),
      inputSuppressed: false,
    });
  });

  afterEach(() => {
    useHotkeyStore.setState({
      scopeStack: [],
      registry: new Map(),
      inputSuppressed: false,
    });
  });

  it("exports useHotkeyLayer", () => {
    expect(useHotkeyLayer).toBeDefined();
    expect(typeof useHotkeyLayer).toBe("function");
  });

  it("pushScope results in layer being on stack", () => {
    useHotkeyStore.getState().pushScope("test-layer");
    expect(useHotkeyStore.getState().scopeStack).toContain("test-layer");
    expect(useHotkeyStore.getState().peekScope()).toBe("test-layer");
  });

  it("popScope removes layer from stack", () => {
    const s = useHotkeyStore.getState();
    s.pushScope("test-layer");
    s.popScope("test-layer");
    expect(useHotkeyStore.getState().scopeStack).not.toContain("test-layer");
  });
});
