import { describe, it, expect, beforeEach, afterEach } from "vitest";

import { useHotkeyStore } from "../features/hotkeys/hotkey-store";
import { shouldSuppress } from "../features/hotkeys/use-scoped-hotkey";

describe("shouldSuppress input logic", () => {
  let activeEl: HTMLElement | null = null;

  beforeEach(() => {
    activeEl = null;
    Object.defineProperty(document, "activeElement", {
      get() {
        return activeEl;
      },
      configurable: true,
    });
  });

  afterEach(() => {
    Object.defineProperty(document, "activeElement", {
      value: document.body,
      configurable: true,
    });
    useHotkeyStore.setState({
      scopeStack: [],
      registry: new Map(),
      inputSuppressed: false,
    });
  });

  it("does not suppress when no input focused", () => {
    const ev = new KeyboardEvent("keydown", { key: "j" });
    expect(shouldSuppress("j", ev)).toBe(false);
  });

  it("suppresses bare letter when input focused", () => {
    const input = document.createElement("input");
    activeEl = input;
    const ev = new KeyboardEvent("keydown", { key: "j" });
    expect(shouldSuppress("j", ev)).toBe(true);
  });

  it("suppresses Enter when input focused", () => {
    const input = document.createElement("input");
    activeEl = input;
    const ev = new KeyboardEvent("keydown", { key: "Enter" });
    expect(shouldSuppress("Enter", ev)).toBe(true);
  });

  it("suppresses Space when input focused", () => {
    const input = document.createElement("input");
    activeEl = input;
    const ev = new KeyboardEvent("keydown", { key: " " });
    expect(shouldSuppress(" ", ev)).toBe(true);
  });

  it("does NOT suppress F-keys even when input focused", () => {
    const input = document.createElement("input");
    activeEl = input;
    const ev = new KeyboardEvent("keydown", { key: "F5" });
    expect(shouldSuppress("F5", ev)).toBe(false);
  });

  it("does NOT suppress modifier combos when input focused", () => {
    const input = document.createElement("input");
    activeEl = input;
    const ev = new KeyboardEvent("keydown", { key: "j", ctrlKey: true });
    expect(shouldSuppress("j", ev)).toBe(false);
  });

  it("does NOT suppress Alt+key when input focused", () => {
    const input = document.createElement("input");
    activeEl = input;
    const ev = new KeyboardEvent("keydown", { key: "j", altKey: true });
    expect(shouldSuppress("j", ev)).toBe(false);
  });

  it("suppresses bare digit when input focused", () => {
    const input = document.createElement("input");
    activeEl = input;
    const ev = new KeyboardEvent("keydown", { key: "1" });
    expect(shouldSuppress("1", ev)).toBe(true);
  });

  it("does not suppress Escape when input focused", () => {
    const input = document.createElement("input");
    activeEl = input;
    const ev = new KeyboardEvent("keydown", { key: "Escape" });
    expect(shouldSuppress("Escape", ev)).toBe(false);
  });
});
