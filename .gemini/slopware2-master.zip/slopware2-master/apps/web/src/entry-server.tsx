import "./telemetry";
import { createStartHandler, defaultStreamHandler } from "@tanstack/react-start/server";

export default createStartHandler({
  handler: defaultStreamHandler,
});
