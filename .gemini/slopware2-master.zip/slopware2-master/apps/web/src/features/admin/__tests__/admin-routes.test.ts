import { describe, it, expect } from "vitest";

import { t } from "../../workspace/i18n";
import type { Lang } from "../../workspace/i18n";

describe("Admin i18n messages", () => {
  const lang: Lang = "en";

  it("has dashboard messages", () => {
    expect(t("admin.dashboard.title", lang)).toBe("Admin Dashboard");
    expect(t("admin.dashboard.overview", lang)).toBe("Overview");
    expect(t("admin.dashboard.orgs", lang)).toBe("Organizations");
    expect(t("admin.dashboard.tenants", lang)).toBe("Tenants");
    expect(t("admin.dashboard.users", lang)).toBe("Users");
    expect(t("admin.dashboard.companies", lang)).toBe("Companies");
    expect(t("admin.dashboard.quickLinks", lang)).toBe("Quick Links");
  });

  it("has users messages", () => {
    expect(t("admin.users.title", lang)).toBe("User Management");
    expect(t("admin.users.search", lang)).toMatch(/search/i);
    expect(t("admin.users.name", lang)).toBe("Name");
    expect(t("admin.users.email", lang)).toBe("Email");
    expect(t("admin.users.role", lang)).toBe("Role");
    expect(t("admin.users.status", lang)).toBe("Status");
    expect(t("admin.users.active", lang)).toBe("Active");
    expect(t("admin.users.inactive", lang)).toBe("Inactive");
    expect(t("admin.users.empty", lang)).toMatch(/no.*users/i);
  });

  it("has organizations messages", () => {
    expect(t("admin.orgs.title", lang)).toBe("Organization Management");
    expect(t("admin.orgs.name", lang)).toBe("Name");
    expect(t("admin.orgs.slug", lang)).toBe("Slug");
    expect(t("admin.orgs.tenants", lang)).toBe("Tenants");
    expect(t("admin.orgs.empty", lang)).toMatch(/no.*organizations/i);
  });

  it("has tenants messages", () => {
    expect(t("admin.tenants.title", lang)).toBe("Tenant Management");
    expect(t("admin.tenants.name", lang)).toBe("Name");
    expect(t("admin.tenants.slug", lang)).toBe("Slug");
    expect(t("admin.tenants.org", lang)).toBe("Organization");
    expect(t("admin.tenants.isbase", lang)).toBe("Base");
    expect(t("admin.tenants.empty", lang)).toMatch(/no.*tenants/i);
  });

  it("has companies messages", () => {
    expect(t("admin.companies.title", lang)).toBe("Company Management");
    expect(t("admin.companies.name", lang)).toBe("Name");
    expect(t("admin.companies.code", lang)).toBe("Code");
    expect(t("admin.companies.tenant", lang)).toBe("Tenant");
    expect(t("admin.companies.empty", lang)).toMatch(/no.*companies/i);
  });

  it("has integration messages", () => {
    expect(t("admin.integration.title", lang)).toBe("Integration Configuration");
    expect(t("admin.integration.connectors", lang)).toBe("Connectors");
    expect(t("admin.integration.apikeys", lang)).toBe("API Keys");
    expect(t("admin.integration.enabled", lang)).toBe("Enabled");
    expect(t("admin.integration.disabled", lang)).toBe("Disabled");
    expect(t("admin.integration.test", lang)).toMatch(/test/i);
  });
});

describe("Admin i18n German translations", () => {
  const lang: Lang = "de";

  it("has dashboard messages in German", () => {
    expect(t("admin.dashboard.title", lang)).toBe("Admin Dashboard");
    expect(t("admin.dashboard.overview", lang)).toBe("Übersicht");
    expect(t("admin.dashboard.orgs", lang)).toBe("Organisationen");
    expect(t("admin.dashboard.users", lang)).toBe("Benutzer");
  });

  it("has users messages in German", () => {
    expect(t("admin.users.title", lang)).toBe("Benutzerverwaltung");
    expect(t("admin.users.active", lang)).toBe("Aktiv");
    expect(t("admin.users.inactive", lang)).toBe("Inaktiv");
  });

  it("has organizations messages in German", () => {
    expect(t("admin.orgs.title", lang)).toBe("Organisationsverwaltung");
  });

  it("has tenants messages in German", () => {
    expect(t("admin.tenants.title", lang)).toBe("Mandantenverwaltung");
  });

  it("has companies messages in German", () => {
    expect(t("admin.companies.title", lang)).toBe("Unternehmensverwaltung");
  });

  it("has integration messages in German", () => {
    expect(t("admin.integration.title", lang)).toBe("Integrationskonfiguration");
  });
});

describe("Admin mock data", () => {
  it("user data has required fields", () => {
    const user = {
      id: "1",
      name: "Test User",
      email: "test@example.com",
      role: "admin",
      isActive: true,
    };
    expect(user.id).toBeDefined();
    expect(user.name).toBeDefined();
    expect(user.email).toBeDefined();
    expect(user.role).toBeDefined();
    expect(user.isActive).toBeDefined();
  });

  it("organization data has required fields", () => {
    const org = {
      id: "1",
      name: "Test Org",
      slug: "test-org",
      isActive: true,
      tenantCount: 5,
    };
    expect(org.id).toBeDefined();
    expect(org.name).toBeDefined();
    expect(org.slug).toBeDefined();
    expect(org.tenantCount).toBe(5);
  });

  it("tenant data has required fields", () => {
    const tenant = {
      id: "1",
      name: "Test Tenant",
      slug: "test",
      organizationName: "Test Org",
      isActive: true,
      isBase: false,
    };
    expect(tenant.id).toBeDefined();
    expect(tenant.name).toBeDefined();
    expect(tenant.isBase).toBe(false);
  });

  it("company data has required fields", () => {
    const company = {
      id: "1",
      name: "Test Company",
      code: "TST",
      tenantName: "Test Tenant",
      isActive: true,
    };
    expect(company.id).toBeDefined();
    expect(company.code).toBe("TST");
  });

  it("connector data has required fields", () => {
    const connector = {
      id: "1",
      name: "Test Connector",
      type: "erp",
      isEnabled: true,
      lastSync: "2026-05-07",
    };
    expect(connector.id).toBeDefined();
    expect(connector.type).toBe("erp");
    expect(connector.isEnabled).toBe(true);
  });
});
