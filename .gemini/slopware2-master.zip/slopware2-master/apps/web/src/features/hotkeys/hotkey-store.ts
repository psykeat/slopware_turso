import { create } from "zustand";

export type HotkeyScope = string;

export type HotkeyHandler = (e: KeyboardEvent) => void;

export type HotkeyEntry = {
  key: string;
  handler: HotkeyHandler;
  layerId: HotkeyScope;
};

type HotkeyState = {
  scopeStack: HotkeyScope[];
  registry: Map<HotkeyScope, HotkeyEntry[]>;
  inputSuppressed: boolean;
  pushScope: (scope: HotkeyScope) => void;
  popScope: (scope: HotkeyScope) => void;
  peekScope: () => HotkeyScope | undefined;
  register: (layerId: HotkeyScope, entry: HotkeyEntry) => void;
  unregister: (layerId: HotkeyScope, key: string) => void;
  setSuppressed: (val: boolean) => void;
  getTopHandlers: (key: string) => HotkeyHandler[];
};

export const useHotkeyStore = create<HotkeyState>((set, get) => ({
  scopeStack: [],
  registry: new Map(),
  inputSuppressed: false,

  pushScope: (scope) => set((s) => ({ scopeStack: [...s.scopeStack, scope] })),

  popScope: (scope) =>
    set((s) => ({
      scopeStack: s.scopeStack.filter(
        (_, i) => !(i === s.scopeStack.length - 1 && s.scopeStack[i] === scope),
      ),
    })),

  peekScope: () => {
    const s = get().scopeStack;
    return s.length ? s[s.length - 1] : undefined;
  },

  register: (layerId, entry) =>
    set((s) => {
      const next = new Map(s.registry);
      const layer = next.get(layerId) || [];
      layer.push(entry);
      next.set(layerId, layer);
      return { registry: next };
    }),

  unregister: (layerId, key) =>
    set((s) => {
      const next = new Map(s.registry);
      const layer = next.get(layerId);
      if (layer) {
        next.set(
          layerId,
          layer.filter((e) => e.key !== key),
        );
      }
      return { registry: next };
    }),

  setSuppressed: (val) => set({ inputSuppressed: val }),

  getTopHandlers: (key) => {
    const { scopeStack, registry } = get();
    const topScope = scopeStack.length ? scopeStack[scopeStack.length - 1] : undefined;
    if (!topScope) return [];
    const layer = registry.get(topScope);
    if (!layer) return [];
    return layer.filter((e) => e.key === key).map((e) => e.handler);
  },
}));
