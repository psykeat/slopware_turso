import { useEffect } from "react";

import { useHotkeyStore, type HotkeyScope } from "./hotkey-store";

export function useHotkeyLayer(id: HotkeyScope) {
  const pushScope = useHotkeyStore((s) => s.pushScope);
  const popScope = useHotkeyStore((s) => s.popScope);
  const peekScope = useHotkeyStore((s) => s.peekScope);

  const isTop = peekScope() === id;

  useEffect(() => {
    pushScope(id);
    return () => {
      popScope(id);
    };
  }, [id, pushScope, popScope]);

  return { isTop };
}
