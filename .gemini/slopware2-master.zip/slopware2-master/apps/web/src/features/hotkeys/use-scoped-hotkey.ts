import { useEffect, useRef } from "react";

import { useHotkeyStore, type HotkeyHandler, type HotkeyScope } from "./hotkey-store";

const SUPPRESSED_KEYS = new Set([
  "Enter",
  " ",
  "Backspace",
  "Tab",
  "ArrowUp",
  "ArrowDown",
  "ArrowLeft",
  "ArrowRight",
]);

const INPUT_SELECTORS = "input, textarea, [contenteditable=true], [data-hotkey-input]";

const parseKey = (key: string) => {
  const parts = key.includes("+") ? key.split("+") : [key];
  const baseKey = parts.pop()!;
  const modifiers = parts;
  return { baseKey, modifiers };
};

const matchKey = (registered: string, e: KeyboardEvent) => {
  const { baseKey, modifiers } = parseKey(registered);
  if (e.key !== baseKey) return false;
  if (modifiers.length === 0) return true;
  if (modifiers.includes("Ctrl") && !e.ctrlKey) return false;
  if (modifiers.includes("Shift") && !e.shiftKey) return false;
  if (modifiers.includes("Alt") && !e.altKey) return false;
  return true;
};

export function shouldSuppress(key: string, e: KeyboardEvent): boolean {
  const { baseKey } = parseKey(key);
  const isFKey = baseKey.startsWith("F") && baseKey.length <= 3;
  const hasModifier = e.ctrlKey || e.altKey || e.metaKey;

  if (isFKey || hasModifier) return false;

  const el = document.activeElement;
  const isInput = el instanceof HTMLElement && el.matches(INPUT_SELECTORS);

  if (!isInput) return false;

  if (SUPPRESSED_KEYS.has(key)) return true;

  const len = key.length;
  if (len === 1 && /[a-zA-Z0-9]/.test(key)) return true;

  return false;
}

export interface UseScopedHotkeyOptions {
  /** Bypass scope stack check — fires regardless of current scope (for self-contained components) */
  global?: boolean;
}

export function useScopedHotkey(
  layerId: HotkeyScope,
  key: string,
  handler: HotkeyHandler,
  options: UseScopedHotkeyOptions = {},
) {
  const { global: isGlobal } = options;
  const handlerRef = useRef<HotkeyHandler>(handler);

  useEffect(() => {
    handlerRef.current = handler;
  }, [handler]);

  const register = useHotkeyStore((s) => s.register);
  const unregister = useHotkeyStore((s) => s.unregister);
  const peekScope = useHotkeyStore((s) => s.peekScope);

  useEffect(() => {
    register(layerId, { key, handler: handlerRef.current, layerId });
    return () => {
      unregister(layerId, key);
    };
  }, [layerId, key, register, unregister]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!isGlobal) {
        const top = peekScope();
        if (layerId !== "global" && top !== layerId) {
          return;
        }
      }
      if (!matchKey(key, e)) return;
      if (shouldSuppress(key, e)) return;
      e.preventDefault();
      handlerRef.current(e);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
    };
  }, [layerId, key, peekScope, isGlobal]);
}
