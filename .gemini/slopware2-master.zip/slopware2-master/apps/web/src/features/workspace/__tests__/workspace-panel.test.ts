import { deserializePanelState, serializePanelState } from "@repo/shared/workspace";
import { describe, it, expect } from "vitest";

describe("deserializePanelState for document-list", () => {
  it("parses document-list panel state", () => {
    const result = deserializePanelState("document-list:document");
    expect(result).not.toBeNull();
    expect(result!.type).toBe("document-list");
    expect(result!.entity).toBe("document");
  });

  it("serializes document-list panel state", () => {
    const panel = { type: "document-list", entity: "document" } as const;
    const serialized = serializePanelState(panel);
    expect(serialized).toBe("document-list:document");
  });

  it("round-trips document-list panel state", () => {
    const panel = { type: "document-list", entity: "document" } as const;
    const serialized = serializePanelState(panel);
    const deserialized = deserializePanelState(serialized);
    expect(deserialized).not.toBeNull();
    expect(deserialized!.type).toBe("document-list");
    expect(deserialized!.entity).toBe("document");
  });
});

describe("deserializePanelState existing types unchanged", () => {
  it("parses list panel", () => {
    const result = deserializePanelState("list:customers");
    expect(result!.type).toBe("list");
    expect(result!.entity).toBe("customers");
  });

  it("parses detail panel with id", () => {
    const result = deserializePanelState("detail:customers:abc-123");
    expect(result!.type).toBe("detail");
    expect(result!.entity).toBe("customers");
    if (result!.type === "detail") {
      expect(result!.id).toBe("abc-123");
    }
  });

  it("parses lines panel with parentId", () => {
    const result = deserializePanelState("lines:document:doc-42");
    expect(result!.type).toBe("lines");
    expect(result!.entity).toBe("document");
    if (result!.type === "lines") {
      expect(result!.parentId).toBe("doc-42");
    }
  });

  it("parses tree panel", () => {
    const result = deserializePanelState("tree:document");
    expect(result!.type).toBe("tree");
    expect(result!.entity).toBe("document");
  });

  it("parses kpi panel", () => {
    const result = deserializePanelState("kpi:document");
    expect(result!.type).toBe("kpi");
    expect(result!.entity).toBe("document");
  });

  it("returns null for invalid input", () => {
    expect(deserializePanelState("")).toBeNull();
    expect(deserializePanelState("unknown:type")).toBeNull();
  });
});
