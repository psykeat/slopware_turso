import { describe, it, expect } from "vitest";

import { parseServerError } from "../error-parser";

const visibleFields = ["name", "code", "price", "description"];

describe("parseServerError", () => {
  it("handles null/undefined input", () => {
    expect(parseServerError(null, visibleFields)).toEqual({
      fieldErrors: {},
      globalError: null,
      source: "fallback",
      code: null,
    });
    expect(parseServerError(undefined, visibleFields)).toEqual({
      fieldErrors: {},
      globalError: null,
      source: "fallback",
      code: null,
    });
  });

  it("parses Zod JSON array into field errors", () => {
    const raw = JSON.stringify([
      { path: ["data", "name"], message: "Required" },
      { path: ["data", "price"], message: "Must be a number" },
      { path: ["data", "unknown_field"], message: "Unexpected" },
    ]);
    const result = parseServerError(raw, visibleFields);
    expect(result.source).toBe("zod");
    expect(result.fieldErrors).toHaveProperty("name", "Required");
    expect(result.fieldErrors).toHaveProperty("price", "Must be a number");
    expect(result.fieldErrors).toHaveProperty("unknown_field", "Unexpected");
    expect(result.globalError).toBeNull();
  });

  it("falls back to globalError when no field paths match", () => {
    const raw = JSON.stringify([{ path: ["data", "unknown_field"], message: "Something wrong" }]);
    const result = parseServerError(raw, []);
    expect(result.source).toBe("zod");
    expect(result.fieldErrors).toHaveProperty("unknown_field");
    expect(result.globalError).toBeNull();
  });

  it("parses domain semicolon-separated errors", () => {
    const raw = "name: darf nicht leer sein; price: muss >= 0 sein";
    const result = parseServerError(raw, visibleFields);
    expect(result.source).toBe("domain");
    expect(result.fieldErrors).toHaveProperty("name", "darf nicht leer sein");
    expect(result.fieldErrors).toHaveProperty("price", "muss >= 0 sein");
    expect(result.globalError).toBeNull();
  });

  it("falls back to globalError for domain errors with no matching fields", () => {
    const raw = "unknown_field: something wrong; other_field: also wrong";
    const result = parseServerError(raw, []);
    expect(result.source).toBe("domain");
    expect(result.globalError).toBe(raw);
  });

  it("uses fallback source for plain string errors", () => {
    const result = parseServerError("Something went wrong", visibleFields);
    expect(result.source).toBe("fallback");
    expect(result.globalError).toBe("Something went wrong");
    expect(result.fieldErrors).toEqual({});
  });

  it("handles object with message property", () => {
    const result = parseServerError({ message: "Server error occurred" }, visibleFields);
    expect(result.globalError).toBe("Server error occurred");
    expect(result.source).toBe("fallback");
  });

  it("handles object with error property", () => {
    const result = parseServerError({ error: "Validation failed" }, visibleFields);
    expect(result.globalError).toBe("Validation failed");
  });

  it("treats JSON object string as fallback (not array)", () => {
    const raw = JSON.stringify({ error: "bad request", code: 400 });
    const result = parseServerError(raw, visibleFields);
    expect(result.source).toBe("fallback");
    expect(result.globalError).toBe(raw);
  });
});
