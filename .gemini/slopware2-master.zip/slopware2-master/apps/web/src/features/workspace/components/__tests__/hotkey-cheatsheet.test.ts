import { describe, it, expect, afterEach, vi } from "vitest";

import { useHotkeyStore } from "../../../hotkeys/hotkey-store";

describe("HotkeyCheatsheet - registry integration", () => {
  afterEach(() => {
    useHotkeyStore.setState({
      scopeStack: [],
      registry: new Map(),
      inputSuppressed: false,
    });
  });

  it("registry entries are readable for cheatsheet", () => {
    const s = useHotkeyStore.getState();
    s.register("global", { key: "?", handler: vi.fn(), layerId: "global" });
    s.register("global", { key: "Alt+I", handler: vi.fn(), layerId: "global" });

    const registry = useHotkeyStore.getState().registry;
    const globalEntries = registry.get("global");
    expect(globalEntries).toHaveLength(2);
    expect(globalEntries![0].key).toBe("?");
    expect(globalEntries![1].key).toBe("Alt+I");
  });

  it("registry groups entries by layer", () => {
    const s = useHotkeyStore.getState();
    s.register("global", { key: "?", handler: vi.fn(), layerId: "global" });
    s.register("crud-dialog", { key: "Escape", handler: vi.fn(), layerId: "crud-dialog" });

    const registry = useHotkeyStore.getState().registry;
    expect(registry.get("global")).toHaveLength(1);
    expect(registry.get("crud-dialog")).toHaveLength(1);
    expect(registry.size).toBe(2);
  });

  it("duplicate keys in same layer are tracked separately", () => {
    const s = useHotkeyStore.getState();
    s.register("global", { key: "?", handler: vi.fn(), layerId: "global" });
    s.register("global", { key: "?", handler: vi.fn(), layerId: "global" });

    const registry = useHotkeyStore.getState().registry;
    expect(registry.get("global")).toHaveLength(2);
  });

  it("unregister removes entries for cheatsheet accuracy", () => {
    const s = useHotkeyStore.getState();
    s.register("global", { key: "?", handler: vi.fn(), layerId: "global" });
    s.unregister("global", "?");

    const registry = useHotkeyStore.getState().registry;
    const globalEntries = registry.get("global");
    expect(globalEntries).toHaveLength(0);
  });
});
