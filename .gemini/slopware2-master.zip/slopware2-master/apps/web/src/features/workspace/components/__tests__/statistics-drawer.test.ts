import { describe, it, expect } from "vitest";

describe("StatisticsDrawer - entity detection logic", () => {
  it("detects address entity from context", () => {
    const ctx = {
      selectedAddress: { id: "addr-123", name: "Test Customer" },
      selectedDocument: null,
      selectedArticle: null,
      selectedArticleGroup: null,
    };

    const info = getActiveEntity(ctx);
    expect(info).not.toBeNull();
    expect(info!.type).toBe("address");
    expect(info!.id).toBe("addr-123");
  });

  it("detects article entity from context", () => {
    const ctx = {
      selectedAddress: null,
      selectedDocument: null,
      selectedArticle: { id: "art-456", name: "Widget" },
      selectedArticleGroup: null,
    };

    const info = getActiveEntity(ctx);
    expect(info).not.toBeNull();
    expect(info!.type).toBe("article");
    expect(info!.id).toBe("art-456");
  });

  it("detects document entity from context", () => {
    const ctx = {
      selectedAddress: null,
      selectedDocument: { id: "doc-789", nr: "RE-2024-001" },
      selectedArticle: null,
      selectedArticleGroup: null,
    };

    const info = getActiveEntity(ctx);
    expect(info).not.toBeNull();
    expect(info!.type).toBe("document");
    expect(info!.id).toBe("doc-789");
  });

  it("detects article_group entity from context", () => {
    const ctx = {
      selectedAddress: null,
      selectedDocument: null,
      selectedArticle: null,
      selectedArticleGroup: { id: "ag-001", name: "Electronics" },
    };

    const info = getActiveEntity(ctx);
    expect(info).not.toBeNull();
    expect(info!.type).toBe("article_group");
    expect(info!.id).toBe("ag-001");
  });

  it("returns null when no entity is selected", () => {
    const ctx = {
      selectedAddress: null,
      selectedDocument: null,
      selectedArticle: null,
      selectedArticleGroup: null,
    };

    const info = getActiveEntity(ctx);
    expect(info).toBeNull();
  });

  it("prioritizes address over other entities", () => {
    const ctx = {
      selectedAddress: { id: "addr-123", name: "Test" },
      selectedDocument: { id: "doc-789", nr: "RE-001" },
      selectedArticle: { id: "art-456", name: "Widget" },
      selectedArticleGroup: null,
    };

    const info = getActiveEntity(ctx);
    expect(info!.type).toBe("address");
  });
});

type EntityCtx = {
  selectedAddress: { id: string; name: string } | null;
  selectedDocument: { id: string; nr: string } | null;
  selectedArticle: { id: string; name: string } | null;
  selectedArticleGroup: { id: string; name: string } | null;
};

function getActiveEntity(ctx: EntityCtx) {
  if (ctx.selectedAddress && ctx.selectedAddress.id) {
    return { type: "address" as const, id: ctx.selectedAddress.id };
  }
  if (ctx.selectedDocument && ctx.selectedDocument.id) {
    return { type: "document" as const, id: ctx.selectedDocument.id };
  }
  if (ctx.selectedArticle && ctx.selectedArticle.id) {
    return { type: "article" as const, id: ctx.selectedArticle.id };
  }
  if (ctx.selectedArticleGroup && ctx.selectedArticleGroup.id) {
    return { type: "article_group" as const, id: ctx.selectedArticleGroup.id };
  }
  return null;
}
