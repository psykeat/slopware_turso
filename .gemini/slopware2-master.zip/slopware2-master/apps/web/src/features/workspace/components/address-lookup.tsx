import { useQuery } from "@tanstack/react-query";
import { Search, Edit2, X } from "lucide-react";
import { useState, useEffect, useRef } from "react";

import { searchAddressFn } from "~/server/server-functions";

interface AddressLookupProps {
  label: string;
  value: string | null; // The ID
  addressData: any; // The JSON
  onChange: (id: string | null, data: any) => void;
  lang: "de" | "en";
  placeholder?: string;
  tabIndex?: number;
}

export function AddressLookup({
  label,
  value,
  addressData,
  onChange,
  lang,
  placeholder,
  tabIndex,
}: AddressLookupProps) {
  const [query, setQuery] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [localData, setLocalData] = useState<any>(addressData || {});
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const [selectedIndex, setSelectedIndex] = useState(0);

  const { data: resultsRaw, error } = useQuery({
    queryKey: ["address-search", query],
    queryFn: async () => {
      try {
        const res = await searchAddressFn({ data: { query, limit: 50 } });
        return res;
      } catch (e) {
        console.error("Address search error:", e);
        return [];
      }
    },
    enabled: isOpen && query.length >= 1,
  });

  const results = (resultsRaw as any[]) || [];

  if (error) {
    console.error("Query error:", error);
  }

  useEffect(() => {
    setLocalData(addressData || {});
  }, [addressData]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const displayData = addressData || localData;

  const handleSelect = (addr: any) => {
    const json = {
      name: addr.company_name || `${addr.first_name || ""} ${addr.last_name || ""}`.trim(),
      companyName: addr.company_name,
      firstName: addr.first_name,
      lastName: addr.last_name,
      addressLine1: addr.address_line_1,
      addressLine2: addr.address_line_2,
      postalCode: addr.postal_code,
      city: addr.city,
      countryCode: addr.country_code,
    };
    setLocalData(json);
    onChange(addr.address_id, json);
    setIsOpen(false);
    setQuery("");
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % (results.length || 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + (results.length || 1)) % (results.length || 1));
    } else if (e.key === "Enter") {
      if (isOpen && results[selectedIndex]) {
        e.preventDefault();
        handleSelect(results[selectedIndex]);
      }
    } else if (e.key === "Escape") {
      setIsOpen(false);
    }
  };

  const handleLocalChange = (field: string, val: string) => {
    const newData = { ...localData, [field]: val };
    setLocalData(newData);
    onChange(value, newData);
  };

  const hasData = displayData && (displayData.name || displayData.addressLine1);

  return (
    <div className="sw-address-lookup flex flex-col gap-1" ref={containerRef}>
      <label className="text-[10px] font-bold tracking-wider text-gray-400 uppercase">
        {label}
      </label>

      <div className="relative">
        <div className="relative flex items-center">
          <input
            ref={inputRef}
            tabIndex={tabIndex}
            className="sw-input w-full pr-8"
            style={{ height: "28px", fontSize: "12px", background: "var(--sw-bg-pane)" }}
            placeholder={placeholder || (lang === "de" ? "Suchen..." : "Search...")}
            value={isOpen ? query : displayData?.name || displayData?.companyName || ""}
            onFocus={() => {
              setIsOpen(true);
              setQuery("");
            }}
            onChange={(e) => {
              setQuery(e.target.value);
              setIsOpen(true);
              setSelectedIndex(0);
            }}
            onKeyDown={handleKeyDown}
          />
          <Search
            size={12}
            className="pointer-events-none absolute top-2 right-2.5 text-gray-400"
          />
        </div>

        {isOpen && results.length > 0 && (
          <div
            ref={dropdownRef}
            className="absolute z-[100] mt-1 w-full overflow-auto rounded-md border bg-white shadow-xl"
            style={{ maxHeight: "300px", minWidth: "240px" }}
          >
            {results.map((r: any, idx: number) => (
              <div
                key={r.address_id}
                className={`flex cursor-pointer flex-col border-b p-2 last:border-0 hover:bg-blue-50 ${idx === selectedIndex ? "bg-blue-50/50" : ""}`}
                onClick={() => handleSelect(r)}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate text-[12px] font-bold text-gray-900">
                    {r.name || r.company_name}
                  </span>
                  <span className="mono flex-none text-[10px] font-semibold text-blue-500">
                    {r.address_no}
                  </span>
                </div>
                <div className="truncate text-[11px] text-gray-500">{r.address_line_1}</div>
                <div className="text-[10px] font-medium text-gray-400 uppercase">
                  {r.postal_code} {r.city} {r.country_code}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="group relative mt-1">
        <div
          className={`cursor-pointer rounded-sm border p-2 text-[11px] transition-colors ${isEditing ? "border-blue-300 bg-white" : "border-transparent bg-gray-50/50 hover:bg-gray-100/50"}`}
          onClick={() => !isEditing && setIsEditing(true)}
        >
          {isEditing ? (
            <div className="flex flex-col gap-2">
              <div className="mb-1 flex items-center justify-between">
                <span className="text-[9px] font-bold text-blue-500 uppercase">
                  {lang === "de" ? "Manuelle Bearbeitung" : "Manual Edit"}
                </span>
                <button
                  tabIndex={-1}
                  className="text-gray-400 hover:text-gray-600"
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsEditing(false);
                  }}
                >
                  <X size={12} />
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <input
                  tabIndex={tabIndex ? tabIndex + 0.1 : undefined}
                  className="sw-input col-span-2"
                  placeholder="Name"
                  value={localData.name || ""}
                  onChange={(e) => handleLocalChange("name", e.target.value)}
                />
                <input
                  tabIndex={tabIndex ? tabIndex + 0.2 : undefined}
                  className="sw-input col-span-2"
                  placeholder="Strasse"
                  value={localData.addressLine1 || ""}
                  onChange={(e) => handleLocalChange("addressLine1", e.target.value)}
                />
                <input
                  tabIndex={tabIndex ? tabIndex + 0.3 : undefined}
                  className="sw-input"
                  placeholder="PLZ"
                  value={localData.postalCode || ""}
                  onChange={(e) => handleLocalChange("postalCode", e.target.value)}
                />
                <input
                  tabIndex={tabIndex ? tabIndex + 0.4 : undefined}
                  className="sw-input"
                  placeholder="Ort"
                  value={localData.city || ""}
                  onChange={(e) => handleLocalChange("city", e.target.value)}
                />
              </div>
            </div>
          ) : (
            <div className="flex min-h-[48px] flex-col justify-center text-gray-600">
              {hasData ? (
                <>
                  <span className="font-bold text-gray-800">
                    {displayData.name || displayData.companyName}
                  </span>
                  <span>{displayData.addressLine1}</span>
                  <span className="text-[10px] font-medium text-gray-400 uppercase">
                    {displayData.postalCode} {displayData.city} {displayData.countryCode}
                  </span>
                </>
              ) : (
                <span className="text-gray-400 italic">
                  {lang === "de" ? "Keine Adresse ausgewählt" : "No address selected"}
                </span>
              )}

              <div className="absolute top-2 right-2 opacity-0 transition-opacity group-hover:opacity-100">
                <Edit2 size={12} className="text-gray-400" />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
