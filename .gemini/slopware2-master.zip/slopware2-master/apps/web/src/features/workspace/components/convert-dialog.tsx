import { useQuery } from "@tanstack/react-query";
import { ArrowRightCircle, X } from "lucide-react";
import { useState } from "react";

import { getDocumentConvertInfoFn } from "~/server/server-functions";

import { t, type Lang } from "../i18n";

interface ConvertDialogProps {
  documentId: string;
  lang: Lang;
  onClose: () => void;
  onConfirm: (targetGroupId?: string) => void;
}

export function ConvertDialog({ documentId, lang, onClose, onConfirm }: ConvertDialogProps) {
  const [selectedGroupId, setSelectedGroupId] = useState<string | undefined>(undefined);

  const { data: info, isLoading } = useQuery({
    queryKey: ["convert-info", documentId],
    queryFn: () => getDocumentConvertInfoFn({ data: { documentId } }),
  });

  const preselectedId = info?.nextGroupId ?? undefined;
  const effectiveGroupId = selectedGroupId !== undefined ? selectedGroupId : preselectedId;

  const handleConfirm = () => {
    onConfirm(effectiveGroupId);
  };

  if (isLoading || !info) {
    return null;
  }

  const hasGroups = info.targetGroups.length > 0;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ background: "rgba(0,0,0,0.4)" }}
    >
      <div
        className="sw-modal flex w-[420px] flex-col rounded-lg border"
        style={{ background: "var(--bg)", borderColor: "var(--border)" }}
      >
        <div
          className="flex items-center justify-between border-b px-4 py-3"
          style={{ borderColor: "var(--border)" }}
        >
          <div className="flex items-center gap-2">
            <ArrowRightCircle size={14} style={{ color: "var(--accent)" }} />
            <span className="text-sm font-semibold">{t("convert.dialog.title", lang)}</span>
          </div>
          <button onClick={onClose} className="sw-btn sw-btn-ghost sw-btn-xs" type="button">
            <X size={14} />
          </button>
        </div>

        <div className="flex flex-col gap-3 px-4 py-4">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <div
                style={{
                  fontSize: 9.5,
                  fontWeight: 700,
                  letterSpacing: 0.1,
                  textTransform: "uppercase",
                  color: "var(--text-muted)",
                }}
              >
                {t("convert.dialog.source", lang)}
              </div>
              <div style={{ fontSize: 12.5, fontWeight: 500, marginTop: 2 }}>
                {info.sourceDocNo} ({info.sourceDocType})
              </div>
            </div>
            <div>
              <div
                style={{
                  fontSize: 9.5,
                  fontWeight: 700,
                  letterSpacing: 0.1,
                  textTransform: "uppercase",
                  color: "var(--text-muted)",
                }}
              >
                {t("convert.dialog.target", lang)}
              </div>
              <div style={{ fontSize: 12.5, fontWeight: 500, marginTop: 2 }}>
                {info.targetDocType}
              </div>
            </div>
          </div>

          {hasGroups && (
            <div>
              <div
                style={{
                  fontSize: 9.5,
                  fontWeight: 700,
                  letterSpacing: 0.1,
                  textTransform: "uppercase",
                  color: "var(--text-muted)",
                  marginBottom: 4,
                }}
              >
                {t("convert.dialog.group", lang)}
              </div>
              <select
                className="sw-input w-full rounded border px-2 py-1"
                style={{
                  fontSize: 11.5,
                  borderColor: "var(--border)",
                  background: "var(--bg-card)",
                }}
                value={selectedGroupId !== undefined ? selectedGroupId : (preselectedId ?? "")}
                onChange={(e) => setSelectedGroupId(e.target.value || undefined)}
              >
                {info.targetGroups.map((g: Record<string, unknown>) => {
                  const gid = String(g.document_group_id);
                  return (
                    <option key={gid} value={gid}>
                      {String(g.group_number)} — {String(g.name)}
                    </option>
                  );
                })}
              </select>
            </div>
          )}
        </div>

        <div
          className="flex justify-end gap-2 border-t px-4 py-3"
          style={{ borderColor: "var(--border)" }}
        >
          <button
            className="sw-btn sw-btn-secondary sw-btn-xs rounded px-3 py-1 text-xs"
            onClick={onClose}
            type="button"
          >
            {t("cancel", lang)}
          </button>
          <button
            className="sw-btn sw-btn-primary sw-btn-xs rounded px-3 py-1 text-xs"
            onClick={handleConfirm}
            type="button"
          >
            {t("convert.dialog.confirm", lang)}
          </button>
        </div>
      </div>
    </div>
  );
}
