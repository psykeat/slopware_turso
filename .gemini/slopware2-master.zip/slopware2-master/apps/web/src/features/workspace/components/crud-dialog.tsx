import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Archive, X, Settings2, Plus, Eye, EyeOff, Save } from "lucide-react";
import { useCallback, useMemo, useState, useEffect, useRef, type ReactNode } from "react";

import {
  getEffectiveFieldsFn,
  createEntityFn,
  updateEntityFn,
  deleteEntityFn,
  saveTenantFieldFn,
} from "../../../server/server-functions";
import { useHotkeyLayer } from "../../hotkeys/use-hotkey-layer";
import { useScopedHotkey } from "../../hotkeys/use-scoped-hotkey";
import type { Lang } from "../i18n";
import { t } from "../i18n";
import { ENTITY_REGISTRY, ICONS } from "../registry";
import { useWorkspaceContext } from "../workspace-context";
import { parseServerError } from "./error-parser";
import { FieldRenderer } from "./form-fields";
import type { GridRow } from "./grid/grid-types";

export interface CrudDialogProps {
  mode: "create" | "edit" | "deactivate" | "delete" | null;
  entityName: string;
  row: GridRow | null;
  lang: Lang;
  onClose: () => void;
  inline?: boolean;
  childSection?: ReactNode;
}

function getIdFieldName(entityName: string): string {
  const map: Record<string, string> = {
    address: "address_id",
    article: "article_id",
    article_group: "article_group_id",
    company: "company_id",
    cost_center: "cost_center_id",
    price_list: "price_list_id",
    warehouse: "warehouse_id",
    tax_code: "tax_code_id",
    tax_class: "tax_class_id",
    document: "document_id",
    document_line: "document_line_id",
    tenant_fields: "field_id",
    payment_term: "payment_term_id",
    shipping_method: "shipping_method_id",
    discount_group: "discount_group_id",
    address_category: "category_id",
    industry: "industry_id",
    unit: "unit_id",
    gl_account: "gl_account_id",
    currency: "currency_id",
    country: "country_id",
    postal_code: "postal_code_id",
    number_sequence: "sequence_id",
    bank_account: "bank_account_id",
  };
  return map[entityName] ?? "id";
}

function getLookupTableForField(fieldName: string): string | null {
  if (fieldName.endsWith("_id")) {
    const entityName = fieldName.slice(0, -3);
    if (ENTITY_REGISTRY[entityName]) return entityName;
  }
  return null;
}

export function CrudDialog({
  mode,
  entityName,
  row,
  lang,
  onClose,
  inline = false,
  childSection,
}: CrudDialogProps) {
  const queryClient = useQueryClient();
  const { toast } = useWorkspaceContext();
  const [formValues, setFormValues] = useState<Record<string, unknown>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [serverGlobalError, setServerGlobalError] = useState<string | null>(null);
  const [isDesignMode, setIsDesignMode] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (mode && !inline) {
      const timer = setTimeout(() => {
        const firstInput = containerRef.current?.querySelector(
          "input, select, textarea",
        ) as HTMLElement;
        if (firstInput) {
          firstInput.focus();
        }
      }, 100);
      return () => clearTimeout(timer);
    }
  }, [mode, inline]);

  const idField = useMemo(() => getIdFieldName(entityName), [entityName]);

  const { data: fields = [], isLoading: isLoadingFields } = useQuery({
    queryKey: ["effective-fields", entityName],
    queryFn: () => getEffectiveFieldsFn({ data: { entityName } }),
    enabled: !!mode,
  });

  // Initialize form values from row
  useEffect(() => {
    if (row && mode === "edit") {
      const values: Record<string, unknown> = { ...row };
      // Merge custom_attributes into root for easier editing
      if (row.custom_attributes && typeof row.custom_attributes === "object") {
        Object.assign(values, row.custom_attributes);
      }

      // Handle i18n fields for display: if value is an object, extract current lang
      Object.entries(values).forEach(([key, val]) => {
        if (val && typeof val === "object" && !Array.isArray(val)) {
          const typedVal = val as Record<string, unknown>;
          if (typedVal[lang]) {
            values[key] = typedVal[lang];
          }
        }
      });

      setFormValues(values);
    } else {
      setFormValues({});
    }
    setErrors({});
    setServerGlobalError(null);
  }, [row, mode, lang]);

  useScopedHotkey(
    "crud-dialog",
    "Ctrl+Shift+F2",
    useCallback((e: KeyboardEvent) => {
      e.preventDefault();
      setIsDesignMode((prev) => !prev);
    }, []) as any,
  );

  useScopedHotkey(
    "crud-dialog",
    "Escape",
    useCallback(
      (e: KeyboardEvent) => {
        e.preventDefault();
        onClose();
      },
      [onClose],
    ) as any,
  );

  const createMutation = useMutation({
    mutationFn: (payload: Record<string, unknown>) => {
      // Split payload into base and custom_attributes
      const basePayload: Record<string, unknown> = {};
      const customAttributes: Record<string, unknown> = {};

      const baseFieldNames = fields.filter((f) => f.scope === "global").map((f) => f.fieldName);

      Object.entries(payload).forEach(([key, val]) => {
        // Handle i18n fields (like 'name' or any field that should be JSON but is received as string)
        let processedVal = val;
        const fieldDef = fields.find((f) => f.fieldName === key);
        if (
          typeof val === "string" &&
          fieldDef &&
          (fieldDef.fieldType === "jsonb" || key === "name" || key === "label")
        ) {
          processedVal = { [lang]: val };
        }

        if (baseFieldNames.includes(key) || key === idField) {
          basePayload[key] = processedVal;
        } else {
          customAttributes[key] = processedVal;
        }
      });

      if (Object.keys(customAttributes).length > 0) {
        basePayload.custom_attributes = customAttributes;
      }

      return createEntityFn({ data: { entityName, payload: basePayload } });
    },
    onSuccess: (res: any) => {
      if (res.success) {
        toast(t("list.crud.save.success", lang) || "Gespeichert");
        setServerGlobalError(null);
        queryClient.invalidateQueries({ queryKey: ["entity-list", entityName] });
        if (!inline) onClose();
      } else {
        const visibleNames = fields
          .filter((f) => f.isVisible || isDesignMode)
          .map((f) => f.fieldName);
        const parsed = parseServerError(res.error, visibleNames);
        setErrors((prev) => ({ ...prev, ...parsed.fieldErrors }));
        setServerGlobalError(parsed.globalError);
      }
    },
    onError: (err: any) => {
      const visibleNames = fields
        .filter((f) => f.isVisible || isDesignMode)
        .map((f) => f.fieldName);
      const parsed = parseServerError(err, visibleNames);
      setErrors((prev) => ({ ...prev, ...parsed.fieldErrors }));
      setServerGlobalError(parsed.globalError);
    },
  });

  const patchMutation = useMutation({
    mutationFn: (payload: Record<string, unknown>) => {
      // Split payload
      const basePayload: Record<string, unknown> = {};
      const customAttributes: Record<string, unknown> = {};

      const baseFieldNames = fields.filter((f) => f.scope === "global").map((f) => f.fieldName);

      Object.entries(payload).forEach(([key, val]) => {
        // Handle i18n fields
        let processedVal = val;
        const fieldDef = fields.find((f) => f.fieldName === key);
        if (
          typeof val === "string" &&
          fieldDef &&
          (fieldDef.fieldType === "jsonb" || key === "name" || key === "label")
        ) {
          processedVal = { [lang]: val };
        }

        if (baseFieldNames.includes(key) || key === idField) {
          basePayload[key] = processedVal;
        } else {
          customAttributes[key] = processedVal;
        }
      });

      if (Object.keys(customAttributes).length > 0) {
        basePayload.custom_attributes = customAttributes;
      }

      return updateEntityFn({
        data: {
          entityName,
          id: String(row?.[idField] ?? ""),
          payload: basePayload,
        },
      });
    },
    onSuccess: (res: any) => {
      if (res.success) {
        toast(t("list.crud.save.success", lang) || "Gespeichert");
        setServerGlobalError(null);
        queryClient.invalidateQueries({ queryKey: ["entity-list", entityName] });
        if (!inline) onClose();
      } else {
        const visibleNames = fields
          .filter((f) => f.isVisible || isDesignMode)
          .map((f) => f.fieldName);
        const parsed = parseServerError(res.error, visibleNames);
        setErrors((prev) => ({ ...prev, ...parsed.fieldErrors }));
        setServerGlobalError(parsed.globalError);
      }
    },
    onError: (err: any) => {
      const visibleNames = fields
        .filter((f) => f.isVisible || isDesignMode)
        .map((f) => f.fieldName);
      const parsed = parseServerError(err, visibleNames);
      setErrors((prev) => ({ ...prev, ...parsed.fieldErrors }));
      setServerGlobalError(parsed.globalError);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: () => deleteEntityFn({ data: { entityName, id: String(row?.[idField] ?? "") } }),
    onSuccess: () => {
      toast(t("list.crud.delete.success", lang) || "Gelöscht");
      queryClient.invalidateQueries({ queryKey: ["entity-list", entityName] });
      if (!inline) onClose();
    },
    onError: () => {
      toast(t("list.crud.delete.error", lang) || "Fehler beim Löschen");
    },
  });

  const saveFieldMutation = useMutation({
    mutationFn: (fieldData: any) => saveTenantFieldFn({ data: fieldData }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["effective-fields", entityName] });
    },
  });

  const validateLocally = useCallback(() => {
    const newErrors: Record<string, string> = {};
    let isValid = true;

    fields
      .filter((f) => f.isVisible || isDesignMode)
      .forEach((f) => {
        const val = formValues[f.fieldName];

        if (f.isRequired && (val === undefined || val === null || val === "")) {
          newErrors[f.fieldName] = t("list.crud.validation.required", lang) || "Pflichtfeld";
          isValid = false;
        }

        if (val !== undefined && val !== null && val !== "" && f.fieldType) {
          const type = f.fieldType.toLowerCase();
          const isNumeric = [
            "integer",
            "number",
            "decimal",
            "numeric",
            "real",
            "double",
            "float",
            "int",
            "smallint",
            "bigint",
          ].includes(type);

          if (isNumeric && typeof val !== "number" && isNaN(Number(val))) {
            newErrors[f.fieldName] =
              t("list.crud.validation.numeric", lang) || "Muss eine Zahl sein";
            isValid = false;
          }
        }
      });

    setErrors(newErrors);
    return isValid;
  }, [fields, isDesignMode, formValues, lang]);

  const handleSubmit = useCallback(() => {
    setErrors({});
    if (!validateLocally()) {
      toast(t("list.crud.validation.failed", lang) || "Bitte korrigieren Sie die Fehler");
      return;
    }

    if (mode === "create") {
      createMutation.mutate(formValues);
    } else if (mode === "edit" && row) {
      patchMutation.mutate(formValues);
    }
  }, [mode, row, formValues, createMutation, patchMutation, validateLocally, toast, lang]);

  useHotkeyLayer("crud-dialog");

  useScopedHotkey(
    "crud-dialog",
    "F10",
    useCallback(
      (e: KeyboardEvent) => {
        e.preventDefault();
        if (mode === "delete" || mode === "deactivate") {
          deleteMutation.mutate();
        } else {
          handleSubmit();
        }
      },
      [mode, handleSubmit, deleteMutation],
    ),
  );

  const handleFieldChange = useCallback((fieldName: string, value: unknown) => {
    setFormValues((prev) => ({ ...prev, [fieldName]: value }));
    setErrors((prev) => {
      const next = { ...prev };
      delete next[fieldName];
      return next;
    });
  }, []);

  const visibleFields = useMemo(() => {
    return fields
      .filter((f) => f.isVisible || isDesignMode)
      .map((f) => ({
        ...f,
        lookupTable: f.lookupTable || getLookupTableForField(f.fieldName),
      }))
      .sort((a, b) => (a.displayOrder ?? 0) - (b.displayOrder ?? 0));
  }, [fields, isDesignMode]);

  const isLoading =
    createMutation.isPending ||
    patchMutation.isPending ||
    deleteMutation.isPending ||
    isLoadingFields;

  if (!mode) return null;

  const title =
    mode === "create"
      ? t("list.crud.title.new", lang)
      : mode === "edit"
        ? t("list.crud.title.edit", lang)
        : t("list.crud.delete", lang);

  const content = (
    <div
      className="pane"
      ref={containerRef}
      style={{
        boxShadow: inline ? "none" : "var(--shadow-lg)",
        borderRadius: inline ? "0" : "var(--radius)",
        border: inline ? "none" : "1px solid var(--border)",
        background: "var(--bg-pane)",
        width: inline ? "100%" : isDesignMode ? "700px" : "440px",
        maxHeight: inline ? "none" : "85vh",
        transition: "width 0.2s ease-out",
      }}
      onClick={(e) => e.stopPropagation()}
    >
      {!inline && (
        <div className="pane-tabbar">
          <div className="pane-subtab active">
            <span className="icon-mark">{ICONS[ENTITY_REGISTRY[entityName]?.icon ?? "doc"]}</span>
            <span>{title}</span>
          </div>

          <div className="pane-actions">
            <button
              className="pane-action-btn"
              style={{ color: isDesignMode ? "var(--accent)" : "var(--text-muted)" }}
              onClick={() => setIsDesignMode(!isDesignMode)}
              title="Toggle Designer Mode (Ctrl+Shift+F2)"
            >
              <Settings2 size={14} />
            </button>
            <button className="pane-action-btn danger" onClick={onClose}>
              <X size={14} />
            </button>
          </div>
        </div>
      )}

      <div className="pane-body" style={{ padding: inline ? "0" : "20px" }}>
        {isLoadingFields ? (
          <div className="pane-empty">
            <div className="pane-empty-text">Lade Metadaten...</div>
          </div>
        ) : mode === "delete" || mode === "deactivate" ? (
          <div className="detail-view" style={{ padding: 0 }}>
            <p style={{ color: "var(--text-secondary)", marginBottom: "16px" }}>
              {t("list.crud.delete.confirm", lang)}
            </p>
            <div className="detail-field-label">ID</div>
            <div
              className="detail-field-value mono"
              style={{
                padding: "8px",
                background: "var(--bg)",
                borderRadius: "4px",
                border: "1px solid var(--border)",
              }}
            >
              {String(row?.[idField] ?? "N/A")}
            </div>
          </div>
        ) : (
          <div className="detail-view" style={{ padding: 0 }}>
            {visibleFields.length === 0 ? (
              <div className="pane-empty" style={{ padding: "40px 0" }}>
                <div className="pane-empty-icon" style={{ fontSize: "24px" }}>
                  ⚠️
                </div>
                <div className="pane-empty-text" style={{ color: "#ef4444", fontWeight: 600 }}>
                  {isDesignMode
                    ? "Keine Felder definiert. Designer nutzen um Felder hinzuzufügen."
                    : "Keine Felder für diese Entität konfiguriert."}
                </div>
              </div>
            ) : (
              <div className="detail-grid" style={{ gridTemplateColumns: "1fr", gap: "0" }}>
                {visibleFields.map((f) => (
                  <div
                    key={f.fieldId}
                    style={{
                      position: "relative",
                      opacity: !f.isVisible ? 0.5 : 1,
                      background: !f.isVisible
                        ? "repeating-linear-gradient(45deg, transparent, transparent 5px, var(--bg) 5px, var(--bg) 10px)"
                        : "transparent",
                      padding: isDesignMode ? "8px" : "0",
                      borderRadius: "4px",
                      border: isDesignMode ? "1px dashed var(--border)" : "none",
                      marginBottom: isDesignMode ? "8px" : "0",
                    }}
                  >
                    <FieldRenderer
                      field={f}
                      value={formValues[f.fieldName]}
                      onChange={(val) => handleFieldChange(f.fieldName, val)}
                      lang={lang}
                      error={errors[f.fieldName]}
                    />

                    {isDesignMode && (
                      <div
                        style={{
                          position: "absolute",
                          top: 2,
                          right: 2,
                          display: "flex",
                          gap: "4px",
                        }}
                      >
                        <button
                          className="btn btn-ghost btn-xs"
                          style={{
                            height: "20px",
                            padding: "0 4px",
                            background: "var(--bg-pane)",
                            border: "1px solid var(--border)",
                          }}
                          onClick={() => {
                            saveFieldMutation.mutate({
                              entityName,
                              fieldName: f.fieldName,
                              fieldType: f.fieldType,
                              isVisible: !f.isVisible,
                            });
                          }}
                        >
                          {f.isVisible ? <Eye size={12} /> : <EyeOff size={12} />}
                        </button>
                        <button
                          className="btn btn-ghost btn-xs"
                          style={{
                            height: "20px",
                            padding: "0 4px",
                            background: "var(--bg-pane)",
                            border: "1px solid var(--border)",
                          }}
                          onClick={() => {
                            const newLabel = prompt(
                              "Label (JSON):",
                              JSON.stringify(f.label || { [lang]: f.fieldName }),
                            );
                            if (newLabel) {
                              try {
                                saveFieldMutation.mutate({
                                  entityName,
                                  fieldName: f.fieldName,
                                  fieldType: f.fieldType,
                                  label: JSON.parse(newLabel),
                                });
                              } catch (e) {
                                alert("Invalid JSON");
                              }
                            }
                          }}
                        >
                          <Settings2 size={12} />
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {isDesignMode && (
              <button
                className="btn btn-secondary"
                style={{ width: "100%", marginTop: "12px", borderStyle: "dashed", height: "36px" }}
                onClick={() => {
                  const name = prompt("Feld Name (z.B. custom_info):");
                  const type = prompt("Feld Typ (varchar, integer, boolean, numeric):", "varchar");
                  if (name && type) {
                    saveFieldMutation.mutate({
                      entityName,
                      fieldName: name,
                      fieldType: type,
                      label: { [lang]: name },
                      isVisible: true,
                    });
                  }
                }}
              >
                <Plus size={14} />
                Feld hinzufügen
              </button>
            )}
          </div>
        )}
      </div>

      {childSection}

      {serverGlobalError && (
        <div
          style={{
            margin: "0 16px",
            padding: "8px 12px",
            background: "var(--bg)",
            border: "1px solid var(--danger)",
            borderRadius: "var(--radius-sm)",
            color: "var(--danger)",
            fontSize: "12px",
            lineHeight: "1.4",
          }}
        >
          <div style={{ fontWeight: 600, marginBottom: "4px" }}>
            {t("list.crud.error.banner", lang)}
          </div>
          <div style={{ opacity: 0.85 }}>{serverGlobalError}</div>
          <button
            className="btn btn-ghost"
            style={{
              marginTop: "6px",
              height: "22px",
              fontSize: "11px",
              color: "var(--danger)",
            }}
            onClick={() => setServerGlobalError(null)}
          >
            {t("list.crud.error.dismiss", lang)}
          </button>
        </div>
      )}

      <div
        style={{
          padding: "12px 16px",
          borderTop: inline ? "none" : "1px solid var(--border)",
          background: inline ? "transparent" : "var(--bg)",
          display: "flex",
          justifyContent: "flex-end",
          gap: "8px",
        }}
      >
        {!inline && (
          <button className="btn btn-secondary" onClick={onClose} disabled={isLoading}>
            {t("list.crud.cancel", lang)}
          </button>
        )}

        {mode === "delete" || mode === "deactivate" ? (
          <button
            className="btn btn-primary"
            style={{ background: "#ef4444", borderColor: "#ef4444" }}
            onClick={() => deleteMutation.mutate()}
            disabled={isLoading}
          >
            <Archive size={14} />
            {t("list.crud.delete", lang)}
          </button>
        ) : (
          <button className="btn btn-primary" onClick={handleSubmit} disabled={isLoading}>
            <Save size={14} />
            {t("list.crud.save", lang)}
          </button>
        )}
      </div>
    </div>
  );

  if (inline) return content;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      {content}
    </div>
  );
}
