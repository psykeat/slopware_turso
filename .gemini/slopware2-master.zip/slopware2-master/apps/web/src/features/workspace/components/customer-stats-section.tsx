import type { CustomerDocumentRow, CustomerYearlyRevenueRow } from "@repo/domain";
import { useQuery } from "@tanstack/react-query";
import * as React from "react";

import { getCustomerDocumentsFn, getCustomerYearlyRevenueFn } from "~/server/server-functions";

interface CustomerStatsSectionProps {
  customerId: string;
  isCustomer: boolean;
}

export function CustomerStatsSection({ customerId, isCustomer }: CustomerStatsSectionProps) {
  if (!isCustomer) {
    return null;
  }

  return (
    <div style={{ marginTop: 12 }}>
      <CustomerDocumentsTable customerId={customerId} />
      <CustomerRevenueTable customerId={customerId} />
    </div>
  );
}

function CustomerDocumentsTable({ customerId }: { customerId: string }) {
  const { data, isLoading } = useQuery({
    queryKey: ["customer-documents", customerId],
    queryFn: () => getCustomerDocumentsFn({ data: { customerId, limit: 10 } }),
    enabled: !!customerId,
  });

  const rows = (data as CustomerDocumentRow[]) ?? [];

  if (isLoading) {
    return (
      <div style={{ padding: "8px 12px", color: "var(--text-muted)", fontSize: "13px" }}>
        Lade Dokumente...
      </div>
    );
  }

  if (rows.length === 0) {
    return (
      <div style={{ padding: "8px 12px", color: "var(--text-muted)", fontSize: "13px" }}>
        Keine Dokumente
      </div>
    );
  }

  return (
    <div>
      <div
        style={{
          fontWeight: 600,
          fontSize: "12px",
          color: "var(--text-muted)",
          textTransform: "uppercase",
          marginBottom: 6,
        }}
      >
        Letzte Dokumente
      </div>
      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          fontSize: "13px",
        }}
      >
        <thead>
          <tr>
            <th style={thStyle}>Datum</th>
            <th style={thStyle}>Nr.</th>
            <th style={thStyle}>Typ</th>
            <th style={thStyle}>Status</th>
            <th style={{ ...thStyle, textAlign: "right" }}>Brutto</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.documentId}>
              <td style={tdStyle}>{r.documentDate}</td>
              <td style={tdStyle}>{r.documentNo}</td>
              <td style={tdStyle}>{r.documentType}</td>
              <td style={tdStyle}>{r.status}</td>
              <td style={{ ...tdStyle, textAlign: "right" }}>{r.totalGross.toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function CustomerRevenueTable({ customerId }: { customerId: string }) {
  const { data, isLoading } = useQuery({
    queryKey: ["customer-yearly-revenue", customerId],
    queryFn: () => getCustomerYearlyRevenueFn({ data: { customerId } }),
    enabled: !!customerId,
  });

  const rows = (data as CustomerYearlyRevenueRow[]) ?? [];

  if (isLoading) {
    return (
      <div style={{ padding: "8px 12px", color: "var(--text-muted)", fontSize: "13px" }}>
        Lade Umsatz...
      </div>
    );
  }

  if (rows.length === 0) {
    return null;
  }

  const totalNet = rows.reduce((s, r) => s + r.netAmount, 0);

  return (
    <div style={{ marginTop: 12 }}>
      <div
        style={{
          fontWeight: 600,
          fontSize: "12px",
          color: "var(--text-muted)",
          textTransform: "uppercase",
          marginBottom: 6,
        }}
      >
        Umsatz nach Jahr
      </div>
      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          fontSize: "13px",
        }}
      >
        <thead>
          <tr>
            <th style={thStyle}>Jahr</th>
            <th style={{ ...thStyle, textAlign: "right" }}>Menge</th>
            <th style={{ ...thStyle, textAlign: "right" }}>Netto</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.year}>
              <td style={tdStyle}>{r.year}</td>
              <td style={{ ...tdStyle, textAlign: "right" }}>{r.quantity.toFixed(0)}</td>
              <td style={{ ...tdStyle, textAlign: "right" }}>{r.netAmount.toFixed(2)}</td>
            </tr>
          ))}
          <tr style={{ borderTop: "2px solid var(--border)", fontWeight: 600 }}>
            <td style={tdStyle}>Gesamt</td>
            <td style={{ ...tdStyle, textAlign: "right" }}>
              {rows.reduce((s, r) => s + r.quantity, 0).toFixed(0)}
            </td>
            <td style={{ ...tdStyle, textAlign: "right", color: "var(--accent)" }}>
              {totalNet.toFixed(2)}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

const thStyle: React.CSSProperties = {
  padding: "4px 8px",
  textAlign: "left",
  borderBottom: "1px solid var(--border)",
  color: "var(--text-muted)",
  fontWeight: 600,
  fontSize: "11px",
  textTransform: "uppercase",
};

const tdStyle: React.CSSProperties = {
  padding: "4px 8px",
  borderBottom: "1px solid var(--border-subtle)",
};
