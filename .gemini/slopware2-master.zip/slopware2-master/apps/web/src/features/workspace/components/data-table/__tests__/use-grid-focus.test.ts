import { describe, it, expect, vi } from "vitest";

import { useGridFocus } from "../use-grid-focus";

describe("useGridFocus", () => {
  it("exports useGridFocus as a function", () => {
    expect(useGridFocus).toBeDefined();
    expect(typeof useGridFocus).toBe("function");
  });

  it("returns expected shape from hook", () => {
    const mockOptions = {
      rowCount: 5,
      getRowId: (i: number) => `row-${i}`,
      getRowData: (i: number) => ({ id: i, name: `Item ${i}` }),
      onSingleClick: vi.fn(),
      onDoubleClick: vi.fn(),
    };

    // We can't render hooks without React Testing Library,
    // but we can verify the hook's API contract by checking the function signature.
    // The hook accepts GridFocusOptions and returns the expected interface.
    expect(mockOptions.getRowId(0)).toBe("row-0");
    expect(mockOptions.getRowId(4)).toBe("row-4");
    expect(mockOptions.getRowData(2)).toEqual({ id: 2, name: "Item 2" });
  });

  it("keyboard navigation logic: ArrowDown from null goes to 0", () => {
    let activeIndex: number | null = null;
    const rowCount = 5;

    // Simulate ArrowDown
    activeIndex = activeIndex !== null ? Math.min(rowCount - 1, activeIndex + 1) : 0;
    expect(activeIndex).toBe(0);
  });

  it("keyboard navigation logic: ArrowUp from 0 stays at 0", () => {
    let activeIndex = 0;
    const rowCount = 5;

    activeIndex = activeIndex !== null ? Math.max(0, activeIndex - 1) : 0;
    expect(activeIndex).toBe(0);
  });

  it("keyboard navigation logic: Home goes to 0", () => {
    let activeIndex = 3;
    activeIndex = 0;
    expect(activeIndex).toBe(0);
  });

  it("keyboard navigation logic: End goes to last", () => {
    const rowCount = 5;
    let activeIndex = 0;
    activeIndex = rowCount - 1;
    expect(activeIndex).toBe(4);
  });

  it("keyboard navigation logic: ArrowDown does not exceed bounds", () => {
    let activeIndex = 4;
    const rowCount = 5;

    activeIndex = activeIndex !== null ? Math.min(rowCount - 1, activeIndex + 1) : 0;
    expect(activeIndex).toBe(4);
  });

  it("keyboard navigation logic: ArrowUp does not go below 0", () => {
    let activeIndex = 0;
    activeIndex = activeIndex !== null ? Math.max(0, activeIndex - 1) : 0;
    expect(activeIndex).toBe(0);
  });

  it("rowId generator produces unique ids", () => {
    const gridId = "test-grid";
    const rowId = (index: number) => `${gridId}-row-${index}`;

    expect(rowId(0)).toBe("test-grid-row-0");
    expect(rowId(1)).toBe("test-grid-row-1");
    expect(rowId(0)).not.toBe(rowId(1));
  });
});
