import type { Column, Table } from "@tanstack/react-table";
import { ChevronDown, ArrowUp, ArrowDown, EyeOff, Filter } from "lucide-react";
import * as React from "react";

import type { ColumnMeta } from "./data-table.types";
import type { ColumnFilter } from "./filter-types";

interface ColumnHeaderProps<TData> {
  column: Column<TData, unknown>;
  table: Table<TData>;
  label: React.ReactNode;
}

export function ColumnHeader<TData>({ column, table, label }: ColumnHeaderProps<TData>) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef<HTMLDivElement>(null);
  const isSorted = column.getIsSorted();
  const meta = column.columnDef.meta as ColumnMeta | undefined;

  const activeFilters = (table.options.meta as any)?.activeFilters as ColumnFilter[] | undefined;
  const hasFilter = activeFilters?.some((f) => f.id === column.id) ?? false;

  React.useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  const onSort = (desc: boolean) => {
    column.toggleSorting(desc);
    setOpen(false);
  };

  const onClearSort = () => {
    column.clearSorting();
    setOpen(false);
  };

  const onAddFilter = () => {
    const onFilter = (table.options.meta as any)?.onAddFilter as
      | ((columnId: string) => void)
      | undefined;
    onFilter?.(column.id);
    setOpen(false);
  };

  const onHide = () => {
    column.toggleVisibility(false);
    setOpen(false);
  };

  return (
    <div className="col-header" ref={ref} style={{ position: "relative" }}>
      <button className="col-header-btn" onClick={() => setOpen((v) => !v)} aria-expanded={open}>
        <span className="col-header-label">{label}</span>
        {isSorted ? (
          <span className="col-header-sort-icon">
            {isSorted === "asc" ? <ArrowUp size={10} /> : <ArrowDown size={10} />}
          </span>
        ) : (
          <ChevronDown size={10} className="col-header-chevron" />
        )}
        {hasFilter && <span className="col-header-filter-dot" />}
      </button>

      {open && (
        <div
          className="dropdown-menu"
          style={{ top: "100%", left: 0, right: "auto", minWidth: 140 }}
        >
          {column.getCanSort() && (
            <>
              <button
                className={`dropdown-item${isSorted === "asc" ? " active" : ""}`}
                onClick={() => onSort(false)}
              >
                <ArrowUp size={12} style={{ marginRight: 6 }} /> Aufsteigend
              </button>
              <button
                className={`dropdown-item${isSorted === "desc" ? " active" : ""}`}
                onClick={() => onSort(true)}
              >
                <ArrowDown size={12} style={{ marginRight: 6 }} /> Absteigend
              </button>
              {isSorted && (
                <button className="dropdown-item" onClick={onClearSort}>
                  Sortierung entfernen
                </button>
              )}
              <div className="dropdown-item divider" />
            </>
          )}
          {meta?.variant && (
            <button className="dropdown-item" onClick={onAddFilter}>
              <Filter size={12} style={{ marginRight: 6 }} /> Filter hinzufügen
            </button>
          )}
          {column.getCanHide() && (
            <button className="dropdown-item" onClick={onHide}>
              <EyeOff size={12} style={{ marginRight: 6 }} /> Spalte ausblenden
            </button>
          )}
        </div>
      )}
    </div>
  );
}
