import type { Table } from "@tanstack/react-table";
import { Columns3 } from "lucide-react";
import * as React from "react";

interface ColumnVisibilityDropdownProps<TData> {
  table: Table<TData>;
}

export function ColumnVisibilityDropdown<TData>({ table }: ColumnVisibilityDropdownProps<TData>) {
  const [open, setOpen] = React.useState(false);
  const ref = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [open]);

  const hiddenCount = table
    .getAllColumns()
    .filter((col) => col.getCanHide() && !col.getIsVisible()).length;

  return (
    <div ref={ref} style={{ position: "relative" }}>
      <button
        className={`btn btn-ghost btn-xs${hiddenCount > 0 ? " active" : ""}`}
        onClick={() => setOpen((v) => !v)}
        title="Spalten ein-/ausblenden"
      >
        <Columns3 size={13} />
        Spalten
        {hiddenCount > 0 && (
          <span
            className="badge badge-blue"
            style={{ marginLeft: 4, fontSize: 9, padding: "0 4px" }}
          >
            {hiddenCount}
          </span>
        )}
      </button>

      {open && (
        <div
          className="dropdown-menu"
          style={{ right: 0, left: "auto", top: "100%", minWidth: 160 }}
        >
          <div className="dropdown-section-label">Spalten anzeigen</div>
          {table
            .getAllColumns()
            .filter((col) => col.getCanHide())
            .map((col) => {
              const isVisible = col.getIsVisible();
              const label =
                typeof col.columnDef.header === "string" ? col.columnDef.header : col.id;
              return (
                <label
                  key={col.id}
                  className="dropdown-item"
                  style={{ cursor: "pointer", display: "flex", alignItems: "center", gap: 8 }}
                >
                  <input
                    type="checkbox"
                    checked={isVisible}
                    onChange={() => col.toggleVisibility()}
                    style={{ cursor: "pointer" }}
                  />
                  {label}
                </label>
              );
            })}
          {table.getAllColumns().some((col) => col.getCanHide() && !col.getIsVisible()) && (
            <>
              <div className="dropdown-item divider" />
              <button className="dropdown-item" onClick={() => table.toggleAllColumnsVisible(true)}>
                Alle einblenden
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}
