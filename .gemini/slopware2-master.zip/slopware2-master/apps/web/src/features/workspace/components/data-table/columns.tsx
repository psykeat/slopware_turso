import type { ColumnDef } from "@tanstack/react-table";
import * as React from "react";

import { resolveI18n } from "../../metadata-renderers";

export const getEntityColumns = (
  entity: string,
  t: (k: string) => string,
  lang = "de",
): ColumnDef<any, any>[] => {
  switch (entity) {
    case "company":
      return [
        { accessorKey: "company_no", header: "Nr", size: 80 },
        {
          accessorKey: "name",
          header: t("col.name"),
          cell: ({ getValue }) => resolveI18n(getValue(), lang),
        },
        { accessorKey: "city", header: t("col.city"), size: 110 },
        {
          accessorKey: "is_active",
          header: t("col.status"),
          size: 80,
          cell: ({ getValue }) => {
            const v = getValue();
            return (
              <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
                {v ? "Aktiv" : "Inaktiv"}
              </span>
            );
          },
        },
      ];
    case "address":
      return [
        { accessorKey: "address_no", header: t("addr.field.nr"), size: 80 },
        { accessorKey: "company_name", header: t("col.name") },
        { accessorKey: "city", header: t("col.city"), size: 110 },
        { accessorKey: "address_type", header: t("col.type"), size: 90 },
        {
          accessorKey: "is_active",
          header: t("col.status"),
          size: 80,
          cell: ({ getValue }) => {
            const v = getValue();
            return (
              <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
                {v ? "Aktiv" : "Inaktiv"}
              </span>
            );
          },
        },
      ];
    case "app_user":
      return [
        { accessorKey: "email", header: "Email" },
        { accessorKey: "display_name", header: t("col.name") },
        { accessorKey: "role", header: "Role", size: 100 },
        {
          accessorKey: "is_active",
          header: t("col.status"),
          size: 80,
          cell: ({ getValue }) => {
            const v = getValue();
            return (
              <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
                {v ? "Aktiv" : "Inaktiv"}
              </span>
            );
          },
        },
      ];
    case "tenant":
      return [
        {
          accessorKey: "name",
          header: t("col.name"),
          cell: ({ getValue }) => resolveI18n(getValue(), lang),
        },
        { accessorKey: "slug", header: "Slug", size: 120 },
        { accessorKey: "is_base", header: "Base", size: 60 },
        {
          accessorKey: "is_active",
          header: t("col.status"),
          size: 80,
          cell: ({ getValue }) => {
            const v = getValue();
            return (
              <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
                {v ? "Aktiv" : "Inaktiv"}
              </span>
            );
          },
        },
      ];
    case "article":
      return [
        { accessorKey: "article_no", header: t("col.artnr"), size: 90 },
        {
          accessorKey: "name",
          header: t("col.descr"),
          cell: ({ getValue }) => resolveI18n(getValue(), lang),
        },
        { accessorKey: "base_unit", header: t("col.unit"), size: 60 },
        {
          accessorKey: "is_active",
          header: t("col.status"),
          size: 80,
          cell: ({ getValue }) => {
            const v = getValue();
            return (
              <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
                {v ? "Aktiv" : "Inaktiv"}
              </span>
            );
          },
        },
      ];
    case "document":
      return [
        { accessorKey: "document_no", header: t("col.docnr"), size: 130 },
        { accessorKey: "document_type", header: t("col.type"), size: 120 },
        {
          accessorKey: "status",
          header: t("col.status"),
          size: 110,
          cell: ({ getValue }) => {
            const s = String(getValue() ?? "");
            const cls =
              s === "open" ? "badge-blue" : s === "posted" ? "badge-green" : "badge-orange";
            return <span className={`badge ${cls}`}>{s}</span>;
          },
        },
        { accessorKey: "created_at", header: t("col.date"), size: 100 },
      ];
    case "delivery":
      return [
        { accessorKey: "nr", header: t("col.delivnr"), size: 120 },
        { accessorKey: "kunde", header: t("col.recipient") },
        { accessorKey: "carrier", header: t("col.carrier"), size: 80 },
        { accessorKey: "tracking", header: t("col.tracking") },
        {
          accessorKey: "status",
          header: t("col.status"),
          size: 110,
          cell: ({ getValue }) => {
            const v = getValue() as string;
            const cls =
              v === "Zugestellt"
                ? "badge-green"
                : v === "Unterwegs"
                  ? "badge-orange"
                  : "badge-blue";
            return <span className={`badge ${cls}`}>{v}</span>;
          },
        },
      ];
    case "stock":
      return [
        { accessorKey: "nr", header: t("col.artnr"), size: 90 },
        { accessorKey: "bez", header: t("col.descr") },
        { accessorKey: "lager", header: t("col.warehouse"), size: 80 },
        { accessorKey: "bestand", header: t("col.stock"), size: 80 },
        { accessorKey: "reserviert", header: t("col.reserved"), size: 90 },
        { accessorKey: "verfuegbar", header: t("col.available"), size: 90 },
      ];
    case "ledger":
      return [
        { accessorKey: "beleg", header: t("col.docref"), size: 120 },
        { accessorKey: "datum", header: t("col.date"), size: 100 },
        { accessorKey: "konto", header: t("col.account"), size: 70 },
        { accessorKey: "text", header: t("col.bookingtext") },
        { accessorKey: "soll", header: t("col.debit"), size: 110 },
        { accessorKey: "haben", header: t("col.credit"), size: 110 },
      ];
    case "article_group":
      return [
        { accessorKey: "article_group_id", header: "ID", size: 100 },
        {
          accessorKey: "name",
          header: t("col.name"),
          cell: ({ getValue }) => resolveI18n(getValue(), lang),
        },
        {
          accessorKey: "is_active",
          header: t("col.status"),
          size: 80,
          cell: ({ getValue }) => {
            const v = getValue();
            return (
              <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
                {v ? "Aktiv" : "Inaktiv"}
              </span>
            );
          },
        },
      ];
    case "cost_center":
      return [
        { accessorKey: "code", header: "Code", size: 100 },
        {
          accessorKey: "name",
          header: t("col.name"),
          cell: ({ getValue }) => resolveI18n(getValue(), lang),
        },
        {
          accessorKey: "is_active",
          header: t("col.status"),
          size: 80,
          cell: ({ getValue }) => {
            const v = getValue();
            return (
              <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
                {v ? "Aktiv" : "Inaktiv"}
              </span>
            );
          },
        },
      ];
    case "warehouse":
      return [
        { accessorKey: "code", header: "Code", size: 100 },
        {
          accessorKey: "name",
          header: t("col.name"),
          cell: ({ getValue }) => resolveI18n(getValue(), lang),
        },
        {
          accessorKey: "is_active",
          header: t("col.status"),
          size: 80,
          cell: ({ getValue }) => {
            const v = getValue();
            return (
              <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
                {v ? "Aktiv" : "Inaktiv"}
              </span>
            );
          },
        },
      ];
    case "prodord":
      return [
        { accessorKey: "production_order_id", header: "ID", size: 80 },
        { accessorKey: "order_no", header: t("col.fanr"), size: 110 },
        { accessorKey: "status", header: t("col.status"), size: 130 },
        { accessorKey: "planned_start_date", header: t("col.start"), size: 100 },
      ];
    case "inventory_balance":
      return [
        { accessorKey: "article_id", header: "Art-ID", size: 80 },
        { accessorKey: "warehouse_id", header: "Whse-ID", size: 80 },
        { accessorKey: "on_hand_qty", header: t("col.stock"), size: 80 },
        { accessorKey: "reserved_qty", header: t("col.reserved"), size: 90 },
        { accessorKey: "available_qty", header: t("col.available"), size: 90 },
      ];
    case "payment_term":
      return [
        { accessorKey: "code", header: "Code", size: 100 },
        {
          accessorKey: "name",
          header: t("col.name"),
          cell: ({ getValue }) => resolveI18n(getValue(), lang),
        },
        {
          accessorKey: "is_active",
          header: t("col.status"),
          size: 80,
          cell: ({ getValue }) => {
            const v = getValue();
            return (
              <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
                {v ? "Aktiv" : "Inaktiv"}
              </span>
            );
          },
        },
      ];
    case "shipping_method":
      return [
        { accessorKey: "code", header: "Code", size: 100 },
        {
          accessorKey: "name",
          header: t("col.name"),
          cell: ({ getValue }) => resolveI18n(getValue(), lang),
        },
        {
          accessorKey: "is_active",
          header: t("col.status"),
          size: 80,
          cell: ({ getValue }) => {
            const v = getValue();
            return (
              <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
                {v ? "Aktiv" : "Inaktiv"}
              </span>
            );
          },
        },
      ];
    case "tax_code":
      return [
        { accessorKey: "code", header: "Code", size: 100 },
        { accessorKey: "tax_rate", header: "Satz %", size: 80 },
        { accessorKey: "description", header: "Beschreibung" },
        {
          accessorKey: "is_active",
          header: t("col.status"),
          size: 80,
          cell: ({ getValue }) => {
            const v = getValue();
            return (
              <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
                {v ? "Aktiv" : "Inaktiv"}
              </span>
            );
          },
        },
      ];
    case "gl_account":
      return [
        { accessorKey: "account_no", header: "Konto", size: 100 },
        {
          accessorKey: "name",
          header: t("col.name"),
          cell: ({ getValue }) => resolveI18n(getValue(), lang),
        },
        { accessorKey: "account_type", header: "Typ", size: 100 },
        {
          accessorKey: "is_active",
          header: t("col.status"),
          size: 80,
          cell: ({ getValue }) => {
            const v = getValue();
            return (
              <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
                {v ? "Aktiv" : "Inaktiv"}
              </span>
            );
          },
        },
      ];
    case "currency":
      return [
        { accessorKey: "code", header: "Code", size: 80 },
        {
          accessorKey: "name",
          header: t("col.name"),
          cell: ({ getValue }) => resolveI18n(getValue(), lang),
        },
        { accessorKey: "symbol", header: "Symbol", size: 60 },
        {
          accessorKey: "is_active",
          header: t("col.status"),
          size: 80,
          cell: ({ getValue }) => {
            const v = getValue();
            return (
              <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
                {v ? "Aktiv" : "Inaktiv"}
              </span>
            );
          },
        },
      ];
    case "import_batch":
      return [
        { accessorKey: "connector_label", header: t("col.connector") },
        { accessorKey: "created_at", header: t("col.date"), size: 140 },
        { accessorKey: "total_rows", header: t("col.total_rows"), size: 90 },
        { accessorKey: "error_count", header: t("col.error_count"), size: 90 },
        { accessorKey: "error_summary", header: t("col.error_summary") },
      ];
    case "country":
      return [
        { accessorKey: "iso2_code", header: "ISO2", size: 80 },
        {
          accessorKey: "name",
          header: t("col.name"),
          cell: ({ getValue }) => resolveI18n(getValue(), lang),
        },
        { accessorKey: "is_eu", header: "EU", size: 60 },
        {
          accessorKey: "is_active",
          header: t("col.status"),
          size: 80,
          cell: ({ getValue }) => {
            const v = getValue();
            return (
              <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
                {v ? "Aktiv" : "Inaktiv"}
              </span>
            );
          },
        },
      ];
    case "organization":
      return [
        {
          accessorKey: "name",
          header: t("col.name"),
          cell: ({ getValue }) => resolveI18n(getValue(), lang),
        },
        { accessorKey: "slug", header: "Slug", size: 120 },
        {
          accessorKey: "is_active",
          header: t("col.status"),
          size: 80,
          cell: ({ getValue }) => {
            const v = getValue();
            return (
              <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
                {v ? "Aktiv" : "Inaktiv"}
              </span>
            );
          },
        },
      ];
    case "postal_code":
      return [
        { accessorKey: "country_code", header: "Land", size: 60 },
        { accessorKey: "plz", header: "PLZ", size: 80 },
        { accessorKey: "city", header: "Ort" },
      ];
    case "bank_account":
      return [
        { accessorKey: "iban", header: "IBAN" },
        { accessorKey: "bic", header: "BIC" },
        { accessorKey: "bank_name", header: t("col.name") },
        {
          accessorKey: "is_default",
          header: t("col.default"),
          size: 90,
          cell: ({ getValue }) => (getValue() ? "Ja" : "Nein"),
        },
        {
          accessorKey: "is_active",
          header: t("col.status"),
          size: 80,
          cell: ({ getValue }) => {
            const v = getValue();
            return (
              <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
                {v ? "Aktiv" : "Inaktiv"}
              </span>
            );
          },
        },
      ];
    default:
      return [];
  }
};
