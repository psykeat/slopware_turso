import * as React from "react";

interface DataTableSkeletonProps {
  columnCount?: number;
  rowCount?: number;
  cellWidths?: number[];
  hasActions?: boolean;
}

export function DataTableSkeleton({
  columnCount = 5,
  rowCount = 12,
  cellWidths,
  hasActions = false,
}: DataTableSkeletonProps) {
  const cols = Array.from({ length: columnCount });
  const rows = Array.from({ length: rowCount });

  const getWidth = (i: number) =>
    cellWidths?.[i % cellWidths.length] ?? [120, 80, 160, 100, 90][i % 5];

  return (
    <div className="datagrid-wrap" aria-busy="true" aria-label="Wird geladen">
      <div className="datagrid-toolbar">
        <div className="search-wrap">
          <span className="search-icon" style={{ opacity: 0.3 }}>
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <circle cx="11" cy="11" r="8" />
              <path d="m21 21-4.35-4.35" />
            </svg>
          </span>
          <div className="skel" style={{ width: 160, height: 18, borderRadius: 4 }} />
        </div>
        <div className="skel" style={{ width: 52, height: 22, borderRadius: 4 }} />
        <div className="skel" style={{ width: 62, height: 22, borderRadius: 4 }} />
        <div style={{ marginLeft: "auto" }}>
          <div className="skel" style={{ width: 52, height: 22, borderRadius: 4 }} />
        </div>
      </div>

      <div style={{ flex: 1, overflow: "hidden" }}>
        <table className="datagrid">
          <thead>
            <tr role="row">
              {cols.map((_, i) => (
                <th key={i} style={{ width: getWidth(i) }}>
                  <div className="skel" style={{ width: "60%", height: 11, borderRadius: 3 }} />
                </th>
              ))}
              {hasActions && <th style={{ width: 60 }} />}
            </tr>
          </thead>
          <tbody>
            {rows.map((_, ri) => (
              <tr key={ri} role="row">
                {cols.map((_, ci) => (
                  <td key={ci}>
                    <div
                      className="skel"
                      style={{
                        width: `${50 + ((ri * 7 + ci * 13) % 40)}%`,
                        height: 11,
                        borderRadius: 3,
                        opacity: 1 - ri * 0.04,
                      }}
                    />
                  </td>
                ))}
                {hasActions && <td />}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="datagrid-footer">
        <div className="skel" style={{ width: 80, height: 11, borderRadius: 3 }} />
      </div>
    </div>
  );
}
