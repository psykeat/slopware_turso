import { flexRender, getCoreRowModel, useReactTable } from "@tanstack/react-table";
import { useVirtualizer } from "@tanstack/react-virtual";
import { Search, Filter, Plus, Trash2, Settings2 } from "lucide-react";
import * as React from "react";

import { ColumnHeader } from "./column-header";
import { ColumnVisibilityDropdown } from "./column-visibility-dropdown";
import type { ColumnMeta, DataTableProps } from "./data-table.types";
import { FilterBar } from "./filter-bar";
import { FilterPopover } from "./filter-popover";
import type { ColumnFilter, FilterVariant } from "./filter-types";
import { useGridFocus } from "./use-grid-focus";

export function DataTable<TData>({
  columns,
  data,
  totalCount,
  loading,
  mode = "virtual",
  state,
  onStateChange,
  onRowClick,
  onRowDoubleClick,
  onDragStart,
  onAdd,
  onEdit,
  onDelete,
  onDuplicate,
  renderHeaderActions,
  renderRowActions,
  emptyMessage = "No data found",
  gridId = "datagrid",
}: DataTableProps<TData>) {
  const tableContainerRef = React.useRef<HTMLDivElement>(null);

  // Filter popover state
  const [filterPopoverOpen, setFilterPopoverOpen] = React.useState(false);
  const [editingFilter, setEditingFilter] = React.useState<ColumnFilter | undefined>(undefined);
  const [filterAnchorColumn, setFilterAnchorColumn] = React.useState<string | undefined>(undefined);
  const filterAnchorRef = React.useRef<HTMLDivElement>(null);

  const table = useReactTable({
    data,
    columns,
    state: {
      sorting: state.sorting,
      pagination: {
        pageIndex: state.pagination.pageIndex,
        pageSize: state.pagination.pageSize,
      },
      columnVisibility: state.columnVisibility,
    },
    onSortingChange: (updater) => {
      const newSorting = typeof updater === "function" ? updater(state.sorting) : updater;
      onStateChange({ ...state, sorting: newSorting });
    },
    onColumnVisibilityChange: (updater) => {
      const newVis = typeof updater === "function" ? updater(state.columnVisibility) : updater;
      onStateChange({ ...state, columnVisibility: newVis });
    },
    getCoreRowModel: getCoreRowModel(),
    manualSorting: true,
    manualPagination: true,
    meta: {
      activeFilters: state.columnFilters,
      onAddFilter: (columnId: string) => {
        setFilterAnchorColumn(columnId);
        setEditingFilter(undefined);
        setFilterPopoverOpen(true);
      },
    },
  });

  const { rows } = table.getRowModel();

  const rowVirtualizer = useVirtualizer({
    count: rows.length,
    estimateSize: () => 35,
    getScrollElement: () => tableContainerRef.current,
    overscan: 10,
  });

  const isVirtual = mode === "virtual";
  const hasActions = !!renderRowActions || !!onEdit || !!onDelete;
  const rowId = (index: number) => `${gridId}-row-${index}`;

  const {
    activeRowIndex,
    activeRowId,
    handleKeyDown,
    handleClick,
    isSelected: isGridSelected,
  } = useGridFocus({
    rowCount: rows.length,
    getRowId: rowId,
    getRowData: (index: number) => rows[index]?.original ?? null,
    onSingleClick: onRowClick,
    onDoubleClick: onRowDoubleClick,
    onNew: onAdd,
    onDeleteRow: onDelete,
    onDuplicateRow: onDuplicate,
  });

  // Columns available for filtering (those with a variant in meta)
  const filterableColumns = React.useMemo(
    () =>
      table
        .getAllColumns()
        .filter(
          (col) => col.getIsVisible() && (col.columnDef.meta as ColumnMeta | undefined)?.variant,
        )
        .map((col) => ({
          id: col.id,
          label: (col.columnDef.meta as ColumnMeta).label ?? col.id,
          variant: (col.columnDef.meta as ColumnMeta).variant as FilterVariant,
        })),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [columns, state.columnVisibility],
  );

  const openFilterForColumn = (columnId?: string) => {
    const col = columnId
      ? (filterableColumns.find((c) => c.id === columnId) ?? filterableColumns[0])
      : filterableColumns[0];
    setFilterAnchorColumn(col?.id);
    setEditingFilter(undefined);
    setFilterPopoverOpen(true);
  };

  const onFilterConfirm = (filter: ColumnFilter) => {
    const existing = state.columnFilters.findIndex(
      (f) => f.id === filter.id && f.operator === filter.operator,
    );
    let newFilters: ColumnFilter[];
    if (editingFilter) {
      newFilters = state.columnFilters.map((f) =>
        f.id === editingFilter.id && f.operator === editingFilter.operator ? filter : f,
      );
    } else if (existing >= 0) {
      newFilters = state.columnFilters.map((f, i) => (i === existing ? filter : f));
    } else {
      newFilters = [...state.columnFilters, filter];
    }
    onStateChange({ ...state, columnFilters: newFilters });
    setFilterPopoverOpen(false);
    setEditingFilter(undefined);
  };

  const onFilterRemove = (id: string) => {
    onStateChange({ ...state, columnFilters: state.columnFilters.filter((f) => f.id !== id) });
  };

  const onFilterEdit = (filter: ColumnFilter) => {
    setEditingFilter(filter);
    setFilterAnchorColumn(filter.id);
    setFilterPopoverOpen(true);
  };

  const renderActions = (row: TData) => {
    if (renderRowActions) return renderRowActions(row);
    if (!onEdit && !onDelete) return null;
    return (
      <div className="flex items-center justify-end gap-1">
        {onEdit && (
          <button
            className="btn btn-ghost btn-xs px-1"
            onClick={(e) => {
              e.stopPropagation();
              onEdit(row);
            }}
          >
            <Settings2 size={12} />
          </button>
        )}
        {onDelete && (
          <button
            className="btn btn-ghost btn-xs px-1 text-red-500 hover:bg-red-50 hover:text-red-600"
            onClick={(e) => {
              e.stopPropagation();
              onDelete(row);
            }}
          >
            <Trash2 size={12} />
          </button>
        )}
      </div>
    );
  };

  // Initial column to pre-select in filter popover
  const popoverInitialCol = filterAnchorColumn
    ? filterableColumns.find((c) => c.id === filterAnchorColumn)
    : filterableColumns[0];

  return (
    <div className="datagrid-wrap">
      {/* TOOLBAR */}
      <div className="datagrid-toolbar">
        <div className="search-wrap">
          <span className="search-icon">
            <Search size={14} />
          </span>
          <input
            className="datagrid-search"
            placeholder="Suchen..."
            value={state.search}
            onChange={(e) => onStateChange({ ...state, search: e.target.value })}
          />
        </div>

        <div className="filter-popover-anchor" ref={filterAnchorRef}>
          <button
            className={`btn btn-ghost btn-xs${state.columnFilters.length > 0 ? " active" : ""}`}
            onClick={() => openFilterForColumn()}
            title="Filter hinzufügen"
          >
            <Filter size={13} />
            Filter
            {state.columnFilters.length > 0 && (
              <span
                className="badge badge-blue"
                style={{ marginLeft: 4, fontSize: 9, padding: "0 4px" }}
              >
                {state.columnFilters.length}
              </span>
            )}
          </button>
          {filterPopoverOpen && filterableColumns.length > 0 && (
            <FilterPopover
              columns={filterableColumns}
              initialFilter={
                editingFilter ??
                (popoverInitialCol
                  ? {
                      id: popoverInitialCol.id,
                      label: popoverInitialCol.label,
                      variant: popoverInitialCol.variant,
                      operator: "contains",
                    }
                  : undefined)
              }
              onConfirm={onFilterConfirm}
              onClose={() => {
                setFilterPopoverOpen(false);
                setEditingFilter(undefined);
              }}
            />
          )}
        </div>

        <ColumnVisibilityDropdown table={table} />

        {renderHeaderActions && (
          <div className="ml-2 flex items-center gap-2">{renderHeaderActions()}</div>
        )}

        <div style={{ marginLeft: "auto", display: "flex", gap: 4 }}>
          {onAdd && !renderHeaderActions && (
            <button className="btn btn-primary btn-xs" onClick={onAdd}>
              <Plus size={12} /> Neu
            </button>
          )}
        </div>
      </div>

      {/* ACTIVE FILTER CHIPS */}
      <FilterBar
        filters={state.columnFilters}
        onRemove={onFilterRemove}
        onEdit={onFilterEdit}
        onAdd={() => openFilterForColumn()}
      />

      {/* TABLE */}
      <div
        ref={tableContainerRef}
        role="grid"
        tabIndex={-1}
        aria-activedescendant={activeRowId ?? undefined}
        aria-rowcount={rows.length}
        style={{ flex: 1, overflow: "auto", position: "relative" }}
        onKeyDown={handleKeyDown}
      >
        <table className="datagrid">
          <thead>
            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id} role="row">
                {headerGroup.headers.map((header) => {
                  const col = header.column;
                  const isSorted = col.getIsSorted();
                  return (
                    <th
                      key={header.id}
                      role="columnheader"
                      aria-sort={
                        isSorted === "asc"
                          ? "ascending"
                          : isSorted === "desc"
                            ? "descending"
                            : undefined
                      }
                      className={isSorted ? "sorted" : ""}
                      style={{ width: header.getSize() }}
                    >
                      {header.isPlaceholder ? null : (
                        <ColumnHeader
                          column={col}
                          table={table}
                          label={flexRender(col.columnDef.header, header.getContext())}
                        />
                      )}
                    </th>
                  );
                })}
                {hasActions && <th style={{ width: 60 }} />}
              </tr>
            ))}
          </thead>
          <tbody>
            {loading && data.length === 0 ? (
              <tr>
                <td
                  colSpan={columns.length + (hasActions ? 1 : 0)}
                  style={{ padding: 24, textAlign: "center", color: "var(--text-muted)" }}
                >
                  Wird geladen...
                </td>
              </tr>
            ) : rows.length === 0 ? (
              <tr>
                <td
                  colSpan={columns.length + (hasActions ? 1 : 0)}
                  style={{ padding: 24, textAlign: "center", color: "var(--text-muted)" }}
                >
                  {emptyMessage}
                </td>
              </tr>
            ) : isVirtual ? (
              <>
                <tr style={{ height: `${rowVirtualizer.getVirtualItems()[0]?.start ?? 0}px` }}>
                  <td colSpan={columns.length + (hasActions ? 1 : 0)} />
                </tr>
                {rowVirtualizer.getVirtualItems().map((virtualRow) => {
                  const row = rows[virtualRow.index]!;
                  const idx = virtualRow.index;
                  const isSelected = (row.original as any)._isSelected || isGridSelected(idx);
                  const isActive = activeRowIndex === idx;
                  return (
                    <tr
                      key={row.id}
                      id={rowId(idx)}
                      role="row"
                      aria-selected={isSelected}
                      className={[isSelected ? "selected" : "", isActive ? "row-active" : ""]
                        .filter(Boolean)
                        .join(" ")}
                      onClick={() => handleClick(idx)}
                      draggable={!!onDragStart}
                      onDragStart={(e) => {
                        if (onDragStart) {
                          const payload = onDragStart(row.original);
                          e.dataTransfer.setData("application/x-slopware", JSON.stringify(payload));
                          e.dataTransfer.effectAllowed = "copy";
                        }
                      }}
                    >
                      {row.getVisibleCells().map((cell, ci) => (
                        <td key={cell.id} role={ci === 0 ? "rowheader" : "gridcell"}>
                          {flexRender(cell.column.columnDef.cell, cell.getContext())}
                        </td>
                      ))}
                      {hasActions && (
                        <td style={{ textAlign: "right" }}>{renderActions(row.original)}</td>
                      )}
                    </tr>
                  );
                })}
                <tr
                  style={{
                    height: `${rowVirtualizer.getTotalSize() - (rowVirtualizer.getVirtualItems().at(-1)?.end ?? 0)}px`,
                  }}
                >
                  <td colSpan={columns.length + (hasActions ? 1 : 0)} />
                </tr>
              </>
            ) : (
              rows.map((row, idx) => {
                const isSelected = (row.original as any)._isSelected || isGridSelected(idx);
                const isActive = activeRowIndex === idx;
                return (
                  <tr
                    key={row.id}
                    id={rowId(idx)}
                    role="row"
                    tabIndex={isActive ? 0 : activeRowIndex === null && idx === 0 ? 0 : -1}
                    aria-selected={isSelected}
                    className={[isSelected ? "selected" : "", isActive ? "row-active" : ""]
                      .filter(Boolean)
                      .join(" ")}
                    onClick={() => handleClick(idx)}
                    draggable={!!onDragStart}
                    onDragStart={(e) => {
                      if (onDragStart) {
                        const payload = onDragStart(row.original);
                        e.dataTransfer.setData("application/x-slopware", JSON.stringify(payload));
                        e.dataTransfer.effectAllowed = "copy";
                      }
                    }}
                  >
                    {row.getVisibleCells().map((cell, ci) => (
                      <td key={cell.id} role={ci === 0 ? "rowheader" : "gridcell"}>
                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                      </td>
                    ))}
                    {hasActions && (
                      <td style={{ textAlign: "right" }}>{renderActions(row.original)}</td>
                    )}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* FOOTER */}
      <div className="datagrid-footer">
        <span>
          {totalCount !== undefined ? `${totalCount} Einträge` : `${data.length} Einträge`}
          {rows.some((r) => (r.original as any)._isSelected) && ` · 1 selektiert`}
        </span>
        {mode === "paginated" && totalCount !== undefined && (
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <button
              disabled={state.pagination.pageIndex === 0}
              onClick={(e) => {
                e.stopPropagation();
                onStateChange({
                  ...state,
                  pagination: { ...state.pagination, pageIndex: state.pagination.pageIndex - 1 },
                });
              }}
              className="btn btn-ghost btn-xs"
            >
              Vorherige
            </button>
            <span style={{ fontFamily: "var(--font-mono)" }}>
              Seite {state.pagination.pageIndex + 1}
            </span>
            <button
              disabled={(state.pagination.pageIndex + 1) * state.pagination.pageSize >= totalCount}
              onClick={(e) => {
                e.stopPropagation();
                onStateChange({
                  ...state,
                  pagination: { ...state.pagination, pageIndex: state.pagination.pageIndex + 1 },
                });
              }}
              className="btn btn-ghost btn-xs"
            >
              Nächste
            </button>
          </div>
        )}
        <span style={{ fontFamily: "var(--font-mono)", fontWeight: 600, color: "var(--accent)" }}>
          tanstack-table / query
        </span>
      </div>
    </div>
  );
}
