import type { ColumnDef, SortingState, VisibilityState } from "@tanstack/react-table";

import type { ColumnFilter, FilterVariant } from "./filter-types";

export interface ColumnMeta {
  variant?: FilterVariant;
  label?: string;
  searchable?: boolean;
}

export type DataTableMode = "paginated" | "virtual";

export interface DataTablePagination {
  pageIndex: number;
  pageSize: number;
}

export interface DataTableState {
  sorting: SortingState;
  pagination: DataTablePagination;
  search: string;
  columnVisibility: VisibilityState;
  columnFilters: ColumnFilter[];
}

export interface DataTableFocusState {
  activeRowId: string | null;
  selectedRowIds: Set<string>;
}

export interface DataTableProps<TData> {
  columns: ColumnDef<TData, any>[];
  data: TData[];
  totalCount?: number;
  loading?: boolean;
  mode?: DataTableMode;
  state: DataTableState;
  onStateChange: (state: DataTableState) => void;
  onRowClick?: (row: TData) => void;
  onRowDoubleClick?: (row: TData) => void;
  onRowSelect?: (row: TData, isSelected: boolean) => void;
  onDragStart?: (row: TData) => any;
  onAdd?: () => void;
  onEdit?: (row: TData) => void;
  onDelete?: (row: TData) => void;
  onDuplicate?: (row: TData) => void;
  renderHeaderActions?: () => React.ReactNode;
  renderRowActions?: (row: TData) => React.ReactNode;
  emptyMessage?: string;
  gridId?: string;
}
