import { useQueries, useQuery } from "@tanstack/react-query";
import * as React from "react";

import { getEffectiveFieldsFn, listEntityFn, lookupHelperTableFn } from "~/server/server-functions";

import type { Lang } from "../../i18n";
import { fieldsToColumns } from "../../metadata-renderers";
import { CrudDialog } from "../crud-dialog";
import { CustomerStatsSection } from "../customer-stats-section";
import { InventoryBalanceTable } from "../inventory-balance-table";
import { getEntityColumns } from "./columns";
import { DataTable } from "./data-table";
import { DataTableSkeleton } from "./data-table-skeleton";
import type { DataTableMode } from "./data-table.types";
import { columnFiltersToEntityFilters } from "./filter-utils";
import { useDataTable } from "./use-data-table";

interface EntityDataTableProps {
  entityName: string;
  columns?: any[];
  mode?: DataTableMode;
  onRowClick?: (row: any) => void;
  onDragStart?: (row: any) => any;
  renderHeaderActions?: () => React.ReactNode;
  renderRowActions?: (row: any) => React.ReactNode;
  selectedId?: string | number | null;
  reloadKey?: number;
  t: (key: string) => string;
  lang?: Lang;
  onDuplicateRow?: (row: any) => void;
}

export function EntityDataTable({
  entityName,
  columns: customColumns,
  mode = "virtual",
  onRowClick,
  onDragStart,
  renderHeaderActions,
  renderRowActions,
  selectedId,
  reloadKey,
  t,
  lang = "de",
  onDuplicateRow,
}: EntityDataTableProps) {
  const { state, debouncedSearch, debouncedFilters, setState } = useDataTable({ entityName });
  const [crudMode, setCrudMode] = React.useState<"create" | "edit" | "delete" | null>(null);
  const [selectedRow, setSelectedRow] = React.useState<any>(null);

  const { data: effectiveFields = [], isLoading: isFieldsLoading } = useQuery({
    queryKey: ["effective-fields", entityName],
    queryFn: () => getEffectiveFieldsFn({ data: { entityName } }),
    enabled: !customColumns,
    staleTime: 5 * 60 * 1000,
  });

  const lookupTableNames = React.useMemo(
    () => [
      ...new Set(effectiveFields.filter((f) => f.lookupTable).map((f) => f.lookupTable as string)),
    ],
    [effectiveFields],
  );

  const lookupResults = useQueries({
    queries: lookupTableNames.map((tableName) => ({
      queryKey: ["lookup", tableName],
      queryFn: () => lookupHelperTableFn({ data: { tableName, limit: 2000 } }),
      staleTime: 10 * 60 * 1000,
    })),
  });

  const lookupMap = React.useMemo(() => {
    const map: Record<string, Record<string, string>> = {};
    lookupTableNames.forEach((tableName, i) => {
      const items = lookupResults[i]?.data;
      if (items) {
        map[tableName] = Object.fromEntries(items.map((item) => [item.value, item.label]));
      }
    });
    return map;
  }, [lookupTableNames, lookupResults]);

  // Derive search columns from visible text-like effective fields
  const searchColumns = React.useMemo(() => {
    if (customColumns || effectiveFields.length === 0) return undefined;
    return effectiveFields
      .filter(
        (f) =>
          f.isVisible !== false &&
          (f.customAttributes?.searchable as boolean | undefined) !== false &&
          f.fieldType !== "boolean" &&
          f.fieldType !== "integer" &&
          f.fieldType !== "decimal" &&
          !f.lookupTable,
      )
      .map((f) => f.fieldName);
  }, [customColumns, effectiveFields]);

  const entityFilters = React.useMemo(
    () => columnFiltersToEntityFilters(debouncedFilters),
    [debouncedFilters],
  );

  const { data, isLoading } = useQuery({
    queryKey: [
      "entity-list",
      entityName,
      state.pagination,
      state.sorting,
      debouncedSearch,
      entityFilters,
      reloadKey,
    ],
    queryFn: () =>
      listEntityFn({
        data: {
          entityName,
          options: {
            limit: state.pagination.pageSize,
            offset: state.pagination.pageIndex * state.pagination.pageSize,
            sortBy: state.sorting[0]?.id,
            sortOrder: state.sorting[0]?.desc ? "DESC" : "ASC",
            filters: entityFilters.length > 0 ? entityFilters : undefined,
            searchQuery: debouncedSearch || undefined,
            searchColumns: debouncedSearch && searchColumns?.length ? searchColumns : undefined,
          },
        },
      }),
    enabled: !isFieldsLoading || !!customColumns,
  });

  const columns = React.useMemo(() => {
    if (customColumns) return customColumns;
    if (effectiveFields.length > 0) return fieldsToColumns(effectiveFields, lang, lookupMap);
    return getEntityColumns(entityName, t, lang);
  }, [customColumns, effectiveFields, lang, lookupMap, entityName, t]);

  const items = data?.items ?? [];
  const processedData = React.useMemo(() => {
    if (!items.length) return [];
    return items.map((item: any) => ({
      ...item,
      _isSelected:
        selectedId != null && String(item.id || item[`${entityName}_id`]) === String(selectedId),
    }));
  }, [items, selectedId, entityName]);

  const restoreFocus = React.useCallback(() => {
    requestAnimationFrame(() => {
      const activeRow = document.querySelector(".row-active") as HTMLElement;
      if (activeRow) {
        activeRow.focus();
      } else {
        const firstRow = document.querySelector('tr[role="row"]') as HTMLElement;
        if (firstRow) firstRow.focus();
      }
      const grid = document.querySelector('[role="grid"]') as HTMLElement;
      if (grid) grid.focus();
    });
  }, []);

  if (isFieldsLoading && !customColumns) {
    return <DataTableSkeleton columnCount={5} rowCount={12} />;
  }

  return (
    <>
      <DataTable
        columns={columns}
        data={processedData}
        totalCount={data?.total}
        loading={isLoading}
        mode={mode}
        state={state}
        onStateChange={setState}
        onRowClick={onRowClick}
        onRowDoubleClick={(row) => {
          setSelectedRow(row);
          setCrudMode("edit");
        }}
        onDragStart={onDragStart}
        onAdd={() => {
          setSelectedRow(null);
          setCrudMode("create");
        }}
        onEdit={(row) => {
          setSelectedRow(row);
          setCrudMode("edit");
        }}
        onDelete={(row) => {
          setSelectedRow(row);
          setCrudMode("delete");
        }}
        onDuplicate={(row) => {
          if (onDuplicateRow) {
            onDuplicateRow(row);
          } else {
            setSelectedRow(row);
            setCrudMode("create");
          }
        }}
        renderHeaderActions={renderHeaderActions}
        renderRowActions={renderRowActions}
        emptyMessage={t("pane.empty.noview")}
      />
      {crudMode && (
        <CrudDialog
          mode={crudMode}
          entityName={entityName}
          row={selectedRow}
          lang={lang}
          onClose={() => {
            setCrudMode(null);
            setSelectedRow(null);
            restoreFocus();
          }}
          childSection={
            entityName === "article" && crudMode === "edit" && selectedRow?.article_id ? (
              <InventoryBalanceTable articleId={selectedRow.article_id} />
            ) : entityName === "address" && crudMode === "edit" && selectedRow?.address_id ? (
              <CustomerStatsSection
                customerId={selectedRow.address_id}
                isCustomer={selectedRow.is_customer === true}
              />
            ) : undefined
          }
        />
      )}
    </>
  );
}
