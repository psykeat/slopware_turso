import { X, Plus } from "lucide-react";
import * as React from "react";

import type { ColumnFilter } from "./filter-types";
import { OPERATOR_LABELS } from "./filter-types";

interface FilterBarProps {
  filters: ColumnFilter[];
  onRemove: (id: string) => void;
  onEdit: (filter: ColumnFilter) => void;
  onAdd: () => void;
}

export function FilterBar({ filters, onRemove, onEdit, onAdd }: FilterBarProps) {
  if (filters.length === 0) return null;

  return (
    <div className="datagrid-filter-bar">
      {filters.map((f) => (
        <button
          key={`${f.id}-${f.operator}`}
          className="datagrid-filter-chip"
          onClick={() => onEdit(f)}
          title={`${f.label} ${OPERATOR_LABELS[f.operator]}${f.value ? ` "${f.value}"` : ""}${f.endValue ? ` – "${f.endValue}"` : ""}`}
        >
          <span className="chip-field">{f.label}</span>
          <span className="chip-op">{OPERATOR_LABELS[f.operator]}</span>
          {f.value && (
            <span className="chip-val">
              {f.value}
              {f.endValue ? ` – ${f.endValue}` : ""}
            </span>
          )}
          <span
            className="chip-remove"
            role="button"
            aria-label="Filter entfernen"
            onClick={(e) => {
              e.stopPropagation();
              onRemove(f.id);
            }}
          >
            <X size={10} />
          </span>
        </button>
      ))}
      <button className="btn btn-ghost btn-xs datagrid-filter-add" onClick={onAdd}>
        <Plus size={11} /> Filter
      </button>
    </div>
  );
}
