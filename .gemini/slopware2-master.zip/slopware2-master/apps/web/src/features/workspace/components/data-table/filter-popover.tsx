import * as React from "react";

import type { ColumnFilter, FilterOperator, FilterVariant } from "./filter-types";
import { OPERATORS_BY_VARIANT, OPERATOR_LABELS, needsValue, needsEndValue } from "./filter-types";

interface AvailableColumn {
  id: string;
  label: string;
  variant: FilterVariant;
}

interface FilterPopoverProps {
  columns: AvailableColumn[];
  initialFilter?: ColumnFilter;
  onConfirm: (filter: ColumnFilter) => void;
  onClose: () => void;
}

export function FilterPopover({ columns, initialFilter, onConfirm, onClose }: FilterPopoverProps) {
  const ref = React.useRef<HTMLDivElement>(null);

  const [columnId, setColumnId] = React.useState(initialFilter?.id ?? columns[0]?.id ?? "");
  const [operator, setOperator] = React.useState<FilterOperator>(
    initialFilter?.operator ??
      (OPERATORS_BY_VARIANT[columns[0]?.variant ?? "text"][0] as FilterOperator),
  );
  const [value, setValue] = React.useState(initialFilter?.value ?? "");
  const [endValue, setEndValue] = React.useState(initialFilter?.endValue ?? "");

  const selectedCol = columns.find((c) => c.id === columnId);
  const availableOps = selectedCol ? OPERATORS_BY_VARIANT[selectedCol.variant] : [];

  const onColumnChange = (id: string) => {
    setColumnId(id);
    const col = columns.find((c) => c.id === id);
    if (col) {
      const ops = OPERATORS_BY_VARIANT[col.variant];
      setOperator(ops[0] as FilterOperator);
      setValue("");
      setEndValue("");
    }
  };

  React.useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    const escape = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("mousedown", handler);
    document.addEventListener("keydown", escape);
    return () => {
      document.removeEventListener("mousedown", handler);
      document.removeEventListener("keydown", escape);
    };
  }, [onClose]);

  const handleConfirm = () => {
    if (!selectedCol) return;
    onConfirm({
      id: columnId,
      label: selectedCol.label,
      variant: selectedCol.variant,
      operator,
      value: value || undefined,
      endValue: endValue || undefined,
    });
    onClose();
  };

  const showValue = needsValue(operator);
  const showEndValue = needsEndValue(operator);
  const inputType =
    selectedCol?.variant === "number"
      ? "number"
      : selectedCol?.variant === "date"
        ? "date"
        : "text";

  return (
    <div className="filter-popover" ref={ref} role="dialog" aria-label="Filter hinzufügen">
      <div className="filter-popover-title">Filter</div>

      <div className="filter-popover-row">
        <label className="filter-popover-label">Spalte</label>
        <select
          className="filter-popover-select"
          value={columnId}
          onChange={(e) => onColumnChange(e.target.value)}
        >
          {columns.map((c) => (
            <option key={c.id} value={c.id}>
              {c.label}
            </option>
          ))}
        </select>
      </div>

      <div className="filter-popover-row">
        <label className="filter-popover-label">Operator</label>
        <select
          className="filter-popover-select"
          value={operator}
          onChange={(e) => {
            setOperator(e.target.value as FilterOperator);
            setValue("");
            setEndValue("");
          }}
        >
          {availableOps.map((op) => (
            <option key={op} value={op}>
              {OPERATOR_LABELS[op]}
            </option>
          ))}
        </select>
      </div>

      {showValue && (
        <div className="filter-popover-row">
          <label className="filter-popover-label">{showEndValue ? "Von" : "Wert"}</label>
          <input
            className="filter-popover-input"
            type={inputType}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            autoFocus
            onKeyDown={(e) => {
              if (e.key === "Enter" && !showEndValue) handleConfirm();
            }}
          />
        </div>
      )}

      {showEndValue && (
        <div className="filter-popover-row">
          <label className="filter-popover-label">Bis</label>
          <input
            className="filter-popover-input"
            type={inputType}
            value={endValue}
            onChange={(e) => setEndValue(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleConfirm();
            }}
          />
        </div>
      )}

      <div className="filter-popover-actions">
        <button className="btn btn-ghost btn-xs" onClick={onClose}>
          Abbrechen
        </button>
        <button className="btn btn-primary btn-xs" onClick={handleConfirm}>
          Anwenden
        </button>
      </div>
    </div>
  );
}
