export type FilterVariant = "text" | "number" | "boolean" | "date" | "select";

export type FilterOperator =
  | "contains"
  | "not_contains"
  | "equals"
  | "not_equals"
  | "is_empty"
  | "is_not_empty"
  | "gt"
  | "gte"
  | "lt"
  | "lte"
  | "between"
  | "is_true"
  | "is_false"
  | "is_any_of"
  | "is_none_of";

export interface ColumnFilter {
  id: string;
  label: string;
  variant: FilterVariant;
  operator: FilterOperator;
  value?: string;
  endValue?: string;
}

export const OPERATORS_BY_VARIANT: Record<FilterVariant, FilterOperator[]> = {
  text: ["contains", "not_contains", "equals", "not_equals", "is_empty", "is_not_empty"],
  number: ["equals", "not_equals", "gt", "gte", "lt", "lte", "between"],
  date: ["equals", "gt", "gte", "lt", "lte", "between"],
  boolean: ["is_true", "is_false"],
  select: ["equals", "not_equals", "is_any_of", "is_none_of", "is_empty", "is_not_empty"],
};

export const OPERATOR_LABELS: Record<FilterOperator, string> = {
  contains: "enthält",
  not_contains: "enthält nicht",
  equals: "ist gleich",
  not_equals: "ist ungleich",
  is_empty: "ist leer",
  is_not_empty: "nicht leer",
  gt: "größer als",
  gte: "≥",
  lt: "kleiner als",
  lte: "≤",
  between: "zwischen",
  is_true: "ist wahr",
  is_false: "ist falsch",
  is_any_of: "ist eines von",
  is_none_of: "ist keines von",
};

export function needsValue(operator: FilterOperator): boolean {
  return (
    operator !== "is_empty" &&
    operator !== "is_not_empty" &&
    operator !== "is_true" &&
    operator !== "is_false"
  );
}

export function needsEndValue(operator: FilterOperator): boolean {
  return operator === "between";
}
