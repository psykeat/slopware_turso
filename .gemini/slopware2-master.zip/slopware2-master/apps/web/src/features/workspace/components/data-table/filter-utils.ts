import type { EffectiveField, EntityFilter } from "@repo/domain";

import type { ColumnFilter, FilterVariant } from "./filter-types";

export function getVariantFromField(field: EffectiveField): FilterVariant {
  const ft = field.fieldType?.toLowerCase();
  if (ft === "boolean") return "boolean";
  if (ft === "integer" || ft === "decimal" || ft === "number" || ft === "float") return "number";
  if (ft === "date" || ft === "datetime" || ft === "timestamp") return "date";
  if (field.lookupTable || ft === "select" || ft === "enum") return "select";
  return "text";
}

export function columnFiltersToEntityFilters(filters: ColumnFilter[]): EntityFilter[] {
  const result: EntityFilter[] = [];

  for (const f of filters) {
    switch (f.operator) {
      case "contains":
        if (f.value) result.push({ column: f.id, operator: "ILIKE", value: `%${f.value}%` });
        break;
      case "not_contains":
        if (f.value) result.push({ column: f.id, operator: "NOT_ILIKE", value: `%${f.value}%` });
        break;
      case "equals":
        if (f.value !== undefined) result.push({ column: f.id, operator: "=", value: f.value });
        break;
      case "not_equals":
        if (f.value !== undefined) result.push({ column: f.id, operator: "!=", value: f.value });
        break;
      case "is_empty":
        result.push({ column: f.id, operator: "IS_NULL" });
        break;
      case "is_not_empty":
        result.push({ column: f.id, operator: "IS_NOT_NULL" });
        break;
      case "gt":
        if (f.value !== undefined) result.push({ column: f.id, operator: ">", value: f.value });
        break;
      case "gte":
        if (f.value !== undefined) result.push({ column: f.id, operator: ">=", value: f.value });
        break;
      case "lt":
        if (f.value !== undefined) result.push({ column: f.id, operator: "<", value: f.value });
        break;
      case "lte":
        if (f.value !== undefined) result.push({ column: f.id, operator: "<=", value: f.value });
        break;
      case "between":
        if (f.value !== undefined) result.push({ column: f.id, operator: ">=", value: f.value });
        if (f.endValue !== undefined)
          result.push({ column: f.id, operator: "<=", value: f.endValue });
        break;
      case "is_true":
        result.push({ column: f.id, operator: "=", value: true });
        break;
      case "is_false":
        result.push({ column: f.id, operator: "=", value: false });
        break;
      case "is_any_of":
        if (f.value) {
          result.push({
            column: f.id,
            operator: "IN",
            value: f.value
              .split(",")
              .map((v) => v.trim())
              .filter(Boolean),
          });
        }
        break;
      case "is_none_of":
        if (f.value) {
          result.push({
            column: f.id,
            operator: "NOT_IN",
            value: f.value
              .split(",")
              .map((v) => v.trim())
              .filter(Boolean),
          });
        }
        break;
    }
  }

  return result;
}
