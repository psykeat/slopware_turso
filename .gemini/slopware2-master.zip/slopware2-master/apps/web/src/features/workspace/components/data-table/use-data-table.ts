import type { SortingState, VisibilityState } from "@tanstack/react-table";
import { useState, useCallback, useEffect } from "react";

import type { DataTableState, DataTablePagination } from "./data-table.types";
import type { ColumnFilter } from "./filter-types";

interface UseDataTableOptions {
  initialSorting?: SortingState;
  initialPagination?: DataTablePagination;
  initialSearch?: string;
  entityName?: string;
  onStateChange?: (state: DataTableState) => void;
}

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function saveToStorage(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // ignore quota errors
  }
}

export function useDataTable({
  initialSorting = [],
  initialPagination = { pageIndex: 0, pageSize: 50 },
  initialSearch = "",
  entityName,
  onStateChange,
}: UseDataTableOptions = {}) {
  const visKey = entityName ? `dt:${entityName}:visibility` : null;

  const [state, setState] = useState<DataTableState>(() => ({
    sorting: initialSorting,
    pagination: initialPagination,
    search: initialSearch,
    columnVisibility: visKey ? loadFromStorage<VisibilityState>(visKey, {}) : {},
    columnFilters: [],
  }));

  // Reset state when entity changes to prevent cross-entity sort/search bleed
  useEffect(() => {
    setState({
      sorting: initialSorting,
      pagination: { ...initialPagination, pageIndex: 0 },
      search: initialSearch,
      columnVisibility: visKey ? loadFromStorage<VisibilityState>(visKey, {}) : {},
      columnFilters: [],
    });
  }, [entityName]);

  const handleStateChange = useCallback(
    (newState: DataTableState) => {
      setState(newState);
      onStateChange?.(newState);
    },
    [onStateChange],
  );

  // Persist column visibility to localStorage whenever it changes
  useEffect(() => {
    if (visKey) saveToStorage(visKey, state.columnVisibility);
  }, [visKey, state.columnVisibility]);

  // Debounced search
  const [debouncedSearch, setDebouncedSearch] = useState(state.search);
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(state.search), 300);
    return () => clearTimeout(t);
  }, [state.search]);

  // Debounced column filters
  const [debouncedFilters, setDebouncedFilters] = useState<ColumnFilter[]>(state.columnFilters);
  useEffect(() => {
    const t = setTimeout(() => setDebouncedFilters(state.columnFilters), 300);
    return () => clearTimeout(t);
  }, [state.columnFilters]);

  // Reset page on search/sort/filter change
  useEffect(() => {
    if (state.pagination.pageIndex !== 0) {
      handleStateChange({
        ...state,
        pagination: { ...state.pagination, pageIndex: 0 },
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.search, state.sorting, state.columnFilters]);

  return {
    state,
    debouncedSearch,
    debouncedFilters,
    setState: handleStateChange,
  };
}
