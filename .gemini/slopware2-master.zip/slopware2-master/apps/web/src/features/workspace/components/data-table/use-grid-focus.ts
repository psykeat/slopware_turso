import { KeyboardEvent, useCallback, useRef, useState } from "react";

export interface GridFocusOptions {
  rowCount: number;
  getRowId: (index: number) => string;
  getRowData: (index: number) => any;
  onSingleClick?: (row: any) => void;
  onDoubleClick?: (row: any) => void;
  onActivate?: (rowId: string | null) => void;
  onNew?: () => void;
  onDeleteRow?: (row: any) => void;
  onDuplicateRow?: (row: any) => void;
}

export function useGridFocus({
  rowCount,
  getRowId,
  getRowData,
  onSingleClick,
  onDoubleClick,
  onActivate,
  onNew,
  onDeleteRow,
  onDuplicateRow,
}: GridFocusOptions) {
  const [activeRowIndex, setActiveRowIndex] = useState<number | null>(null);
  const [selectedRowIds, setSelectedRowIds] = useState<Set<string>>(new Set());
  const clickTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastClickedIndexRef = useRef<number | null>(null);

  const activeRowId = activeRowIndex !== null ? getRowId(activeRowIndex) : null;

  const focusRow = useCallback(
    (index: number) => {
      requestAnimationFrame(() => {
        const rowId = getRowId(index);
        const element = document.getElementById(rowId);
        if (element) {
          element.focus();
        }
      });
    },
    [getRowId],
  );

  const handleKeyDown = useCallback(
    (e: KeyboardEvent<HTMLElement>) => {
      // Ignore navigation if any modifier is pressed
      if (e.ctrlKey || e.altKey || e.metaKey) return;

      if (rowCount === 0) return;

      switch (e.key) {
        case "ArrowUp": {
          e.preventDefault();
          setActiveRowIndex((prev) => {
            const next = prev !== null ? Math.max(0, prev - 1) : 0;
            onActivate?.(getRowId(next));
            focusRow(next);
            return next;
          });
          break;
        }
        case "ArrowDown": {
          e.preventDefault();
          setActiveRowIndex((prev) => {
            const next = prev !== null ? Math.min(rowCount - 1, prev + 1) : 0;
            onActivate?.(getRowId(next));
            focusRow(next);
            return next;
          });
          break;
        }
        case "Home": {
          e.preventDefault();
          setActiveRowIndex(0);
          onActivate?.(getRowId(0));
          focusRow(0);
          break;
        }
        case "End": {
          e.preventDefault();
          const last = rowCount - 1;
          setActiveRowIndex(last);
          onActivate?.(getRowId(last));
          focusRow(last);
          break;
        }
        case "Enter": {
          e.preventDefault();
          if (activeRowIndex !== null) {
            onDoubleClick?.(getRowData(activeRowIndex));
          }
          break;
        }
        case " ": {
          e.preventDefault();
          if (activeRowIndex !== null) {
            const rowId = getRowId(activeRowIndex);
            setSelectedRowIds((prev) => {
              const next = new Set(prev);
              if (next.has(rowId)) {
                next.delete(rowId);
              } else {
                next.add(rowId);
              }
              return next;
            });
            onSingleClick?.(getRowData(activeRowIndex));
          }
          break;
        }
        case "F3": {
          e.preventDefault();
          onNew?.();
          break;
        }
        case "F4": {
          e.preventDefault();
          if (activeRowIndex !== null) {
            onDeleteRow?.(getRowData(activeRowIndex));
          }
          break;
        }
        case "F8": {
          e.preventDefault();
          if (activeRowIndex !== null) {
            onDuplicateRow?.(getRowData(activeRowIndex));
          }
          break;
        }
      }
    },
    [
      rowCount,
      getRowId,
      getRowData,
      onSingleClick,
      onDoubleClick,
      onActivate,
      onNew,
      onDeleteRow,
      onDuplicateRow,
      focusRow,
      activeRowIndex,
    ],
  );

  const handleClick = useCallback(
    (index: number) => {
      const rowId = getRowId(index);
      setActiveRowIndex(index);
      onActivate?.(rowId);
      focusRow(index);

      if (lastClickedIndexRef.current === index) {
        if (clickTimerRef.current) clearTimeout(clickTimerRef.current);
        clickTimerRef.current = null;
        lastClickedIndexRef.current = null;
        onDoubleClick?.(getRowData(index));
      } else {
        lastClickedIndexRef.current = index;
        clickTimerRef.current = setTimeout(() => {
          onSingleClick?.(getRowData(index));
          lastClickedIndexRef.current = null;
          clickTimerRef.current = null;
        }, 250);
      }
    },
    [getRowId, getRowData, onSingleClick, onDoubleClick, onActivate, focusRow],
  );

  const isSelected = useCallback(
    (index: number) => selectedRowIds.has(getRowId(index)),
    [selectedRowIds, getRowId],
  );

  return {
    activeRowIndex,
    activeRowId,
    handleKeyDown,
    handleClick,
    isSelected,
    selectedRowIds,
  };
}
