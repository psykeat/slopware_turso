import { ChevronLeft, ChevronRight } from "lucide-react";
import { useState, useEffect, useRef } from "react";

export interface DatePickerProps {
  label?: string;
  value: string | null;
  onChange: (value: string | null) => void;
  placeholder?: string;
  tabIndex?: number;
  disabled?: boolean;
  format?: "YYYY-MM-DD" | "DD.MM.YYYY";
}

const DAYS_DE = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];
const DAYS_EN = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];
const MONTHS_DE = [
  "Jan",
  "Feb",
  "M\u00e4r",
  "Apr",
  "Mai",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Okt",
  "Nov",
  "Dez",
];
const MONTHS_EN = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];

function getWeeks(year: number, month: number): number[][] {
  const first = new Date(year, month, 1);
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  let startDay = first.getDay() - 1;
  if (startDay < 0) startDay = 6;

  const weeks: number[][] = [];
  let week: number[] = [];
  for (let i = 0; i < startDay; i++) week.push(0);
  for (let d = 1; d <= daysInMonth; d++) {
    week.push(d);
    if (week.length === 7) {
      weeks.push(week);
      week = [];
    }
  }
  if (week.length > 0) weeks.push(week);
  return weeks;
}

function formatDate(value: string, format: string, lang: string): string {
  if (!value) return "";
  const d = new Date(value + "T00:00:00");
  if (isNaN(d.getTime())) return value;
  const yyyy = String(d.getFullYear());
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  if (format === "DD.MM.YYYY") return `${dd}.${mm}.${yyyy}`;
  return `${yyyy}-${mm}-${dd}`;
}

export function DatePicker({
  label,
  value,
  onChange,
  placeholder,
  tabIndex,
  disabled,
  format = "YYYY-MM-DD",
}: DatePickerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const dateObj = value ? new Date(value + "T00:00:00") : new Date();
  const [viewYear, setViewYear] = useState(dateObj.getFullYear());
  const [viewMonth, setViewMonth] = useState(dateObj.getMonth());

  const weeks = getWeeks(viewYear, viewMonth);
  const lang = placeholder?.includes(".") ? "de" : "en";
  const days = lang === "de" ? DAYS_DE : DAYS_EN;
  const months = lang === "de" ? MONTHS_DE : MONTHS_EN;

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleDayClick = (day: number) => {
    const y = String(viewYear);
    const m = String(viewMonth + 1).padStart(2, "0");
    const d = String(day).padStart(2, "0");
    onChange(`${y}-${m}-${d}`);
    setIsOpen(false);
  };

  const prevMonth = () => {
    setViewMonth((m) => {
      if (m === 0) {
        setViewYear((y) => y - 1);
        return 11;
      }
      return m - 1;
    });
  };

  const nextMonth = () => {
    setViewMonth((m) => {
      if (m === 11) {
        setViewYear((y) => y + 1);
        return 0;
      }
      return m + 1;
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      setIsOpen((prev) => !prev);
    } else if (e.key === "Escape") {
      setIsOpen(false);
    }
  };

  const displayValue = value ? formatDate(value, format, lang) : "";

  return (
    <div className="sw-datepicker flex flex-col gap-0.5" ref={containerRef}>
      {label && <label className="sw-lookup-label">{label}</label>}
      <div className="relative">
        <div
          className={`sw-lookup-trigger ${disabled ? "sw-lookup-disabled" : ""}`}
          tabIndex={disabled ? -1 : (tabIndex ?? 0)}
          role="combobox"
          aria-expanded={isOpen}
          onClick={() => !disabled && setIsOpen((p) => !p)}
          onKeyDown={handleKeyDown}
        >
          <input
            ref={inputRef}
            className="sw-datepicker-input flex-1 bg-transparent text-current outline-none"
            type="text"
            readOnly
            value={displayValue}
            placeholder={placeholder || "Date"}
            tabIndex={-1}
          />
          <span className="sw-datepicker-icon font-mono text-[10px] text-gray-400">
            {format === "DD.MM.YYYY" ? "DD.MM" : "YYYY"}
          </span>
        </div>

        {isOpen && (
          <div className="sw-datepicker-popup">
            <div className="sw-datepicker-nav flex items-center justify-between">
              <button className="sw-datepicker-nav-btn" onClick={prevMonth} type="button">
                <ChevronLeft size={12} />
              </button>
              <span className="sw-datepicker-month">
                {months[viewMonth]} {viewYear}
              </span>
              <button className="sw-datepicker-nav-btn" onClick={nextMonth} type="button">
                <ChevronRight size={12} />
              </button>
            </div>
            <div className="sw-datepicker-grid">
              <div className="sw-datepicker-header flex">
                {days.map((d) => (
                  <div key={d} className="sw-datepicker-day-header">
                    {d}
                  </div>
                ))}
              </div>
              {weeks.map((week, wi) => (
                <div key={wi} className="sw-datepicker-week flex">
                  {week.map((day, di) => {
                    const dayVal = day
                      ? `${viewYear}-${String(viewMonth + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`
                      : "";
                    const isSelected = dayVal === value;
                    const isToday = dayVal === new Date().toISOString().slice(0, 10);
                    return (
                      <div
                        key={di}
                        className={`sw-datepicker-day ${day ? "cursor-pointer" : ""} ${isSelected ? "sw-datepicker-day-selected" : ""} ${isToday && !isSelected ? "sw-datepicker-day-today" : ""}`}
                        onClick={() => day && handleDayClick(day)}
                      >
                        {day || ""}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
            <div className="sw-datepicker-footer flex justify-between">
              <button
                className="sw-datepicker-footer-btn text-gray-400"
                onClick={() => {
                  onChange(null);
                  setIsOpen(false);
                }}
                type="button"
              >
                Clear
              </button>
              <button
                className="sw-datepicker-footer-btn text-blue-500"
                onClick={() => {
                  const today = new Date().toISOString().slice(0, 10);
                  onChange(today);
                  setIsOpen(false);
                }}
                type="button"
              >
                Today
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
