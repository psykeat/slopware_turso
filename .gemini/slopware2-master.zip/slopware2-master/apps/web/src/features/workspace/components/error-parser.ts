export interface ParsedServerError {
  fieldErrors: Record<string, string>;
  globalError: string | null;
  source: "zod" | "domain" | "fallback";
  code: string | null;
}

export function parseServerError(
  rawError: unknown,
  visibleFieldNames: string[],
): ParsedServerError {
  const result: ParsedServerError = {
    fieldErrors: {},
    globalError: null,
    source: "fallback",
    code: null,
  };

  const rawString = extractErrorMessage(rawError);
  if (!rawString) return result;

  result.globalError = rawString;

  try {
    const parsed = JSON.parse(rawString);
    if (Array.isArray(parsed)) {
      result.source = "zod";
      result.globalError = null;
      for (const issue of parsed) {
        const path = issue.path ?? [];
        const field = path[path.length - 1];
        if (field && visibleFieldNames.includes(field)) {
          result.fieldErrors[field] = issue.message ?? "Validation failed";
        } else if (field) {
          result.fieldErrors[field] = issue.message ?? "Validation failed";
        }
      }
      if (Object.keys(result.fieldErrors).length === 0) {
        result.globalError = rawString;
      }
      return result;
    }
  } catch {
    /* not JSON */
  }

  if (rawString.includes(";")) {
    result.source = "domain";
    result.globalError = null;
    const parts = rawString
      .split(";")
      .map((s) => s.trim())
      .filter(Boolean);
    for (const part of parts) {
      const colonIdx = part.indexOf(":");
      if (colonIdx > 0) {
        const field = part.slice(0, colonIdx).trim();
        const msg = part.slice(colonIdx + 1).trim();
        if (visibleFieldNames.includes(field)) {
          result.fieldErrors[field] = msg;
        }
      }
    }
    if (Object.keys(result.fieldErrors).length === 0) {
      result.globalError = rawString;
    }
    return result;
  }

  result.source = "fallback";
  return result;
}

function extractErrorMessage(err: unknown): string | null {
  if (!err) return null;
  if (typeof err === "string") return err;
  if (typeof err === "object") {
    const obj = err as Record<string, unknown>;
    if (typeof obj.message === "string") return obj.message;
    if (typeof obj.error === "string") return obj.error;
  }
  return null;
}
