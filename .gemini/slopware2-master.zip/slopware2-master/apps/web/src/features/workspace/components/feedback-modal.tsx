import {
  X,
  MessageSquare,
  AlertCircle,
  ChevronDown,
  ChevronRight,
  CheckCircle,
  ExternalLink,
  Loader2,
} from "lucide-react";
import * as React from "react";

import { logger, type Breadcrumb } from "../../../lib/logger";
import { submitFeedbackFn } from "../../../server/server-functions";

export interface FeedbackSnapshot {
  workspace: string;
  panes: string[][];
  activeFiles: string[];
  selection?: {
    address?: Record<string, unknown> | null;
    document?: Record<string, unknown> | null;
    article?: Record<string, unknown> | null;
    articleGroup?: Record<string, unknown> | null;
  };
  breadcrumbs?: Breadcrumb[];
  url: string;
  userAgent: string;
  viewport: { width: number; height: number };
  timestamp: string;
  userId?: string;
  tenantId?: string;
  locale?: string;
  lastError?: string | null;
  traceId?: string;
}

function predictFilePath(viewKey: string): string {
  if (viewKey === "dashboard:kpi") {
    return "apps/web/src/features/workspace/views/dashboard/dashboard-kpi-view.tsx";
  }
  const [prefix, suffix] = viewKey.split(":");
  if (!prefix || !suffix) return `unknown (${viewKey})`;

  // Der deterministische Pfad aus unserem neuen Refactor
  return `apps/web/src/features/workspace/views/${prefix}/${prefix}-${suffix}-view.tsx`;
}

export function captureFeedbackSnapshot(
  wsId: string,
  panes: string[][],
  selection: FeedbackSnapshot["selection"],
  userId?: string,
  tenantId?: string,
  locale?: string,
  lastError?: string | null,
): FeedbackSnapshot {
  const allActiveKeys = panes.flat();
  const activeFiles = Array.from(new Set(allActiveKeys.map(predictFilePath)));
  const breadcrumbs = logger.getBreadcrumbs();

  // Placeholder: Get traceId from OTel or a global variable
  const traceId = (window as any)._currentTraceId;

  return {
    workspace: wsId,
    panes: panes,
    activeFiles,
    selection,
    breadcrumbs,
    url: window.location.href,
    userAgent: navigator.userAgent,
    viewport: { width: window.innerWidth, height: window.innerHeight },
    timestamp: new Date().toISOString(),
    userId,
    tenantId,
    locale,
    lastError,
    traceId,
  };
}

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  snapshot: FeedbackSnapshot;
  t: (k: string) => string;
}

export function FeedbackModal({ isOpen, onClose, snapshot, t }: FeedbackModalProps) {
  const [description, setDescription] = React.useState("");
  const [showContext, setShowContext] = React.useState(false);
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [result, setResult] = React.useState<{
    success: boolean;
    issueUrl?: string;
    error?: string;
  } | null>(null);

  // Reset state when modal opens
  React.useEffect(() => {
    if (isOpen) {
      setResult(null);
      setDescription("");
      setShowContext(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (description.length < 10) return;

    setIsSubmitting(true);
    setResult(null);

    try {
      const res = await submitFeedbackFn({
        data: {
          description,
          snapshot: snapshot as any,
        },
      });
      setResult(res);
    } catch (e) {
      setResult({ success: false, error: String(e) });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="modal-overlay"
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: "rgba(0,0,0,0.5)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 1000,
        backdropFilter: "blur(2px)",
      }}
    >
      <div
        className="modal-content"
        style={{
          background: "var(--bg-pane)",
          width: "500px",
          borderRadius: "8px",
          boxShadow: "var(--shadow-lg)",
          border: "1px solid var(--border)",
          display: "flex",
          flexDirection: "column",
          maxHeight: "90vh",
        }}
      >
        <div
          className="modal-header"
          style={{
            padding: "12px 16px",
            borderBottom: "1px solid var(--border)",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 8, fontWeight: 600 }}>
            <MessageSquare size={16} className="text-accent" />
            <span>Feedback & Support</span>
          </div>
          <button onClick={onClose} className="btn-icon">
            <X size={16} />
          </button>
        </div>

        <div className="modal-body" style={{ padding: 16, overflowY: "auto" }}>
          {result?.success ? (
            <div style={{ textAlign: "center", padding: "20px 0" }}>
              <CheckCircle size={48} color="var(--accent)" style={{ marginBottom: 16 }} />
              <h3 style={{ marginBottom: 8 }}>Issue Created Successfully</h3>
              <p style={{ color: "var(--text-muted)", marginBottom: 20 }}>
                Our AI has formatted your report and created a GitHub issue.
              </p>
              <a
                href={result.issueUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="sw-btn sw-btn-primary"
                style={{ display: "inline-flex", alignItems: "center", gap: 8 }}
              >
                View on GitHub <ExternalLink size={14} />
              </a>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <div style={{ marginBottom: 16 }}>
                <label style={{ display: "block", marginBottom: 6, fontSize: 13, fontWeight: 500 }}>
                  What happened? / What's your idea?
                </label>
                <textarea
                  className="sw-input"
                  style={{ width: "100%", minHeight: 120, resize: "vertical", padding: 10 }}
                  placeholder="Please describe the issue or your feature request (min. 10 characters)..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  disabled={isSubmitting}
                  required
                />
              </div>

              <div style={{ marginBottom: 16 }}>
                <button
                  type="button"
                  onClick={() => setShowContext(!showContext)}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 4,
                    background: "none",
                    border: "none",
                    fontSize: 12,
                    color: "var(--text-muted)",
                    cursor: "pointer",
                    padding: 0,
                  }}
                >
                  {showContext ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                  Captured Context (Automatic)
                </button>

                {showContext && (
                  <pre
                    style={{
                      marginTop: 8,
                      padding: 10,
                      background: "var(--bg)",
                      border: "1px solid var(--border)",
                      borderRadius: 4,
                      fontSize: 10,
                      maxHeight: 150,
                      overflow: "auto",
                      color: "var(--text-muted)",
                    }}
                  >
                    {JSON.stringify(snapshot, null, 2)}
                  </pre>
                )}
              </div>

              {result?.error && (
                <div
                  style={{
                    marginBottom: 16,
                    padding: 10,
                    background: "rgba(239, 68, 68, 0.1)",
                    border: "1px solid var(--danger)",
                    borderRadius: 4,
                    fontSize: 12,
                    color: "var(--danger)",
                    display: "flex",
                    gap: 8,
                  }}
                >
                  <AlertCircle size={14} style={{ flexShrink: 0 }} />
                  <span>{result.error}</span>
                </div>
              )}

              <div style={{ display: "flex", justifyContent: "flex-end", gap: 10 }}>
                <button type="button" onClick={onClose} className="sw-btn" disabled={isSubmitting}>
                  Cancel
                </button>
                <button
                  type="submit"
                  className="sw-btn sw-btn-primary"
                  disabled={isSubmitting || description.length < 10}
                  style={{ display: "flex", alignItems: "center", gap: 8 }}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 size={14} className="animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    "Submit Report"
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
