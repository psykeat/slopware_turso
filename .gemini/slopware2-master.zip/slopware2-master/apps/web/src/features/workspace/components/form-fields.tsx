import { useQuery } from "@tanstack/react-query";
import { useState, useEffect, useRef, useId } from "react";

import { useScopedHotkey } from "../../../features/hotkeys/use-scoped-hotkey";
import { lookupHelperTableFn } from "../../../server/server-functions";
import { t, type Lang } from "../i18n";

interface LookupSelectProps {
  tableName: string;
  value: string | null;
  onChange: (value: string | null) => void;
  disabled?: boolean;
  placeholder?: string;
  error?: string;
}

export function LookupSelect({
  tableName,
  value,
  onChange,
  disabled,
  placeholder = "Select...",
  error,
}: LookupSelectProps) {
  const instanceId = useId();
  const layerId = `lookupselect-${instanceId}`;
  const [search, setSearch] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useScopedHotkey(
    layerId,
    "F5",
    (e) => {
      if (disabled) return;
      const target = e.target as HTMLElement;
      if (containerRef.current?.contains(target)) {
        e.stopPropagation();
        setIsOpen(true);
      }
    },
    { global: true },
  );

  const { data: items = [], isLoading } = useQuery({
    queryKey: ["lookup", tableName, search],
    queryFn: () => lookupHelperTableFn({ data: { tableName, search } }),
    enabled: isOpen || !!value,
  });

  // Find label for current value
  const selectedItem = items.find((item) => item.value === value);
  const displayLabel = selectedItem ? selectedItem.label : value || "";

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="relative w-full" ref={containerRef}>
      <div
        className={`input flex cursor-pointer items-center justify-between ${
          disabled ? "cursor-not-allowed opacity-50 grayscale" : ""
        }`}
        onClick={() => !disabled && setIsOpen(!isOpen)}
        style={{
          height: "28px",
          background: "var(--bg-pane)",
          borderColor: error ? "#ef4444" : "var(--border)",
        }}
      >
        <span className={!value ? "text-muted" : ""} style={{ fontSize: "12px" }}>
          {displayLabel || placeholder}
        </span>
        <span style={{ fontSize: "9px", opacity: 0.5 }}>▼</span>
      </div>

      {isOpen && (
        <div
          className="dropdown-menu"
          style={{ width: "100%", top: "100%", right: "auto", left: 0, padding: 0 }}
        >
          <input
            autoFocus
            className="input"
            style={{
              border: "none",
              borderBottom: "1px solid var(--border)",
              borderRadius: 0,
              height: "30px",
            }}
            placeholder="Search..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <div style={{ maxHeight: "200px", overflowY: "auto" }}>
            {isLoading && (
              <div className="text-muted p-2" style={{ fontSize: "11px" }}>
                Loading...
              </div>
            )}
            {!isLoading && items.length === 0 && (
              <div className="text-muted p-2" style={{ fontSize: "11px" }}>
                No results
              </div>
            )}
            {items.map((item) => (
              <div
                key={item.value}
                className="dropdown-item"
                style={{ background: item.value === value ? "var(--accent-muted)" : "transparent" }}
                onClick={() => {
                  onChange(item.value);
                  setIsOpen(false);
                }}
              >
                <span style={{ fontWeight: item.value === value ? 600 : 400 }}>{item.label}</span>
                {item.code && (
                  <span
                    style={{
                      marginLeft: "auto",
                      fontFamily: "var(--font-mono)",
                      fontSize: "10px",
                      color: "var(--text-muted)",
                    }}
                  >
                    {item.code}
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

interface FieldRendererProps {
  field: {
    fieldName: string;
    fieldType: string;
    label: Record<string, string> | null;
    isRequired: boolean | null;
    lookupTable: string | null;
  };
  value: any;
  onChange: (value: any) => void;
  lang?: string;
  error?: string;
}

export function FieldRenderer({ field, value, onChange, lang = "en", error }: FieldRendererProps) {
  const tLabel = t(`field.${field.fieldName}`, lang as Lang);
  const isTranslated = tLabel !== `field.${field.fieldName}`;

  const label = field.label?.[lang] || field.label?.de || (isTranslated ? tLabel : field.fieldName);
  const type = (field.fieldType || "varchar").toLowerCase();
  const isNumeric = [
    "integer",
    "number",
    "decimal",
    "numeric",
    "real",
    "double",
    "float",
    "int",
    "smallint",
    "bigint",
  ].includes(type);

  return (
    <div style={{ marginBottom: "12px" }}>
      <label
        className="detail-field-label"
        style={{ display: "flex", alignItems: "center", gap: "4px" }}
      >
        {label}
        {field.isRequired && <span style={{ color: "#ef4444" }}>*</span>}
      </label>

      {field.lookupTable ? (
        <LookupSelect
          tableName={field.lookupTable}
          value={value as string}
          onChange={onChange}
          placeholder={`Select ${label}...`}
          error={error}
        />
      ) : type === "boolean" || type === "bool" ? (
        <div style={{ padding: "4px 0" }}>
          <input
            type="checkbox"
            checked={!!value}
            onChange={(e) => onChange(e.target.checked)}
            style={{
              width: "16px",
              height: "16px",
              cursor: "pointer",
              accentColor: "var(--accent)",
            }}
          />
        </div>
      ) : isNumeric ? (
        <input
          type="number"
          step="any"
          value={value ?? ""}
          onChange={(e) => onChange(e.target.value === "" ? null : Number(e.target.value))}
          className="input"
          style={{ height: "28px", borderColor: error ? "#ef4444" : "var(--border)" }}
        />
      ) : (
        <input
          type="text"
          value={value ?? ""}
          onChange={(e) => onChange(e.target.value)}
          className="input"
          style={{ height: "28px", borderColor: error ? "#ef4444" : "var(--border)" }}
        />
      )}

      {error && (
        <div style={{ color: "#ef4444", fontSize: "10px", marginTop: "2px", fontWeight: 500 }}>
          {error}
        </div>
      )}
    </div>
  );
}
