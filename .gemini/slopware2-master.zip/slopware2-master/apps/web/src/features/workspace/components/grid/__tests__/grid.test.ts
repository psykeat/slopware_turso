import { describe, it, expect } from "vitest";

describe("Grid component exports", () => {
  it("exports all grid components", async () => {
    const grid = await import("../index");
    expect(grid.GridRoot).toBeDefined();
    expect(grid.GridTable).toBeDefined();
    expect(grid.GridToolbar).toBeDefined();
    expect(grid.GridSearch).toBeDefined();
    expect(grid.GridFooter).toBeDefined();
    expect(grid.GridPagination).toBeDefined();
  });

  it("exports context hooks", async () => {
    const grid = await import("../index");
    expect(grid.useGridSearch).toBeDefined();
    expect(grid.useGridState).toBeDefined();
  });

  it("exports context providers", async () => {
    const grid = await import("../index");
    expect(grid.GridSearchContext).toBeDefined();
    expect(grid.GridStateContext).toBeDefined();
  });
});

describe("GridSearch default context value", () => {
  it("context is a valid React context object", async () => {
    const { GridSearchContext } = await import("../grid-context");
    expect(GridSearchContext).toBeDefined();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    expect((GridSearchContext as any)._currentValue).toBeDefined();
  });
});

describe("GridPageParams type shape", () => {
  it("has expected fields", async () => {
    const params = {
      pageIndex: 0,
      pageSize: 50,
      search: "",
      sorting: [],
    };
    expect(params.pageIndex).toBe(0);
    expect(params.pageSize).toBe(50);
    expect(params.search).toBe("");
    expect(Array.isArray(params.sorting)).toBe(true);
  });
});

describe("GridPageResult type shape", () => {
  it("has expected fields", async () => {
    const result = {
      items: [{ id: "1", name: "test" }],
      total: 1,
    };
    expect(result.items.length).toBe(1);
    expect(result.total).toBe(1);
  });
});

describe("GridRow type constraints", () => {
  it("requires id field", () => {
    const row = { id: "1", extra: "value" };
    expect(row.id).toBe("1");
    expect(row.extra).toBe("value");
  });

  it("accepts numeric id", () => {
    const row = { id: 42, name: "numeric" };
    expect(row.id).toBe(42);
  });
});

describe("GridMode type", () => {
  it("accepts valid modes", async () => {
    const modes = ["plain", "paginated", "virtual"];
    expect(modes).toContain("plain");
    expect(modes).toContain("paginated");
    expect(modes).toContain("virtual");
  });
});

describe("pagination calculations", () => {
  it("calculates correct page count", () => {
    const total = 123;
    const pageSize = 50;
    const pageCount = Math.max(1, Math.ceil(total / pageSize));
    expect(pageCount).toBe(3);
  });

  it("returns 1 page for zero items", () => {
    const total = 0;
    const pageSize = 50;
    const pageCount = Math.max(1, Math.ceil(total / pageSize));
    expect(pageCount).toBe(1);
  });

  it("returns 1 page when items fit exactly", () => {
    const total = 100;
    const pageSize = 50;
    const pageCount = Math.max(1, Math.ceil(total / pageSize));
    expect(pageCount).toBe(2);
  });

  it("returns 1 page when items equal page size", () => {
    const total = 50;
    const pageSize = 50;
    const pageCount = Math.max(1, Math.ceil(total / pageSize));
    expect(pageCount).toBe(1);
  });
});

describe("sorting state transitions", () => {
  it("adds new sort when none exists", () => {
    const prev: Array<{ id: string; desc: boolean }> = [];
    const columnId = "name";
    const existing = prev.find((s) => s.id === columnId);
    let next;
    if (!existing) next = [{ id: columnId, desc: false }];
    else if (existing.desc === false) next = [{ id: columnId, desc: true }];
    else next = prev.filter((s) => s.id !== columnId);
    expect(next).toEqual([{ id: "name", desc: false }]);
  });

  it("toggles from asc to desc", () => {
    const prev = [{ id: "name", desc: false }];
    const columnId = "name";
    const existing = prev.find((s) => s.id === columnId);
    let next;
    if (!existing) next = [{ id: columnId, desc: false }];
    else if (existing.desc === false) next = [{ id: columnId, desc: true }];
    else next = prev.filter((s) => s.id !== columnId);
    expect(next).toEqual([{ id: "name", desc: true }]);
  });

  it("removes sort when toggled from desc", () => {
    const prev = [{ id: "name", desc: true }];
    const columnId = "name";
    const existing = prev.find((s) => s.id === columnId);
    let next;
    if (!existing) next = [{ id: columnId, desc: false }];
    else if (existing.desc === false) next = [{ id: columnId, desc: true }];
    else next = prev.filter((s) => s.id !== columnId);
    expect(next).toEqual([]);
  });
});

describe("selection toggle logic", () => {
  it("adds id when not selected", () => {
    const prev = new Set<string | number>();
    const id = "1";
    const next = new Set(prev);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    expect(next.has(id)).toBe(true);
    expect(next.size).toBe(1);
  });

  it("removes id when already selected", () => {
    const prev = new Set(["1", "2"]);
    const id = "1";
    const next = new Set(prev);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    expect(next.has(id)).toBe(false);
    expect(next.size).toBe(1);
  });
});
