import { createContext, useContext } from "react";

import type { GridRow, GridMode } from "./grid-types";

export interface GridSearchValue {
  value: string;
  onChange: (value: string) => void;
}

const GridSearchContext = createContext<GridSearchValue>({
  value: "",
  onChange: () => {},
});

export function useGridSearch(): GridSearchValue {
  return useContext(GridSearchContext);
}

export interface GridStateValue<TData extends GridRow> {
  data: TData[];
  loading: boolean;
  total: number;
  mode: GridMode;
  selectable: boolean;
  selectedIds: Set<string | number>;
  selectedRowId: string | number | null;
  toggleSelect: (id: string | number) => void;
  editingRowId: string | number | null;
  editingValues: Record<string, unknown>;
  editableFields: string[] | undefined;
  onEditCellChange: ((field: string, value: unknown) => void) | undefined;
  onRowClick: ((row: TData) => void) | undefined;
  onRowDoubleClick: ((row: TData) => void) | undefined;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  renderRowActions: ((row: TData) => React.ReactNode) | undefined;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const GridStateContext = createContext<GridStateValue<any>>({
  data: [],
  loading: false,
  total: 0,
  mode: "plain",
  selectable: false,
  selectedIds: new Set(),
  selectedRowId: null,
  toggleSelect: () => {},
  editingRowId: null,
  editingValues: {},
  editableFields: undefined,
  onEditCellChange: undefined,
  onRowClick: undefined,
  onRowDoubleClick: undefined,
  renderRowActions: undefined,
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function useGridState<TData extends GridRow>(): GridStateValue<TData> {
  return useContext(GridStateContext) as GridStateValue<TData>;
}

export { GridSearchContext, GridStateContext };
