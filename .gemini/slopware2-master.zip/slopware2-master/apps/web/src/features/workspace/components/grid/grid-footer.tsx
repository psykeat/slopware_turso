import { GridPagination } from "./grid-pagination";
import type { GridMode } from "./grid-types";

interface GridFooterProps {
  total: number;
  pageSize: number;
  pageCount: number;
  pageIndex: number;
  selectedCount: number;
  onPageSizeChange: (size: number) => void;
  onPageChange: (index: number) => void;
  mode: GridMode;
  isServerManaged: boolean;
  className?: string;
}

export function GridFooter({
  total,
  pageSize,
  pageCount,
  pageIndex,
  selectedCount,
  onPageSizeChange,
  onPageChange,
  mode,
  isServerManaged,
  className,
}: GridFooterProps): React.ReactElement {
  if (mode === "paginated" && isServerManaged) {
    return (
      <div className={`sw-grid-footer ${className ?? ""}`}>
        <span className="sw-grid-total">
          {pageSize} of {total} entries
        </span>
        {selectedCount > 0 && (
          <span className="sw-grid-selected-count">{selectedCount} selected</span>
        )}
        <GridPagination
          pageIndex={pageIndex}
          pageCount={pageCount}
          pageSize={pageSize}
          onPageChange={onPageChange}
          onPageSizeChange={onPageSizeChange}
        />
      </div>
    );
  }

  return (
    <div className={`sw-grid-footer ${className ?? ""}`}>
      <span className="sw-grid-total">{total} entries</span>
      {selectedCount > 0 && (
        <span className="sw-grid-selected-count">{selectedCount} selected</span>
      )}
    </div>
  );
}
