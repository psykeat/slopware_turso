import { ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight } from "lucide-react";

interface GridPaginationProps {
  pageIndex: number;
  pageCount: number;
  pageSize: number;
  onPageChange: (index: number) => void;
  onPageSizeChange: (size: number) => void;
  pageSizeOptions?: number[];
  className?: string;
}

export function GridPagination({
  pageIndex,
  pageCount,
  pageSize,
  onPageChange,
  onPageSizeChange,
  pageSizeOptions = [25, 50, 100, 250],
  className,
}: GridPaginationProps): React.ReactElement {
  return (
    <div className={`sw-grid-pagination ${className ?? ""}`}>
      <button
        className="sw-grid-page-btn"
        disabled={pageIndex === 0}
        onClick={() => onPageChange(0)}
        aria-label="First page"
      >
        <ChevronsLeft size={14} />
      </button>
      <button
        className="sw-grid-page-btn"
        disabled={pageIndex === 0}
        onClick={() => onPageChange(pageIndex - 1)}
        aria-label="Previous page"
      >
        <ChevronLeft size={14} />
      </button>
      <select
        value={pageIndex + 1}
        onChange={(e) => onPageChange(Number(e.target.value) - 1)}
        className="sw-grid-page-select"
        aria-label="Current page"
      >
        {Array.from({ length: pageCount }, (_, i) => (
          <option key={i} value={i + 1}>
            {i + 1}
          </option>
        ))}
      </select>
      <span className="sw-grid-page-of">/ {pageCount}</span>
      <button
        className="sw-grid-page-btn"
        disabled={pageIndex >= pageCount - 1}
        onClick={() => onPageChange(pageIndex + 1)}
        aria-label="Next page"
      >
        <ChevronRight size={14} />
      </button>
      <button
        className="sw-grid-page-btn"
        disabled={pageIndex >= pageCount - 1}
        onClick={() => onPageChange(pageCount - 1)}
        aria-label="Last page"
      >
        <ChevronsRight size={14} />
      </button>
      <select
        value={pageSize}
        onChange={(e) => onPageSizeChange(Number(e.target.value))}
        className="sw-grid-page-size"
        aria-label="Page size"
      >
        {pageSizeOptions.map((size) => (
          <option key={size} value={size}>
            {size}
          </option>
        ))}
      </select>
    </div>
  );
}
