import type { SortingState } from "@tanstack/react-table";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { GridSearchContext, GridStateContext } from "./grid-context";
import type { GridStateValue } from "./grid-context";
import { GridFooter } from "./grid-footer";
import { GridTable } from "./grid-table";
import { GridToolbar } from "./grid-toolbar";
import type { GridRow, GridRootProps } from "./grid-types";

export function GridRoot<TData extends GridRow>(props: GridRootProps<TData>): React.ReactElement {
  const {
    columns,
    mode = "virtual",
    data: externalData,
    loading: externalLoading,
    total: externalTotal,
    loader,
    defaultSorting = [],
    defaultPageSize = 50,
    pageSizeOptions: _pageSizeOptions = [25, 50, 100, 250],
    selectable = false,
    onRowClick,
    onRowDoubleClick,
    renderHeaderActions,
    renderRowActions,
    emptyMessage = "No data",
    className,
    defaultSearch = "",
    searchDebounceMs = 300,
    onSearchCommit,
    selectedRowId,
    editingRowId,
    editingValues,
    onEditCellChange,
    editableFields,
    onKeyDown,
    reloadKey,
  } = props;

  const isServerManaged = loader !== undefined;
  const _isPaginated = mode === "paginated" && isServerManaged;
  const isVirtual = mode === "virtual";

  const [sorting, setSorting] = useState<SortingState>(defaultSorting);
  const [paging, setPaging] = useState({
    pageIndex: 0,
    pageSize: defaultPageSize,
  });
  const [selectedIds, setSelectedIds] = useState<Set<string | number>>(new Set());

  const [sData, setSData] = useState<TData[]>([]);
  const [sTotal, setSTotal] = useState(0);
  const [sLoading, setSLoading] = useState(false);

  const [searchInput, setSearchInput] = useState(defaultSearch);
  const [searchCommitted, setSearchCommitted] = useState(defaultSearch);
  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const loaderRef = useRef(loader);
  useEffect(() => {
    loaderRef.current = loader;
  }, [loader]);

  useEffect(() => {
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    if (searchInput === defaultSearch) {
      setSearchCommitted(searchInput);
      onSearchCommit?.(searchInput);
      return;
    }
    debounceTimer.current = setTimeout(() => {
      setSearchCommitted(searchInput);
      onSearchCommit?.(searchInput);
    }, searchDebounceMs);
    return () => {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
    };
  }, [searchInput, searchDebounceMs, defaultSearch, onSearchCommit]);

  useEffect(() => {
    if (!isServerManaged) return;

    setSLoading(true);
    loaderRef
      .current?.({
        pageIndex: paging.pageIndex,
        pageSize: paging.pageSize,
        search: searchCommitted,
        sorting,
      })
      .then((result) => {
        if (isVirtual && paging.pageIndex > 0) {
          setSData((prev) => [...prev, ...result.items]);
        } else {
          setSData(result.items);
        }
        setSTotal(result.total);
      })
      .finally(() => {
        setSLoading(false);
      });
  }, [
    isServerManaged,
    isVirtual,
    paging.pageIndex,
    paging.pageSize,
    searchCommitted,
    sorting,
    reloadKey,
  ]);

  const emptyData = useMemo(() => [], []);
  const data = isServerManaged ? sData : (externalData ?? emptyData);
  const loading = isServerManaged ? sLoading : (externalLoading ?? false);
  const total = isServerManaged ? sTotal : (externalTotal ?? data.length);

  const handleSort = useCallback((columnId: string) => {
    setSorting((prev) => {
      const existing = prev.find((s) => s.id === columnId);
      if (!existing) return [{ id: columnId, desc: false }];
      if (existing.desc === false) return [{ id: columnId, desc: true }];
      return prev.filter((s) => s.id !== columnId);
    });
  }, []);

  const prevSorting = useRef<SortingState>(defaultSorting);
  const prevSearch = useRef(defaultSearch);

  useEffect(() => {
    const sortChanged = JSON.stringify(sorting) !== JSON.stringify(prevSorting.current);
    const searchChanged = searchCommitted !== prevSearch.current;

    if (isServerManaged && (sortChanged || searchChanged)) {
      setPaging((p) => ({ ...p, pageIndex: 0 }));
      if (isVirtual) setSData([]);
      prevSorting.current = sorting;
      prevSearch.current = searchCommitted;
    }
  }, [sorting, searchCommitted, isServerManaged, isVirtual]);

  const toggleSelect = useCallback((id: string | number) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  useEffect(() => {
    if (!isVirtual || !isServerManaged || loading) return;

    const pageCount = Math.max(1, Math.ceil(total / paging.pageSize));
    if (data.length < total && paging.pageIndex < pageCount) {
      const lastItemIndex = data.length - 1;
      if (lastItemIndex >= 0) {
        setPaging((p) => ({ ...p, pageIndex: p.pageIndex + 1 }));
      }
    }
  }, [isVirtual, isServerManaged, loading, data.length, total, paging.pageIndex, paging.pageSize]);

  const searchContext = useMemo(
    () => ({
      value: searchInput,
      onChange: setSearchInput,
    }),
    [searchInput],
  );

  const stateContext = useMemo(
    () =>
      ({
        data,
        loading,
        total,
        mode,
        selectable,
        selectedIds,
        selectedRowId: selectedRowId ?? null,
        toggleSelect,
        editingRowId,
        editingValues: editingValues ?? {},
        editableFields,
        onEditCellChange,
        onRowClick,
        onRowDoubleClick,
        renderRowActions,
      }) as GridStateValue<TData>,
    [
      data,
      loading,
      total,
      mode,
      selectable,
      selectedIds,
      selectedRowId,
      toggleSelect,
      editingRowId,
      editingValues,
      editableFields,
      onEditCellChange,
      onRowClick,
      onRowDoubleClick,
      renderRowActions,
    ],
  );

  const pageCount = useMemo(() => {
    const t = total || data.length;
    return Math.max(1, Math.ceil(t / paging.pageSize));
  }, [total, data.length, paging.pageSize]);

  return (
    <GridSearchContext.Provider value={searchContext}>
      <GridStateContext.Provider value={stateContext}>
        <div
          className={`sw-grid-root ${className ?? ""} sw-grid-mode-${mode}`}
          role="presentation"
          onKeyDown={onKeyDown}
        >
          {renderHeaderActions && <GridToolbar>{renderHeaderActions()}</GridToolbar>}

          <GridTable
            columns={columns}
            sorting={sorting}
            onSort={handleSort}
            pageSize={paging.pageSize}
            isVirtual={isVirtual}
            emptyMessage={emptyMessage}
          />

          <GridFooter
            total={total}
            pageSize={paging.pageSize}
            pageCount={pageCount}
            pageIndex={paging.pageIndex}
            selectedCount={selectedIds.size}
            onPageSizeChange={(size) => setPaging((p) => ({ ...p, pageSize: size, pageIndex: 0 }))}
            onPageChange={(index) => setPaging((p) => ({ ...p, pageIndex: index }))}
            mode={mode}
            isServerManaged={isServerManaged}
          />
        </div>
      </GridStateContext.Provider>
    </GridSearchContext.Provider>
  );
}
