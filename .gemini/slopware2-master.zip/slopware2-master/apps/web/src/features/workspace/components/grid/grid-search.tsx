import { useGridSearch } from "./grid-context";
import type { GridSearchProps } from "./grid-types";

export function GridSearch({ placeholder, className }: GridSearchProps): React.ReactElement {
  const { value, onChange } = useGridSearch();
  return (
    <input
      className={`sw-grid-search ${className ?? ""}`}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder ?? "Search..."}
    />
  );
}
