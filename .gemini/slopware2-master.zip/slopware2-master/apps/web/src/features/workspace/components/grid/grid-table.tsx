import {
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  useReactTable,
  type ColumnDef,
  type SortingState,
} from "@tanstack/react-table";
import { useVirtualizer } from "@tanstack/react-virtual";
import { ChevronDown, ChevronUp } from "lucide-react";
import { useRef } from "react";

import { useGridState } from "./grid-context";
import type { GridRow } from "./grid-types";

interface GridTableProps<TData extends GridRow> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  columns: ColumnDef<TData, any>[];
  sorting: SortingState;
  onSort: (columnId: string) => void;
  pageSize: number;
  isVirtual: boolean;
  emptyMessage: string;
  className?: string;
}

export function GridTable<TData extends GridRow>({
  columns,
  sorting,
  onSort,
  pageSize: _pageSize,
  isVirtual,
  emptyMessage,
  className,
}: GridTableProps<TData>): React.ReactElement {
  const {
    data,
    loading,
    selectable,
    selectedIds,
    selectedRowId,
    toggleSelect,
    editingRowId,
    editingValues,
    editableFields,
    onEditCellChange,
    onRowClick,
    onRowDoubleClick,
    renderRowActions,
  } = useGridState<TData>();

  const table = useReactTable({
    data,
    columns,
    state: { sorting, pagination: { pageIndex: 0, pageSize: _pageSize } },
    onSortingChange: () => {},
    getSortedRowModel: getSortedRowModel(),
    getCoreRowModel: getCoreRowModel(),
    manualSorting: true,
    manualPagination: true,
  });

  const { rows } = table.getRowModel();

  const tableContainerRef = useRef<HTMLDivElement>(null);

  const rowVirtualizer = useVirtualizer({
    count: rows.length,
    estimateSize: () => 35,
    getScrollElement: () => tableContainerRef.current,
    overscan: 10,
  });

  const virtualRows = rowVirtualizer.getVirtualItems();
  const totalSize = rowVirtualizer.getTotalSize();

  const paddingTop = virtualRows.length > 0 ? virtualRows?.[0]?.start || 0 : 0;
  const paddingBottom =
    virtualRows.length > 0 ? totalSize - (virtualRows?.[virtualRows.length - 1]?.end || 0) : 0;

  const totalColumns = columns.length + (selectable ? 1 : 0) + (renderRowActions ? 1 : 0);

  return (
    <div
      ref={tableContainerRef}
      className={`sw-grid-table-wrap ${className ?? ""}`}
      style={isVirtual ? { height: "100%", overflow: "auto", position: "relative" } : {}}
    >
      <table className="sw-grid-table">
        <thead>
          {table.getHeaderGroups().map((hg) => (
            <tr key={hg.id}>
              {selectable && <th className="sw-grid-checkbox-col" />}
              {hg.headers.map((h) => {
                const col = h.column;
                const isSorted = col.getIsSorted();
                return (
                  <th
                    key={h.id}
                    className={col.getCanSort() ? "sw-grid-sortable" : ""}
                    style={{ width: h.getSize() }}
                    onClick={() => col.getCanSort() && onSort(col.id)}
                  >
                    {h.isPlaceholder ? null : flexRender(h.column.columnDef.header, h.getContext())}
                    {col.getCanSort() && (
                      <span className="sw-grid-sort-icon">
                        {isSorted === "asc" ? (
                          <ChevronUp size={12} />
                        ) : isSorted === "desc" ? (
                          <ChevronDown size={12} />
                        ) : null}
                      </span>
                    )}
                  </th>
                );
              })}
              {renderRowActions ? <th className="sw-grid-actions-col" /> : null}
            </tr>
          ))}
        </thead>
        <tbody>
          {paddingTop > 0 && (
            <tr>
              <td colSpan={totalColumns} style={{ height: `${paddingTop}px`, padding: 0 }} />
            </tr>
          )}
          {loading && !isVirtual ? (
            <tr>
              <td colSpan={totalColumns} className="sw-grid-loading">
                Loading...
              </td>
            </tr>
          ) : rows.length === 0 ? (
            <tr>
              <td colSpan={totalColumns} className="sw-grid-empty">
                {emptyMessage}
              </td>
            </tr>
          ) : (
            (isVirtual ? virtualRows : rows).map((item) => {
              const row = isVirtual ? rows[item.index] : (item as any);
              const rowData = row.original as TData;
              return (
                <tr
                  key={row.id}
                  data-index={isVirtual ? item.index : undefined}
                  ref={isVirtual ? rowVirtualizer.measureElement : undefined}
                  className={[
                    onRowClick ? "sw-grid-clickable" : "",
                    selectedIds.has(rowData.id) || rowData.id === selectedRowId
                      ? "sw-grid-selected"
                      : "",
                  ]
                    .filter(Boolean)
                    .join(" ")}
                  onClick={() => onRowClick?.(rowData)}
                  onDoubleClick={() => onRowDoubleClick?.(rowData)}
                >
                  {selectable && (
                    <td className="sw-grid-checkbox-col" onClick={(e) => e.stopPropagation()}>
                      <input
                        type="checkbox"
                        checked={selectedIds.has(rowData.id)}
                        onChange={() => toggleSelect(rowData.id)}
                      />
                    </td>
                  )}
                  {row.getVisibleCells().map((cell: any) => {
                    const colId = cell.column.id;
                    const isEditing =
                      editingRowId !== null &&
                      rowData.id === editingRowId &&
                      editableFields !== undefined &&
                      editableFields.includes(colId);
                    const cellValue = isEditing
                      ? (editingValues?.[colId] ?? cell.getValue())
                      : cell.getValue();
                    return (
                      <td key={cell.id} className={isEditing ? "sw-grid-editing-cell" : ""}>
                        {isEditing && onEditCellChange ? (
                          <input
                            className="sw-grid-edit-input"
                            type="text"
                            value={String(cellValue ?? "")}
                            onChange={(e) => onEditCellChange(colId, e.target.value)}
                            onClick={(e) => e.stopPropagation()}
                            onKeyDown={(e) => e.stopPropagation()}
                          />
                        ) : (
                          flexRender(cell.column.columnDef.cell, cell.getContext())
                        )}
                      </td>
                    );
                  })}
                  {renderRowActions && (
                    <td className="sw-grid-actions-col" onClick={(e) => e.stopPropagation()}>
                      {renderRowActions(rowData)}
                    </td>
                  )}
                </tr>
              );
            })
          )}
          {paddingBottom > 0 && (
            <tr>
              <td colSpan={totalColumns} style={{ height: `${paddingBottom}px`, padding: 0 }} />
            </tr>
          )}
          {loading && isVirtual && (
            <tr>
              <td colSpan={totalColumns} className="sw-grid-loading">
                Loading more...
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
