import type { GridToolbarProps } from "./grid-types";

export function GridToolbar({ children, className }: GridToolbarProps): React.ReactElement {
  return <div className={`sw-grid-toolbar ${className ?? ""}`}>{children}</div>;
}
