import type { ColumnDef, SortingState } from "@tanstack/react-table";

export interface GridRow {
  id: string | number;
  [key: string]: unknown;
}

export interface GridPageParams {
  pageIndex: number;
  pageSize: number;
  search: string;
  sorting: SortingState;
}

export interface GridPageResult<TData extends GridRow> {
  items: TData[];
  total: number;
}

export type GridMode = "plain" | "paginated" | "virtual";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type GridColumnDef<TData extends GridRow> = ColumnDef<TData, any>;

export interface GridRootProps<TData extends GridRow> {
  columns: GridColumnDef<TData>[];
  mode?: GridMode;
  data?: TData[];
  loading?: boolean;
  total?: number;
  loader?: (params: GridPageParams) => Promise<GridPageResult<TData>>;
  defaultSorting?: SortingState;
  defaultPageSize?: number;
  pageSizeOptions?: number[];
  selectable?: boolean;
  onRowClick?: (row: TData) => void;
  onRowDoubleClick?: (row: TData) => void;
  renderHeaderActions?: () => React.ReactNode;
  renderRowActions?: (row: TData) => React.ReactNode;
  emptyMessage?: string;
  className?: string;
  defaultSearch?: string;
  searchDebounceMs?: number;
  onSearchCommit?: (search: string) => void;
  selectedRowId?: string | number | null;
  editingRowId?: string | number | null;
  editingValues?: Record<string, unknown>;
  onEditCellChange?: (field: string, value: unknown) => void;
  editableFields?: string[];
  onKeyDown?: (e: React.KeyboardEvent) => void;
  reloadKey?: number;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export interface GridTableProps<TData extends GridRow = any> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  columns: ColumnDef<TData, any>[];
  sorting: SortingState;
  onSort: (columnId: string) => void;
  pageSize: number;
  isVirtual: boolean;
  emptyMessage: string;
  pageSizeOptions?: number[];
  className?: string;
}

export interface GridToolbarProps {
  children?: React.ReactNode;
  className?: string;
}

export interface GridSearchProps {
  placeholder?: string;
  className?: string;
}

export interface GridFooterProps {
  total: number;
  pageSize: number;
  pageCount: number;
  pageIndex: number;
  selectedCount: number;
  onPageSizeChange: (size: number) => void;
  onPageChange: (index: number) => void;
  mode: GridMode;
  isServerManaged: boolean;
  className?: string;
}

export interface GridPaginationProps {
  pageIndex: number;
  pageCount: number;
  pageSize: number;
  onPageChange: (index: number) => void;
  onPageSizeChange: (size: number) => void;
  className?: string;
}
