import { X } from "lucide-react";
import * as React from "react";

import { useHotkeyStore } from "../../hotkeys/hotkey-store";

const SHORTCUT_DESCRIPTIONS: Record<string, Record<string, string>> = {
  de: {
    "global:?": "Tastenkürzel anzeigen",
    "global:Alt+I": "Statistik öffnen",
    "global:Shift+F1": "Feedback senden",
    "crud-dialog:Escape": "Dialog schließen",
    "detail-panel:F7": "Beleg wandeln",
    "detail-panel:F9": "Beleg wandeln (alt)",
    "lines-panel:Escape": "Zeilen-Editor schließen",
  },
  en: {
    "global:?": "Show keyboard shortcuts",
    "global:Alt+I": "Open statistics",
    "global:Shift+F1": "Send feedback",
    "crud-dialog:Escape": "Close dialog",
    "detail-panel:F7": "Convert document",
    "detail-panel:F9": "Convert document (alt)",
    "lines-panel:Escape": "Close lines editor",
  },
};

const SCOPE_LABELS: Record<string, Record<string, string>> = {
  de: {
    global: "Global",
    "crud-dialog": "Erstellungs-Dialog",
    "detail-panel": "Detail-Ansicht",
    "lines-panel": "Zeilen-Editor",
  },
  en: {
    global: "Global",
    "crud-dialog": "Create Dialog",
    "detail-panel": "Detail View",
    "lines-panel": "Lines Editor",
  },
};

interface HotkeyCheatsheetProps {
  isOpen: boolean;
  onClose: () => void;
  t: (k: string) => string;
  lang: string;
}

export function HotkeyCheatsheet({ isOpen, onClose, t, lang }: HotkeyCheatsheetProps) {
  const registry = useHotkeyStore((s) => s.registry);

  const descriptions = SHORTCUT_DESCRIPTIONS[lang] ?? SHORTCUT_DESCRIPTIONS.en;
  const scopeLabels = SCOPE_LABELS[lang] ?? SCOPE_LABELS.en;

  const groupedEntries = React.useMemo(() => {
    const groups: Record<string, { key: string; desc: string }[]> = {};
    registry.forEach((entries, layerId) => {
      const keys = entries.map((e) => e.key);
      const uniqueKeys = Array.from(new Set(keys));
      uniqueKeys.forEach((key) => {
        if (!groups[layerId]) groups[layerId] = [];
        const descKey = `${layerId}:${key}`;
        groups[layerId].push({
          key,
          desc: descriptions[descKey] ?? key,
        });
      });
    });
    return groups;
  }, [registry, descriptions]);

  if (!isOpen) return null;

  return (
    <div
      className="sw-overlay"
      role="presentation"
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.5)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 1000,
        backdropFilter: "blur(2px)",
      }}
      onClick={onClose}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onClose();
        }
      }}
      tabIndex={-1}
    >
      <div
        className="sw-cheatsheet"
        role="dialog"
        aria-modal="true"
        aria-label={t("cheatsheet.title")}
        style={{
          background: "var(--bg-pane)",
          width: "480px",
          borderRadius: "var(--radius)",
          border: "1px solid var(--border)",
          display: "flex",
          flexDirection: "column",
          maxHeight: "80vh",
          boxShadow: "var(--shadow-lg)",
        }}
        onClick={(e) => e.stopPropagation()}
        onKeyDown={(e) => e.stopPropagation()}
      >
        <div
          style={{
            padding: "10px 14px",
            borderBottom: "1px solid var(--border)",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <span style={{ fontSize: 13, fontWeight: 600 }}>{t("cheatsheet.title")}</span>
          <button onClick={onClose} className="sw-btn-icon">
            <X size={14} />
          </button>
        </div>

        <div style={{ padding: 14, overflowY: "auto", flex: 1 }}>
          {Object.entries(groupedEntries).map(([scope, entries]) => (
            <div key={scope} style={{ marginBottom: 14 }}>
              <div
                style={{
                  fontSize: 9.5,
                  fontWeight: 700,
                  textTransform: "uppercase",
                  letterSpacing: "0.1em",
                  color: "var(--text-muted)",
                  marginBottom: 6,
                }}
              >
                {scopeLabels[scope] ?? scope}
              </div>
              {entries.map((entry) => (
                <div
                  key={entry.key}
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "3px 0",
                    fontSize: 12,
                  }}
                >
                  <span>{entry.desc}</span>
                  <kbd
                    style={{
                      fontFamily: "DM Mono, monospace",
                      fontSize: 11,
                      background: "var(--bg)",
                      border: "1px solid var(--border)",
                      borderRadius: 3,
                      padding: "1px 6px",
                      color: "var(--text-primary)",
                    }}
                  >
                    {entry.key}
                  </kbd>
                </div>
              ))}
            </div>
          ))}

          {Object.keys(groupedEntries).length === 0 && (
            <div
              style={{ color: "var(--text-muted)", fontSize: 12, textAlign: "center", padding: 20 }}
            >
              {t("cheatsheet.empty")}
            </div>
          )}
        </div>

        <div
          style={{
            padding: "8px 14px",
            borderTop: "1px solid var(--border)",
            fontSize: 11,
            color: "var(--text-muted)",
            textAlign: "center",
          }}
        >
          {t("cheatsheet.close")}
        </div>
      </div>
    </div>
  );
}
