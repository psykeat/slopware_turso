import type { InventoryBalanceRow } from "@repo/domain";
import { useQuery } from "@tanstack/react-query";
import * as React from "react";

import { getInventoryBalanceFn } from "~/server/server-functions";

interface InventoryBalanceTableProps {
  articleId: string;
}

export function InventoryBalanceTable({ articleId }: InventoryBalanceTableProps) {
  const { data, isLoading } = useQuery({
    queryKey: ["inventory-balance", articleId],
    queryFn: () => getInventoryBalanceFn({ data: { articleId } }),
    enabled: !!articleId,
  });

  const rows = (data as InventoryBalanceRow[]) ?? [];
  const hasMultiple = rows.length > 1;
  const total = hasMultiple
    ? {
        onHandQty: rows.reduce((s, r) => s + r.onHandQty, 0),
        reservedQty: rows.reduce((s, r) => s + r.reservedQty, 0),
        availableQty: rows.reduce((s, r) => s + r.availableQty, 0),
      }
    : null;

  if (isLoading) {
    return <div style={{ padding: "12px", color: "var(--text-muted)" }}>Lade Bestände...</div>;
  }

  if (rows.length === 0) {
    return <div style={{ padding: "12px", color: "var(--text-muted)" }}>Keine Bestände</div>;
  }

  return (
    <div style={{ marginTop: "12px" }}>
      <table
        style={{
          width: "100%",
          borderCollapse: "collapse",
          fontSize: "13px",
        }}
      >
        <thead>
          <tr>
            <th style={thStyle}>Lager</th>
            <th style={{ ...thStyle, textAlign: "right" }}>Vorhanden</th>
            <th style={{ ...thStyle, textAlign: "right" }}>Reserviert</th>
            <th style={{ ...thStyle, textAlign: "right" }}>Verfügbar</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.warehouseId}>
              <td style={tdStyle}>
                {r.warehouseName} ({r.warehouseCode})
              </td>
              <td style={{ ...tdStyle, textAlign: "right" }}>{r.onHandQty.toFixed(2)}</td>
              <td style={{ ...tdStyle, textAlign: "right", color: "#d97706" }}>
                {r.reservedQty.toFixed(2)}
              </td>
              <td style={{ ...tdStyle, textAlign: "right", color: "#16a34a" }}>
                {r.availableQty.toFixed(2)}
              </td>
            </tr>
          ))}
          {total && (
            <tr style={{ borderTop: "2px solid var(--border)", fontWeight: 600 }}>
              <td style={tdStyle}>Gesamt</td>
              <td style={{ ...tdStyle, textAlign: "right" }}>{total.onHandQty.toFixed(2)}</td>
              <td style={{ ...tdStyle, textAlign: "right", color: "#d97706" }}>
                {total.reservedQty.toFixed(2)}
              </td>
              <td style={{ ...tdStyle, textAlign: "right", color: "#16a34a" }}>
                {total.availableQty.toFixed(2)}
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

const thStyle: React.CSSProperties = {
  padding: "6px 8px",
  textAlign: "left",
  borderBottom: "1px solid var(--border)",
  color: "var(--text-muted)",
  fontWeight: 600,
  fontSize: "11px",
  textTransform: "uppercase",
};

const tdStyle: React.CSSProperties = {
  padding: "6px 8px",
  borderBottom: "1px solid var(--border-subtle)",
};
