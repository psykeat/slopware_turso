import { useQuery } from "@tanstack/react-query";
import { ChevronDown, Search } from "lucide-react";
import { useState, useEffect, useRef, useCallback, useId } from "react";

import { useScopedHotkey } from "../../hotkeys/use-scoped-hotkey";

export interface LookupItem {
  value: string;
  label: string;
  code?: string;
}

export interface LookupInputProps {
  label?: string;
  value: string | null;
  onChange: (value: string | null) => void;
  queryKey: (string | number | null)[];
  queryFn: (search: string) => Promise<LookupItem[]>;
  getDisplayLabel?: (item: LookupItem) => string;
  renderItem?: (item: LookupItem, isActive: boolean) => React.ReactNode;
  placeholder?: string;
  icon?: React.ReactNode;
  tabIndex?: number;
  disabled?: boolean;
  hotkey?: string;
}

export function LookupInput({
  label,
  value,
  onChange,
  queryKey,
  queryFn,
  getDisplayLabel,
  renderItem,
  placeholder,
  icon,
  tabIndex,
  disabled,
  hotkey,
}: LookupInputProps) {
  const instanceId = useId();
  const layerId = `lookup-${instanceId}`;
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  const { data: items = [] } = useQuery({
    queryKey,
    queryFn: () => queryFn(search),
    enabled: isOpen,
  });

  const results = items as LookupItem[];

  useEffect(() => {
    if (isOpen) {
      setSelectedIndex(0);
      setTimeout(() => searchRef.current?.focus(), 50);
    }
  }, [isOpen]);

  useScopedHotkey(
    layerId,
    hotkey || "F5",
    (e) => {
      if (disabled) return;
      const target = e.target as HTMLElement;
      if (containerRef.current?.contains(target)) {
        e.stopPropagation();
        setIsOpen((prev) => !prev);
      }
    },
    { global: true },
  );

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  useEffect(() => {
    if (selectedIndex >= results.length && results.length > 0) {
      setSelectedIndex(results.length - 1);
    }
  }, [results.length, selectedIndex]);

  const selectItem = useCallback(
    (item: LookupItem) => {
      onChange(item.value);
      setIsOpen(false);
      setSearch("");
    },
    [onChange],
  );

  const handleToggle = () => {
    if (!disabled) {
      setIsOpen((prev) => !prev);
      setSearch("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setIsOpen(true);
      setSelectedIndex((prev) => Math.min(prev + 1, results.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((prev) => Math.max(prev - 1, 0));
    } else if (e.key === "Enter" && isOpen && results[selectedIndex]) {
      e.preventDefault();
      selectItem(results[selectedIndex]);
    } else if (e.key === "Escape") {
      setIsOpen(false);
    }
  };

  const selectedItem = results.find((i) => i.value === value);
  const displayLabel = selectedItem ? (getDisplayLabel?.(selectedItem) ?? selectedItem.label) : "";

  return (
    <div className="sw-lookup-input flex flex-col gap-0.5" ref={containerRef}>
      {label && <label className="sw-lookup-label">{label}</label>}
      <div className="relative">
        <div
          className={`sw-lookup-trigger flex items-center justify-between gap-1 ${disabled ? "sw-lookup-disabled" : ""}`}
          tabIndex={disabled ? -1 : (tabIndex ?? 0)}
          role="combobox"
          aria-expanded={isOpen}
          onClick={handleToggle}
          onKeyDown={handleKeyDown}
        >
          <div className="sw-lookup-content flex items-center gap-1.5 overflow-hidden">
            {icon && <span className="sw-lookup-icon text-gray-400">{icon}</span>}
            <span className={`sw-lookup-text truncate ${!value ? "text-gray-400" : ""}`}>
              {displayLabel || placeholder || "..."}
            </span>
          </div>
          <ChevronDown size={10} className="sw-lookup-chevron text-gray-400" />
        </div>

        {isOpen && (
          <div className="sw-lookup-dropdown">
            <div className="sw-lookup-search-wrap flex items-center">
              <Search size={10} className="sw-lookup-search-icon text-gray-400" />
              <input
                ref={searchRef}
                className="sw-lookup-search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "ArrowDown") {
                    e.preventDefault();
                    setSelectedIndex(0);
                  } else if (e.key === "Escape") {
                    setIsOpen(false);
                  }
                }}
              />
            </div>
            <div ref={listRef} className="sw-lookup-list">
              {results.length === 0 && (
                <div className="sw-lookup-empty text-gray-400">No results</div>
              )}
              {results.map((item, idx) => {
                const isActive = idx === selectedIndex;
                const isSelected = item.value === value;
                if (renderItem) {
                  return (
                    <div
                      key={item.value}
                      className={`sw-lookup-row ${isActive ? "sw-lookup-row-active" : ""} ${isSelected ? "sw-lookup-row-selected" : ""}`}
                      onClick={() => selectItem(item)}
                      onMouseEnter={() => setSelectedIndex(idx)}
                    >
                      {renderItem(item, isActive)}
                    </div>
                  );
                }
                return (
                  <div
                    key={item.value}
                    className={`sw-lookup-row ${isActive ? "sw-lookup-row-active" : ""} ${isSelected ? "sw-lookup-row-selected" : ""}`}
                    onClick={() => selectItem(item)}
                    onMouseEnter={() => setSelectedIndex(idx)}
                  >
                    <span className="sw-lookup-row-label">{item.label}</span>
                    {item.code && <span className="sw-lookup-row-code">{item.code}</span>}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
