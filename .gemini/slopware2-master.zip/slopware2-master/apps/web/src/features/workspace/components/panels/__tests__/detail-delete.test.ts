import { describe, it, expect } from "vitest";

const DELETABLE_TYPES = new Set(["N", "A", "L", "b", "l", "V", "Z", "E", "U"]);

describe("DetailPanelAdapter delete visibility", () => {
  it("allows delete for allowed document types", () => {
    const allowed = ["N", "A", "L", "b", "l", "V", "Z", "E", "U"];
    for (const type of allowed) {
      expect(DELETABLE_TYPES.has(type)).toBe(true);
    }
  });

  it("hides delete for protected document types R, r, G, g", () => {
    const protectedTypes = ["R", "r", "G", "g"];
    for (const type of protectedTypes) {
      expect(DELETABLE_TYPES.has(type)).toBe(false);
    }
  });

  it("computes isDeletable correctly for document entity", () => {
    const entity = "document";
    const postableEntities = new Set(["document"]);

    const isDeletable = (docType: string | undefined) =>
      postableEntities.has(entity ?? "") && !!docType ? DELETABLE_TYPES.has(docType) : false;

    expect(isDeletable("N")).toBe(true);
    expect(isDeletable("A")).toBe(true);
    expect(isDeletable("L")).toBe(true);
    expect(isDeletable("R")).toBe(false);
    expect(isDeletable("r")).toBe(false);
    expect(isDeletable("G")).toBe(false);
    expect(isDeletable("g")).toBe(false);
    expect(isDeletable(undefined)).toBe(false);
  });

  it("hides delete for non-document entities", () => {
    const entity = "address";
    const postableEntities = new Set(["document"]);

    const isDeletable = (docType: string | undefined) =>
      postableEntities.has(entity ?? "") && !!docType ? DELETABLE_TYPES.has(docType) : false;

    expect(isDeletable("N")).toBe(false);
  });
});
