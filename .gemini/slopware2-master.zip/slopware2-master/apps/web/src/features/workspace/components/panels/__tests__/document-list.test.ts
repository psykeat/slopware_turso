import { describe, it, expect } from "vitest";

describe("DocumentListAdapter exports", () => {
  it("exports DocumentListAdapter", async () => {
    const panels = await import("../index");
    expect(panels.DocumentListAdapter).toBeDefined();
  });
});

describe("DocumentListAdapter panel type", () => {
  it("identifies a document-list panel state", () => {
    const panel = { type: "document-list", entity: "document" } as const;
    expect(panel.type).toBe("document-list");
    expect(panel.entity).toBe("document");
  });

  it("identifies a document-list panel with filter params", () => {
    const panel = {
      type: "document-list",
      entity: "document",
      viewKey: "all",
      params: {
        documentType: "N",
        documentGroupId: "group-1",
      },
    } as const;
    expect(panel.type).toBe("document-list");
    expect(panel.params?.documentType).toBe("N");
    expect(panel.params?.documentGroupId).toBe("group-1");
  });
});

describe("Document tree grouping logic", () => {
  const outbound = new Set(["N", "A", "L", "R", "G"]);
  const inbound = new Set(["b", "l", "r"]);
  const _inventory = new Set(["g", "Z", "E", "V", "U"]);

  const getGroupKey = (mt: string) => {
    if (outbound.has(mt)) return "outbound";
    if (inbound.has(mt)) return "inbound";
    return "inventory";
  };

  it("groups outbound types correctly", () => {
    expect(getGroupKey("N")).toBe("outbound");
    expect(getGroupKey("A")).toBe("outbound");
    expect(getGroupKey("L")).toBe("outbound");
    expect(getGroupKey("R")).toBe("outbound");
    expect(getGroupKey("G")).toBe("outbound");
  });

  it("groups inbound types correctly", () => {
    expect(getGroupKey("b")).toBe("inbound");
    expect(getGroupKey("l")).toBe("inbound");
    expect(getGroupKey("r")).toBe("inbound");
  });

  it("groups inventory types correctly", () => {
    expect(getGroupKey("g")).toBe("inventory");
    expect(getGroupKey("Z")).toBe("inventory");
    expect(getGroupKey("E")).toBe("inventory");
    expect(getGroupKey("V")).toBe("inventory");
    expect(getGroupKey("U")).toBe("inventory");
  });

  it("defaults to inventory for unknown types", () => {
    expect(getGroupKey("q")).toBe("inventory");
    expect(getGroupKey("")).toBe("inventory");
  });
});

describe("Document tree group labels", () => {
  const getGroupLabels = (key: string) => {
    switch (key) {
      case "outbound":
        return { group_de: "Warenausgang", group_en: "Outgoing documents" };
      case "inbound":
        return { group_de: "Wareneingang", group_en: "Incoming documents" };
      default:
        return { group_de: "Lagerbuchungen", group_en: "Inventory postings", collapsed: true };
    }
  };

  it("returns correct outbound labels", () => {
    const labels = getGroupLabels("outbound");
    expect(labels.group_de).toBe("Warenausgang");
    expect(labels.group_en).toBe("Outgoing documents");
    expect(labels.collapsed).toBeUndefined();
  });

  it("returns correct inbound labels", () => {
    const labels = getGroupLabels("inbound");
    expect(labels.group_de).toBe("Wareneingang");
    expect(labels.group_en).toBe("Incoming documents");
    expect(labels.collapsed).toBeUndefined();
  });

  it("returns correct inventory labels with collapsed", () => {
    const labels = getGroupLabels("inventory");
    expect(labels.group_de).toBe("Lagerbuchungen");
    expect(labels.group_en).toBe("Inventory postings");
    expect(labels.collapsed).toBe(true);
  });
});

describe("Document list filter construction", () => {
  it("builds filter for document type", () => {
    const documentType = "N";
    const conditions: string[] = [];
    const params: unknown[] = [];
    params.push(documentType);
    conditions.push(`d.document_type = $${params.length}`);
    expect(conditions.length).toBe(1);
    expect(conditions[0]).toBe("d.document_type = $1");
  });

  it("builds combined filter for type and group", () => {
    const documentType = "L";
    const documentGroupId = "grp-123";
    const conditions: string[] = [];
    const params: unknown[] = [];
    params.push(documentType);
    conditions.push(`d.document_type = $${params.length}`);
    params.push(documentGroupId);
    conditions.push(`d.document_group_id = $${params.length}`);
    expect(conditions.length).toBe(2);
    expect(conditions[0]).toBe("d.document_type = $1");
    expect(conditions[1]).toBe("d.document_group_id = $2");
  });

  it("builds search filter with ILIKE", () => {
    const search = "AUF";
    const conditions: string[] = [];
    const params: unknown[] = [];
    params.push(`%${search}%`);
    conditions.push(`(d.document_no ILIKE $${params.length} OR d.status ILIKE $${params.length})`);
    expect(conditions.length).toBe(1);
    expect(conditions[0]).toContain("ILIKE");
    expect(conditions[0]).toContain("$1");
    expect(params[0]).toBe("%AUF%");
  });

  it("returns empty conditions when no filters", () => {
    const conditions: string[] = [];
    expect(conditions.length).toBe(0);
    const whereClause = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    expect(whereClause).toBe("");
  });
});

describe("Document list row click handler", () => {
  it("dispatches openRecord intent with document id", () => {
    const intents: any[] = [];
    const dispatchIntent = (intent: any) => intents.push(intent);
    const row = { document_id: "doc-42" };
    dispatchIntent({
      action: "openRecord",
      entity: "document",
      id: String(row.document_id),
      targetSlot: "s2",
    });
    expect(intents.length).toBe(1);
    expect(intents[0].action).toBe("openRecord");
    expect(intents[0].entity).toBe("document");
    expect(intents[0].id).toBe("doc-42");
    expect(intents[0].targetSlot).toBe("s2");
  });
});

describe("Document tree item click", () => {
  it("sets group and type from tree item with groupId", () => {
    let selectedGroup: string | null = null;
    let selectedType: string | null = null;
    const item = { key: "dg-1", groupId: "grp-1", docType: "N" } as {
      key: string;
      groupId?: string;
      docType?: string;
    };
    if (item.groupId) {
      selectedGroup = item.groupId;
      selectedType = item.docType ?? null;
    }
    expect(selectedGroup).toBe("grp-1");
    expect(selectedType).toBe("N");
  });

  it("handles tree item without docType", () => {
    let selectedGroup: string | null = null;
    let selectedType: string | null = null;
    const item = { key: "dg-2", groupId: "grp-2" } as {
      key: string;
      groupId?: string;
      docType?: string;
    };
    if (item.groupId) {
      selectedGroup = item.groupId;
      selectedType = item.docType ?? null;
    }
    expect(selectedGroup).toBe("grp-2");
    expect(selectedType).toBe(null);
  });
});

describe("Document list pagination params", () => {
  it("uses default limit and offset", () => {
    const input = {} as { limit?: number; offset?: number };
    const limit = input.limit ?? 50;
    const offset = input.offset ?? 0;
    expect(limit).toBe(50);
    expect(offset).toBe(0);
  });

  it("uses custom limit and offset", () => {
    const input = { limit: 25, offset: 100 };
    const limit = input.limit ?? 50;
    const offset = input.offset ?? 0;
    expect(limit).toBe(25);
    expect(offset).toBe(100);
  });

  it("uses default sort", () => {
    const input = {} as { sortBy?: string; sortOrder?: string };
    const sortBy = input.sortBy ?? "document_date";
    const sortOrder = input.sortOrder ?? "DESC";
    expect(sortBy).toBe("document_date");
    expect(sortOrder).toBe("DESC");
  });
});

describe("Document tree key generation", () => {
  it("creates consistent group key from German label", () => {
    const group_de = "Warenausgang";
    const groupKey = group_de.toLowerCase().replace(/[^a-z]/g, "");
    expect(groupKey).toBe("warenausgang");
  });

  it("creates consistent group key for inventory", () => {
    const group_de = "Lagerbuchungen";
    const groupKey = group_de.toLowerCase().replace(/[^a-z]/g, "");
    expect(groupKey).toBe("lagerbuchungen");
  });
});

describe("Document tree collapsed state toggle", () => {
  it("removes group from collapsed set", () => {
    const prev = new Set(["lagerbuchungen", "warenausgang"]);
    const groupKey = "lagerbuchungen";
    const next = new Set(prev);
    if (next.has(groupKey)) next.delete(groupKey);
    else next.add(groupKey);
    expect(next.has("lagerbuchungen")).toBe(false);
    expect(next.has("warenausgang")).toBe(true);
  });

  it("adds group to collapsed set", () => {
    const prev = new Set(["warenausgang"]);
    const groupKey = "lagerbuchungen";
    const next = new Set(prev);
    if (next.has(groupKey)) next.delete(groupKey);
    else next.add(groupKey);
    expect(next.has("lagerbuchungen")).toBe(true);
    expect(next.has("warenausgang")).toBe(true);
  });
});
