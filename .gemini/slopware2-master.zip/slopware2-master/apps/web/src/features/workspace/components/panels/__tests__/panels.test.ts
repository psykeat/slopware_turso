import { describe, it, expect } from "vitest";

describe("Panel adapter exports", () => {
  it("exports all panel adapters", async () => {
    const panels = await import("../index");
    expect(panels.ListPanelAdapter).toBeDefined();
    expect(panels.DetailPanelAdapter).toBeDefined();
    expect(panels.LinesPanelAdapter).toBeDefined();
  });
});

describe("ListPanelAdapter type guards", () => {
  it("identifies a list panel state", () => {
    const panel = { type: "list", entity: "customers" } as const;
    expect(panel.type).toBe("list");
    expect(panel.entity).toBe("customers");
  });

  it("identifies a list panel with params", () => {
    const panel = {
      type: "list",
      entity: "orders",
      viewKey: "open",
      params: {
        sort: "date",
        filters: [{ column: "status", operator: "=" as const, value: "open" }],
      },
    } as const;
    expect(panel.type).toBe("list");
    expect(panel.viewKey).toBe("open");
    expect(panel.params?.sort).toBe("date");
    expect(panel.params?.filters?.length).toBe(1);
  });
});

describe("DetailPanelAdapter type guards", () => {
  it("identifies a detail panel state", () => {
    const panel = { type: "detail", entity: "customers", id: "1" } as const;
    expect(panel.type).toBe("detail");
    expect(panel.entity).toBe("customers");
    expect(panel.id).toBe("1");
  });

  it("identifies a detail panel with edit mode", () => {
    const panel = {
      type: "detail",
      entity: "orders",
      id: "42",
      params: { mode: "edit" as const },
    } as const;
    expect(panel.params?.mode).toBe("edit");
  });
});

describe("LinesPanelAdapter type guards", () => {
  it("identifies a lines panel state", () => {
    const panel = { type: "lines", entity: "document", parentId: "1" } as const;
    expect(panel.type).toBe("lines");
    expect(panel.entity).toBe("document");
    expect(panel.parentId).toBe("1");
  });

  it("identifies a lines panel with viewKey", () => {
    const panel = {
      type: "lines",
      entity: "invoice",
      parentId: "100",
      viewKey: "items",
    } as const;
    expect(panel.viewKey).toBe("items");
  });
});

describe("lines entity resolution", () => {
  it("appends _line for non-line entities", () => {
    const result = "document".endsWith("_line") ? "document" : "document" + "_line";
    expect(result).toBe("document_line");
  });

  it("keeps _line suffix for line entities", () => {
    const result = "document_line".endsWith("_line") ? "document_line" : "document_line" + "_line";
    expect(result).toBe("document_line");
  });
});

describe("parent column derivation", () => {
  it("derives parent column from entity name", () => {
    const entity = "document";
    const parentColumn = entity + "_id";
    expect(parentColumn).toBe("document_id");
  });

  it("derives parent column for line entities", () => {
    const entity = "invoice_line";
    const parentColumn = entity + "_id";
    expect(parentColumn).toBe("invoice_line_id");
  });
});

describe("panel filter construction", () => {
  it("creates filter for lines with parent", () => {
    const parentId = "123";
    const parentColumn = "document_id";
    const filters = [{ column: parentColumn, operator: "=" as const, value: parentId }];
    expect(filters.length).toBe(1);
    expect(filters[0]!.column).toBe("document_id");
    expect(filters[0]!.operator).toBe("=");
    expect(filters[0]!.value).toBe("123");
  });

  it("returns undefined filter when no parent", () => {
    const parentId = "" as string;
    const hasParentId = !!parentId && parentId.trim() !== "";
    const filters = hasParentId
      ? [{ column: "document_id", operator: "=" as const, value: parentId }]
      : undefined;
    expect(filters).toBeUndefined();
  });
});

describe("postable entity check", () => {
  const POSTABLE_ENTITIES = new Set(["document"]);
  const POSTABLE_TYPES = new Set(["L", "R", "G", "b", "l", "r", "g", "V", "Z", "E", "U"]);

  it("identifies postable document", () => {
    const entity = "document";
    const docType = "L";
    const isPostable = POSTABLE_ENTITIES.has(entity) && POSTABLE_TYPES.has(docType);
    expect(isPostable).toBe(true);
  });

  it("rejects non-postable entity", () => {
    const entity = "customer";
    const docType = "L";
    const isPostable = POSTABLE_ENTITIES.has(entity) && POSTABLE_TYPES.has(docType);
    expect(isPostable).toBe(false);
  });

  it("rejects posted document", () => {
    const entity = "document";
    const docType = "L";
    const isPosted = true;
    const isPostable = POSTABLE_ENTITIES.has(entity) && !isPosted && POSTABLE_TYPES.has(docType);
    expect(isPostable).toBe(false);
  });
});

describe("field type mapping", () => {
  function mapFieldType(fieldType: string): string {
    if (fieldType.includes("int") || fieldType.includes("numeric") || fieldType.includes("decimal"))
      return "number";
    if (fieldType.includes("bool")) return "boolean";
    if (fieldType.includes("date") || fieldType.includes("timestamp")) return "date";
    return "text";
  }

  it("maps int4 to number", () => {
    expect(mapFieldType("int4")).toBe("number");
  });

  it("maps numeric to number", () => {
    expect(mapFieldType("numeric")).toBe("number");
  });

  it("maps boolean to boolean", () => {
    expect(mapFieldType("boolean")).toBe("boolean");
  });

  it("maps timestamp to date", () => {
    expect(mapFieldType("timestamp")).toBe("date");
  });

  it("maps varchar to text", () => {
    expect(mapFieldType("varchar")).toBe("text");
  });
});

describe("value formatting", () => {
  function formatValue(val: unknown, fieldType?: string): string {
    if (val === null || val === undefined) return "—";
    if (fieldType === "boolean") {
      return val === true ? "Ja" : "Nein";
    }
    if (fieldType === "number") {
      const num = Number(val);
      return isNaN(num) ? String(val) : num.toLocaleString();
    }
    if (fieldType === "date" && typeof val === "string") {
      return new Date(val).toLocaleDateString();
    }
    return String(val);
  }

  it("formats null as dash", () => {
    expect(formatValue(null)).toBe("—");
  });

  it("formats undefined as dash", () => {
    expect(formatValue(undefined)).toBe("—");
  });

  it("formats boolean true as Ja", () => {
    expect(formatValue(true, "boolean")).toBe("Ja");
  });

  it("formats boolean false as Nein", () => {
    expect(formatValue(false, "boolean")).toBe("Nein");
  });

  it("formats number with locale", () => {
    const result = formatValue(1234.56, "number");
    expect(result).toContain("1");
    expect(result).toContain("2");
    expect(result).toContain("3");
  });

  it("formats string as-is", () => {
    expect(formatValue("hello", "text")).toBe("hello");
  });
});

describe("pane context shape", () => {
  it("has required fields", async () => {
    const ctx = {
      t: (key: string) => key,
      lang: "en" as const,
      dispatchIntent: (_intent: any) => {},
      toast: (msg: string) => console.log(msg),
    };
    expect(typeof ctx.t).toBe("function");
    expect(typeof ctx.lang).toBe("string");
    expect(typeof ctx.dispatchIntent).toBe("function");
    expect(typeof ctx.toast).toBe("function");
  });
});

describe("panel state discrimination", () => {
  it("list panel has no id field", () => {
    const panel = { type: "list", entity: "customers" };
    expect("id" in panel).toBe(false);
    expect("parentId" in panel).toBe(false);
  });

  it("detail panel has id field", () => {
    const panel = { type: "detail", entity: "customers", id: "1" };
    expect("id" in panel).toBe(true);
    expect(panel.id).toBe("1");
  });

  it("lines panel has parentId field", () => {
    const panel = { type: "lines", entity: "document", parentId: "1" };
    expect("parentId" in panel).toBe(true);
    expect(panel.parentId).toBe("1");
  });
});

describe("mock lines data filtering", () => {
  const mockLinesData = [
    { id: "l1", document_id: "1", line_nr: 1, article_id: "A001", qty: 2, price: 25.5 },
    { id: "l2", document_id: "1", line_nr: 2, article_id: "A002", qty: 1, price: 49.99 },
    { id: "l3", document_id: "2", line_nr: 1, article_id: "A003", qty: 5, price: 12.0 },
  ];

  it("filters by parent id", () => {
    const parentId = "1";
    const parentColumn = "document_id";
    const filtered = mockLinesData.filter((r) => String(r[parentColumn]) === parentId);
    expect(filtered.length).toBe(2);
    expect(filtered[0]!.id).toBe("l1");
    expect(filtered[1]!.id).toBe("l2");
  });

  it("returns single line for parent 2", () => {
    const parentId = "2";
    const parentColumn = "document_id";
    const filtered = mockLinesData.filter((r) => String(r[parentColumn]) === parentId);
    expect(filtered.length).toBe(1);
    expect(filtered[0]!.id).toBe("l3");
  });

  it("returns empty for unknown parent", () => {
    const parentId = "999";
    const parentColumn = "document_id";
    const filtered = mockLinesData.filter((r) => String(r[parentColumn]) === parentId);
    expect(filtered.length).toBe(0);
  });
});

describe("new line number calculation", () => {
  it("calculates next line number from existing data", () => {
    const data = [
      { id: "l1", line_nr: 1 },
      { id: "l2", line_nr: 2 },
      { id: "l3", line_nr: 5 },
    ];
    const maxPos = data.length > 0 ? Math.max(...data.map((r) => Number(r.line_nr) || 0)) : 0;
    expect(maxPos + 1).toBe(6);
  });

  it("starts at 1 for empty data", () => {
    const data: Array<{ line_nr: number }> = [];
    const maxPos = data.length > 0 ? Math.max(...data.map((r) => Number(r.line_nr) || 0)) : 0;
    expect(maxPos + 1).toBe(1);
  });
});
