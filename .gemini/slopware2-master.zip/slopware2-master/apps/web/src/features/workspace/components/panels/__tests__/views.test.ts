import {
  serializePanelState,
  deserializePanelState,
  isNavigationIntent,
} from "@repo/shared/workspace";
import { describe, it, expect } from "vitest";

describe("serializePanelState", () => {
  it("serializes list panel", () => {
    expect(serializePanelState({ type: "list", entity: "customers" })).toBe("list:customers");
  });
  it("serializes detail panel with id", () => {
    expect(serializePanelState({ type: "detail", entity: "customers", id: "42" })).toBe(
      "detail:customers:42",
    );
  });
  it("serializes lines panel with parentId", () => {
    expect(serializePanelState({ type: "lines", entity: "document", parentId: "100" })).toBe(
      "lines:document:100",
    );
  });
  it("serializes kpi panel", () => {
    expect(serializePanelState({ type: "kpi", entity: "_meta" })).toBe("kpi:_meta");
  });
  it("serializes tree panel", () => {
    expect(serializePanelState({ type: "tree", entity: "documents" })).toBe("tree:documents");
  });
  it("serializes lookup panel", () => {
    expect(serializePanelState({ type: "lookup", entity: "articles" })).toBe("lookup:articles");
  });
  it("serializes period-comparison panel", () => {
    expect(serializePanelState({ type: "period-comparison", entity: "finance" })).toBe(
      "period-comparison:finance",
    );
  });
  it("serializes detail panel with empty id", () => {
    expect(serializePanelState({ type: "detail", entity: "customers", id: "" })).toBe(
      "detail:customers",
    );
  });
});

describe("deserializePanelState", () => {
  it("deserializes list panel", () => {
    const result = deserializePanelState("list:customers");
    expect(result).toEqual({ type: "list", entity: "customers" });
  });
  it("deserializes detail panel with id", () => {
    const result = deserializePanelState("detail:customers:42");
    expect(result).toEqual({ type: "detail", entity: "customers", id: "42" });
  });
  it("deserializes detail panel without id", () => {
    const result = deserializePanelState("detail:customers");
    expect(result).toEqual({ type: "detail", entity: "customers", id: "" });
  });
  it("deserializes lines panel with parentId", () => {
    const result = deserializePanelState("lines:document:100");
    expect(result).toEqual({ type: "lines", entity: "document", parentId: "100" });
  });
  it("deserializes lines panel without parentId", () => {
    const result = deserializePanelState("lines:document");
    expect(result).toEqual({ type: "lines", entity: "document", parentId: "" });
  });
  it("deserializes kpi panel", () => {
    const result = deserializePanelState("kpi:_meta");
    expect(result).toEqual({ type: "kpi", entity: "_meta" });
  });
  it("deserializes tree panel", () => {
    const result = deserializePanelState("tree:documents");
    expect(result).toEqual({ type: "tree", entity: "documents" });
  });
  it("deserializes lookup panel", () => {
    const result = deserializePanelState("lookup:articles");
    expect(result).toEqual({ type: "lookup", entity: "articles" });
  });
  it("deserializes period-comparison panel", () => {
    const result = deserializePanelState("period-comparison:finance");
    expect(result).toEqual({ type: "period-comparison", entity: "finance" });
  });
  it("returns null for invalid input", () => {
    expect(deserializePanelState("")).toBeNull();
    expect(deserializePanelState("onlyone")).toBeNull();
  });
});
describe("serialize/deserialize roundtrip", () => {
  it("roundtrips list panel", () => {
    const panel = { type: "list", entity: "customers" } as const;
    const serialized = serializePanelState(panel);
    const deserialized = deserializePanelState(serialized);
    expect(deserialized).toEqual(panel);
  });
  it("roundtrips detail panel", () => {
    const panel = { type: "detail", entity: "orders", id: "99" } as const;
    const serialized = serializePanelState(panel);
    const deserialized = deserializePanelState(serialized);
    expect(deserialized).toEqual(panel);
  });
  it("roundtrips lines panel", () => {
    const panel = { type: "lines", entity: "document", parentId: "5" } as const;
    const serialized = serializePanelState(panel);
    const deserialized = deserializePanelState(serialized);
    expect(deserialized).toEqual(panel);
  });
  it("roundtrips kpi panel", () => {
    const panel = { type: "kpi", entity: "_meta" } as const;
    const serialized = serializePanelState(panel);
    const deserialized = deserializePanelState(serialized);
    expect(deserialized).toEqual(panel);
  });
});

describe("isNavigationIntent", () => {
  it("identifies openRecord intent", () => {
    expect(isNavigationIntent({ action: "openRecord", entity: "customers" })).toBe(true);
  });
  it("identifies openLookup intent", () => {
    expect(isNavigationIntent({ action: "openLookup", entity: "articles" })).toBe(true);
  });
  it("identifies openLines intent", () => {
    expect(isNavigationIntent({ action: "openLines", entity: "document", id: "1" })).toBe(true);
  });
  it("rejects invalid action", () => {
    expect(isNavigationIntent({ action: "deleteRecord", entity: "customers" })).toBe(false);
  });
  it("rejects missing entity", () => {
    expect(isNavigationIntent({ action: "openRecord" })).toBe(false);
  });
  it("rejects non-string entity", () => {
    expect(isNavigationIntent({ action: "openRecord", entity: 123 })).toBe(false);
  });
  it("rejects empty object", () => {
    expect(isNavigationIntent({})).toBe(false);
  });
});

describe("TreeView collapse logic", () => {
  const COLLAPSED_BY_DEFAULT = new Set(["lagerbuchungen"]);
  it("collapses lagerbuchungen by default", () => {
    expect(COLLAPSED_BY_DEFAULT.has("lagerbuchungen")).toBe(true);
  });
  it("does not collapse other groups", () => {
    expect(COLLAPSED_BY_DEFAULT.has("rechnungen")).toBe(false);
  });
  it("toggles group collapse state", () => {
    let collapsed = new Set(COLLAPSED_BY_DEFAULT);
    const toggle = (key: string) => {
      if (collapsed.has(key)) collapsed.delete(key);
      else collapsed.add(key);
    };
    toggle("lagerbuchungen");
    expect(collapsed.has("lagerbuchungen")).toBe(false);
    toggle("lagerbuchungen");
    expect(collapsed.has("lagerbuchungen")).toBe(true);
  });
});

describe("isLagerbuchung detection", () => {
  const isLagerbuchung = (key: string) => key.startsWith("lagerbuchung-");
  it("identifies lagerbuchung keys", () => {
    expect(isLagerbuchung("lagerbuchung-E")).toBe(true);
    expect(isLagerbuchung("lagerbuchung-R")).toBe(true);
  });
  it("rejects non-lagerbuchung keys", () => {
    expect(isLagerbuchung("rechnung-001")).toBe(false);
  });
});
describe("KpiView currency formatting", () => {
  function fmtCurrency(n: number): string {
    return n.toLocaleString("de-DE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }
  it("formats with German locale", () => {
    const result = fmtCurrency(1250000);
    expect(result).toContain("1");
    expect(result).toContain("25");
    expect(result).toContain(",00");
  });
  it("formats zero", () => {
    expect(fmtCurrency(0)).toBe("0,00");
  });
  it("formats decimal values", () => {
    const result = fmtCurrency(1234.567);
    expect(result).toContain("1.234,57");
  });
});

describe("yoyDelta calculation", () => {
  function yoyDelta(current: number, prior: number): string {
    if (prior === 0) return current > 0 ? "+inf%" : "-";
    const pct = ((current - prior) / Math.abs(prior)) * 100;
    return `${pct >= 0 ? "+" : ""}${pct.toFixed(1)}%`;
  }
  it("calculates positive delta", () => {
    expect(yoyDelta(1250000, 1100000)).toBe("+13.6%");
  });
  it("calculates negative delta", () => {
    expect(yoyDelta(900000, 1000000)).toBe("-10.0%");
  });
  it("handles zero prior with positive current", () => {
    expect(yoyDelta(100, 0)).toBe("+inf%");
  });
  it("handles zero prior with zero current", () => {
    expect(yoyDelta(0, 0)).toBe("-");
  });
  it("handles no change", () => {
    expect(yoyDelta(500, 500)).toBe("+0.0%");
  });
});

describe("DetailView mapFieldType", () => {
  function mapFieldType(fieldType: string): string {
    if (fieldType.includes("int") || fieldType.includes("numeric") || fieldType.includes("decimal"))
      return "number";
    if (fieldType.includes("bool")) return "boolean";
    if (fieldType.includes("date") || fieldType.includes("timestamp")) return "date";
    return "text";
  }
  it("maps int4 to number", () => {
    expect(mapFieldType("int4")).toBe("number");
  });
  it("maps numeric to number", () => {
    expect(mapFieldType("numeric")).toBe("number");
  });
  it("maps decimal to number", () => {
    expect(mapFieldType("decimal")).toBe("number");
  });
  it("maps boolean to boolean", () => {
    expect(mapFieldType("boolean")).toBe("boolean");
  });
  it("maps date to date", () => {
    expect(mapFieldType("date")).toBe("date");
  });
  it("maps timestamp to date", () => {
    expect(mapFieldType("timestamp")).toBe("date");
  });
  it("maps varchar to text", () => {
    expect(mapFieldType("varchar")).toBe("text");
  });
  it("maps unknown to text", () => {
    expect(mapFieldType("jsonb")).toBe("text");
  });
});

describe("DetailView formatValue", () => {
  function formatValue(val: unknown, fieldType?: string): string {
    if (val === null || val === undefined) return "\u2014";
    if (fieldType === "boolean") return val === true ? "Ja" : "Nein";
    if (fieldType === "number") {
      const num = Number(val);
      return isNaN(num) ? String(val) : num.toLocaleString();
    }
    if (fieldType === "date" && typeof val === "string") return new Date(val).toLocaleDateString();
    return String(val);
  }
  it("formats null as dash", () => {
    expect(formatValue(null)).toBe("\u2014");
  });
  it("formats undefined as dash", () => {
    expect(formatValue(undefined)).toBe("\u2014");
  });
  it("formats true as Ja", () => {
    expect(formatValue(true, "boolean")).toBe("Ja");
  });
  it("formats false as Nein", () => {
    expect(formatValue(false, "boolean")).toBe("Nein");
  });
  it("formats text as-is", () => {
    expect(formatValue("hello", "text")).toBe("hello");
  });
  it("formats invalid number as string", () => {
    expect(formatValue("notanumber", "number")).toBe("notanumber");
  });
});
describe("CrudDialog getIdFieldName", () => {
  function getIdFieldName(entityName: string): string {
    const map: Record<string, string> = {
      address: "address_id",
      article: "article_id",
      article_group: "article_group_id",
      company: "company_id",
      cost_center: "cost_center_id",
      price_list: "price_list_id",
      warehouse: "warehouse_id",
      tax_code: "tax_code_id",
      document: "document_id",
      document_line: "document_line_id",
    };
    return map[entityName] ?? "id";
  }
  it("resolves address_id for address", () => {
    expect(getIdFieldName("address")).toBe("address_id");
  });
  it("resolves article_id for article", () => {
    expect(getIdFieldName("article")).toBe("article_id");
  });
  it("resolves document_id for document", () => {
    expect(getIdFieldName("document")).toBe("document_id");
  });
  it("resolves document_line_id", () => {
    expect(getIdFieldName("document_line")).toBe("document_line_id");
  });
  it("falls back to id for unknown", () => {
    expect(getIdFieldName("unknown_entity")).toBe("id");
  });
});

describe("CrudDialog field filtering", () => {
  function getIdFieldName(entityName: string): string {
    const map: Record<string, string> = {
      address: "address_id",
      article: "article_id",
      document: "document_id",
    };
    return map[entityName] ?? "id";
  }
  it("excludes id field from editable fields", () => {
    const fields = [
      { fieldName: "address_id", fieldLabel: "ID", fieldType: "int4" },
      { fieldName: "name", fieldLabel: "Name", fieldType: "varchar" },
      { fieldName: "street", fieldLabel: "Street", fieldType: "varchar" },
    ];
    const idField = getIdFieldName("address");
    const editable = fields.filter((f) => f.fieldName !== idField);
    expect(editable.length).toBe(2);
    expect(editable[0]!.fieldName).toBe("name");
    expect(editable[1]!.fieldName).toBe("street");
  });
  it("keeps all fields when no id mapping", () => {
    const fields = [
      { fieldName: "id", fieldLabel: "ID", fieldType: "int4" },
      { fieldName: "name", fieldLabel: "Name", fieldType: "varchar" },
    ];
    const idField = getIdFieldName("unknown");
    const editable = fields.filter((f) => f.fieldName !== idField);
    expect(editable.length).toBe(1);
    expect(editable[0]!.fieldName).toBe("name");
  });
});

describe("CrudDialog validation", () => {
  it("detects missing required fields", () => {
    const fields = [
      { fieldName: "name", fieldLabel: "Name", fieldType: "varchar", isRequired: true },
      { fieldName: "note", fieldLabel: "Note", fieldType: "varchar" },
    ];
    const formValues: Record<string, unknown> = { note: "something" };
    const errors: Record<string, string> = {};
    for (const f of fields) {
      if (f.isRequired && formValues[f.fieldName] == null) {
        errors[f.fieldName] = "required";
      }
    }
    expect(Object.keys(errors).length).toBe(1);
    expect(errors["name"]).toBe("required");
  });
  it("passes validation when required fields present", () => {
    const fields = [
      { fieldName: "name", fieldLabel: "Name", fieldType: "varchar", isRequired: true },
      { fieldName: "note", fieldLabel: "Note", fieldType: "varchar" },
    ];
    const formValues: Record<string, unknown> = { name: "test", note: "something" };
    const errors: Record<string, string> = {};
    for (const f of fields) {
      if (f.isRequired && formValues[f.fieldName] == null) {
        errors[f.fieldName] = "required";
      }
    }
    expect(Object.keys(errors).length).toBe(0);
  });
});

describe("ListView search filtering", () => {
  const rows = [
    { id: "1", name: "Acme Corp", email: "acme@test.com" },
    { id: "2", name: "Beta Inc", email: "beta@test.com" },
    { id: "3", name: "Gamma LLC", email: "gamma@test.com" },
  ];
  const filterBySearch = (search: string) =>
    rows.filter((r) =>
      Object.values(r).some((v) => String(v).toLowerCase().includes(search.toLowerCase())),
    );
  it("filters by name substring", () => {
    const result = filterBySearch("acme");
    expect(result.length).toBe(1);
    expect(result[0]!.id).toBe("1");
  });
  it("filters by email", () => {
    const result = filterBySearch("beta");
    expect(result.length).toBe(1);
    expect(result[0]!.id).toBe("2");
  });
  it("returns all for empty search", () => {
    expect(filterBySearch("").length).toBe(3);
  });
  it("returns none for no match", () => {
    expect(filterBySearch("zzzzz").length).toBe(0);
  });
});

describe("ListView sort logic", () => {
  const rows = [
    { id: "1", name: "Charlie", qty: 10 },
    { id: "2", name: "Alpha", qty: 3 },
    { id: "3", name: "Beta", qty: 7 },
  ];
  const sortBy = (col: string, dir: "asc" | "desc") =>
    [...rows].sort((a, b) => {
      const av = String((a as Record<string, unknown>)[col]);
      const bv = String((b as Record<string, unknown>)[col]);
      return dir === "asc"
        ? av.localeCompare(bv, "de", { numeric: true })
        : bv.localeCompare(av, "de", { numeric: true });
    });
  it("sorts ascending by name", () => {
    const result = sortBy("name", "asc");
    expect(result[0]!.name).toBe("Alpha");
    expect(result[1]!.name).toBe("Beta");
    expect(result[2]!.name).toBe("Charlie");
  });
  it("sorts descending by name", () => {
    const result = sortBy("name", "desc");
    expect(result[0]!.name).toBe("Charlie");
    expect(result[2]!.name).toBe("Alpha");
  });
  it("sorts ascending by qty numerically", () => {
    const result = sortBy("qty", "asc");
    expect(result[0]!.qty).toBe(3);
    expect(result[2]!.qty).toBe(10);
  });
});

describe("panel-resolver exports", () => {
  it("exports resolvePanelComponent", async () => {
    const mod = await import("../../../panel-resolver");
    expect(typeof mod.resolvePanelComponent).toBe("function");
  });
  it("exports FallbackPanel", async () => {
    const mod = await import("../../../panel-resolver");
    expect(typeof mod.FallbackPanel).toBe("function");
  });
});

describe("CrudDialog export", () => {
  it("exports CrudDialog from panels index", async () => {
    const panels = await import("../index");
    expect(panels.CrudDialog).toBeDefined();
  });
});

describe("Workspace dispatchIntent logic", () => {
  it("openRecord with id creates detail panel", () => {
    const intent = { action: "openRecord", entity: "customers", id: "42", targetSlot: "s2" };
    const panel = intent.id
      ? { type: "detail", entity: intent.entity, id: intent.id }
      : { type: "list", entity: intent.entity };
    expect(panel).toEqual({ type: "detail", entity: "customers", id: "42" });
  });
  it("openRecord without id creates list panel", () => {
    const intent = { action: "openRecord", entity: "customers", targetSlot: "s2" };
    const hasId = "id" in intent && !!intent.id;
    const panel = hasId
      ? { type: "detail", entity: intent.entity, id: intent.id as string }
      : { type: "list", entity: intent.entity };
    expect(panel).toEqual({ type: "list", entity: "customers" });
  });
  it("openLines creates lines panel", () => {
    const intent = { action: "openLines", entity: "document", id: "5", targetSlot: "s3" };
    const panel = { type: "lines", entity: intent.entity, parentId: intent.id ?? "" };
    expect(panel).toEqual({ type: "lines", entity: "document", parentId: "5" });
  });
  it("openLookup creates lookup panel", () => {
    const intent = { action: "openLookup", entity: "articles", targetSlot: "s2" };
    const panel = { type: "lookup", entity: intent.entity };
    expect(panel).toEqual({ type: "lookup", entity: "articles" });
  });
});

describe("Workspace default slots", () => {
  it("has 3 default slots", () => {
    const DEFAULT_SLOTS = {
      s1: { type: "kpi", entity: "_meta" },
      s2: { type: "list", entity: "Customers" },
      s3: { type: "detail", entity: "Customers", id: "" },
    };
    expect(Object.keys(DEFAULT_SLOTS).length).toBe(3);
    expect(DEFAULT_SLOTS.s1.type).toBe("kpi");
    expect(DEFAULT_SLOTS.s2.type).toBe("list");
    expect(DEFAULT_SLOTS.s3.type).toBe("detail");
  });
});
