import type { PanelState } from "@repo/shared/workspace";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowRightCircle, CheckCircle2Icon, FileText, Trash2, Undo2 } from "lucide-react";
import { useCallback, useState } from "react";

import {
  convertDocumentFn,
  deleteDocumentFn,
  getEffectiveFieldsFn,
  getEntityFn,
  postDocumentFn,
  stornoDocumentFn,
} from "~/server/server-functions";

import { useHotkeyLayer } from "../../../hotkeys/use-hotkey-layer";
import { useScopedHotkey } from "../../../hotkeys/use-scoped-hotkey";
import { t } from "../../i18n";
import type { PaneCtx } from "../../pane";
import { ConvertDialog } from "../convert-dialog";
import { CrudDialog } from "../crud-dialog";

type DetailPanel = PanelState & { type: "detail" };

const POSTABLE_ENTITIES = new Set(["document"]);
const POSTABLE_TYPES = new Set(["L", "R", "G", "b", "l", "r", "g", "V", "Z", "E", "U"]);
const CONVERTIBLE_TYPES = new Set(["N", "A", "L", "b", "l"]);
const STORNO_TYPES = new Set(["R", "r"]);
const DELETABLE_TYPES = new Set(["N", "A", "L", "b", "l", "V", "Z", "E", "U"]);

export function DetailPanelAdapter({ panel, ctx }: { panel: DetailPanel; ctx: PaneCtx }) {
  const { entity, id } = panel;
  const { toast } = ctx;
  const queryClient = useQueryClient();

  const hasId = !!id && id.trim() !== "";
  const [crudMode, setCrudMode] = useState<"edit" | null>(null);
  const [convertMode, setConvertMode] = useState(false);

  const handleConvertConfirm = (targetGroupId?: string) => {
    if (id) {
      convertMutation.mutate({ documentId: id, targetGroupId });
    }
  };

  const {
    data: recordObj,
    isLoading: isLoadingRecord,
    refetch,
  } = useQuery({
    queryKey: ["entity-detail", entity, id],
    queryFn: () => getEntityFn({ data: { entityName: entity!, id: id! } }),
    enabled: !!entity && !!id,
  });

  const { data: fields = [], isLoading: isLoadingFields } = useQuery({
    queryKey: ["effective-fields", entity],
    queryFn: () => getEffectiveFieldsFn({ data: { entityName: entity! } }),
    enabled: !!entity,
  });

  const isPosted = recordObj?.status === "posted";

  const postMutation = useMutation({
    mutationFn: (docId: string) => postDocumentFn({ data: { documentId: docId } }),
    onSuccess: () => {
      refetch();
      toast?.(t("detail.book.success", ctx.lang));
    },
    onError: () => {
      toast?.(t("detail.book.error", ctx.lang));
    },
  });

  const isPostable =
    POSTABLE_ENTITIES.has(entity ?? "") && !isPosted && !!recordObj?.document_type
      ? POSTABLE_TYPES.has(recordObj.document_type as string)
      : false;

  const docType = recordObj?.document_type as string | undefined;
  const docStatus = recordObj?.status as string | undefined;
  const isConvertible =
    POSTABLE_ENTITIES.has(entity ?? "") && !isPosted && docStatus !== "archived" && !!docType
      ? CONVERTIBLE_TYPES.has(docType)
      : false;
  const isStornable =
    POSTABLE_ENTITIES.has(entity ?? "") && isPosted && docStatus !== "cancelled" && !!docType
      ? STORNO_TYPES.has(docType)
      : false;

  const isDeletable =
    POSTABLE_ENTITIES.has(entity ?? "") && !!docType ? DELETABLE_TYPES.has(docType) : false;

  const layerId = `detail-${entity}-${id || "empty"}`;
  useHotkeyLayer(layerId);

  const handleConvertHotkey = useCallback(() => {
    if (isConvertible) {
      setConvertMode(true);
    }
  }, [isConvertible]);

  useScopedHotkey(layerId, "F7", handleConvertHotkey);
  useScopedHotkey(layerId, "F9", handleConvertHotkey);

  const convertMutation = useMutation({
    mutationFn: (payload: { documentId: string; targetGroupId?: string }) =>
      convertDocumentFn({ data: payload }),
    onSuccess: () => {
      refetch();
      toast?.(t("detail.convert.success", ctx.lang));
    },
    onError: () => {
      toast?.(t("detail.convert.error", ctx.lang));
    },
  });

  const stornoMutation = useMutation({
    mutationFn: (docId: string) => stornoDocumentFn({ data: { documentId: docId } }),
    onSuccess: () => {
      refetch();
      toast?.(t("detail.storno.success", ctx.lang));
    },
    onError: () => {
      toast?.(t("detail.storno.error", ctx.lang));
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (docId: string) => deleteDocumentFn({ data: { documentId: docId } }),
    onSuccess: (result) => {
      if (result?.success) {
        queryClient.invalidateQueries({ queryKey: ["entity-list", "document"] });
        queryClient.invalidateQueries({ queryKey: ["documents"] });
        queryClient.invalidateQueries({ queryKey: ["document-tree"] });
        toast?.(t("detail.delete.success", ctx.lang));
        refetch();
      } else {
        const errMsg = (result as any)?.error as string | undefined;
        if (errMsg?.includes("Cannot delete")) {
          toast?.(t("detail.delete.error.protected", ctx.lang));
        } else {
          toast?.(t("detail.delete.error", ctx.lang));
        }
      }
    },
    onError: () => {
      toast?.(t("detail.delete.error", ctx.lang));
    },
  });

  const handleDelete = () => {
    const docNo = recordObj?.document_no ?? id;
    const confirmMsg = t("detail.delete.confirm", ctx.lang)
      .replace("{no}", String(docNo))
      .replace("{type}", docType ?? "");
    if (confirm(confirmMsg) && id) {
      deleteMutation.mutate(id);
    }
  };

  const labelField = fields[0] ?? null;
  const labelValue = labelField
    ? String(recordObj?.[labelField.fieldName] ?? "—")
    : `${entity}:${id}`;

  const technicalFields = [
    "document_id",
    "organization_id",
    "tenant_id",
    "version",
    "created_at",
    "updated_at",
    "created_by",
    "updated_by",
    "is_active",
    "id",
  ];

  const groups = fields.reduce(
    (acc, f) => {
      if (!f.isVisible) return acc;
      const isTechnical = technicalFields.includes(f.fieldName) || f.fieldName.endsWith("_id");
      const gId = isTechnical ? "technical" : f.groupId || "general";
      if (!acc[gId]) acc[gId] = [];
      acc[gId].push(f);
      return acc;
    },
    {} as Record<string, any[]>,
  );

  if (!hasId) {
    return (
      <div className="sw-pane-empty flex flex-1 items-center justify-center">
        <div className="flex flex-col items-center gap-2">
          <div className="sw-pane-empty-icon">
            <FileText size={32} />
          </div>
          <div style={{ fontWeight: 600, marginBottom: 4 }}>
            {t("detail.placeholder.title", ctx.lang)}
          </div>
          <div
            style={{
              fontSize: 12.5,
              color: "var(--sw-text-muted, #6b7280)",
              textAlign: "center",
              maxWidth: 200,
            }}
          >
            {t("detail.placeholder.description", ctx.lang)}
          </div>
        </div>
      </div>
    );
  }

  if (isLoadingRecord || isLoadingFields) {
    return (
      <div className="flex flex-1 items-center justify-center p-8 text-gray-400">Loading...</div>
    );
  }

  if (!recordObj) {
    return (
      <div className="sw-pane-empty flex flex-1 items-center justify-center">
        <div className="flex flex-col items-center gap-2">
          <div className="sw-pane-empty-icon">
            <FileText size={32} />
          </div>
          <div style={{ fontSize: 12.5, color: "var(--sw-text-muted, #6b7280)" }}>
            {t("detail.notfound", ctx.lang)}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="sw-detail-view flex h-full flex-col overflow-auto p-4">
      <div className="sw-detail-header mb-6 flex items-center justify-between border-b pb-4">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-3">
            <div className="sw-detail-title text-xl font-bold tracking-tight">{labelValue}</div>
            {docStatus && <StatusBadge status={docStatus} lang={ctx.lang} />}
          </div>
          <div className="flex items-center gap-2 text-[11px] font-medium text-gray-500">
            <span className="tracking-wider uppercase">{entity}</span>
            <span className="text-gray-300">|</span>
            <span className="font-mono">{id}</span>
            {docType && (
              <>
                <span className="text-gray-300">|</span>
                <span className="rounded border border-gray-200 px-1.5 py-0.5 text-[9px] font-bold uppercase">
                  {docType}
                </span>
              </>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/* Primary Action */}
          {isPostable ? (
            <button
              className="sw-btn sw-btn-primary sw-btn-sm rounded px-4 py-1 text-xs font-bold shadow-sm"
              onClick={() => id && postMutation.mutate(id)}
              disabled={postMutation.isPending}
            >
              {postMutation.isPending ? "..." : t("detail.book", ctx.lang)}
            </button>
          ) : !isPosted ? (
            <button
              className="sw-btn sw-btn-primary sw-btn-sm rounded px-4 py-1 text-xs font-bold shadow-sm"
              onClick={() => setCrudMode("edit")}
            >
              {t("detail.edit", ctx.lang)}
            </button>
          ) : null}

          {/* Secondary Actions */}
          <div className="ml-1 flex items-center gap-1 border-l pl-2">
            {isConvertible && (
              <button
                className="sw-btn sw-btn-ghost sw-btn-xs rounded px-2 hover:bg-gray-100"
                onClick={() => setConvertMode(true)}
                title={t("detail.convert", ctx.lang)}
              >
                <ArrowRightCircle size={14} className="text-gray-500" />
              </button>
            )}
            {isStornable && (
              <button
                className="sw-btn sw-btn-ghost sw-btn-xs rounded px-2 hover:bg-gray-100"
                onClick={() => id && stornoMutation.mutate(id)}
                title={t("detail.storno", ctx.lang)}
                disabled={stornoMutation.isPending}
              >
                <Undo2 size={14} className="text-gray-500" />
              </button>
            )}
            {isDeletable && (
              <button
                className="sw-btn sw-btn-ghost sw-btn-xs rounded px-2 text-red-500 hover:bg-red-50"
                onClick={handleDelete}
                title={t("detail.delete", ctx.lang)}
                disabled={deleteMutation.isPending}
              >
                <Trash2 size={14} />
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-8">
        {Object.entries(groups).map(([groupId, groupFields]) => {
          if (groupId === "technical") return null;
          return (
            <div key={groupId} className="sw-detail-group">
              <div className="sw-detail-group-label mb-3 text-[11px] font-bold tracking-tight text-gray-500 uppercase">
                {t(`group.${groupId}`, ctx.lang)}
              </div>
              <div className="sw-detail-grid grid grid-cols-2 gap-x-12 gap-y-4">
                {groupFields.map((field) => (
                  <DetailField
                    key={field.fieldName}
                    field={field}
                    value={recordObj[field.fieldName]}
                    lang={ctx.lang}
                  />
                ))}
              </div>
            </div>
          );
        })}

        {groups.technical && (
          <details className="mt-4 border-t pt-6">
            <summary className="cursor-pointer text-[10px] font-bold tracking-widest text-gray-400 uppercase hover:text-gray-600">
              {t("detail.technical_info", ctx.lang)}
            </summary>
            <div className="sw-detail-grid mt-6 grid grid-cols-2 gap-4">
              {groups.technical.map((field) => (
                <DetailField
                  key={field.fieldName}
                  field={field}
                  value={recordObj[field.fieldName]}
                  lang={ctx.lang}
                />
              ))}
            </div>
          </details>
        )}
      </div>

      {crudMode && (
        <CrudDialog
          mode={crudMode}
          entityName={entity!}
          row={recordObj as any}
          lang={ctx.lang}
          onClose={() => {
            setCrudMode(null);
            refetch();
          }}
        />
      )}

      {convertMode && id && (
        <ConvertDialog
          documentId={id}
          lang={ctx.lang}
          onClose={() => setConvertMode(false)}
          onConfirm={(targetGroupId) => {
            handleConvertConfirm(targetGroupId);
            setConvertMode(false);
          }}
        />
      )}
    </div>
  );
}

function StatusBadge({ status, lang }: { status: string; lang: string }) {
  const colors: Record<string, string> = {
    posted: "badge-green",
    draft: "badge-blue",
    cancelled: "badge-red",
    archived: "badge-orange",
  };
  const className = colors[status] || "badge-blue";
  return (
    <span
      className={`${className} rounded px-1.5 py-0.5 text-[10px] font-bold tracking-wider uppercase`}
    >
      {status}
    </span>
  );
}

function DetailField({ field, value, lang }: { field: any; value: any; lang: string }) {
  const label = field.label?.[lang] || field.fieldName;
  const fieldType = field.fieldType;
  return (
    <div>
      <div className="sw-detail-field-label mb-1 text-[10px] font-bold tracking-wider text-gray-400 uppercase">
        {label}
      </div>
      <div
        className={`sw-detail-field-value text-[13px] ${fieldType === "number" || fieldType === "integer" ? "font-mono" : ""}`}
      >
        {formatValue(value, fieldType)}
      </div>
    </div>
  );
}

function formatValue(val: unknown, fieldType?: string): string {
  if (val === null || val === undefined) return "—";
  if (fieldType === "boolean") {
    return val === true ? "Ja" : "Nein";
  }
  if (fieldType === "number") {
    const num = Number(val);
    return isNaN(num) ? String(val) : num.toLocaleString();
  }
  if (fieldType === "date" && typeof val === "string") {
    return new Date(val).toLocaleDateString();
  }
  return String(val);
}
