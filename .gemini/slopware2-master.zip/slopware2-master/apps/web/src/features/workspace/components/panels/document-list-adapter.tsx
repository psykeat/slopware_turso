import { useQuery } from "@tanstack/react-query";
import { ChevronRight, FileText, PanelRightOpen, Plus } from "lucide-react";
import { useCallback, useState } from "react";

import { listDocumentsFn, listDocumentTreeFn } from "~/server/server-functions";

import { t } from "../../i18n";
import type { PaneCtx } from "../../pane";
import { EntityDataTable } from "../data-table/entity-data-table";

type DocTreeItem = {
  key: string;
  label_de: string;
  label_en: string;
  count: number;
  groupId?: string;
  docType?: string;
  defaultGroupId?: string;
  items?: DocTreeItem[];
};

type DocTreeCategory = {
  key: string;
  label_de: string;
  label_en: string;
  items: DocTreeItem[];
};

type DocumentListPanel = {
  entity: string;
  viewKey?: string;
  params?: {
    filter?: string;
    documentType?: string;
    documentGroupId?: string;
  };
};

export function DocumentListAdapter({ panel, ctx }: { panel: DocumentListPanel; ctx: PaneCtx }) {
  const isEn = ctx.lang === "en";
  const [selectedGroup, setSelectedGroup] = useState<string | null>(
    panel.params?.documentGroupId ?? null,
  );
  const [selectedType, setSelectedType] = useState<string | null>(
    panel.params?.documentType ?? null,
  );
  const [activeKey, setActiveKey] = useState<string>(
    panel.params?.documentGroupId
      ? `dg-${panel.params.documentGroupId}`
      : panel.params?.documentType
        ? `dt-${panel.params.documentType}`
        : "",
  );
  const [collapsedKeys, setCollapsedKeys] = useState<Set<string>>(new Set());
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // Fetch tree data
  const { data: treeData, isLoading: treeLoading } = useQuery({
    queryKey: ["document-tree", ctx.lang],
    queryFn: () => listDocumentTreeFn(),
  });

  // Fetch documents with filters
  const { data: docs, isLoading: docsLoading } = useQuery({
    queryKey: ["documents", selectedGroup, selectedType],
    queryFn: () =>
      listDocumentsFn({
        data: {
          documentType: selectedType ?? undefined,
          documentGroupId: selectedGroup ?? undefined,
          limit: 50,
          offset: 0,
        },
      }),
    enabled: true,
  });

  const handlePick = useCallback(
    (item: { key: string; docType?: string; groupId?: string; defaultGroupId?: string }) => {
      setActiveKey(item.key);
      setSelectedType(item.docType ?? null);
      setSelectedGroup(item.groupId ?? null);
    },
    [],
  );

  const handleNewDocument = useCallback(() => {
    let targetGroupId = selectedGroup;

    // If we only have a type selected, try to find the merged default group (00)
    if (!targetGroupId && selectedType && treeData) {
      for (const cat of treeData as DocTreeCategory[]) {
        const typeNode = cat.items.find((t) => t.docType === selectedType);
        if (typeNode) {
          targetGroupId = typeNode.defaultGroupId ?? null;
          break;
        }
      }
    }

    ctx.dispatchIntent({
      action: "openRecord",
      entity: "document",
      id: "__new__",
      targetSlot: "s2",
      initialData: {
        document_type: selectedType,
        document_group_id: targetGroupId,
      },
    });
  }, [selectedGroup, selectedType, treeData, ctx]);

  const handleRowClick = useCallback(
    (row: any) => {
      ctx.dispatchIntent({
        action: "openRecord",
        entity: "document",
        id: String(row.document_id),
        targetSlot: "s2",
      });
    },
    [ctx],
  );

  const toggle = useCallback((key: string) => {
    setCollapsedKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }, []);

  if (treeLoading) {
    return (
      <div className="sw-pane-empty flex flex-1 items-center justify-center">
        <div style={{ fontSize: 12.5, color: "var(--sw-text-muted, #6b7280)" }}>
          {t("tree.loading", ctx.lang)}
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col">
      {/* Toolbar */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          borderBottom: "1px solid var(--sw-border)",
          padding: "6px 12px",
          fontSize: 11,
        }}
      >
        <button
          type="button"
          onClick={() => setSidebarOpen((o) => !o)}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 4,
            borderRadius: "var(--sw-radius-sm)",
            padding: "2px 6px",
            color: "var(--sw-text-muted)",
            background: "none",
            border: "none",
            cursor: "pointer",
          }}
          title={isEn ? "Toggle sidebar" : "Seitenleiste umschalten"}
        >
          <PanelRightOpen size={12} />
        </button>
        <span style={{ fontWeight: 600, color: "var(--sw-accent)" }}>
          {isEn ? "Documents" : "Belege"}
        </span>
        {selectedType && (
          <span
            style={{
              marginLeft: 8,
              borderRadius: "var(--sw-radius-sm)",
              background: "var(--sw-accent-muted)",
              padding: "2px 6px",
              fontSize: 10,
              color: "var(--sw-accent)",
            }}
          >
            {selectedGroup ? `${selectedType} / ${selectedGroup}` : selectedType}
          </span>
        )}
        <button
          type="button"
          onClick={handleNewDocument}
          className="sw-btn sw-btn-primary sw-btn-xs"
          style={{
            marginLeft: "auto",
            display: "flex",
            alignItems: "center",
            gap: 4,
            fontSize: 10.5,
          }}
        >
          <Plus size={11} />
          {isEn ? "New Document" : "Neuer Beleg"}
        </button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar tree (3-level) */}
        {sidebarOpen && (
          <div
            className="flex flex-col border-r border-[var(--sw-border)]"
            style={{ width: 220, minWidth: 220, overflow: "auto", padding: "8px 4px" }}
          >
            {(treeData as DocTreeCategory[] | undefined)?.map((cat) => (
              <div key={cat.key} className="mb-2">
                <div
                  style={{
                    display: "flex",
                    cursor: "pointer",
                    alignItems: "center",
                    gap: 4,
                    padding: "4px 8px",
                    fontWeight: 700,
                    fontSize: 10,
                    textTransform: "uppercase",
                    color: "var(--sw-text-muted)",
                  }}
                  onClick={() => toggle(cat.key)}
                >
                  <ChevronRight
                    size={10}
                    style={{
                      transform: collapsedKeys.has(cat.key) ? "rotate(0deg)" : "rotate(90deg)",
                    }}
                  />
                  {isEn ? cat.label_en : cat.label_de}
                </div>

                {!collapsedKeys.has(cat.key) &&
                  cat.items.map((type) => {
                    const isTypeSelected = activeKey === type.key;
                    const typeCollapsed = collapsedKeys.has(type.key);
                    const hasGroups = (type.items?.length ?? 0) > 0;

                    return (
                      <div key={type.key} className="mt-0.5">
                        <div
                          style={{
                            display: "flex",
                            cursor: "pointer",
                            alignItems: "center",
                            gap: 6,
                            borderRadius: "var(--sw-radius-sm)",
                            padding: "4px 8px 4px 16px",
                            fontSize: 12,
                            background: isTypeSelected ? "var(--sw-accent-muted)" : "none",
                            fontWeight: isTypeSelected ? 600 : 500,
                          }}
                          onClick={() => {
                            handlePick({
                              key: type.key,
                              docType: type.docType,
                              defaultGroupId: type.defaultGroupId,
                            });
                          }}
                        >
                          {hasGroups ? (
                            <ChevronRight
                              size={10}
                              style={{
                                transform: typeCollapsed ? "rotate(0deg)" : "rotate(90deg)",
                                opacity: 0.5,
                              }}
                              onClick={(e) => {
                                e.stopPropagation();
                                toggle(type.key);
                              }}
                            />
                          ) : (
                            <div style={{ width: 10 }} />
                          )}
                          <span className="flex-1 truncate">
                            {isEn ? type.label_en : type.label_de}
                          </span>
                          <span style={{ fontSize: 9, opacity: 0.6 }}>{type.count}</span>
                        </div>

                        {!typeCollapsed &&
                          hasGroups &&
                          type.items?.map((group) => {
                            const isGroupSelected = activeKey === group.key;
                            return (
                              <div
                                key={group.key}
                                style={{
                                  display: "flex",
                                  cursor: "pointer",
                                  alignItems: "center",
                                  gap: 6,
                                  borderRadius: "var(--sw-radius-sm)",
                                  padding: "2px 8px 2px 32px",
                                  fontSize: 11,
                                  background: isGroupSelected ? "var(--sw-accent-muted)" : "none",
                                  color: isGroupSelected
                                    ? "var(--sw-accent)"
                                    : "var(--sw-text-muted)",
                                }}
                                onClick={() =>
                                  handlePick({
                                    key: group.key,
                                    groupId: group.groupId,
                                    docType: group.docType,
                                  })
                                }
                              >
                                <FileText size={10} />
                                <span className="flex-1 truncate">
                                  {isEn ? group.label_en : group.label_de}
                                </span>
                                <span style={{ fontSize: 9, opacity: 0.6 }}>{group.count}</span>
                              </div>
                            );
                          })}
                      </div>
                    );
                  })}
              </div>
            ))}
          </div>
        )}

        {/* Document list */}
        <div className="flex-1 overflow-hidden">
          <EntityDataTable
            entityName="document"
            mode="paginated"
            onRowClick={handleRowClick}
            t={(key) => t(key, ctx.lang)}
            lang={ctx.lang}
            renderHeaderActions={() => (
              <span
                style={{
                  fontSize: 11,
                  color: "var(--sw-text-muted, #6b7280)",
                  fontWeight: 500,
                  marginLeft: 8,
                }}
              >
                {docsLoading ? "…" : `${docs?.total ?? 0} ${t("list.entries", ctx.lang)}`}
              </span>
            )}
          />
        </div>
      </div>
    </div>
  );
}
