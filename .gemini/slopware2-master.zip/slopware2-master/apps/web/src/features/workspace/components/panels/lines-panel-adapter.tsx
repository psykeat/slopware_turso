import type { PanelState } from "@repo/shared/workspace";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  CheckIcon,
  ListIcon,
  PlusIcon,
  SaveIcon,
  SearchIcon,
  Trash2Icon,
  XIcon,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { listEntityFn, resolveArticlePricingFn } from "~/server/server-functions";

import { useHotkeyLayer } from "../../../hotkeys/use-hotkey-layer";
import { useScopedHotkey } from "../../../hotkeys/use-scoped-hotkey";
import { t } from "../../i18n";
import type { PaneCtx } from "../../pane";
import { GridRoot } from "../grid";
import type { GridRow } from "../grid";

type LinesPanel = PanelState & { type: "lines" };

interface DocLine extends GridRow {
  document_line_id: string;
  document_id: string;
  line_no: number;
  article_id: string | null;
  article_text_snapshot: string | null;
  quantity: number;
  net_price: number;
  tax_code_id: string | null;
  tax_rate: number | null;
  tax_amount: number | null;
  line_total_net: number | null;
  warehouse_id: string | null;
  line_type: string;
  unit: string | null;
  discount_percentage: number | null;
  movement_type: string | null;
}

export interface SaveLine {
  lineNo: number;
  articleId?: string;
  articleTextSnapshot?: string;
  quantity: number;
  netPrice: number;
  taxCodeId?: string;
  warehouseId?: string;
  lineType?: string;
  discountPercentage?: number;
}

interface ArticleOption {
  id: string;
  article_no: string;
  name: string;
}

interface LinesPanelAdapterProps {
  panel: LinesPanel;
  ctx: PaneCtx;
  onSave?: (lines: SaveLine[]) => Promise<void>;
  renderExtraActions?: () => React.ReactNode;
  baseTabIndex?: number;
}

function resolveLinesEntity(parentEntity: string): string {
  if (parentEntity.endsWith("_line")) return parentEntity;
  return parentEntity + "_line";
}

function calcLineTotal(qty: number, price: number, discount: number | null): number {
  const base = qty * price;
  if (discount) return base * (1 - discount / 100);
  return base;
}

function calcTax(net: number, rate: number | null): number {
  if (!rate) return 0;
  return net * (rate / 100);
}

function emptyLine(id: string, parentId: string, lineNo: number, lineType: string): DocLine {
  return {
    document_line_id: id,
    id,
    document_id: parentId,
    line_no: lineNo,
    line_type: lineType,
    article_id: null,
    article_text_snapshot: null,
    quantity: lineType === "comment" ? 0 : 1,
    net_price: 0,
    tax_code_id: null,
    tax_rate: null,
    tax_amount: null,
    line_total_net: null,
    warehouse_id: null,
    unit: null,
    discount_percentage: null,
    movement_type: null,
  };
}

export function LinesPanelAdapter({
  panel,
  ctx,
  onSave,
  renderExtraActions,
  baseTabIndex,
}: LinesPanelAdapterProps) {
  const { entity, parentId, viewKey } = panel;
  const hasParentId = !!parentId && parentId.trim() !== "";
  const linesEntity = useMemo(() => resolveLinesEntity(entity), [entity]);

  const { data: linesData, isLoading: linesLoading } = useQuery({
    queryKey: ["entity-list", linesEntity, parentId],
    queryFn: () =>
      listEntityFn({
        data: {
          entityName: linesEntity,
          options: {
            filters: [{ column: "document_id", operator: "=", value: parentId }],
            sortBy: "line_no",
            sortOrder: "ASC",
            limit: 500,
          },
        },
      }),
    enabled: !!entity && hasParentId,
  });

  const { data: taxCodeData } = useQuery({
    queryKey: ["entity-list", "tax_code"],
    queryFn: () => listEntityFn({ data: { entityName: "tax_code", options: { limit: 100 } } }),
    enabled: !!entity,
  });

  const taxRateMap = useMemo(() => {
    const map: Record<string, number> = {};
    for (const tc of (taxCodeData?.items ?? []) as Record<string, unknown>[]) {
      if (tc.tax_code_id && tc.tax_rate !== undefined) {
        map[tc.tax_code_id as string] = Number(tc.tax_rate ?? 0);
      }
    }
    return map;
  }, [taxCodeData]);

  // Local stateful lines (dirty tracking)
  const [localLines, setLocalLines] = useState<DocLine[]>([]);
  const [dirty, setDirty] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (!dirty) {
      setLocalLines((linesData?.items as DocLine[]) ?? []);
    }
  }, [linesData, dirty]);

  // Editing / selection state
  const [editingRowId, setEditingRowId] = useState<string | null>(null);
  const [editingValues, setEditingValues] = useState<Record<string, unknown>>({});
  const [selectedRowId, setSelectedRowId] = useState<string | null>(null);

  // Article search
  const [articleSearch, setArticleSearch] = useState("");
  const [articleOptions, setArticleOptions] = useState<ArticleOption[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const searchRef = useRef<HTMLDivElement>(null);

  // Focus refs
  const firstInputRef = useRef<HTMLInputElement>(null);
  const qtyInputRef = useRef<HTMLInputElement>(null);
  const priceInputRef = useRef<HTMLInputElement>(null);
  const discInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editingRowId) {
      // Small delay to ensure render
      const t = setTimeout(() => {
        firstInputRef.current?.focus();
        if (firstInputRef.current) firstInputRef.current.select();
      }, 50);
      return () => clearTimeout(t);
    }
  }, [editingRowId]);

  const { data: searchResults } = useQuery({
    queryKey: ["article-search", articleSearch],
    queryFn: () =>
      listEntityFn({
        data: {
          entityName: "article",
          options: {
            filters: [{ column: "article_no", operator: "ILIKE", value: `%${articleSearch}%` }],
            limit: 20,
          },
        },
      }),
    enabled: articleSearch.length >= 1,
  });

  const pricingMutation = useMutation({
    mutationFn: (params: { articleId: string; addressId: string; documentDate: string }) =>
      resolveArticlePricingFn({ data: params }),
  });

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleEditCellChange = useCallback((field: string, value: unknown) => {
    setEditingValues((prev) => ({ ...prev, [field]: value }));
  }, []);

  const handleStartEdit = useCallback((row: GridRow) => {
    setEditingRowId(row.id as string);
    setSelectedRowId(row.id as string);
    setEditingValues({ ...row });
  }, []);

  const handleAddLine = useCallback(() => {
    const newId = `new-${Date.now()}`;
    setLocalLines((prev) => {
      const maxPos = prev.length > 0 ? Math.max(...prev.map((r) => r.line_no)) : 0;
      const placeholder = emptyLine(newId, parentId ?? "", maxPos + 1, "article");
      return [...prev, placeholder];
    });
    setEditingRowId(newId);
    setEditingValues({});
    setDirty(true);
  }, [parentId]);

  // Auto-add line if focused and empty
  useEffect(() => {
    if (!linesLoading && hasParentId && localLines.length === 0 && !editingRowId) {
      handleAddLine();
    }
  }, [linesLoading, hasParentId, localLines.length, editingRowId, handleAddLine]);

  const handleArticleSearch = useCallback((query: string) => {
    setArticleSearch(query);
    if (query.length >= 1) {
      setShowDropdown(true);
      setSelectedIndex(0);
    } else {
      setShowDropdown(false);
    }
  }, []);

  useEffect(() => {
    if (searchResults?.items) {
      setArticleOptions(searchResults.items as unknown as ArticleOption[]);
    }
  }, [searchResults]);

  const handleArticleSelect = useCallback(
    (article: ArticleOption) => {
      setEditingValues((prev) => ({
        ...prev,
        article_id: article.id,
        article_text_snapshot: `${article.article_no} ${article.name}`,
      }));
      setShowDropdown(false);
      setArticleSearch("");

      const addressId = editingValues.customer_id as string | undefined;
      const documentDate = editingValues.document_date as string | undefined;
      if (addressId && documentDate) {
        pricingMutation.mutate(
          { articleId: article.id, addressId, documentDate },
          {
            onSuccess: (pricing) => {
              setEditingValues((prev) => ({
                ...prev,
                net_price: pricing.netPrice ? Number(pricing.netPrice) : prev.net_price,
                tax_code_id: pricing.taxCodeId ?? prev.tax_code_id,
              }));
            },
          },
        );
      }
      setTimeout(() => qtyInputRef.current?.focus(), 50);
    },
    [editingValues, pricingMutation],
  );

  const handleConfirmEdit = useCallback(
    (chain = false) => {
      if (!editingRowId) return;
      setLocalLines((prev) => {
        const exists = prev.some((l) => l.document_line_id === editingRowId);
        if (exists) {
          return prev.map((l) =>
            l.document_line_id === editingRowId ? ({ ...l, ...editingValues } as DocLine) : l,
          );
        }
        const maxNo = prev.length > 0 ? Math.max(...prev.map((l) => l.line_no)) : 0;
        const newLine: DocLine = {
          ...emptyLine(editingRowId, parentId ?? "", maxNo + 1, "article"),
          ...(editingValues as Partial<DocLine>),
        };
        return [...prev, newLine];
      });
      setDirty(true);
      setEditingRowId(null);
      setEditingValues({});

      if (chain) {
        setTimeout(() => handleAddLine(), 0);
      }
    },
    [editingRowId, editingValues, parentId, handleAddLine],
  );

  const handleCancelEdit = useCallback(() => {
    if (editingRowId?.startsWith("new-")) {
      setLocalLines((prev) => prev.filter((l) => l.document_line_id !== editingRowId));
    }
    setEditingRowId(null);
    setEditingValues({});
  }, [editingRowId]);

  const handleDeleteLine = useCallback(
    (lineId: string) => {
      if (!confirm(t("doc.lines.delete.confirm", ctx.lang))) return;
      setLocalLines((prev) => {
        const filtered = prev.filter((l) => l.document_line_id !== lineId);
        return filtered.map((l, i) => ({ ...l, line_no: i + 1 }));
      });
      setDirty(true);
      if (selectedRowId === lineId) setSelectedRowId(null);
    },
    [ctx.lang, selectedRowId],
  );

  const handleSave = useCallback(async () => {
    if (!onSave || isSaving) return;
    setIsSaving(true);
    try {
      await onSave(
        localLines.map((l, i) => ({
          lineNo: i + 1,
          articleId: l.article_id ?? undefined,
          articleTextSnapshot: l.article_text_snapshot ?? undefined,
          quantity: Number(l.quantity) || 0,
          netPrice: Number(l.net_price) || 0,
          taxCodeId: l.tax_code_id ?? undefined,
          warehouseId: l.warehouse_id ?? undefined,
          lineType: l.line_type,
          discountPercentage: l.discount_percentage ? Number(l.discount_percentage) : undefined,
        })),
      );
      setDirty(false);
    } finally {
      setIsSaving(false);
    }
  }, [onSave, isSaving, localLines]);

  useHotkeyLayer("lines-panel");

  useScopedHotkey(
    "lines-panel",
    "Enter",
    useCallback(
      (e: KeyboardEvent) => {
        if (!e.ctrlKey) return;
        e.preventDefault();
        if (editingRowId !== null) handleConfirmEdit();
      },
      [editingRowId, handleConfirmEdit],
    ),
  );

  const handleAddComment = useCallback(() => {
    const newId = `new-${Date.now()}`;
    setLocalLines((prev) => {
      const maxPos = prev.length > 0 ? Math.max(...prev.map((r) => r.line_no)) : 0;
      const placeholder = emptyLine(newId, parentId ?? "", maxPos + 1, "comment");
      return [...prev, placeholder];
    });
    setEditingRowId(newId);
    setEditingValues({});
    setDirty(true);
  }, [parentId]);

  const handleEditKeyDown = useCallback(
    (e: React.KeyboardEvent, field: string) => {
      if (e.key === "Enter" || e.key === "Tab") {
        if (field === "article") {
          if (showDropdown && articleOptions[selectedIndex]) {
            e.preventDefault();
            handleArticleSelect(articleOptions[selectedIndex]);
          } else if (editingValues.article_id) {
            if (e.key === "Enter") {
              e.preventDefault();
              qtyInputRef.current?.focus();
            }
          }
        } else if (field === "quantity") {
          if (e.key === "Enter") {
            e.preventDefault();
            priceInputRef.current?.focus();
          }
        } else if (field === "net_price") {
          if (e.key === "Enter") {
            e.preventDefault();
            discInputRef.current?.focus();
          }
        } else if (field === "discount_percentage") {
          e.preventDefault();
          handleConfirmEdit(true); // Chain!
        }
      } else if (e.key === "ArrowDown" && field === "article" && showDropdown) {
        e.preventDefault();
        setSelectedIndex((prev) => (prev + 1) % articleOptions.length);
      } else if (e.key === "ArrowUp" && field === "article" && showDropdown) {
        e.preventDefault();
        setSelectedIndex((prev) => (prev - 1 + articleOptions.length) % articleOptions.length);
      } else if (e.key === "Escape") {
        e.preventDefault();
        handleCancelEdit();
      }
    },
    [
      handleConfirmEdit,
      handleCancelEdit,
      showDropdown,
      articleOptions,
      selectedIndex,
      handleArticleSelect,
      editingValues.article_id,
    ],
  );

  const handleContainerKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      if (e.key === "Delete" && selectedRowId && !editingRowId) {
        e.preventDefault();
        handleDeleteLine(selectedRowId);
      }
    },
    [selectedRowId, editingRowId, handleDeleteLine],
  );

  // Display lines: merge server/local with active editing values
  const displayLines = useMemo(() => {
    return localLines.map((l) =>
      l.document_line_id === editingRowId ? ({ ...l, ...editingValues } as DocLine) : l,
    );
  }, [localLines, editingRowId, editingValues]);

  const totals = useMemo(() => {
    let netto = 0;
    let tax = 0;
    for (const l of displayLines) {
      if (l.line_type === "comment") continue;
      const qty = Number(l.quantity) || 0;
      const price = Number(l.net_price) || 0;
      const disc = l.discount_percentage ? Number(l.discount_percentage) : 0;
      const lineNet = calcLineTotal(qty, price, disc || null);
      netto += lineNet;
      const rate = l.tax_code_id ? (taxRateMap[l.tax_code_id] ?? 0) : 0;
      tax += calcTax(lineNet, rate || null);
    }
    return { netto, tax, gross: netto + tax };
  }, [displayLines, taxRateMap]);

  const fmt = useCallback(
    (n: number, decimals = 2) =>
      n.toLocaleString(ctx.lang === "de" ? "de-DE" : "en-US", {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
      }),
    [ctx.lang],
  );

  const columns = useMemo(
    () => [
      {
        accessorKey: "line_no",
        header: t("doc.lines.pos", ctx.lang),
        size: 40,
        enableSorting: false,
        cell: ({ row }: { row: { original: DocLine } }) => (
          <span
            className="mono"
            style={{ textAlign: "center", color: "var(--sw-text-muted)", fontSize: 11 }}
          >
            {row.original.line_no}
          </span>
        ),
      },
      {
        accessorKey: "article_text_snapshot",
        header: t("doc.lines.article", ctx.lang),
        size: 200,
        enableSorting: false,
        cell: ({ row }: { row: { original: DocLine } }) => {
          const isEditing = row.original.id === editingRowId;
          if (isEditing) {
            return (
              <div ref={searchRef} style={{ position: "relative", width: "100%" }}>
                <input
                  ref={firstInputRef}
                  tabIndex={baseTabIndex}
                  className="sw-input"
                  style={{ width: "100%", fontSize: 12, padding: "2px 4px" }}
                  placeholder={t("doc.lines.searcharticle", ctx.lang)}
                  value={articleSearch || (editingValues.article_text_snapshot as string) || ""}
                  onChange={(e) => handleArticleSearch(e.target.value)}
                  onKeyDown={(e) => handleEditKeyDown(e, "article")}
                />
                {showDropdown && articleOptions.length > 0 && (
                  <div
                    style={{
                      position: "absolute",
                      top: "100%",
                      left: 0,
                      right: 0,
                      zIndex: 100,
                      maxHeight: 200,
                      overflow: "auto",
                      border: "1px solid var(--sw-border)",
                      borderRadius: "var(--sw-radius-sm)",
                      background: "var(--sw-bg-card)",
                    }}
                  >
                    {articleOptions.map((opt, idx) => (
                      <div
                        key={opt.id}
                        role="option"
                        aria-selected={idx === selectedIndex}
                        tabIndex={-1}
                        style={{
                          padding: "4px 8px",
                          cursor: "pointer",
                          fontSize: 12,
                          background: idx === selectedIndex ? "var(--sw-accent-muted)" : "none",
                        }}
                        onMouseDown={(e) => {
                          e.preventDefault();
                          handleArticleSelect(opt);
                        }}
                      >
                        <span style={{ color: "var(--sw-text-muted)" }}>{opt.article_no}</span>{" "}
                        {opt.name}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          }
          const snapshot = row.original.article_text_snapshot ?? "";
          return (
            <span style={{ fontSize: 12 }}>
              {row.original.line_type === "comment" ? (
                <em style={{ color: "var(--sw-text-muted)" }}>{snapshot || "—"}</em>
              ) : (
                snapshot || "—"
              )}
            </span>
          );
        },
      },
      {
        accessorKey: "quantity",
        header: t("doc.lines.qty", ctx.lang),
        size: 70,
        enableSorting: false,
        cell: ({ row }: { row: { original: DocLine } }) => {
          const isEditing = row.original.id === editingRowId;
          if (isEditing && row.original.line_type !== "comment") {
            return (
              <input
                ref={qtyInputRef}
                className="sw-input"
                type="number"
                style={{ width: "100%", fontSize: 12, padding: "2px 4px", textAlign: "right" }}
                value={Number(editingValues.quantity) || 0}
                onChange={(e) => handleEditCellChange("quantity", parseFloat(e.target.value) || 0)}
                onKeyDown={(e) => handleEditKeyDown(e, "quantity")}
                onFocus={(e) => e.target.select()}
              />
            );
          }
          return (
            <span className="mono" style={{ fontSize: 12, textAlign: "right", display: "block" }}>
              {row.original.line_type === "comment" ? "—" : fmt(Number(row.original.quantity), 0)}
            </span>
          );
        },
      },
      {
        accessorKey: "net_price",
        header: t("doc.lines.unitprice", ctx.lang),
        size: 90,
        enableSorting: false,
        cell: ({ row }: { row: { original: DocLine } }) => {
          const isEditing = row.original.id === editingRowId;
          if (isEditing && row.original.line_type !== "comment") {
            return (
              <input
                ref={priceInputRef}
                className="sw-input"
                type="number"
                style={{ width: "100%", fontSize: 12, padding: "2px 4px", textAlign: "right" }}
                value={Number(editingValues.net_price) || 0}
                onChange={(e) => handleEditCellChange("net_price", parseFloat(e.target.value) || 0)}
                onKeyDown={(e) => handleEditKeyDown(e, "net_price")}
                onFocus={(e) => e.target.select()}
              />
            );
          }
          return (
            <span className="mono" style={{ fontSize: 12, textAlign: "right", display: "block" }}>
              {row.original.line_type === "comment" ? "—" : fmt(Number(row.original.net_price))}
            </span>
          );
        },
      },
      {
        accessorKey: "discount_percentage",
        header: ctx.lang === "de" ? "Rabatt%" : "Disc%",
        size: 60,
        enableSorting: false,
        cell: ({ row }: { row: { original: DocLine } }) => {
          const isEditing = row.original.id === editingRowId;
          if (isEditing && row.original.line_type !== "comment") {
            return (
              <input
                ref={discInputRef}
                className="sw-input"
                type="number"
                style={{ width: "100%", fontSize: 12, padding: "2px 4px", textAlign: "right" }}
                value={Number(editingValues.discount_percentage) || 0}
                onChange={(e) =>
                  handleEditCellChange("discount_percentage", parseFloat(e.target.value) || 0)
                }
                onKeyDown={(e) => handleEditKeyDown(e, "discount_percentage")}
                onFocus={(e) => e.target.select()}
              />
            );
          }
          const disc = row.original.discount_percentage;
          return (
            <span
              className="mono"
              style={{
                fontSize: 11,
                color: "var(--sw-text-muted)",
                textAlign: "right",
                display: "block",
              }}
            >
              {disc && Number(disc) > 0 ? `${Number(disc)}%` : "—"}
            </span>
          );
        },
      },
      {
        accessorKey: "tax_code_id",
        header: t("doc.lines.taxrate", ctx.lang),
        size: 60,
        enableSorting: false,
        cell: ({ row }: { row: { original: DocLine } }) => {
          if (row.original.line_type === "comment") {
            return (
              <span
                style={{
                  fontSize: 12,
                  color: "var(--sw-text-muted)",
                  textAlign: "right",
                  display: "block",
                }}
              >
                —
              </span>
            );
          }
          const rate = row.original.tax_code_id
            ? (taxRateMap[row.original.tax_code_id] ?? null)
            : null;
          return (
            <span
              className="mono"
              style={{
                fontSize: 11,
                color: "var(--sw-text-muted)",
                textAlign: "right",
                display: "block",
              }}
            >
              {rate != null ? `${rate}%` : "—"}
            </span>
          );
        },
      },
      {
        accessorKey: "line_total_net",
        header: t("doc.lines.linnet", ctx.lang),
        size: 90,
        enableSorting: false,
        cell: ({ row }: { row: { original: DocLine } }) => {
          if (row.original.line_type === "comment") {
            return (
              <span
                style={{
                  fontSize: 12,
                  color: "var(--sw-text-muted)",
                  textAlign: "right",
                  display: "block",
                }}
              >
                —
              </span>
            );
          }
          const qty = Number(row.original.quantity) || 0;
          const price = Number(row.original.net_price) || 0;
          const disc = row.original.discount_percentage
            ? Number(row.original.discount_percentage)
            : 0;
          const total = calcLineTotal(qty, price, disc || null);
          return (
            <span
              className="mono"
              style={{ fontSize: 12, fontWeight: 600, textAlign: "right", display: "block" }}
            >
              {fmt(total)}
            </span>
          );
        },
      },
      ...(onSave
        ? [
            {
              accessorKey: "_delete",
              header: "",
              size: 32,
              enableSorting: false,
              cell: ({ row }: { row: { original: DocLine } }) => (
                <button
                  title={t("doc.lines.delete", ctx.lang)}
                  style={{
                    background: "none",
                    border: "none",
                    cursor: "pointer",
                    color: "var(--sw-text-muted)",
                    padding: "2px 4px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    width: "100%",
                  }}
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteLine(row.original.document_line_id);
                  }}
                >
                  <Trash2Icon size={12} />
                </button>
              ),
            },
          ]
        : []),
    ],
    [
      ctx.lang,
      editingRowId,
      editingValues,
      articleSearch,
      articleOptions,
      showDropdown,
      taxRateMap,
      onSave,
      handleArticleSearch,
      handleArticleSelect,
      handleEditCellChange,
      handleDeleteLine,
      handleEditKeyDown,
      fmt,
      selectedIndex,
      baseTabIndex,
    ],
  );

  if (!entity) {
    return (
      <div
        className="sw-pane-empty"
        style={{
          display: "flex",
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
          gap: 8,
        }}
      >
        <div className="sw-pane-empty-icon">
          <ListIcon size={32} />
        </div>
        <div style={{ fontWeight: 600 }}>{t("lines.placeholder.title", ctx.lang)}</div>
        <div
          style={{
            fontSize: 12.5,
            color: "var(--sw-text-muted)",
            textAlign: "center",
            maxWidth: 200,
          }}
        >
          {t("lines.placeholder.description", ctx.lang)}
        </div>
      </div>
    );
  }

  if (!hasParentId) {
    return (
      <div
        className="sw-pane-empty"
        style={{
          display: "flex",
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
          gap: 8,
        }}
      >
        <div className="sw-pane-empty-icon">
          <ListIcon size={32} />
        </div>
        <div style={{ fontWeight: 600 }}>{t("lines.noparent.title", ctx.lang)}</div>
        <div
          style={{
            fontSize: 12.5,
            color: "var(--sw-text-muted)",
            textAlign: "center",
            maxWidth: 200,
          }}
        >
          {t("lines.noparent.description", ctx.lang)}
        </div>
      </div>
    );
  }

  if (linesLoading) {
    return (
      <div
        className="sw-pane-empty"
        style={{ display: "flex", flex: 1, alignItems: "center", justifyContent: "center" }}
      >
        <span style={{ fontSize: 12, color: "var(--sw-text-muted)" }}>
          {t("lines.loading", ctx.lang)}
        </span>
      </div>
    );
  }

  return (
    <div
      className="flex h-full flex-col"
      tabIndex={-1}
      onKeyDown={handleContainerKeyDown}
      style={{ outline: "none" }}
    >
      <div className="flex-1 overflow-hidden">
        <GridRoot
          columns={columns}
          mode="plain"
          data={displayLines}
          onRowClick={(row) => setSelectedRowId(row.id as string)}
          onRowDoubleClick={handleStartEdit}
          selectedRowId={selectedRowId}
          editingRowId={editingRowId}
          editingValues={editingValues}
          onEditCellChange={handleEditCellChange}
          editableFields={["quantity", "net_price", "discount_percentage"]}
          onKeyDown={(e) => handleEditKeyDown(e, "grid")}
          emptyMessage={t("lines.empty", ctx.lang)}
          renderHeaderActions={() => (
            <div
              className="sw-datagrid-toolbar"
              style={{
                display: "flex",
                width: "100%",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <span style={{ fontSize: 11, color: "var(--sw-text-muted)", fontWeight: 500 }}>
                {linesEntity}
                {viewKey ? ` (${viewKey})` : ""}
              </span>
              <div style={{ display: "flex", gap: 4 }}>
                {renderExtraActions && renderExtraActions()}
                {editingRowId !== null ? (
                  <>
                    <button
                      className="sw-btn sw-btn-primary sw-btn-xs"
                      onClick={() => handleConfirmEdit()}
                      style={{ display: "flex", alignItems: "center", gap: 4 }}
                    >
                      <CheckIcon size={11} /> {t("lines.confirm", ctx.lang)}
                    </button>
                    <button
                      className="sw-btn sw-btn-ghost sw-btn-xs"
                      onClick={handleCancelEdit}
                      style={{ display: "flex", alignItems: "center", gap: 4 }}
                    >
                      <XIcon size={11} />
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      className="sw-btn sw-btn-primary sw-btn-xs"
                      onClick={handleAddLine}
                      style={{ display: "flex", alignItems: "center", gap: 4 }}
                    >
                      <PlusIcon size={11} /> {t("doc.lines.add", ctx.lang)}
                    </button>
                    <button
                      className="sw-btn sw-btn-ghost sw-btn-xs"
                      onClick={handleAddComment}
                      style={{ display: "flex", alignItems: "center", gap: 4 }}
                    >
                      <SearchIcon size={11} /> {t("doc.lines.add.comment", ctx.lang)}
                    </button>
                    {onSave && dirty && (
                      <button
                        className="sw-btn sw-btn-primary sw-btn-xs"
                        onClick={handleSave}
                        disabled={isSaving}
                        style={{ display: "flex", alignItems: "center", gap: 4 }}
                      >
                        <SaveIcon size={11} />
                        {isSaving ? "…" : t("doc.lines.save", ctx.lang)}
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          )}
        />
      </div>
      {/* Totals footer */}
      <div className="sw-lines-totals sticky bottom-0 z-10 mt-auto border-t bg-white p-4 shadow-sm">
        <div className="flex items-center justify-end gap-12">
          <div className="flex flex-col items-end">
            <span className="text-[10px] font-bold tracking-wider text-gray-400 uppercase">
              {t("doc.lines.totals.netto", ctx.lang)}
            </span>
            <span className="font-mono text-sm font-medium">{fmt(totals.netto)}</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-[10px] font-bold tracking-wider text-gray-400 uppercase">
              {t("doc.lines.totals.tax", ctx.lang)}
            </span>
            <span className="font-mono text-sm font-medium">{fmt(totals.tax)}</span>
          </div>
          <div className="flex flex-col items-end border-l pl-12">
            <span className="text-[10px] font-bold tracking-wider text-gray-400 uppercase">
              {t("doc.lines.totals.gross", ctx.lang)}
            </span>
            <span className="font-mono text-xl font-bold text-blue-600">{fmt(totals.gross)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
