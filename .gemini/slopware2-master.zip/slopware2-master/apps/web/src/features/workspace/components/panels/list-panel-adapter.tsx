import type { PanelState } from "@repo/shared/workspace";
import { useMutation } from "@tanstack/react-query";
import { ListIcon } from "lucide-react";
import { useCallback } from "react";

import { duplicateEntityFn } from "~/server/server-functions";

import { t } from "../../i18n";
import type { PaneCtx } from "../../pane";
import { EntityDataTable } from "../data-table/entity-data-table";

type ListPanel = PanelState & { type: "list" };

export function ListPanelAdapter({ panel, ctx }: { panel: ListPanel; ctx: PaneCtx }) {
  const { entity, viewKey, params } = panel;
  const { dispatchIntent } = ctx;

  const _permanentFilters = params?.filters;

  const duplicateMutation = useMutation({
    mutationFn: (row: any) => {
      const idField = Object.keys(row).find((k) => k.endsWith("_id")) ?? "id";
      return duplicateEntityFn({ data: { entityName: entity!, sourceId: String(row[idField]) } });
    },
  });

  const handleRowClick = useCallback(
    (row: any) => {
      const idField = Object.keys(row).find((k) => k.endsWith("_id")) ?? "id";
      dispatchIntent({ action: "openRecord", entity, id: String(row[idField]), targetSlot: "s2" });
    },
    [dispatchIntent, entity],
  );

  const handleDuplicateRow = useCallback(
    (row: any) => {
      duplicateMutation.mutate(row);
    },
    [duplicateMutation],
  );

  if (!entity) {
    return (
      <div className="sw-pane-empty flex flex-1 items-center justify-center">
        <div className="flex flex-col items-center gap-2">
          <div className="sw-pane-empty-icon">
            <ListIcon size={32} />
          </div>
          <div style={{ fontWeight: 600, marginBottom: 4 }}>
            {t("list.placeholder.title", ctx.lang)}
          </div>
          <div
            style={{
              fontSize: 12.5,
              color: "var(--sw-text-muted, #6b7280)",
              textAlign: "center",
              maxWidth: 200,
            }}
          >
            {t("list.placeholder.description", ctx.lang)}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col">
      <EntityDataTable
        entityName={entity}
        mode="paginated"
        onRowClick={handleRowClick}
        onDuplicateRow={handleDuplicateRow}
        t={(key) => t(key, ctx.lang)}
        lang={ctx.lang}
        renderHeaderActions={() => (
          <span
            style={{
              fontSize: 11,
              color: "var(--sw-text-muted, #6b7280)",
              fontWeight: 500,
              marginLeft: 8,
            }}
          >
            {entity}
            {viewKey ? ` (${viewKey})` : ""}
          </span>
        )}
      />
      {_permanentFilters !== undefined && (
        <div className="sr-only">active-filters: {JSON.stringify(_permanentFilters)}</div>
      )}
    </div>
  );
}
