import { X, BarChart3, Package, Users, Hash } from "lucide-react";
import * as React from "react";

import { useWorkspaceContext } from "../workspace-context";
import { CustomerStatsSection } from "./customer-stats-section";
import { InventoryBalanceTable } from "./inventory-balance-table";

interface StatisticsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  t: (k: string) => string;
  lang: string;
}

function getActiveEntityInfo(ctx: ReturnType<typeof useWorkspaceContext>) {
  if (ctx.selectedAddress && ctx.selectedAddress.id) {
    return {
      type: "address" as const,
      id: String(ctx.selectedAddress.id),
      label: ctx.t("stats.entity.address"),
    };
  }
  if (ctx.selectedDocument && ctx.selectedDocument.id) {
    return {
      type: "document" as const,
      id: String(ctx.selectedDocument.id),
      label: ctx.t("stats.entity.document"),
    };
  }
  if (ctx.selectedArticle && ctx.selectedArticle.id) {
    return {
      type: "article" as const,
      id: String(ctx.selectedArticle.id),
      label: ctx.t("stats.entity.article"),
    };
  }
  if (ctx.selectedArticleGroup && ctx.selectedArticleGroup.id) {
    return {
      type: "article_group" as const,
      id: String(ctx.selectedArticleGroup.id),
      label: ctx.t("stats.entity.article_group"),
    };
  }
  return null;
}

function AddressStats({ addressId }: { addressId: string }) {
  const ctx = useWorkspaceContext();
  return (
    <div>
      <div
        style={{
          fontSize: 9.5,
          fontWeight: 700,
          textTransform: "uppercase",
          letterSpacing: "0.1em",
          color: "var(--text-muted)",
          marginBottom: 8,
        }}
      >
        {ctx.t("stats.address.documents")}
      </div>
      <CustomerStatsSection customerId={addressId} isCustomer={true} />
    </div>
  );
}

function ArticleStats({ articleId }: { articleId: string }) {
  const ctx = useWorkspaceContext();
  return (
    <div>
      <div
        style={{
          fontSize: 9.5,
          fontWeight: 700,
          textTransform: "uppercase",
          letterSpacing: "0.1em",
          color: "var(--text-muted)",
          marginBottom: 8,
        }}
      >
        {ctx.t("stats.article.inventory")}
      </div>
      <InventoryBalanceTable articleId={articleId} />
    </div>
  );
}

function DocumentStats() {
  const ctx = useWorkspaceContext();
  return (
    <div style={{ padding: 12, color: "var(--text-muted)", fontSize: 12 }}>
      {ctx.t("stats.document.info")}
    </div>
  );
}

function ArticleGroupStats() {
  const ctx = useWorkspaceContext();
  return (
    <div style={{ padding: 12, color: "var(--text-muted)", fontSize: 12 }}>
      {ctx.t("stats.articlegroup.info")}
    </div>
  );
}

const ENTITY_ICONS: Record<string, React.ReactNode> = {
  address: <Users size={14} />,
  document: <Hash size={14} />,
  article: <Package size={14} />,
  article_group: <BarChart3 size={14} />,
};

export function StatisticsDrawer({ isOpen, onClose, t }: StatisticsDrawerProps) {
  const ctx = useWorkspaceContext();
  const entityInfo = getActiveEntityInfo(ctx);

  if (!isOpen) return null;

  return (
    <div
      className="sw-overlay"
      role="presentation"
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.3)",
        zIndex: 1000,
        backdropFilter: "blur(1px)",
      }}
      onClick={onClose}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onClose();
        }
      }}
      tabIndex={-1}
    >
      <div
        className="sw-stats-drawer"
        role="dialog"
        aria-modal="true"
        aria-label={t("stats.drawer.title")}
        style={{
          position: "absolute",
          top: 0,
          right: 0,
          bottom: 0,
          width: "420px",
          background: "var(--bg-pane)",
          borderLeft: "1px solid var(--border)",
          display: "flex",
          flexDirection: "column",
          boxShadow: "var(--shadow-lg)",
        }}
        onClick={(e) => e.stopPropagation()}
        onKeyDown={(e) => e.stopPropagation()}
      >
        <div
          style={{
            padding: "10px 14px",
            borderBottom: "1px solid var(--border)",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <BarChart3 size={14} style={{ color: "var(--accent)" }} />
            <span style={{ fontSize: 13, fontWeight: 600 }}>{t("stats.drawer.title")}</span>
          </div>
          <button onClick={onClose} className="sw-btn-icon">
            <X size={14} />
          </button>
        </div>

        <div style={{ flex: 1, overflowY: "auto", padding: 14 }}>
          {entityInfo ? (
            <>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  marginBottom: 14,
                  padding: "6px 10px",
                  background: "var(--bg)",
                  borderRadius: "var(--radius-sm)",
                  border: "1px solid var(--border)",
                  fontSize: 12,
                }}
              >
                {ENTITY_ICONS[entityInfo.type]}
                <span style={{ fontWeight: 500 }}>{entityInfo.label}</span>
              </div>

              {entityInfo.type === "address" && <AddressStats addressId={entityInfo.id} />}
              {entityInfo.type === "article" && <ArticleStats articleId={entityInfo.id} />}
              {entityInfo.type === "document" && <DocumentStats />}
              {entityInfo.type === "article_group" && <ArticleGroupStats />}
            </>
          ) : (
            <div
              style={{
                textAlign: "center",
                padding: "40px 20px",
                color: "var(--text-muted)",
                fontSize: 12,
              }}
            >
              {t("stats.drawer.noentity")}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
