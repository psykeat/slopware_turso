import type { EffectiveField } from "@repo/domain";
import type { ColumnDef } from "@tanstack/react-table";
import * as React from "react";

import { getVariantFromField } from "./components/data-table/filter-utils";

export function resolveI18n(v: unknown, lang: string): string {
  if (v == null) return "";

  let rec: Record<string, string> | null = null;

  if (typeof v === "object" && !Array.isArray(v)) {
    rec = v as Record<string, string>;
  } else if (typeof v === "string") {
    // Handle stringified JSON from JSONB columns
    try {
      const parsed = JSON.parse(v);
      if (typeof parsed === "object" && !Array.isArray(parsed)) {
        rec = parsed as Record<string, string>;
      }
    } catch {
      // Not JSON, return as-is
    }
  }

  if (rec) {
    return rec[lang] ?? rec["de"] ?? (Object.values(rec)[0] as string | undefined) ?? "";
  }

  return String(v);
}

export function fieldsToColumns(
  fields: EffectiveField[],
  lang = "de",
  lookupMap: Record<string, Record<string, string>> = {},
): ColumnDef<any, any>[] {
  return fields
    .filter((f) => f.isVisible !== false)
    .map((f) => {
      const header = f.label?.[lang] ?? f.label?.["de"] ?? f.fieldName;
      const size = (f.customAttributes?.col_size ?? f.customAttributes?.size) as number | undefined;

      const col: ColumnDef<any, any> = {
        accessorKey: f.fieldName,
        header,
        ...(size != null ? { size } : {}),
        meta: {
          variant: getVariantFromField(f),
          label: header,
          searchable:
            (f.customAttributes?.searchable as boolean | undefined) ?? f.fieldType !== "boolean",
        },
      };

      if (f.fieldType === "boolean") {
        col.cell = ({ getValue }) => {
          const v = getValue();
          return (
            <span className={`badge ${v ? "badge-green" : "badge-gray"}`}>
              {v ? "Aktiv" : "Inaktiv"}
            </span>
          );
        };
      } else if (f.lookupTable) {
        const tableMap = lookupMap[f.lookupTable] ?? {};
        col.cell = ({ getValue }) => {
          const v = getValue();
          if (v == null) return "";
          const label = tableMap[String(v)];
          return label != null ? label : String(v);
        };
      } else {
        col.cell = ({ getValue }) => {
          const v = getValue();
          return resolveI18n(v, lang);
        };
      }

      return col;
    });
}

export function fieldsToFormFields(fields: EffectiveField[], lang = "de") {
  return fields
    .filter((f) => f.isVisible !== false)
    .map((f) => ({
      name: f.fieldName,
      label: f.label?.[lang] ?? f.label?.["de"] ?? f.fieldName,
      type: f.fieldType === "boolean" ? "checkbox" : "text",
      required: f.isRequired ?? false,
    }));
}
