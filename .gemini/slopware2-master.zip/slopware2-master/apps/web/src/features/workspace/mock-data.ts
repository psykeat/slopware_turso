export const mockEntities = [
  { id: "1", name: "Customers", label: "Customers", fields: ["name", "email", "phone"] },
  { id: "2", name: "Products", label: "Products", fields: ["sku", "name", "price"] },
  { id: "3", name: "Orders", label: "Orders", fields: ["orderNumber", "customerId", "total"] },
];

export const mockRecords = [
  { id: "1", entityId: "1", data: { name: "Acme Corp", email: "info@acme.com", phone: "+123456" } },
  {
    id: "2",
    entityId: "1",
    data: { name: "Globex", email: "contact@globex.com", phone: "+789012" },
  },
];
