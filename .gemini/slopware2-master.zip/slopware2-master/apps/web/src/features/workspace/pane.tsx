import type { OpenIntent } from "@repo/shared/workspace";

import type { Lang } from "./i18n";

export type PaneCtx = {
  t: (key: string) => string;
  lang: Lang;
  dispatchIntent: (intent: OpenIntent) => void;
  toast?: (message: string) => void;
};

export function Pane({ children }: { children: React.ReactNode }) {
  return (
    <div className="sw-pane flex-1 overflow-auto p-4">
      <div>{children}</div>
    </div>
  );
}
