import type { PanelState } from "@repo/shared/workspace";
import { Info } from "lucide-react";

import { DetailPanelAdapter } from "./components/panels/detail-panel-adapter";
import { DocumentListAdapter } from "./components/panels/document-list-adapter";
import { LinesPanelAdapter } from "./components/panels/lines-panel-adapter";
import { ListPanelAdapter } from "./components/panels/list-panel-adapter";
import type { Lang } from "./i18n";
import { t } from "./i18n";
import type { PaneCtx } from "./pane";
import { StatsKpiView } from "./views/stats/stats-kpi-view";
import type { DocTreeCategory } from "./views/tree-view";
import { TreeView } from "./views/tree-view";

export function FallbackPanel({
  type,
  entity,
  lang,
}: {
  type: string;
  entity: string;
  lang: Lang;
}) {
  return (
    <div className="sw-pane-empty flex flex-1 items-center justify-center">
      <div className="flex flex-col items-center gap-2">
        <div className="sw-pane-empty-icon">
          <Info size={32} />
        </div>
        <div style={{ fontSize: 12.5, color: "var(--sw-text-muted, #6b7280)" }}>
          {t("pane.empty.norenderer", lang).replace("{key}", `${type}:${entity}`)}
        </div>
      </div>
    </div>
  );
}

export function resolvePanelComponent(panel: PanelState, ctx: PaneCtx): React.ReactNode {
  const { type } = panel;
  const entity = "entity" in panel ? panel.entity : "";

  if (type === "kpi") {
    return <StatsKpiView />;
  }

  if (type === "tree") {
    return (
      <TreeView
        data={[] as DocTreeCategory[]}
        activeKey=""
        lang={ctx.lang}
        onPick={(item) => {
          ctx.dispatchIntent({
            action: "openRecord",
            entity: "document",
            id: item.key,
            targetSlot: "s2",
          });
        }}
      />
    );
  }

  if (type === "list") {
    return <ListPanelAdapter panel={panel as PanelState & { type: "list" }} ctx={ctx} />;
  }

  if (type === "detail") {
    return <DetailPanelAdapter panel={panel as PanelState & { type: "detail" }} ctx={ctx} />;
  }

  if (type === "lines") {
    return <LinesPanelAdapter panel={panel as PanelState & { type: "lines" }} ctx={ctx} />;
  }

  if (type === "document-list") {
    return (
      <DocumentListAdapter panel={panel as PanelState & { type: "document-list" }} ctx={ctx} />
    );
  }

  return <FallbackPanel type={type} entity={entity} lang={ctx.lang} />;
}
