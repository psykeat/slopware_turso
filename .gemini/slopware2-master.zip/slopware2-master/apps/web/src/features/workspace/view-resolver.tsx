import { Plus } from "lucide-react";
import React from "react";

import { EntityDataTable } from "./components/data-table/entity-data-table";
import type { WorkspaceViewDefinition } from "./view-registry";
import { VIEW_REGISTRY } from "./view-registry";
import { useWorkspaceContext } from "./workspace-context";

type ViewModule = { default: React.ComponentType };

const viewModules = import.meta.glob("./views/*/*-view.tsx", {
  eager: true,
}) as Record<string, ViewModule>;

// Build key → component map from glob
const customViewMap = new Map<string, React.ComponentType>();
for (const [path, mod] of Object.entries(viewModules)) {
  const parts = path.split("/");
  const dir = parts.at(-2)!;
  const filename = parts.at(-1)!;
  const base = filename.replace(/-view\.tsx$/, "");
  const suffix = base.slice(dir.length + 1);
  const key = `${dir}:${suffix}`;
  if (mod.default) customViewMap.set(key, mod.default);
}

// Startup assertion: every kind === "custom" entry must have a matching file
for (const entry of VIEW_REGISTRY) {
  if (entry.kind === "custom" && !customViewMap.has(entry.key)) {
    const [prefix, suffix] = entry.key.split(":");
    throw new Error(
      `[ViewResolver] Missing file for custom view "${entry.key}". ` +
        `Expected: views/${prefix}/${prefix}-${suffix}-view.tsx`,
    );
  }
}

function GenericView({ entry }: { entry: WorkspaceViewDefinition }) {
  const ctx = useWorkspaceContext();
  const entity = entry.entity!;
  const isAddress = entity === "address";
  const isArticle = entity === "article";
  const isDocument = entity === "document";

  return (
    <EntityDataTable
      entityName={entity}
      mode="paginated"
      selectedId={
        (isAddress
          ? ctx.selectedAddress?.address_id
          : isArticle
            ? ctx.selectedArticle?.article_id
            : isDocument
              ? ctx.selectedDocument?.document_id
              : null) as string | number | null | undefined
      }
      onRowClick={(r) => ctx.setSelected(entity, r as Record<string, unknown>)}
      onDragStart={
        isAddress
          ? (r) => ({
              entity: "address",
              id: (r as Record<string, unknown>)["address_id"],
              label:
                (r as Record<string, unknown>)["company_name"] ??
                (r as Record<string, unknown>)["last_name"],
            })
          : isArticle
            ? (r) => ({
                entity: "article",
                id: (r as Record<string, unknown>)["article_id"],
                label: (r as Record<string, unknown>)["name"],
                article_no: (r as Record<string, unknown>)["article_no"],
              })
            : isDocument
              ? (r) => ({
                  entity: "document",
                  id: (r as Record<string, unknown>)["document_id"],
                  label: (r as Record<string, unknown>)["document_no"],
                })
              : undefined
      }
      renderHeaderActions={
        isDocument
          ? () => (
              <button
                className="btn btn-primary btn-xs"
                onClick={() => ctx.setSelected("document", { document_id: "__new__" })}
              >
                <Plus size={11} style={{ marginRight: 4 }} />
                {ctx.t("doc.header.new")}
              </button>
            )
          : undefined
      }
      t={ctx.t}
    />
  );
}

export function resolveView(key: string): React.ReactNode {
  const entry = VIEW_REGISTRY.find((e) => e.key === key);
  if (!entry) return null;

  if (entry.kind === "generic") {
    return <GenericView entry={entry} />;
  }

  const Component = customViewMap.get(key);
  if (!Component) return null;
  return <Component />;
}
