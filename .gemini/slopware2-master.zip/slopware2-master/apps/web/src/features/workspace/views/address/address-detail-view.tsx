import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";

import { getAddressStatsFn } from "../../../../server/server-functions";
import type { AddressStats } from "../../../../server/server-functions";
import { t, type Lang } from "../../i18n";
import { useWorkspaceContext } from "../../workspace-context";

type TabKey = "stats" | "openitems" | "movements" | "documents";

function fmtCur(n: number): string {
  return n.toLocaleString("de-DE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function DataTabs({ addressId, isCustomer }: { addressId: string; isCustomer: boolean }) {
  const { lang, setSelected } = useWorkspaceContext();
  const lng = lang as Lang;
  const [activeTab, setActiveTab] = useState<TabKey>("stats");

  const { data, isLoading } = useQuery({
    queryKey: ["addressStats", addressId],
    queryFn: () => getAddressStatsFn({ data: { addressId } }),
    enabled: isCustomer,
  });

  useEffect(() => {
    if (data?.documents?.[0]) {
      setSelected("document", {
        document_id: data.documents[0].documentId,
        document_no: data.documents[0].documentNo,
      });
    }
  }, [data?.documents, setSelected]);

  if (!isCustomer) return null;

  const tabs: { key: TabKey; label: string }[] = [
    { key: "stats", label: t("addr.tab.stats", lng) },
    { key: "openitems", label: t("addr.tab.openitems", lng) },
    { key: "movements", label: t("addr.tab.movements", lng) },
    { key: "documents", label: t("addr.tab.documents", lng) },
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div style={{ color: "var(--sw-text-muted)", fontSize: 13 }}>
          {t("addr.tab.loading", lng)}
        </div>
      </div>
    );
  }

  const stats = data as AddressStats | undefined;

  return (
    <div className="mt-4">
      <div className="tab-bar">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            className={`tab-btn ${activeTab === tab.key ? "tab-btn-active" : ""}`}
            onClick={() => setActiveTab(tab.key)}
          >
            {tab.label}
          </button>
        ))}
      </div>
      <div className="tab-content">
        {activeTab === "stats" && <StatsTab data={stats?.stats ?? []} lng={lng} />}
        {activeTab === "openitems" && <OpenItemsTab data={stats?.openItems ?? []} lng={lng} />}
        {activeTab === "movements" && <MovementsTab data={stats?.movements ?? []} lng={lng} />}
        {activeTab === "documents" && <DocumentsTab data={stats?.documents ?? []} lng={lng} />}
      </div>
    </div>
  );
}

function StatsTab({ data, lng }: { data: AddressStats["stats"]; lng: Lang }) {
  if (!data.length) {
    return (
      <div className="flex items-center justify-center py-8">
        <div style={{ color: "var(--sw-text-muted)", fontSize: 13 }}>
          {t("addr.stats.empty", lng)}
        </div>
      </div>
    );
  }
  const maxVal = Math.max(...data.map((r) => Math.max(r.totalAmountNet, r.totalProfit)), 1);

  return (
    <div>
      <div className="mb-2 flex gap-3 text-xs" style={{ color: "var(--sw-text-muted)" }}>
        <span className="flex items-center gap-1">
          <span
            className="inline-block h-2 w-2 rounded-sm"
            style={{ background: "var(--sw-accent)" }}
          />
          {t("period.umsatz", lng)}
        </span>
        <span className="flex items-center gap-1">
          <span
            className="inline-block h-2 w-2 rounded-sm"
            style={{ background: "var(--sw-accent-dark, #1d4ed8)" }}
          />
          {t("period.rohertrag", lng)}
        </span>
      </div>
      <div className="flex items-end gap-0.5" style={{ height: 120 }}>
        {data.slice(0, 24).map((r, i) => {
          const hNet = (r.totalAmountNet / maxVal) * 100;
          const hProfit = (r.totalProfit / maxVal) * 100;
          return (
            <div key={i} className="flex flex-1 items-end gap-px" style={{ height: 110 }}>
              <div
                className="w-full rounded-t"
                style={{ height: `${hNet}%`, background: "var(--sw-accent)" }}
                title={`${t("period.umsatz", lng)}: ${fmtCur(r.totalAmountNet)}`}
              />
              <div
                className="w-full rounded-t"
                style={{ height: `${hProfit}%`, background: "var(--sw-accent-dark, #1d4ed8)" }}
                title={`${t("period.rohertrag", lng)}: ${fmtCur(r.totalProfit)}`}
              />
            </div>
          );
        })}
      </div>
      <table className="mt-3 w-full border-collapse text-xs">
        <thead>
          <tr>
            <th
              className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
              style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
            >
              {t("period.period", lng)}
            </th>
            <th
              className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
              style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
            >
              {t("period.umsatz", lng)}
            </th>
            <th
              className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
              style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
            >
              {t("period.rohertrag", lng)}
            </th>
          </tr>
        </thead>
        <tbody>
          {data.map((r, i) => (
            <tr key={i}>
              <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
                {r.fiscalYear}-{String(r.periodNo).padStart(2, "0")}
              </td>
              <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
                {fmtCur(r.totalAmountNet)}
              </td>
              <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
                {fmtCur(r.totalProfit)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function OpenItemsTab({ data, lng }: { data: AddressStats["openItems"]; lng: Lang }) {
  const { setSelected } = useWorkspaceContext();
  if (!data.length) {
    return (
      <div className="flex flex-col items-center justify-center py-8">
        <div style={{ color: "var(--sw-accent)", fontSize: 13, fontWeight: 600 }}>
          {t("addr.openitems.none", lng)}
        </div>
        <div style={{ color: "var(--sw-text-muted)", fontSize: 12, marginTop: 4 }}>
          {t("addr.openitems.hint", lng)}
        </div>
      </div>
    );
  }
  return (
    <table className="w-full border-collapse text-xs">
      <thead>
        <tr>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("addr.col.docno", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("addr.col.type", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("addr.col.date", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("addr.col.duedate", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("addr.col.gross", lng)}
          </th>
        </tr>
      </thead>
      <tbody>
        {data.map((r) => (
          <tr
            key={r.documentId}
            className="cursor-pointer transition-colors hover:bg-[var(--sw-accent-muted)]"
            onClick={() =>
              setSelected("document", { document_id: r.documentId, document_no: r.documentNo })
            }
          >
            <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
              {r.documentNo}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1">{r.documentType}</td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
              {r.documentDate}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
              {r.dueDate ?? "—"}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
              {fmtCur(r.totalGross)}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function MovementsTab({ data, lng }: { data: AddressStats["movements"]; lng: Lang }) {
  if (!data.length) {
    return (
      <div className="flex items-center justify-center py-8">
        <div style={{ color: "var(--sw-text-muted)", fontSize: 13 }}>
          {t("addr.movements.empty", lng)}
        </div>
      </div>
    );
  }
  return (
    <table className="w-full border-collapse text-xs">
      <thead>
        <tr>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("addr.col.date", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("addr.col.docno", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("addr.col.article", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("addr.col.qty", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("addr.col.price", lng)}
          </th>
        </tr>
      </thead>
      <tbody>
        {data.slice(0, 100).map((r, i) => (
          <tr key={i}>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
              {r.documentDate}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
              {r.documentNo}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1">{r.articleNo}</td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
              {r.quantity}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
              {fmtCur(r.netPrice)}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function DocumentsTab({ data, lng }: { data: AddressStats["documents"]; lng: Lang }) {
  const { setSelected } = useWorkspaceContext();
  if (!data.length) {
    return (
      <div className="flex items-center justify-center py-8">
        <div style={{ color: "var(--sw-text-muted)", fontSize: 13 }}>
          {t("addr.documents.empty", lng)}
        </div>
      </div>
    );
  }
  const statusClass = (s: string) => {
    if (s === "posted") return "badge-green";
    if (s === "draft") return "badge-blue";
    if (s === "cancelled") return "badge-red";
    return "badge-orange";
  };
  return (
    <table className="w-full border-collapse text-xs">
      <thead>
        <tr>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("addr.col.date", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("addr.col.docno", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("addr.col.type", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("addr.col.status", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("addr.col.gross", lng)}
          </th>
        </tr>
      </thead>
      <tbody>
        {data.slice(0, 100).map((r) => (
          <tr
            key={r.documentId}
            className="cursor-pointer transition-colors hover:bg-[var(--sw-accent-muted)]"
            onClick={() =>
              setSelected("document", { document_id: r.documentId, document_no: r.documentNo })
            }
          >
            <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
              {r.documentDate}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
              {r.documentNo}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1">{r.documentType}</td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1">
              <span className={`badge ${statusClass(r.status)}`}>{r.status}</span>
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
              {fmtCur(r.totalGross)}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default function AddressDetailView() {
  const { selectedAddress: addr, t } = useWorkspaceContext();
  if (!addr) {
    return (
      <div className="pane-empty">
        <div className="pane-empty-text">{t("addr.empty")}</div>
      </div>
    );
  }
  const addressId = String(addr.address_id ?? "");
  const isCustomer = Boolean(addr.is_customer);
  const status = String(addr.status ?? "—");
  const statusClass =
    status === "active" ? "badge-green" : status === "lead" ? "badge-blue" : "badge-orange";

  return (
    <div className="detail-view">
      <div className="detail-header">
        <div>
          <div className="detail-title">{String(addr.company_name ?? addr.last_name ?? "—")}</div>
          <div className="detail-subtitle">{String(addr.city ?? "—")}</div>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          <span className={`badge ${statusClass}`}>{status}</span>
          <button className="btn btn-secondary btn-xs">{t("detail.edit")}</button>
          <button className="btn btn-primary btn-xs">{t("detail.create.doc")}</button>
        </div>
      </div>
      <div className="section-heading">{t("addr.section.master")}</div>
      <div className="detail-grid">
        <div>
          <div className="detail-field-label">{t("addr.field.nr")}</div>
          <div className="detail-field-value mono">{String(addr.address_no ?? "—")}</div>
        </div>
        <div>
          <div className="detail-field-label">{t("addr.field.type")}</div>
          <div className="detail-field-value">{String(addr.address_type ?? "—")}</div>
        </div>
        <div>
          <div className="detail-field-label">{t("addr.field.name1")}</div>
          <div className="detail-field-value">{String(addr.first_name ?? "—")}</div>
        </div>
        <div>
          <div className="detail-field-label">{t("addr.field.name2")}</div>
          <div className="detail-field-value">{String(addr.last_name ?? "—")}</div>
        </div>
        <div style={{ gridColumn: "span 2" }}>
          <div className="detail-field-label">{t("addr.field.street")}</div>
          <div className="detail-field-value">{String(addr.address_line_1 ?? "—")}</div>
        </div>
        <div style={{ gridColumn: "span 2" }}>
          <div className="detail-field-label">{t("addr.field.street2")}</div>
          <div className="detail-field-value">{String(addr.address_line_2 ?? "—")}</div>
        </div>
        <div>
          <div className="detail-field-label">{t("addr.field.plzort")}</div>
          <div className="detail-field-value">
            {String(addr.postal_code ?? "")} {String(addr.city ?? "")}
          </div>
        </div>
        <div>
          <div className="detail-field-label">{t("addr.field.country")}</div>
          <div className="detail-field-value">{String(addr.country_code ?? "—")}</div>
        </div>
        <div>
          <div className="detail-field-label">{t("addr.field.vatid")}</div>
          <div className="detail-field-value">{String(addr.vat_id ?? "—")}</div>
        </div>
        <div>
          <div className="detail-field-label">{t("addr.field.contact")}</div>
          <div className="detail-field-value">{String(addr.email ?? "—")}</div>
        </div>
      </div>
      <DataTabs addressId={addressId} isCustomer={isCustomer} />
    </div>
  );
}
