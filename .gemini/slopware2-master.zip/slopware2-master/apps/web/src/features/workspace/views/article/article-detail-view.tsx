import { useQuery } from "@tanstack/react-query";
import { useState } from "react";

import { getArticleStatsFn } from "../../../../server/server-functions";
import type { ArticleStats } from "../../../../server/server-functions";
import { t, type Lang } from "../../i18n";
import { useWorkspaceContext } from "../../workspace-context";

type TabKey = "stats" | "journal" | "movements" | "documents";

function fmtCur(n: number): string {
  return n.toLocaleString("de-DE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function fmtQty(n: number): string {
  return n.toLocaleString("de-DE", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

function DataTabs({ articleId }: { articleId: string }) {
  const { lang } = useWorkspaceContext();
  const lng = lang as Lang;
  const [activeTab, setActiveTab] = useState<TabKey>("stats");
  const [warehouseId, setWarehouseId] = useState<string>("");

  const { data, isLoading } = useQuery({
    queryKey: ["articleStats", articleId, warehouseId],
    queryFn: () =>
      getArticleStatsFn({ data: { articleId, warehouseId: warehouseId || undefined } }),
  });

  const tabs: { key: TabKey; label: string }[] = [
    { key: "stats", label: t("art.tab.stats", lng) },
    { key: "journal", label: t("art.tab.journal", lng) },
    { key: "movements", label: t("art.tab.movements", lng) },
    { key: "documents", label: t("art.tab.documents", lng) },
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div style={{ color: "var(--sw-text-muted)", fontSize: 13 }}>
          {t("art.tab.loading", lng)}
        </div>
      </div>
    );
  }

  const stats = data as ArticleStats | undefined;

  return (
    <div className="mt-4">
      <div className="tab-bar">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            className={`tab-btn ${activeTab === tab.key ? "tab-btn-active" : ""}`}
            onClick={() => setActiveTab(tab.key)}
          >
            {tab.label}
          </button>
        ))}
      </div>
      <div className="tab-content">
        {activeTab === "stats" && <StatsTab data={stats?.stats ?? []} lng={lng} />}
        {activeTab === "journal" && (
          <JournalTab
            data={stats?.stockJournal ?? []}
            lng={lng}
            warehouseId={warehouseId}
            onWarehouseChange={setWarehouseId}
            reservedQty={stats?.reservedQty ?? 0}
            expectedPurchaseQty={stats?.expectedPurchaseQty ?? 0}
          />
        )}
        {activeTab === "movements" && <MovementsTab data={stats?.movements ?? []} lng={lng} />}
        {activeTab === "documents" && <DocumentsTab data={stats?.documents ?? []} lng={lng} />}
      </div>
    </div>
  );
}

function StatsTab({ data, lng }: { data: ArticleStats["stats"]; lng: Lang }) {
  if (!data.length) {
    return (
      <div className="flex items-center justify-center py-8">
        <div style={{ color: "var(--sw-text-muted)", fontSize: 13 }}>
          {t("art.stats.empty", lng)}
        </div>
      </div>
    );
  }
  const maxVal = Math.max(...data.map((r) => Math.max(r.totalAmountNet, r.totalProfit)), 1);

  return (
    <div>
      <div className="mb-2 flex gap-3 text-xs" style={{ color: "var(--sw-text-muted)" }}>
        <span className="flex items-center gap-1">
          <span
            className="inline-block h-2 w-2 rounded-sm"
            style={{ background: "var(--sw-accent)" }}
          />
          {t("period.umsatz", lng)}
        </span>
        <span className="flex items-center gap-1">
          <span
            className="inline-block h-2 w-2 rounded-sm"
            style={{ background: "var(--sw-accent-dark, #1d4ed8)" }}
          />
          {t("period.rohertrag", lng)}
        </span>
      </div>
      <div className="flex items-end gap-0.5" style={{ height: 120 }}>
        {data.slice(0, 24).map((r, i) => {
          const hNet = (r.totalAmountNet / maxVal) * 100;
          const hProfit = (r.totalProfit / maxVal) * 100;
          return (
            <div key={i} className="flex flex-1 items-end gap-px" style={{ height: 110 }}>
              <div
                className="w-full rounded-t"
                style={{ height: `${hNet}%`, background: "var(--sw-accent)" }}
                title={`${t("period.umsatz", lng)}: ${fmtCur(r.totalAmountNet)}`}
              />
              <div
                className="w-full rounded-t"
                style={{ height: `${hProfit}%`, background: "var(--sw-accent-dark, #1d4ed8)" }}
                title={`${t("period.rohertrag", lng)}: ${fmtCur(r.totalProfit)}`}
              />
            </div>
          );
        })}
      </div>
      <table className="mt-3 w-full border-collapse text-xs">
        <thead>
          <tr>
            <th
              className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
              style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
            >
              {t("period.period", lng)}
            </th>
            <th
              className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
              style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
            >
              {t("art.col.qty", lng)}
            </th>
            <th
              className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
              style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
            >
              {t("period.umsatz", lng)}
            </th>
            <th
              className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
              style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
            >
              {t("period.rohertrag", lng)}
            </th>
            <th
              className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
              style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
            >
              {t("kpi.einkauf", lng)}
            </th>
          </tr>
        </thead>
        <tbody>
          {data.map((r, i) => (
            <tr key={i}>
              <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
                {r.fiscalYear}-{String(r.periodNo).padStart(2, "0")}
              </td>
              <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
                {fmtQty(r.totalQty)}
              </td>
              <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
                {fmtCur(r.totalAmountNet)}
              </td>
              <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
                {fmtCur(r.totalProfit)}
              </td>
              <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
                {fmtQty(r.purchaseQty)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function JournalTab({
  data,
  lng,
  warehouseId,
  onWarehouseChange,
  reservedQty,
  expectedPurchaseQty,
}: {
  data: ArticleStats["stockJournal"];
  lng: Lang;
  warehouseId: string;
  onWarehouseChange: (id: string) => void;
  reservedQty: number;
  expectedPurchaseQty: number;
}) {
  const warehouses = [...new Set(data.map((r) => r.warehouseId))];

  return (
    <div>
      <div className="mb-2 flex items-center gap-2">
        <button
          className={`btn btn-xs ${!warehouseId ? "btn-primary" : "btn-secondary"}`}
          onClick={() => onWarehouseChange("")}
        >
          {t("art.journal.wh.all", lng)}
        </button>
        {warehouses.map((wh) => (
          <button
            key={wh}
            className={`btn btn-xs ${warehouseId === wh ? "btn-primary" : "btn-secondary"}`}
            onClick={() => onWarehouseChange(wh)}
          >
            {data.find((r) => r.warehouseId === wh)?.warehouseName ?? wh.slice(0, 8)}
          </button>
        ))}
      </div>
      {data.length === 0 ? (
        <div className="flex items-center justify-center py-8">
          <div style={{ color: "var(--sw-text-muted)", fontSize: 13 }}>
            {t("art.journal.empty", lng)}
          </div>
        </div>
      ) : (
        <div style={{ maxHeight: 320, overflowY: "auto" }}>
          <table className="w-full border-collapse text-xs">
            <thead className="sticky top-0">
              <tr>
                <th
                  className="border-b border-[var(--sw-border)] bg-[var(--sw-bg)] px-2 py-1 text-left font-medium"
                  style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
                >
                  {t("art.col.date", lng)}
                </th>
                <th
                  className="border-b border-[var(--sw-border)] bg-[var(--sw-bg)] px-2 py-1 text-left font-medium"
                  style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
                >
                  {t("art.journal.type", lng)}
                </th>
                <th
                  className="border-b border-[var(--sw-border)] bg-[var(--sw-bg)] px-2 py-1 text-left font-medium"
                  style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
                >
                  {t("art.journal.wh", lng)}
                </th>
                <th
                  className="border-b border-[var(--sw-border)] bg-[var(--sw-bg)] px-2 py-1 text-right font-medium"
                  style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
                >
                  {t("art.journal.qty", lng)}
                </th>
                <th
                  className="border-b border-[var(--sw-border)] bg-[var(--sw-bg)] px-2 py-1 text-right font-medium"
                  style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
                >
                  {t("art.journal.running", lng)}
                </th>
              </tr>
            </thead>
            <tbody>
              {data.slice(0, 200).map((r, i) => (
                <tr key={i}>
                  <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
                    {r.movementDate}
                  </td>
                  <td className="border-b border-[var(--sw-border)] px-2 py-1">{r.movementType}</td>
                  <td className="border-b border-[var(--sw-border)] px-2 py-1">
                    {r.warehouseName}
                  </td>
                  <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
                    {fmtQty(r.qtyDelta)}
                  </td>
                  <td
                    className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono"
                    style={{ fontWeight: 600 }}
                  >
                    {fmtQty(r.runningBalance)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div
            className="sticky bottom-0 border-t-2 border-[var(--sw-accent)] px-2 py-1 text-xs"
            style={{ background: "var(--sw-bg-card, var(--sw-bg))", fontSize: 11 }}
          >
            <span>
              {t("art.journal.footer.reserved", lng)}: {fmtQty(reservedQty)}
            </span>
            <span className="mx-2">|</span>
            <span>
              {t("art.journal.footer.expected", lng)}: {fmtQty(expectedPurchaseQty)}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

function MovementsTab({ data, lng }: { data: ArticleStats["movements"]; lng: Lang }) {
  if (!data.length) {
    return (
      <div className="flex items-center justify-center py-8">
        <div style={{ color: "var(--sw-text-muted)", fontSize: 13 }}>
          {t("art.movements.empty", lng)}
        </div>
      </div>
    );
  }
  return (
    <table className="w-full border-collapse text-xs">
      <thead>
        <tr>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.date", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.docno", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.article", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.qty", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.price", lng)}
          </th>
        </tr>
      </thead>
      <tbody>
        {data.slice(0, 100).map((r, i) => (
          <tr key={i}>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
              {r.documentDate}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
              {r.documentNo}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1">{r.articleNo}</td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
              {r.quantity}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
              {fmtCur(r.netPrice)}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function DocumentsTab({ data, lng }: { data: ArticleStats["documents"]; lng: Lang }) {
  if (!data.length) {
    return (
      <div className="flex items-center justify-center py-8">
        <div style={{ color: "var(--sw-text-muted)", fontSize: 13 }}>
          {t("art.documents.empty", lng)}
        </div>
      </div>
    );
  }
  const statusClass = (s: string) => {
    if (s === "posted") return "badge-green";
    if (s === "draft") return "badge-blue";
    if (s === "cancelled") return "badge-red";
    return "badge-orange";
  };
  return (
    <table className="w-full border-collapse text-xs">
      <thead>
        <tr>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.date", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.docno", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.type", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.status", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.gross", lng)}
          </th>
        </tr>
      </thead>
      <tbody>
        {data.slice(0, 100).map((r) => (
          <tr key={r.documentId}>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
              {r.documentDate}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
              {r.documentNo}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1">{r.documentType}</td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1">
              <span className={`badge ${statusClass(r.status)}`}>{r.status}</span>
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
              {fmtCur(r.totalGross)}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default function ArticleDetailView() {
  const { selectedArticle: art } = useWorkspaceContext();
  if (!art) {
    return (
      <div className="pane-empty">
        <div className="pane-empty-text">{t("art.empty")}</div>
      </div>
    );
  }
  const articleId = String(art.article_id ?? "");
  const isActive = Boolean(art.is_active);
  const status = isActive ? "active" : "inactive";
  const statusClass = status === "active" ? "badge-green" : "badge-orange";

  return (
    <div className="detail-view">
      <div className="detail-header">
        <div>
          <div className="detail-title">{String(art.name ?? "—")}</div>
          <div className="detail-subtitle">{String(art.description ?? "—")}</div>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          <span className={`badge ${statusClass}`}>{status}</span>
          <button className="btn btn-secondary btn-xs">{t("detail.edit")}</button>
        </div>
      </div>
      <div className="section-heading">{t("art.section.master")}</div>
      <div className="detail-grid">
        <div>
          <div className="detail-field-label">{t("art.field.nr")}</div>
          <div className="detail-field-value mono">{String(art.article_no ?? "—")}</div>
        </div>
        <div>
          <div className="detail-field-label">{t("art.field.group")}</div>
          <div className="detail-field-value">{String(art.article_group ?? "—")}</div>
        </div>
        <div>
          <div className="detail-field-label">{t("art.field.unit")}</div>
          <div className="detail-field-value">{String(art.base_unit ?? "—")}</div>
        </div>
        <div>
          <div className="detail-field-label">{t("art.field.tracking")}</div>
          <div className="detail-field-value">{String(art.tracking_mode ?? "—")}</div>
        </div>
        <div>
          <div className="detail-field-label">{t("art.field.bom")}</div>
          <div className="detail-field-value">{String(art.bom_type ?? "—")}</div>
        </div>
      </div>
      <DataTabs articleId={articleId} />
    </div>
  );
}
