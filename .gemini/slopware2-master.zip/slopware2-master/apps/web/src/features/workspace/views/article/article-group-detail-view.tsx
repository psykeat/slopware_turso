import { useQuery } from "@tanstack/react-query";
import { useState } from "react";

import { getArticleGroupStatsFn } from "../../../../server/server-functions";
import type { ArticleGroupStats } from "../../../../server/server-functions";
import { t, type Lang } from "../../i18n";
import { useWorkspaceContext } from "../../workspace-context";

type TabKey = "stats" | "movements" | "documents";

function fmtCur(n: number): string {
  return n.toLocaleString("de-DE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function fmtQty(n: number): string {
  return n.toLocaleString("de-DE", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

function DataTabs({ groupId }: { groupId: string }) {
  const { lang } = useWorkspaceContext();
  const lng = lang as Lang;
  const [activeTab, setActiveTab] = useState<TabKey>("stats");

  const { data, isLoading } = useQuery({
    queryKey: ["articleGroupStats", groupId],
    queryFn: () => getArticleGroupStatsFn({ data: { articleGroupId: groupId } }),
  });

  const tabs: { key: TabKey; label: string }[] = [
    { key: "stats", label: t("ag.tab.stats", lng) },
    { key: "movements", label: t("ag.tab.movements", lng) },
    { key: "documents", label: t("ag.tab.documents", lng) },
  ];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div style={{ color: "var(--sw-text-muted)", fontSize: 13 }}>
          {t("ag.tab.loading", lng)}
        </div>
      </div>
    );
  }

  const stats = data as ArticleGroupStats | undefined;

  return (
    <div className="mt-4">
      <div className="tab-bar">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            className={`tab-btn ${activeTab === tab.key ? "tab-btn-active" : ""}`}
            onClick={() => setActiveTab(tab.key)}
          >
            {tab.label}
          </button>
        ))}
      </div>
      <div className="tab-content">
        {activeTab === "stats" && <StatsTab data={stats?.stats ?? []} lng={lng} />}
        {activeTab === "movements" && <MovementsTab data={stats?.movements ?? []} lng={lng} />}
        {activeTab === "documents" && <DocumentsTab data={stats?.documents ?? []} lng={lng} />}
      </div>
    </div>
  );
}

function StatsTab({ data, lng }: { data: ArticleGroupStats["stats"]; lng: Lang }) {
  if (!data.length) {
    return (
      <div className="flex items-center justify-center py-8">
        <div style={{ color: "var(--sw-text-muted)", fontSize: 13 }}>
          {t("ag.stats.empty", lng)}
        </div>
      </div>
    );
  }
  const maxVal = Math.max(...data.map((r) => Math.max(r.totalAmountNet, r.totalProfit)), 1);

  return (
    <div>
      <div className="mb-2 flex gap-3 text-xs" style={{ color: "var(--sw-text-muted)" }}>
        <span className="flex items-center gap-1">
          <span
            className="inline-block h-2 w-2 rounded-sm"
            style={{ background: "var(--sw-accent)" }}
          />
          {t("period.umsatz", lng)}
        </span>
        <span className="flex items-center gap-1">
          <span
            className="inline-block h-2 w-2 rounded-sm"
            style={{ background: "var(--sw-accent-dark, #1d4ed8)" }}
          />
          {t("period.rohertrag", lng)}
        </span>
      </div>
      <div className="flex items-end gap-0.5" style={{ height: 120 }}>
        {data.slice(0, 24).map((r, i) => {
          const hNet = (r.totalAmountNet / maxVal) * 100;
          const hProfit = (r.totalProfit / maxVal) * 100;
          return (
            <div key={i} className="flex flex-1 items-end gap-px" style={{ height: 110 }}>
              <div
                className="w-full rounded-t"
                style={{ height: `${hNet}%`, background: "var(--sw-accent)" }}
                title={`${t("period.umsatz", lng)}: ${fmtCur(r.totalAmountNet)}`}
              />
              <div
                className="w-full rounded-t"
                style={{ height: `${hProfit}%`, background: "var(--sw-accent-dark, #1d4ed8)" }}
                title={`${t("period.rohertrag", lng)}: ${fmtCur(r.totalProfit)}`}
              />
            </div>
          );
        })}
      </div>
      <table className="mt-3 w-full border-collapse text-xs">
        <thead>
          <tr>
            <th
              className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
              style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
            >
              {t("period.period", lng)}
            </th>
            <th
              className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
              style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
            >
              {t("art.col.qty", lng)}
            </th>
            <th
              className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
              style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
            >
              {t("period.umsatz", lng)}
            </th>
            <th
              className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
              style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
            >
              {t("period.rohertrag", lng)}
            </th>
            <th
              className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
              style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
            >
              {t("kpi.einkauf", lng)}
            </th>
          </tr>
        </thead>
        <tbody>
          {data.map((r, i) => (
            <tr key={i}>
              <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
                {r.fiscalYear}-{String(r.periodNo).padStart(2, "0")}
              </td>
              <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
                {fmtQty(r.totalQty)}
              </td>
              <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
                {fmtCur(r.totalAmountNet)}
              </td>
              <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
                {fmtCur(r.totalProfit)}
              </td>
              <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
                {fmtQty(r.purchaseQty)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function MovementsTab({ data, lng }: { data: ArticleGroupStats["movements"]; lng: Lang }) {
  if (!data.length) {
    return (
      <div className="flex items-center justify-center py-8">
        <div style={{ color: "var(--sw-text-muted)", fontSize: 13 }}>
          {t("ag.movements.empty", lng)}
        </div>
      </div>
    );
  }
  return (
    <table className="w-full border-collapse text-xs">
      <thead>
        <tr>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.date", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.docno", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.article", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.qty", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.price", lng)}
          </th>
        </tr>
      </thead>
      <tbody>
        {data.slice(0, 100).map((r, i) => (
          <tr key={i}>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
              {r.documentDate}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
              {r.documentNo}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1">{r.articleNo}</td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
              {r.quantity}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
              {fmtCur(r.netPrice)}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function DocumentsTab({ data, lng }: { data: ArticleGroupStats["documents"]; lng: Lang }) {
  if (!data.length) {
    return (
      <div className="flex items-center justify-center py-8">
        <div style={{ color: "var(--sw-text-muted)", fontSize: 13 }}>
          {t("ag.documents.empty", lng)}
        </div>
      </div>
    );
  }
  const statusClass = (s: string) => {
    if (s === "posted") return "badge-green";
    if (s === "draft") return "badge-blue";
    if (s === "cancelled") return "badge-red";
    return "badge-orange";
  };
  return (
    <table className="w-full border-collapse text-xs">
      <thead>
        <tr>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.date", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.docno", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.type", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.status", lng)}
          </th>
          <th
            className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
            style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
          >
            {t("art.col.gross", lng)}
          </th>
        </tr>
      </thead>
      <tbody>
        {data.slice(0, 100).map((r) => (
          <tr key={r.documentId}>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
              {r.documentDate}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">
              {r.documentNo}
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1">{r.documentType}</td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1">
              <span className={`badge ${statusClass(r.status)}`}>{r.status}</span>
            </td>
            <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
              {fmtCur(r.totalGross)}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default function ArticleGroupDetailView() {
  const { selectedArticleGroup: grp, lang } = useWorkspaceContext();
  const lng = lang as Lang;
  if (!grp) {
    return (
      <div className="pane-empty">
        <div className="pane-empty-text">{t("ag.empty")}</div>
      </div>
    );
  }
  const groupId = String(grp.article_group_id ?? "");
  const isActive = Boolean(grp.is_active);
  const status = isActive ? "active" : "inactive";
  const statusClass = status === "active" ? "badge-green" : "badge-orange";

  return (
    <div className="detail-view">
      <div className="detail-header">
        <div>
          <div className="detail-title">{String(grp.name ?? "—")}</div>
          <div className="detail-subtitle">{String(grp.description ?? "—")}</div>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          <span className={`badge ${statusClass}`}>{status}</span>
          <button className="btn btn-secondary btn-xs">{t("detail.edit")}</button>
        </div>
      </div>
      <div className="section-heading">{t("ag.section.master", lng)}</div>
      <div className="detail-grid">
        <div>
          <div className="detail-field-label">{t("ag.field.nr")}</div>
          <div className="detail-field-value mono">{String(grp.article_group_no ?? "—")}</div>
        </div>
        <div>
          <div className="detail-field-label">{t("ag.field.name")}</div>
          <div className="detail-field-value">{String(grp.name ?? "—")}</div>
        </div>
      </div>
      <DataTabs groupId={groupId} />
    </div>
  );
}
