import { useQuery } from "@tanstack/react-query";
import { Search, Package, Info, Plus } from "lucide-react";
import { useEffect, useRef, useState } from "react";

import { listEntityFn } from "~/server/server-functions";

import { useWorkspaceContext } from "../../workspace-context";

export default function ArticleLookupView() {
  const { lang, t } = useWorkspaceContext();
  const [search, setSearch] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-focus on mount
  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const { data, isLoading } = useQuery({
    queryKey: ["article-lookup", search],
    queryFn: () =>
      listEntityFn({
        data: {
          entityName: "article",
          options: {
            searchQuery: search || undefined,
            limit: 50,
            sortBy: "article_no",
          },
        },
      }),
  });

  const articles = (data?.items as any[]) ?? [];

  return (
    <div className="flex h-full flex-col bg-gray-50/30">
      <div className="border-b bg-white p-4 shadow-sm">
        <div className="relative">
          <Search className="absolute top-1/2 left-3 -translate-y-1/2 text-gray-400" size={16} />
          <input
            ref={inputRef}
            type="text"
            className="sw-input h-10 w-full pl-10 text-sm"
            placeholder={t("list.search")}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="mt-2 flex items-center gap-1.5 text-[10px] text-gray-400">
          <Info size={12} />
          {lang === "de"
            ? "Artikel ziehen und in Belegpositionen ablegen"
            : "Drag articles and drop into document lines"}
        </div>
      </div>

      <div className="flex-1 overflow-auto p-2">
        {isLoading ? (
          <div className="p-8 text-center text-sm text-gray-400">{t("list.loading")}...</div>
        ) : articles.length === 0 ? (
          <div className="p-8 text-center text-sm text-gray-400">{t("noResults")}</div>
        ) : (
          <div className="flex flex-col gap-2">
            {articles.map((art) => (
              <ArticleLookupCard key={art.article_id} article={art} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ArticleLookupCard({ article }: { article: any }) {
  const handleDragStart = (e: React.DragEvent) => {
    e.dataTransfer.setData(
      "application/json",
      JSON.stringify({
        entity: "article",
        id: article.article_id,
        label: article.name,
        article_no: article.article_no,
      }),
    );
    e.dataTransfer.effectAllowed = "copy";
  };

  return (
    <div
      draggable
      onDragStart={handleDragStart}
      className="group cursor-grab rounded-md border bg-white p-3 shadow-sm transition-all hover:border-blue-400 hover:shadow-md active:cursor-grabbing"
    >
      <div className="mb-1 flex items-start justify-between">
        <span className="font-mono text-[10px] font-bold tracking-tight text-gray-400 uppercase">
          {article.article_no}
        </span>
        <span className="rounded border border-gray-100 px-1 text-[9px] text-gray-400 uppercase">
          {article.unit || "ST"}
        </span>
      </div>
      <div className="mb-3 text-[13px] leading-snug font-semibold text-gray-800">
        {article.name}
      </div>
      <div className="flex items-center justify-between text-[11px]">
        <div className="flex gap-4">
          <div className="flex flex-col">
            <span className="text-[9px] font-bold text-gray-300 uppercase">Price</span>
            <span className="font-mono font-medium text-gray-600">
              {article.base_price ? Number(article.base_price).toLocaleString() : "0.00"} €
            </span>
          </div>
          <div className="flex flex-col">
            <span className="text-[9px] font-bold text-gray-300 uppercase">Stock</span>
            <span className="flex items-center gap-1 font-mono font-medium text-green-600">
              <Package size={10} />
              {article.stock_on_hand ?? 0}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1 text-[9px] font-bold text-blue-500 uppercase opacity-0 transition-opacity group-hover:opacity-100">
          <Plus size={10} /> Drag to add
        </div>
      </div>
    </div>
  );
}
