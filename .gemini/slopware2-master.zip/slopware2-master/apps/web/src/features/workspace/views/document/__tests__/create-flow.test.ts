import { describe, it, expect } from "vitest";

describe("Create Flow — Story #5 + #7", () => {
  it("GenericView renders Neuer Beleg button for document entity", async () => {
    const src = await import("fs").then((m) =>
      m.default.readFileSync(import.meta.dirname + "/../../../view-resolver.tsx", "utf-8"),
    );
    expect(src).toContain("doc.header.new");
    expect(src).toContain("__new__");
    expect(src).toContain("setSelected");
    expect(src).toContain("Plus");
  });

  it("DocumentListAdapter has Neuer Beleg button in toolbar", async () => {
    const src = await import("fs").then((m) =>
      m.default.readFileSync(
        import.meta.dirname + "/../../../components/panels/document-list-adapter.tsx",
        "utf-8",
      ),
    );
    expect(src).toContain("Neuer Beleg");
    expect(src).toContain("__new__");
    expect(src).toContain("dispatchIntent");
  });

  it("DocumentHeaderForm invalidates document list query on success", async () => {
    const src = await import("fs").then((m) =>
      m.default.readFileSync(import.meta.dirname + "/../document-header-form.tsx", "utf-8"),
    );
    expect(src).toContain("invalidateQueries");
    expect(src).toContain("entity-list");
    expect(src).toContain("queryClient");
  });

  it("DocumentHeaderForm shows document number in success toast", async () => {
    const src = await import("fs").then((m) =>
      m.default.readFileSync(import.meta.dirname + "/../document-header-form.tsx", "utf-8"),
    );
    expect(src).toContain("documentNo");
    expect(src).toContain("save.success");
  });

  it("DocumentHeaderForm handles create error with toast", async () => {
    const src = await import("fs").then((m) =>
      m.default.readFileSync(import.meta.dirname + "/../document-header-form.tsx", "utf-8"),
    );
    expect(src).toContain("onError");
    expect(src).toContain("save.error");
  });

  it("DocumentHeaderForm passes documentNo to setSelected on success", async () => {
    const src = await import("fs").then((m) =>
      m.default.readFileSync(import.meta.dirname + "/../document-header-form.tsx", "utf-8"),
    );
    expect(src).toContain("document_no: result.documentNo");
    expect(src).toContain('status: "draft"');
  });

  it("DocumentDetailView delegates to DetailPanelAdapter for existing docs", async () => {
    const src = await import("fs").then((m) =>
      m.default.readFileSync(import.meta.dirname + "/../document-detail-view.tsx", "utf-8"),
    );
    expect(src).toContain("DetailPanelAdapter");
    expect(src).toContain('entity: "document"');
  });

  it("DocumentDetailView keeps new-doc flow via DocumentHeaderForm", async () => {
    const src = await import("fs").then((m) =>
      m.default.readFileSync(import.meta.dirname + "/../document-detail-view.tsx", "utf-8"),
    );
    expect(src).toContain("isNew");
    expect(src).toContain("DocumentHeaderForm");
  });
});
