import { describe, it, expect } from "vitest";

const readView = () =>
  import("fs").then((m) =>
    m.default.readFileSync(import.meta.dirname + "/../document-lines-view.tsx", "utf-8"),
  );

const readAdapter = () =>
  import("fs").then((m) =>
    m.default.readFileSync(
      import.meta.dirname + "/../../../components/panels/lines-panel-adapter.tsx",
      "utf-8",
    ),
  );

describe("DocumentLinesView exports", () => {
  it("exports DocumentLinesView as default", async () => {
    const mod = await import("../document-lines-view");
    expect(mod.default).toBeDefined();
    expect(typeof mod.default).toBe("function");
  });
});

describe("Thin-wrapper contract — document-lines-view.tsx", () => {
  it("uses LinesPanelAdapter (not custom table)", async () => {
    const src = await readView();
    expect(src).toContain("LinesPanelAdapter");
  });

  it("imports updateDocumentFn for save", async () => {
    const src = await readView();
    expect(src).toContain("updateDocumentFn");
  });

  it("fetches header document with getEntityFn for warehouse default", async () => {
    const src = await readView();
    expect(src).toContain("getEntityFn");
    expect(src).toContain('entityName: "document"');
  });

  it("passes onSave callback to LinesPanelAdapter", async () => {
    const src = await readView();
    expect(src).toContain("onSave=");
  });

  it("has save mutation with query invalidation", async () => {
    const src = await readView();
    expect(src).toContain("saveMutation");
    expect(src).toContain("invalidateQueries");
  });

  it("shows save success/error toast messages", async () => {
    const src = await readView();
    expect(src).toContain("doc.lines.save.success");
    expect(src).toContain("doc.lines.save.error");
  });
});

describe("LinesEditor UI — PRD Story #11", () => {
  it("includes all required table columns", async () => {
    const src = await readAdapter();
    expect(src).toContain("doc.lines.pos");
    expect(src).toContain("doc.lines.article");
    expect(src).toContain("doc.lines.qty");
    expect(src).toContain("doc.lines.unitprice");
    expect(src).toContain("doc.lines.taxrate");
    expect(src).toContain("doc.lines.linnet");
  });

  it("has inline quantity field (numeric input)", async () => {
    const src = await readAdapter();
    expect(src).toContain('type="number"');
    expect(src).toContain('"quantity"');
  });

  it("has inline net price field (numeric input)", async () => {
    const src = await readAdapter();
    expect(src).toContain('"net_price"');
  });

  it("stores lines in component state", async () => {
    const src = await readAdapter();
    expect(src).toContain("useState<DocLine[]>");
    expect(src).toContain("setLocalLines");
  });

  it("has add line handler", async () => {
    const src = await readAdapter();
    expect(src).toContain("handleAddLine");
    expect(src).toContain("doc.lines.add");
  });

  it("has add comment handler", async () => {
    const src = await readAdapter();
    expect(src).toContain("handleAddComment");
    expect(src).toContain("doc.lines.add.comment");
  });

  it("has delete line handler", async () => {
    const src = await readAdapter();
    expect(src).toContain("handleDeleteLine");
    expect(src).toContain("doc.lines.delete");
  });

  it("has confirm and cancel edit handlers", async () => {
    const src = await readAdapter();
    expect(src).toContain("handleConfirmEdit");
    expect(src).toContain("handleCancelEdit");
    expect(src).toContain("lines.confirm");
  });

  it("calculates line totals (netto, tax, gross)", async () => {
    const src = await readAdapter();
    expect(src).toContain("calcLineTotal");
    expect(src).toContain("calcTax");
    expect(src).toContain("totals.netto");
    expect(src).toContain("totals.tax");
    expect(src).toContain("totals.gross");
  });

  it("has totals footer with netto, tax, gross", async () => {
    const src = await readAdapter();
    expect(src).toContain("doc.lines.totals.netto");
    expect(src).toContain("doc.lines.totals.tax");
    expect(src).toContain("doc.lines.totals.gross");
  });

  it("has keyboard shortcuts (Enter confirm, Escape cancel)", async () => {
    const src = await readAdapter();
    expect(src).toContain('e.key === "Enter"');
    expect(src).toContain('e.key === "Escape"');
  });
});

describe("Article Autocomplete — PRD Story #15", () => {
  it("has article search input", async () => {
    const src = await readAdapter();
    expect(src).toContain("articleSearch");
    expect(src).toContain("handleArticleSearch");
    expect(src).toContain("doc.lines.searcharticle");
  });

  it("uses listEntityFn for article search with ILIKE", async () => {
    const src = await readAdapter();
    expect(src).toContain("listEntityFn");
    expect(src).toContain('operator: "ILIKE"');
    expect(src).toContain("article_no");
  });

  it("resolves pricing on article selection", async () => {
    const src = await readAdapter();
    expect(src).toContain("handleArticleSelect");
    expect(src).toContain("resolveArticlePricingFn");
    expect(src).toContain("pricingMutation");
  });

  it("shows dropdown with article options", async () => {
    const src = await readAdapter();
    expect(src).toContain("showDropdown");
    expect(src).toContain("articleOptions");
  });

  it("stores article text snapshot on selection", async () => {
    const src = await readAdapter();
    expect(src).toContain("article_text_snapshot");
    expect(src).toContain("article_no");
  });
});

describe("Price Auto-Fill — PRD Story #12", () => {
  it("calls resolveArticlePricing with articleId and addressId", async () => {
    const src = await readAdapter();
    expect(src).toContain("pricingMutation.mutate");
    expect(src).toContain("articleId:");
    expect(src).toContain("addressId:");
  });

  it("auto-fills net_price from pricing response", async () => {
    const src = await readAdapter();
    expect(src).toContain("pricing.netPrice");
    expect(src).toContain("net_price:");
  });

  it("only resolves pricing when addressId and documentDate are available", async () => {
    const src = await readAdapter();
    expect(src).toContain("addressId && documentDate");
  });
});

describe("Tax Auto-Fill — PRD Story #13", () => {
  it("auto-fills tax_code_id from pricing response", async () => {
    const src = await readAdapter();
    expect(src).toContain("pricing.taxCodeId");
    expect(src).toContain("tax_code_id:");
  });

  it("resolves tax rate from tax_code_id via taxRateMap", async () => {
    const src = await readAdapter();
    expect(src).toContain("taxRateMap");
    expect(src).toContain("tax_code_id");
  });
});

describe("Live Calculation — PRD Story #14", () => {
  it("calculates line total in real-time per row", async () => {
    const src = await readAdapter();
    expect(src).toContain("calcLineTotal");
    expect(src).toContain("Number(l.quantity)");
    expect(src).toContain("Number(l.net_price)");
  });

  it("shows net total, tax amount, and gross total in footer", async () => {
    const src = await readAdapter();
    expect(src).toContain("totals.netto");
    expect(src).toContain("totals.tax");
    expect(src).toContain("totals.gross");
    expect(src).toContain("doc.lines.totals.netto");
    expect(src).toContain("doc.lines.totals.tax");
    expect(src).toContain("doc.lines.totals.gross");
  });

  it("skips comment lines in total calculation", async () => {
    const src = await readAdapter();
    expect(src).toContain('l.line_type === "comment"');
  });

  it("uses useMemo for totals (efficient recalculation)", async () => {
    const src = await readAdapter();
    expect(src).toContain("useMemo");
    expect(src).toContain("const totals");
  });
});

describe("Warehouse Per Line — PRD Story #16", () => {
  it("includes warehouse_id in DocLine interface", async () => {
    const src = await readAdapter();
    expect(src).toContain("warehouse_id: string | null");
  });

  it("accepts headerWarehouseId prop", async () => {
    const src = await readAdapter();
    expect(src).toContain("headerWarehouseId");
  });

  it("fetches header document for warehouse default (view layer)", async () => {
    const src = await readView();
    expect(src).toContain("getEntityFn");
    expect(src).toContain('entityName: "document"');
  });

  it("includes warehouseId in save payload", async () => {
    const src = await readAdapter();
    expect(src).toContain("warehouseId:");
  });
});

describe("Keyboard Navigation — PRD Story #18", () => {
  it("Delete key removes selected row", async () => {
    const src = await readAdapter();
    expect(src).toContain('e.key === "Delete"');
    expect(src).toContain("handleDeleteLine");
  });

  it("Delete key requires confirmation", async () => {
    const src = await readAdapter();
    expect(src).toContain("doc.lines.delete.confirm");
    expect(src).toContain("confirm(");
  });
});

describe("Save Functionality — PRD Story #19", () => {
  it("has save button with doc.lines.save i18n key", async () => {
    const src = await readAdapter();
    expect(src).toContain("handleSave");
    expect(src).toContain("doc.lines.save");
  });

  it("save button disabled during save operation", async () => {
    const src = await readAdapter();
    expect(src).toContain("isSaving");
    expect(src).toContain("disabled={isSaving");
  });

  it("no auto-save — only explicit button click triggers save", async () => {
    const src = await readAdapter();
    expect(src).toContain("onClick={handleSave}");
  });

  it("maps local line data to server schema for save", async () => {
    const src = await readAdapter();
    expect(src).toContain("lineNo:");
    expect(src).toContain("articleId:");
    expect(src).toContain("quantity:");
    expect(src).toContain("netPrice:");
  });

  it("view layer invalidates entity-list query after save", async () => {
    const src = await readView();
    expect(src).toContain("invalidateQueries");
    expect(src).toContain("entity-list");
  });
});
