import { FileText, Plus } from "lucide-react";

import { t as i18nT } from "../../i18n";
import { useWorkspaceContext } from "../../workspace-context";
import DocumentUnifiedView from "./document-unified-view";

export default function DocumentDetailView() {
  const { selectedDocument, lang, setSelected } = useWorkspaceContext();
  const docId = selectedDocument?.document_id as string | undefined;

  if (!selectedDocument || !docId) {
    return (
      <div className="pane-empty">
        <div className="pane-empty-icon">
          <FileText size={32} />
        </div>
        <div className="pane-empty-text">{i18nT("doc.empty", lang as "de" | "en")}</div>
        <button
          className="btn btn-primary btn-xs"
          style={{ marginTop: 12 }}
          onClick={() => setSelected("document", { document_id: "__new__" })}
        >
          <Plus size={11} style={{ marginRight: 4 }} />
          {i18nT("doc.header.new", lang as "de" | "en")}
        </button>
      </div>
    );
  }

  return <DocumentUnifiedView />;
}
