import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ZapIcon } from "lucide-react";

import { explodeDocumentBomFn, getEntityFn, updateDocumentFn } from "~/server/server-functions";

import { LinesPanelAdapter } from "../../components/panels/lines-panel-adapter";
import type { SaveLine } from "../../components/panels/lines-panel-adapter";
import { t as i18nT } from "../../i18n";
import type { PaneCtx } from "../../pane";
import { useWorkspaceContext } from "../../workspace-context";

export default function DocumentLinesView() {
  const { selectedDocument, lang, toast } = useWorkspaceContext();
  const docId = selectedDocument?.document_id as string | undefined;
  const queryClient = useQueryClient();

  const { data: docData } = useQuery({
    queryKey: ["entity-detail", "document", docId],
    queryFn: () => getEntityFn({ data: { entityName: "document", id: docId! } }),
    enabled: !!docId && docId !== "__new__",
  });

  const saveMutation = useMutation({
    mutationFn: (lines: SaveLine[]) =>
      updateDocumentFn({
        data: {
          documentId: docId!,
          companyId: (docData as any)?.company_id ?? "",
          lines,
        },
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["entity-list", "document_line", docId] });
      toast?.(i18nT("doc.lines.save.success", lang as "de" | "en"));
    },
    onError: () => {
      toast?.(i18nT("doc.lines.save.error", lang as "de" | "en"));
    },
  });

  const explodeMutation = useMutation({
    mutationFn: () => explodeDocumentBomFn({ data: { documentId: docId! } }),
    onSuccess: (res) => {
      if (res.success) {
        queryClient.invalidateQueries({ queryKey: ["entity-list", "document_line", docId] });
        toast?.(i18nT("doc.lines.explode.success", lang as "de" | "en"));
      } else {
        toast?.(res.error || i18nT("doc.lines.explode.error", lang as "de" | "en"));
      }
    },
    onError: () => {
      toast?.(i18nT("doc.lines.explode.error", lang as "de" | "en"));
    },
  });

  if (!docId || docId === "__new__") {
    return (
      <div
        className="sw-pane-empty"
        style={{ display: "flex", flex: 1, alignItems: "center", justifyContent: "center" }}
      >
        <span style={{ fontSize: 12, color: "var(--sw-text-muted)" }}>
          {i18nT("lines.noparent.title", lang as "de" | "en")}
        </span>
      </div>
    );
  }

  const ctx: PaneCtx = {
    t: (key) => i18nT(key, lang as "de" | "en"),
    lang: lang as "de" | "en",
    dispatchIntent: () => {},
    toast,
  };

  const isDraft = (docData as any)?.status === "draft";

  return (
    <LinesPanelAdapter
      panel={{
        entity: "document",
        parentId: docId,
        viewKey: "document:lines",
        type: "lines",
      }}
      ctx={ctx}
      headerWarehouseId={(docData as any)?.warehouse_id ?? undefined}
      onSave={(lines) => saveMutation.mutateAsync(lines).then(() => {})}
      renderExtraActions={() =>
        isDraft ? (
          <button
            className="sw-btn sw-btn-ghost sw-btn-xs"
            onClick={() => explodeMutation.mutate()}
            disabled={explodeMutation.isPending}
            title={i18nT("doc.lines.explode.tooltip", lang as "de" | "en")}
            style={{ display: "flex", alignItems: "center", gap: 4 }}
          >
            <ZapIcon size={11} /> {i18nT("doc.lines.explode", lang as "de" | "en")}
          </button>
        ) : null
      }
    />
  );
}
