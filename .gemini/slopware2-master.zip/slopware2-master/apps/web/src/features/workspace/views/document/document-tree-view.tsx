import { useQuery } from "@tanstack/react-query";

import { listDocumentTreeFn } from "~/server/server-functions";

import { useWorkspaceContext } from "../../workspace-context";
import { TreeView } from "../tree-view";

export default function DocumentTreeView() {
  const { lang, docFilter, setDocFilter } = useWorkspaceContext();

  const { data: treeData, isLoading } = useQuery({
    queryKey: ["document-tree", lang],
    queryFn: () => listDocumentTreeFn(),
  });

  if (isLoading || !treeData) {
    return (
      <div className="sw-pane-empty flex flex-1 items-center justify-center">
        <div style={{ fontSize: 12.5, color: "var(--sw-text-muted, #6b7280)" }}>
          Lade Belegstruktur...
        </div>
      </div>
    );
  }

  return (
    <TreeView
      data={treeData as any}
      activeKey={docFilter}
      lang={lang as "de" | "en"}
      onPick={(it) => setDocFilter(it.key)}
    />
  );
}
