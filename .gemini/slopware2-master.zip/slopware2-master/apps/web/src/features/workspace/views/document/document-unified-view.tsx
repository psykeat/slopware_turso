import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Zap, ChevronDown, ChevronRight, Truck, CreditCard, Warehouse, Save } from "lucide-react";
import { useState, useEffect, useRef, useCallback } from "react";

import {
  getDocumentFn,
  updateDocumentFn,
  createDocumentFn,
  explodeDocumentBomFn,
  lookupHelperTableFn,
  getCompanyDefaultsFn,
  listDocumentTypesFn,
  listDocumentGroupsFn,
  convertDocumentFn,
  deleteDocumentFn,
  duplicateEntityFn,
} from "~/server/server-functions";

import { useHotkeyLayer } from "../../../hotkeys/use-hotkey-layer";
import { useScopedHotkey } from "../../../hotkeys/use-scoped-hotkey";
import { AddressLookup } from "../../components/address-lookup";
import { ConvertDialog } from "../../components/convert-dialog";
import { DatePicker } from "../../components/date-picker";
import { HotkeyCheatsheet } from "../../components/hotkey-cheatsheet";
import { LookupInput } from "../../components/lookup-input";
import { LinesPanelAdapter } from "../../components/panels/lines-panel-adapter";
import { t as i18nT } from "../../i18n";
import type { PaneCtx } from "../../pane";
import { useWorkspaceContext } from "../../workspace-context";

export default function DocumentUnifiedView() {
  const { selectedDocument, lang, toast, docFilter, setSelected, applyLayout } =
    useWorkspaceContext();
  const docId = selectedDocument?.document_id as string | undefined;
  const isNew = docId === "__new__";
  const queryClient = useQueryClient();

  const [isTechnicalOpen, setIsTechnicalOpen] = useState(false);
  const [localDraft, setLocalDraft] = useState<Record<string, any>>({});
  const [showCheatsheet, setShowCheatsheet] = useState(false);
  const [showConvert, setShowConvert] = useState(false);

  const docLayerId = `document-${docId || "new"}`;
  useHotkeyLayer(docLayerId);

  // 1. Fetch defaults for new documents
  const { data: companyDefaults } = useQuery({
    queryKey: ["company-defaults"],
    queryFn: () => getCompanyDefaultsFn(),
    enabled: isNew,
  });

  // 2. Fetch existing document data
  const {
    data: docRaw,
    isLoading: isDocLoading,
    refetch,
  } = useQuery({
    queryKey: ["document-unified", docId],
    queryFn: () => getDocumentFn({ data: { documentId: docId! } }),
    enabled: !!docId && !isNew,
  });

  const doc = isNew ? localDraft : (docRaw as Record<string, any> | null);

  // 3. Initialize new document from filter/context
  useEffect(() => {
    if (isNew && companyDefaults) {
      const initial: Record<string, any> = {
        companyId: companyDefaults.company_id,
        currencyId: companyDefaults.currency_id,
        documentDate: new Date().toISOString().slice(0, 10),
        status: "draft",
      };

      if (docFilter?.startsWith("dt-")) {
        initial.documentType = docFilter.replace("dt-", "");
      } else if (docFilter?.startsWith("dg-")) {
        initial.documentGroupId = docFilter.replace("dg-", "");
      }
      setLocalDraft((prev) => ({ ...initial, ...prev }));
    }
  }, [isNew, companyDefaults, docFilter]);

  const updateMutation = useMutation({
    mutationFn: (payload: any) =>
      updateDocumentFn({
        data: { documentId: docId!, companyId: doc?.company_id as string, ...payload },
      }),
    onSuccess: () => {
      refetch();
      queryClient.invalidateQueries({ queryKey: ["entity-list", "document"] });
      toast?.(i18nT("detail.save.success", lang as "de" | "en"));
    },
  });

  const createMutation = useMutation({
    mutationFn: (payload: any) => createDocumentFn({ data: payload }),
    onSuccess: (res) => {
      if (res.success && res.documentId) {
        queryClient.invalidateQueries({ queryKey: ["entity-list", "document"] });
        queryClient.invalidateQueries({ queryKey: ["document-tree"] });
        toast?.(i18nT("doc.header.save.success", lang as "de" | "en"));

        // Promote to actual document
        setSelected("document", {
          document_id: res.documentId,
          document_no: res.documentNo,
          status: "draft",
        });
        applyLayout("3");
      } else {
        toast?.(res.error || "Save failed");
      }
    },
  });

  const explodeMutation = useMutation({
    mutationFn: () => explodeDocumentBomFn({ data: { documentId: docId! } }),
    onSuccess: (res) => {
      if (res.success) {
        queryClient.invalidateQueries({ queryKey: ["entity-list", "document_line", docId] });
        toast?.(i18nT("doc.lines.explode.success", lang as "de" | "en"));
      }
    },
  });

  const convertMutation = useMutation({
    mutationFn: (payload: { documentId: string; targetGroupId?: string }) =>
      convertDocumentFn({ data: payload }),
    onSuccess: () => {
      refetch();
      queryClient.invalidateQueries({ queryKey: ["entity-list", "document"] });
      queryClient.invalidateQueries({ queryKey: ["document-tree"] });
      toast?.(i18nT("detail.convert.success", lang as "de" | "en"));
      setShowConvert(false);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (docId: string) => deleteDocumentFn({ data: { documentId: docId } }),
    onSuccess: (result) => {
      if (result?.success) {
        queryClient.invalidateQueries({ queryKey: ["entity-list", "document"] });
        queryClient.invalidateQueries({ queryKey: ["document-tree"] });
        toast?.(i18nT("detail.delete.success", lang as "de" | "en"));
        setSelected(null, null);
      }
    },
  });

  const duplicateMutation = useMutation({
    mutationFn: (payload: { entityName: string; sourceId: string }) =>
      duplicateEntityFn({ data: payload }),
    onSuccess: (res) => {
      if (res.success && res.id) {
        queryClient.invalidateQueries({ queryKey: ["entity-list", "document"] });
        queryClient.invalidateQueries({ queryKey: ["document-tree"] });
        toast?.(i18nT("detail.duplicate.success", lang as "de" | "en"));
        setSelected("document", { document_id: res.id });
        applyLayout("3");
      }
    },
  });

  const getDirection = (code: string) => {
    if (["N", "A", "L", "R", "G"].includes(code)) return "outbound";
    if (["b", "l", "r", "g"].includes(code)) return "inbound";
    return "adjustment";
  };

  /* ── Hotkey handlers ── */

  const handleSaveNew = useCallback(() => {
    if (!doc?.documentType) {
      toast?.("Belegart fehlt");
      return;
    }
    const payload = {
      ...doc,
      documentDirection: getDirection(doc.documentType),
      lines: [],
    };
    createMutation.mutate(payload);
  }, [doc, createMutation, toast]);

  const handleSave = useCallback(() => {
    if (isNew) {
      handleSaveNew();
    } else if (docId) {
      refetch();
      toast?.(i18nT("doc.header.save.success", lang as "de" | "en"));
    }
  }, [isNew, docId, handleSaveNew, refetch, toast, lang]);

  const handleDuplicate = useCallback(() => {
    if (!isNew && docId) {
      duplicateMutation.mutate({ entityName: "document", sourceId: docId });
    }
  }, [isNew, docId, duplicateMutation]);

  const handleConvert = useCallback(() => {
    if (!isNew && docId) {
      setShowConvert(true);
    }
  }, [isNew, docId]);

  const handleDelete = useCallback(() => {
    if (!isNew && docId) {
      const docNo = doc?.document_no ?? docId;
      const msg = i18nT("detail.delete.confirm", lang as "de" | "en")
        .replace("{no}", String(docNo))
        .replace("{type}", String(doc?.type_code ?? ""));
      if (confirm(msg)) {
        deleteMutation.mutate(docId);
      }
    } else if (isNew) {
      setSelected(null, null);
    }
  }, [isNew, docId, doc, deleteMutation, setSelected, lang]);

  const handleCheatsheet = useCallback(() => {
    setShowCheatsheet((p) => !p);
  }, []);

  const handleDiscard = useCallback(() => {
    if (isNew) {
      setSelected(null, null);
    }
  }, [isNew, setSelected]);

  useScopedHotkey(docLayerId, "F10", handleSave);
  useScopedHotkey(docLayerId, "F8", handleDuplicate);
  useScopedHotkey(docLayerId, "F7", handleConvert);
  useScopedHotkey(docLayerId, "F9", handleConvert);
  useScopedHotkey(docLayerId, "F4", handleDelete);
  useScopedHotkey(docLayerId, "?", handleCheatsheet);
  useScopedHotkey(docLayerId, "Escape", handleDiscard);

  const ctx: PaneCtx = {
    t: (key) => i18nT(key, lang as "de" | "en"),
    lang: lang as "de" | "en",
    dispatchIntent: () => {},
    toast,
  };

  if (isDocLoading) {
    return <div className="p-8 text-gray-400">Loading document...</div>;
  }

  if (!doc && !isNew) {
    return <div className="p-8 text-gray-400">Document not found.</div>;
  }

  const isDraft = doc?.status === "draft";
  const combinedType = isNew
    ? "NEW"
    : `${(doc?.type_code as string) || ""}${String(doc?.group_number || 0).padStart(2, "0")}`;

  const technicalFields = [
    "document_id",
    "organization_id",
    "tenant_id",
    "version_no",
    "created_at",
    "updated_at",
    "posted_at",
    "posted_by",
    "cancelled_at",
    "archived_at",
    "document_direction",
    "transaction_id",
  ];

  const handleFieldChange = (field: string, value: any) => {
    if (isNew) {
      setLocalDraft((prev) => ({ ...prev, [field]: value }));
    } else {
      updateMutation.mutate({ [field]: value });
    }
  };

  const handleAddressChange = (
    fieldId: string,
    fieldJson: string,
    id: string | null,
    json: any,
  ) => {
    if (isNew) {
      setLocalDraft((prev) => ({ ...prev, [fieldId]: id, [fieldJson]: json }));
    } else {
      updateMutation.mutate({ [fieldId]: id, [fieldJson]: json });
    }
  };

  return (
    <div className="sw-document-unified flex h-full flex-col overflow-hidden bg-white">
      {/* Unified Header */}
      <div className="sw-unified-header flex-none border-b bg-gray-50/30 p-4">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex flex-col gap-0.5">
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-gray-900">
                {isNew
                  ? i18nT("doc.header.new", lang as "de" | "en")
                  : (doc?.document_no as string) || (doc?.document_id as string)}
              </h1>
              <span className="badge-blue rounded px-1.5 py-0.5 text-[10px] font-bold tracking-wider uppercase">
                {doc?.status as string}
              </span>
            </div>
            <div className="flex items-center gap-2 text-[11px] font-medium text-gray-500">
              <span className="rounded bg-gray-200 px-1.5 py-0.5 font-bold text-gray-700">
                {combinedType}
              </span>
              {!isNew && (
                <>
                  <span className="text-gray-300">|</span>
                  <span>{doc?.type_name as string}</span>
                  {doc?.group_name && (
                    <>
                      <span className="text-gray-300">|</span>
                      <span>{doc?.group_name as string}</span>
                    </>
                  )}
                </>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isNew ? (
              <button
                className="sw-btn sw-btn-primary sw-btn-sm"
                onClick={handleSaveNew}
                disabled={createMutation.isPending}
              >
                <Save className="mr-1.5" size={14} />
                {i18nT("doc.header.save", lang as "de" | "en")}
              </button>
            ) : (
              <>
                {isDraft && (
                  <button
                    className="sw-btn sw-btn-primary sw-btn-sm"
                    onClick={() => explodeMutation.mutate()}
                    disabled={explodeMutation.isPending}
                  >
                    <Zap size={14} className="mr-1.5" />
                    {i18nT("doc.lines.explode", lang as "de" | "en")}
                  </button>
                )}
                <button className="sw-btn sw-btn-ghost sw-btn-sm border" onClick={() => refetch()}>
                  Refresh
                </button>
              </>
            )}
          </div>
        </div>

        {/* Header Grid */}
        <div className="grid grid-cols-4 gap-6">
          <div className="flex flex-col gap-4">
            {isNew && (
              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold tracking-wider text-gray-400 uppercase">
                  {i18nT("doc.header.type", lang as "de" | "en")}
                </label>
                <DocTypeSelector
                  value={doc?.documentType || null}
                  onChange={(val) => handleFieldChange("documentType", val)}
                  lang={lang as "de" | "en"}
                />
              </div>
            )}
            <AddressLookup
              label={i18nT("doc.header.customer", lang as "de" | "en")}
              value={(isNew ? doc?.customerId : doc?.customer_id) as string}
              addressData={isNew ? doc?.billingAddress : doc?.billing_address}
              tabIndex={1}
              onChange={(id, json) => handleAddressChange("customerId", "billingAddress", id, json)}
              lang={lang as "de" | "en"}
            />
          </div>

          <div className="flex flex-col gap-4">
            {isNew && (
              <div className="flex flex-col gap-1">
                <label className="text-[10px] font-bold tracking-wider text-gray-400 uppercase">
                  {i18nT("doc.header.group", lang as "de" | "en")}
                </label>
                <DocGroupSelector
                  docType={doc?.documentType || null}
                  value={doc?.documentGroupId || null}
                  onChange={(val) => handleFieldChange("documentGroupId", val)}
                  lang={lang as "de" | "en"}
                />
              </div>
            )}
            <AddressLookup
              label={i18nT("doc.header.delivery_address", lang as "de" | "en")}
              value={(isNew ? doc?.deliveryAddressId : doc?.delivery_address_id) as string}
              addressData={isNew ? doc?.deliveryAddress : doc?.delivery_address}
              tabIndex={2}
              onChange={(id, json) =>
                handleAddressChange("deliveryAddressId", "deliveryAddress", id, json)
              }
              lang={lang as "de" | "en"}
            />
          </div>

          <div className="flex flex-col gap-3 border-l pl-6">
            <LookupInput
              label={i18nT("doc.header.warehouse", lang as "de" | "en")}
              queryKey={["lookup", "warehouse"]}
              queryFn={(search) =>
                lookupHelperTableFn({ data: { tableName: "warehouse", search } })
              }
              value={(isNew ? doc?.warehouseId : doc?.warehouse_id) as string | null}
              tabIndex={3}
              onChange={(id) => handleFieldChange("warehouseId", id)}
              icon={<Warehouse size={12} />}
              hotkey="F5"
            />
            <LookupInput
              label={i18nT("doc.header.payment_term", lang as "de" | "en")}
              queryKey={["lookup", "payment_term"]}
              queryFn={(search) =>
                lookupHelperTableFn({ data: { tableName: "payment_term", search } })
              }
              value={(isNew ? doc?.paymentTermId : doc?.payment_term_id) as string | null}
              tabIndex={5}
              onChange={(id) => handleFieldChange("paymentTermId", id)}
              icon={<CreditCard size={12} />}
              hotkey="F5"
            />
            <LookupInput
              label={i18nT("doc.header.shipping_method", lang as "de" | "en")}
              queryKey={["lookup", "shipping_method"]}
              queryFn={(search) =>
                lookupHelperTableFn({ data: { tableName: "shipping_method", search } })
              }
              value={(isNew ? doc?.shippingMethodId : doc?.shipping_method_id) as string | null}
              tabIndex={6}
              onChange={(id) => handleFieldChange("shippingMethodId", id)}
              icon={<Truck size={12} />}
              hotkey="F5"
            />
          </div>

          <div className="grid grid-cols-1 gap-3 border-l pl-6">
            <DatePicker
              label={i18nT("doc.header.date", lang as "de" | "en")}
              value={doc?.documentDate ? String(doc?.documentDate).slice(0, 10) : null}
              onChange={(val) => handleFieldChange("documentDate", val)}
              tabIndex={4}
              placeholder="DD.MM.YYYY"
              format="DD.MM.YYYY"
            />

            <LookupInput
              label={i18nT("doc.header.currency", lang as "de" | "en")}
              queryKey={["lookup", "currency"]}
              queryFn={(search) => lookupHelperTableFn({ data: { tableName: "currency", search } })}
              value={(doc?.currency_id as string) || (doc?.currencyId as string) || null}
              tabIndex={7}
              onChange={(id) => handleFieldChange("currencyId", id)}
              hotkey="F5"
            />
          </div>
        </div>

        {/* Technical Info Expander */}
        {!isNew && (
          <div className="mt-4 border-t pt-2">
            <button
              className="flex items-center gap-1 text-[10px] font-bold tracking-widest text-gray-400 uppercase hover:text-gray-600"
              onClick={() => setIsTechnicalOpen(!isTechnicalOpen)}
            >
              {isTechnicalOpen ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
              {i18nT("detail.technical_info", lang as "de" | "en")}
            </button>

            {isTechnicalOpen && (
              <div className="mt-3 grid grid-cols-4 gap-4 rounded bg-gray-100/50 p-3">
                {technicalFields.map((f) => (
                  <div key={f} className="flex flex-col">
                    <span className="text-[9px] font-bold text-gray-400 uppercase">{f}</span>
                    <span className="mono truncate text-[10px] text-gray-600">
                      {String(doc?.[f] || "—")}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Lines Section */}
      {!isNew && (
        <div className="flex-1 overflow-hidden">
          <LinesPanelAdapter
            panel={{
              entity: "document",
              parentId: docId!,
              viewKey: "document:lines",
              type: "lines",
            }}
            ctx={ctx}
            headerWarehouseId={doc?.warehouse_id as string}
            baseTabIndex={8}
            onSave={async (lines) => {
              await updateDocumentFn({
                data: {
                  documentId: docId!,
                  companyId: doc?.company_id as string,
                  lines,
                },
              });
              queryClient.invalidateQueries({ queryKey: ["entity-list", "document_line", docId] });
              refetch();
            }}
          />
        </div>
      )}

      {/* Overlays */}
      <HotkeyCheatsheet
        isOpen={showCheatsheet}
        onClose={() => setShowCheatsheet(false)}
        t={(k) => i18nT(k, lang as "de" | "en")}
        lang={lang as "de" | "en"}
      />

      {showConvert && !isNew && docId && (
        <ConvertDialog
          documentId={docId}
          onClose={() => setShowConvert(false)}
          onConfirm={(targetGroupId?) => {
            convertMutation.mutate({ documentId: docId, targetGroupId });
          }}
          lang={lang as "de" | "en"}
        />
      )}
    </div>
  );
}

function DocTypeSelector({
  value,
  onChange,
}: {
  value: string | null;
  onChange: (val: string) => void;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const { data: types = { outbound: [], inbound: [], adjustment: [] } } = useQuery({
    queryKey: ["document-types"],
    queryFn: () => listDocumentTypesFn(),
  });

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setIsOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  const allTypes = [...types.outbound, ...types.inbound, ...types.adjustment];
  const selected = (allTypes as any[]).find((t) => t.code === value);

  return (
    <div className="relative w-full" ref={ref}>
      <div
        className="sw-input flex cursor-pointer items-center justify-between px-2 py-0"
        style={{ height: "26px", fontSize: "12px", background: "var(--sw-bg-pane)" }}
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className={!selected ? "text-muted" : ""}>
          {selected ? `${selected.code} — ${selected.name}` : "Wählen..."}
        </span>
        <ChevronDown size={10} className="text-gray-400" />
      </div>
      {isOpen && (
        <div className="absolute z-[100] mt-1 max-h-[200px] w-full overflow-auto rounded border bg-white shadow-lg">
          {[
            { label: "WA", items: types.outbound },
            { label: "WE", items: types.inbound },
            { label: "Lager", items: types.adjustment },
          ].map((g) => (
            <div key={g.label}>
              <div className="bg-gray-50 px-2 py-1 text-[9px] font-bold text-gray-400 uppercase">
                {g.label}
              </div>
              {(g.items as any[]).map((t) => (
                <div
                  key={t.code}
                  className="cursor-pointer px-2 py-1.5 text-[11px] hover:bg-gray-100"
                  onClick={() => {
                    onChange(t.code);
                    setIsOpen(false);
                  }}
                >
                  {t.code} — {t.name}
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function DocGroupSelector({
  docType,
  value,
  onChange,
}: {
  docType: string | null;
  value: string | null;
  onChange: (val: string) => void;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const { data: groups = [] } = useQuery({
    queryKey: ["document-groups", docType],
    queryFn: () => listDocumentGroupsFn({ data: { documentType: docType! } }),
    enabled: !!docType,
  });

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setIsOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  const selected = (groups as any[]).find((g) => g.document_group_id === value);

  return (
    <div className="relative w-full" ref={ref}>
      <div
        className="sw-input flex cursor-pointer items-center justify-between px-2 py-0"
        style={{ height: "26px", fontSize: "12px", background: "var(--sw-bg-pane)" }}
        onClick={() => docType && setIsOpen(!isOpen)}
      >
        <span className={!selected ? "text-muted" : ""}>
          {selected ? `${selected.group_number} — ${selected.name}` : "Wählen..."}
        </span>
        <ChevronDown size={10} className="text-gray-400" />
      </div>
      {isOpen && groups.length > 0 && (
        <div className="absolute z-[100] mt-1 max-h-[160px] w-full overflow-auto rounded border bg-white shadow-lg">
          {(groups as any[]).map((g) => (
            <div
              key={g.document_group_id}
              className="cursor-pointer px-2 py-1.5 text-[11px] hover:bg-gray-100"
              onClick={() => {
                onChange(g.document_group_id);
                setIsOpen(false);
              }}
            >
              {g.group_number} — {g.name}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
