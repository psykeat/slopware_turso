import { useMutation, useQuery } from "@tanstack/react-query";
import { Lock, Save } from "lucide-react";
import { useState } from "react";

import {
  getConnectorDefinitionFn,
  getSchemaAnnotationsFn,
  listConnectorMappingsFn,
  listTenantConnectorsFn,
  patchConnectorMappingsFn,
} from "../../../../server/server-functions";
import { useWorkspaceContext } from "../../workspace-context";

// fallow-ignore-next-line complexity
export default function IntegrationConnectorMappingsView() {
  const { lang, toast } = useWorkspaceContext();
  const isDe = lang === "de";
  const [tenantConnectorId, setTenantConnectorId] = useState("");

  const { data: connectors = [] } = useQuery({
    queryKey: ["tenant-connectors"],
    queryFn: () => listTenantConnectorsFn(),
  });

  const { data: definition } = useQuery({
    queryKey: ["connector-def", tenantConnectorId],
    queryFn: () => getConnectorDefinitionFn({ data: { tenantConnectorId } }),
    enabled: !!tenantConnectorId,
  });

  const { data: mappings = [], refetch } = useQuery({
    queryKey: ["connector-mappings", tenantConnectorId],
    queryFn: () => listConnectorMappingsFn({ data: { tenantConnectorId } }),
    enabled: !!tenantConnectorId,
  });

  const { data: annotations = [] } = useQuery({
    queryKey: ["schema-annotations"],
    queryFn: () => getSchemaAnnotationsFn(),
  });

  const saveMutation = useMutation({
    mutationFn: (
      ms: Array<{
        source_field: string;
        target_table: string;
        target_column: string;
        transform?: Record<string, unknown>;
        default_value?: unknown;
      }>,
    ) => patchConnectorMappingsFn({ data: { tenantConnectorId, mappings: ms } }),
    onSuccess: () => {
      toast(isDe ? "Mappings gespeichert" : "Mappings saved");
      refetch();
    },
  });

  const defaultMappings = ((definition as any)?.default_mappings ?? []) as string[];
  const lockedFields = new Set(((definition as any)?.locked_fields ?? []) as string[]);
  const mappingMap = new Map((mappings as any[]).map((m: any) => [m.source_field, m]));
  const annList = annotations as any[];
  const annMap = new Map(annList.map((a: any) => [`${a.table_name}.${a.column_name}`, a]));

  const handleSave = () => {
    const ms: Array<{
      source_field: string;
      target_table: string;
      target_column: string;
      transform: Record<string, unknown>;
      default_value: unknown;
    }> = defaultMappings.map(
      // fallow-ignore-next-line complexity
      (field: string) => {
        const m = mappingMap.get(field) as Record<string, unknown> | undefined;
        return {
          source_field: field,
          target_table: String(m?.target_table ?? ""),
          target_column: String(m?.target_column ?? ""),
          transform: (m?.transform ?? { type: "direct" }) as Record<string, unknown>,
          default_value: m?.default_value ?? null,
        };
      },
    );
    saveMutation.mutate(ms);
  };

  const updateMapping = (field: string, key: string, value: string | null) => {
    const m = mappingMap.get(field) ?? {};
    mappingMap.set(field, { ...m, [key]: value });
  };

  if (!tenantConnectorId) {
    return (
      <div className="sw-panel-body">
        <div className="sw-section-label">{isDe ? "Connector auswählen" : "Select Connector"}</div>
        <select
          className="sw-input"
          value=""
          onChange={(e) => setTenantConnectorId(e.target.value)}
        >
          <option value="">{isDe ? "— wählen —" : "-- select --"}</option>
          {/* fallow-ignore-next-line complexity */}
          {(connectors as any[]).map((c: any) => (
            <option key={c.tenant_connector_id} value={c.tenant_connector_id}>
              {isDe
                ? ((c.label as Record<string, string>)?.de ?? c.slug)
                : ((c.label as Record<string, string>)?.en ?? c.slug)}
            </option>
          ))}
        </select>
      </div>
    );
  }

  // fallow-ignore-next-line complexity
  const rows = defaultMappings.map((field: string) => {
    const locked = lockedFields.has(field);
    const m = mappingMap.get(field) as Record<string, unknown> | undefined;
    const targetTable = String(m?.target_table ?? "");
    const targetColumn = String(m?.target_column ?? "");
    const slug = (definition as any)?.slug ?? "";

    const isMandatory = (() => {
      if (!targetTable || !targetColumn) return false;
      const ann = annMap.get(`${targetTable}.${targetColumn}`);
      const mandatoryFor = (ann as any)?.mandatory_for as string[] | undefined;
      return mandatoryFor?.includes(slug);
    })();

    return (
      <tr key={field}>
        <td className="sw-table-cell">
          <span style={{ fontFamily: "var(--font-mono)", fontSize: 12 }}>{field}</span>
          {locked && <Lock size={11} style={{ marginLeft: 4, color: "var(--text-muted)" }} />}
        </td>
        <td className="sw-table-cell">
          <input
            className="sw-input sw-input-xs"
            value={targetTable}
            disabled={locked}
            onChange={(e) => updateMapping(field, "target_table", e.target.value)}
            style={{ width: 120 }}
          />
        </td>
        <td className="sw-table-cell">
          <select
            className="sw-input sw-input-xs"
            value={targetColumn}
            disabled={locked}
            onChange={(e) => updateMapping(field, "target_column", e.target.value)}
          >
            <option value="">{isDe ? "(leer)" : "(empty)"}</option>
            {annList.map((a: any) => (
              <option key={`${a.table_name}.${a.column_name}`} value={a.column_name}>
                {a.business_name || a.column_name}
              </option>
            ))}
          </select>
        </td>
        <td className="sw-table-cell">
          {isMandatory && !targetColumn ? (
            <span className="badge-red">{isDe ? "Pflicht" : "Required"}</span>
          ) : isMandatory ? (
            <span className="badge-green">OK</span>
          ) : (
            "-"
          )}
        </td>
        <td className="sw-table-cell">
          <input
            className="sw-input sw-input-xs"
            value={String(m?.default_value ?? "")}
            disabled={locked}
            placeholder={isDe ? "Standardwert" : "Default"}
            onChange={(e) => updateMapping(field, "default_value", e.target.value || null)}
            style={{ width: 100 }}
          />
        </td>
      </tr>
    );
  });

  return (
    <div className="sw-panel-body">
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
        <div className="sw-section-label">
          {isDe ? "Feld-Mappings" : "Field Mappings"} — {(definition as any)?.slug ?? ""}
        </div>
        <button className="sw-btn sw-btn-xs sw-btn-accent" onClick={handleSave}>
          <Save size={11} /> {isDe ? "Speichern" : "Save"}
        </button>
      </div>
      {saveMutation.error && (
        <div className="badge-red" style={{ marginBottom: 8 }}>
          {(saveMutation.error as Error).message.includes("source_locked")
            ? isDe
              ? "Quellfeld ist gesperrt"
              : "Source field is locked"
            : (saveMutation.error as Error).message.includes("target_locked")
              ? isDe
                ? "Zielspalte ist gesperrt"
                : "Target column is locked"
              : String(saveMutation.error)}
        </div>
      )}
      <table className="sw-table">
        <thead>
          <tr>
            <th className="sw-table-th">{isDe ? "Quellfeld" : "Source"}</th>
            <th className="sw-table-th">{isDe ? "Zieltabelle" : "Target Table"}</th>
            <th className="sw-table-th">{isDe ? "Zielspalte" : "Target Column"}</th>
            <th className="sw-table-th">{isDe ? "Pflicht" : "Required"}</th>
            <th className="sw-table-th">{isDe ? "Standardwert" : "Default"}</th>
          </tr>
        </thead>
        <tbody>{rows}</tbody>
      </table>
    </div>
  );
}
