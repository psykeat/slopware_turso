import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { RefreshCw, Trash2, AlertCircle } from "lucide-react";
import React from "react";

import {
  listImportQueueFn,
  rerunImportBatchFn,
  rejectImportBatchFn,
} from "../../../../server/server-functions";
import { getEntityColumns } from "../../components/data-table/columns";
import { DataTable } from "../../components/data-table/data-table";
import { useDataTable } from "../../components/data-table/use-data-table";
import { useWorkspaceContext } from "../../workspace-context";

export default function IntegrationImportQueueView() {
  const { t } = useWorkspaceContext();
  const queryClient = useQueryClient();
  const { state, setState } = useDataTable();

  const { data: batches = [], isLoading } = useQuery({
    queryKey: ["import-queue"],
    queryFn: () => listImportQueueFn(),
  });

  const rerunMutation = useMutation({
    mutationFn: (batchId: string) => rerunImportBatchFn({ data: { batchId } }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["import-queue"] });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: (batchId: string) => rejectImportBatchFn({ data: { batchId } }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["import-queue"] });
    },
  });

  const columns = React.useMemo(() => getEntityColumns("import_batch", t), [t]);

  return (
    <div className="flex h-full flex-col gap-4 overflow-hidden p-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold">{t("integration.queue.title")}</h2>
          <p className="text-muted text-sm">{t("integration.queue.description")}</p>
        </div>
      </div>

      <div className="bg-card flex-1 overflow-hidden rounded-lg border">
        {batches.length === 0 && !isLoading ? (
          <div className="text-muted flex h-full flex-col items-center justify-center gap-2">
            <AlertCircle size={48} className="opacity-20" />
            <p>{t("integration.queue.empty")}</p>
          </div>
        ) : (
          <DataTable
            columns={columns}
            data={batches as any[]}
            loading={isLoading}
            state={state}
            onStateChange={setState}
            renderRowActions={(row: any) => (
              <div className="flex items-center gap-2">
                <button
                  className="btn btn-ghost btn-xs text-blue-500"
                  title="Rerun"
                  onClick={() => rerunMutation.mutate(String(row.batch_id))}
                  disabled={rerunMutation.isPending}
                >
                  <RefreshCw size={14} className={rerunMutation.isPending ? "animate-spin" : ""} />
                </button>
                <button
                  className="btn btn-ghost btn-xs text-red-500"
                  title="Reject"
                  onClick={() => {
                    if (confirm(t("integration.queue.confirm_reject"))) {
                      rejectMutation.mutate(String(row.batch_id));
                    }
                  }}
                  disabled={rejectMutation.isPending}
                >
                  <Trash2 size={14} />
                </button>
              </div>
            )}
          />
        )}
      </div>
    </div>
  );
}
