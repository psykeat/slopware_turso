import { useMutation, useQuery } from "@tanstack/react-query";
import { Play, Square, Settings } from "lucide-react";

import {
  activateConnectorFn,
  deactivateConnectorFn,
  listConnectorsFn,
  listTenantConnectorsFn,
} from "../../../../server/server-functions";
import { useWorkspaceContext } from "../../workspace-context";

type ActivationData = {
  connectorId: string;
  credentials: Record<string, unknown>;
  cronExpression: string | null;
};

export default function IntegrationTenantConnectorsView() {
  const { lang } = useWorkspaceContext();
  const isDe = lang === "de";

  const { data: allConnectors = [] } = useQuery({
    queryKey: ["admin-connectors"],
    queryFn: () => listConnectorsFn(),
  });

  const { data: tenantConnectors = [], refetch } = useQuery({
    queryKey: ["tenant-connectors"],
    queryFn: () => listTenantConnectorsFn(),
  });

  const activateMutation = useMutation({
    mutationFn: (d: ActivationData) => activateConnectorFn({ data: d }),
    onSuccess: () => refetch(),
  });

  const deactivateMutation = useMutation({
    mutationFn: ({ tenantConnectorId }: { tenantConnectorId: string }) =>
      deactivateConnectorFn({ data: { tenantConnectorId } }),
    onSuccess: () => refetch(),
  });

  const activeIds = new Set((tenantConnectors as any[]).map((tc) => tc.connector_id));

  // fallow-ignore-next-line complexity
  const promptActivate = (connectorId: string) => {
    const key = prompt(isDe ? "API-Key:" : "API Key:", "");
    if (!key) return;
    const cron = prompt(isDe ? "Cron (optional):" : "Cron (optional):", "");
    activateMutation.mutate({
      connectorId,
      credentials: { api_key: key },
      cronExpression: cron || null,
    });
  };

  // fallow-ignore-next-line complexity
  const rows = (allConnectors as any[]).map((conn) => {
    const tc = (tenantConnectors as any[]).find((t) => t.connector_id === conn.connector_id);
    const active = tc?.is_active ?? false;
    const label = conn.label as Record<string, string> | undefined;
    const name = isDe ? (label?.de ?? conn.slug) : (label?.en ?? conn.slug);
    const isActive = active && !activeIds.has(conn.connector_id) === false;

    return (
      <tr key={conn.connector_id}>
        <td className="sw-table-cell">{name}</td>
        <td className="sw-table-cell">
          <span className="badge-blue">{conn.atomicity_mode}</span>
        </td>
        <td className="sw-table-cell">
          {active ? (
            <span className="badge-green">{isDe ? "Aktiv" : "Active"}</span>
          ) : (
            <span className="badge-orange">{isDe ? "Inaktiv" : "Inactive"}</span>
          )}
        </td>
        <td className="sw-table-cell" style={{ fontSize: 11 }}>
          {tc?.cron_expression ?? "-"}
        </td>
        <td className="sw-table-cell">
          {active ? (
            <button
              className="sw-btn sw-btn-xs sw-btn-danger"
              onClick={() =>
                deactivateMutation.mutate({ tenantConnectorId: tc.tenant_connector_id })
              }
            >
              <Square size={11} /> {isDe ? "Stop" : "Stop"}
            </button>
          ) : (
            <button
              className="sw-btn sw-btn-xs sw-btn-accent"
              onClick={() => promptActivate(conn.connector_id)}
            >
              {isActive ? (
                <>
                  <Play size={11} /> {isDe ? "Start" : "Start"}
                </>
              ) : (
                <>
                  <Settings size={11} /> {isDe ? "Verbinden" : "Connect"}
                </>
              )}
            </button>
          )}
        </td>
      </tr>
    );
  });

  return (
    <div className="sw-panel-body">
      <table className="sw-table">
        <thead>
          <tr>
            <th className="sw-table-th">Connector</th>
            <th className="sw-table-th">{isDe ? "Modus" : "Mode"}</th>
            <th className="sw-table-th">{isDe ? "Status" : "Status"}</th>
            <th className="sw-table-th">Cron</th>
            <th className="sw-table-th">{isDe ? "Aktionen" : "Actions"}</th>
          </tr>
        </thead>
        <tbody>{rows}</tbody>
      </table>
    </div>
  );
}
