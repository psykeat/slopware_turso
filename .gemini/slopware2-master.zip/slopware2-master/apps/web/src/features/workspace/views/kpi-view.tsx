import { BarChart3Icon, TrendingDownIcon, TrendingUpIcon } from "lucide-react";

import type { Lang } from "../i18n";
import { t } from "../i18n";

type KpiCard = {
  label: string;
  value: string;
  delta: string;
  up: boolean;
};

function fmtCurrency(n: number): string {
  return n.toLocaleString("de-DE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function yoyDelta(current: number, prior: number): string {
  if (prior === 0) return current > 0 ? "+∞%" : "—";
  const pct = ((current - prior) / Math.abs(prior)) * 100;
  return `${pct >= 0 ? "+" : ""}${pct.toFixed(1)}%`;
}

type TopGroup = {
  articleGroupId: string;
  name: string;
  totalAmountNet: number;
  totalProfit: number;
};

type MockKpis = {
  currentFiscalYear: number;
  umsatzCurrentYear: number;
  umsatzPriorYear: number;
  rohertragCurrentYear: number;
  rohertragPriorYear: number;
  einkaufsvolumen: number;
  openOrdersCount: number;
  openOrdersValue: number;
  openInvoicesCount: number;
  openInvoicesValue: number;
  inventoryValue: number;
  topArticleGroups: TopGroup[];
};

const MOCK_KPIS: MockKpis = {
  currentFiscalYear: 2026,
  umsatzCurrentYear: 1250000,
  umsatzPriorYear: 1100000,
  rohertragCurrentYear: 425000,
  rohertragPriorYear: 380000,
  einkaufsvolumen: 780000,
  openOrdersCount: 23,
  openOrdersValue: 145000,
  openInvoicesCount: 8,
  openInvoicesValue: 52000,
  inventoryValue: 320000,
  topArticleGroups: [
    { articleGroupId: "g1", name: "Electronics", totalAmountNet: 450000, totalProfit: 135000 },
    { articleGroupId: "g2", name: "Furniture", totalAmountNet: 320000, totalProfit: 96000 },
    { articleGroupId: "g3", name: "Accessories", totalAmountNet: 180000, totalProfit: 72000 },
  ],
};

export function KpiView({ lang }: { lang: Lang }) {
  const k = MOCK_KPIS;

  const umsatzDelta = yoyDelta(k.umsatzCurrentYear, k.umsatzPriorYear);
  const rohertragDelta = yoyDelta(k.rohertragCurrentYear, k.rohertragPriorYear);

  const cards: KpiCard[] = [
    {
      label: t("kpi.umsatz.current", lang),
      value: `${fmtCurrency(k.umsatzCurrentYear)} €`,
      delta: `${umsatzDelta} ${t("kpi.yoy", lang)}`,
      up: k.umsatzCurrentYear >= k.umsatzPriorYear,
    },
    {
      label: t("kpi.rohertrag.current", lang),
      value: `${fmtCurrency(k.rohertragCurrentYear)} €`,
      delta: `${rohertragDelta} ${t("kpi.yoy", lang)}`,
      up: k.rohertragCurrentYear >= k.rohertragPriorYear,
    },
    {
      label: t("kpi.einkauf", lang),
      value: `${fmtCurrency(k.einkaufsvolumen)} €`,
      delta: `GJ ${k.currentFiscalYear}`,
      up: true,
    },
    {
      label: t("kpi.openorders", lang),
      value: String(k.openOrdersCount),
      delta: `${fmtCurrency(k.openOrdersValue)} €`,
      up: k.openOrdersCount > 0,
    },
    {
      label: t("kpi.openinv", lang),
      value: String(k.openInvoicesCount),
      delta: `${fmtCurrency(k.openInvoicesValue)} €`,
      up: k.openInvoicesCount === 0,
    },
    {
      label: t("kpi.stock", lang),
      value: `${fmtCurrency(k.inventoryValue)} €`,
      delta: `GJ ${k.currentFiscalYear}`,
      up: true,
    },
  ];

  return (
    <div className="sw-kpi-view flex h-full flex-col overflow-auto p-4">
      <div className="sw-kpi-grid grid grid-cols-2 gap-4 sm:grid-cols-3">
        {cards.map((card, i) => (
          <div
            key={i}
            className="sw-kpi-card rounded border border-[var(--sw-border)] bg-[var(--sw-bg)] p-4"
          >
            <div
              className="sw-kpi-label mb-1 flex items-center gap-1 text-xs font-medium"
              style={{ color: "var(--sw-text-muted, #6b7280)" }}
            >
              <BarChart3Icon size={12} />
              {card.label}
            </div>
            <div className="sw-kpi-value text-xl font-bold">{card.value}</div>
            <div
              className={`sw-kpi-delta mt-1 flex items-center gap-1 text-xs font-mono${
                card.up ? " text-green-600" : " text-red-600"
              }`}
            >
              {card.up ? <TrendingUpIcon size={12} /> : <TrendingDownIcon size={12} />}
              {card.delta}
            </div>
          </div>
        ))}
      </div>

      {k.topArticleGroups.length > 0 && (
        <div className="mt-6">
          <div className="mb-2 text-sm font-semibold">{t("kpi.section.topgroups", lang)}</div>
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr>
                <th
                  className="border-b border-[var(--sw-border)] px-3 py-2 text-left text-xs font-medium"
                  style={{ color: "var(--sw-text-muted, #6b7280)" }}
                >
                  {t("kpi.col.group", lang)}
                </th>
                <th
                  className="border-b border-[var(--sw-border)] px-3 py-2 text-right text-xs font-medium"
                  style={{ color: "var(--sw-text-muted, #6b7280)" }}
                >
                  {t("kpi.col.revenue", lang)}
                </th>
                <th
                  className="border-b border-[var(--sw-border)] px-3 py-2 text-right text-xs font-medium"
                  style={{ color: "var(--sw-text-muted, #6b7280)" }}
                >
                  {t("kpi.col.profit", lang)}
                </th>
              </tr>
            </thead>
            <tbody>
              {k.topArticleGroups.map((g) => (
                <tr key={g.articleGroupId}>
                  <td className="border-b border-[var(--sw-border)] px-3 py-2">{g.name}</td>
                  <td className="border-b border-[var(--sw-border)] px-3 py-2 text-right font-mono">
                    {fmtCurrency(g.totalAmountNet)} €
                  </td>
                  <td className="border-b border-[var(--sw-border)] px-3 py-2 text-right font-mono">
                    {fmtCurrency(g.totalProfit)} €
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
