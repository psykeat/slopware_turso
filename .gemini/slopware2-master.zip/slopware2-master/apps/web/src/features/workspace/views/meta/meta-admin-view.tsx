import { useQuery, useMutation } from "@tanstack/react-query";
import * as React from "react";

import { getLlmConfigFn, saveLlmConfigFn, testLlmFn } from "../../../../server/server-functions";
import { EntityDataTable } from "../../components/data-table/entity-data-table";
import { useWorkspaceContext } from "../../workspace-context";

export default function AdminSystemView() {
  const { t } = useWorkspaceContext();
  const { data: llmConfig, refetch: refetchLlm } = useQuery({
    queryKey: ["llm-config"],
    queryFn: () => getLlmConfigFn(),
  });

  const saveLlmMutation = useMutation({
    mutationFn: saveLlmConfigFn,
    onSuccess: () => refetchLlm(),
  });

  const [form, setForm] = React.useState({
    endpoint_url: "",
    model: "",
    provider: "",
    api_key: "",
    github_token: "",
    github_repo: "",
    feedback_llm_enabled: true,
  });

  const [testResult, setTestResult] = React.useState<{
    success: boolean;
    content?: string;
    error?: string;
  } | null>(null);
  const [isTesting, setIsTesting] = React.useState(false);

  React.useEffect(() => {
    if (llmConfig) {
      setForm({
        endpoint_url: llmConfig.endpoint_url || "",
        model: llmConfig.model || "",
        provider: llmConfig.provider || "",
        api_key: llmConfig.api_key || "",
        github_token: llmConfig.github_token || "",
        github_repo: llmConfig.github_repo || "",
        feedback_llm_enabled: llmConfig.feedback_llm_enabled ?? true,
      });
    }
  }, [llmConfig]);

  const handleSaveLlm = () => {
    saveLlmMutation.mutate({ data: form });
  };

  const handleTestLlm = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await testLlmFn({
        data: {
          endpoint_url: form.endpoint_url,
          model: form.model,
          provider: form.provider,
          api_key: form.api_key,
        },
      });
      setTestResult(res);
    } catch (e) {
      setTestResult({ success: false, error: String(e) });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div
      className="admin-system-view"
      style={{ display: "flex", flexDirection: "column", gap: 24, padding: 16 }}
    >
      <section className="sw-card" style={{ padding: 16 }}>
        <div className="section-heading" style={{ marginBottom: 12 }}>
          {t("admin.system.users")}
        </div>
        <div
          style={{
            height: 300,
            border: "1px solid var(--border)",
            borderRadius: 8,
            overflow: "hidden",
          }}
        >
          <EntityDataTable entityName="app_user" mode="paginated" t={t} />
        </div>
      </section>

      <section className="sw-card" style={{ padding: 16 }}>
        <div className="section-heading" style={{ marginBottom: 12 }}>
          {t("admin.system.tenants")}
        </div>
        <div
          style={{
            height: 300,
            border: "1px solid var(--border)",
            borderRadius: 8,
            overflow: "hidden",
          }}
        >
          <EntityDataTable entityName="tenant" mode="paginated" t={t} />
        </div>
      </section>

      <section className="sw-card" style={{ padding: 16 }}>
        <div className="section-heading" style={{ marginBottom: 12 }}>
          {t("admin.system.organizations")}
        </div>
        <div
          style={{
            height: 300,
            border: "1px solid var(--border)",
            borderRadius: 8,
            overflow: "hidden",
          }}
        >
          <EntityDataTable entityName="organization" mode="paginated" t={t} />
        </div>
      </section>

      <section className="sw-card" style={{ padding: 16 }}>
        <div className="section-heading" style={{ marginBottom: 12 }}>
          {t("admin.system.connector_definitions")}
        </div>
        <div
          style={{
            height: 300,
            border: "1px solid var(--border)",
            borderRadius: 8,
            overflow: "hidden",
          }}
        >
          <EntityDataTable entityName="connector_definition" mode="paginated" t={t} />
        </div>
      </section>

      <section className="sw-card" style={{ padding: 16 }}>
        <div className="section-heading" style={{ marginBottom: 12 }}>
          {t("admin.system.companies")}
        </div>
        <div
          style={{
            height: 300,
            border: "1px solid var(--border)",
            borderRadius: 8,
            overflow: "hidden",
          }}
        >
          <EntityDataTable entityName="company" mode="paginated" t={t} />
        </div>
      </section>

      <section className="sw-card" style={{ padding: 16 }}>
        <div className="section-heading" style={{ marginBottom: 16 }}>
          {t("admin.system.ai_config")}
        </div>
        <div
          className="detail-grid"
          style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}
        >
          <div className="field-group">
            <label className="detail-field-label">Endpoint URL</label>
            <input
              className="sw-input"
              style={{ width: "100%", marginTop: 4 }}
              value={form.endpoint_url}
              placeholder="https://api.openai.com/v1"
              onChange={(e) => setForm({ ...form, endpoint_url: e.target.value })}
            />
          </div>
          <div className="field-group">
            <label className="detail-field-label">Model</label>
            <input
              className="sw-input"
              style={{ width: "100%", marginTop: 4 }}
              value={form.model}
              placeholder="gpt-4o"
              onChange={(e) => setForm({ ...form, model: e.target.value })}
            />
          </div>
          <div className="field-group">
            <label className="detail-field-label">Provider</label>
            <input
              className="sw-input"
              style={{ width: "100%", marginTop: 4 }}
              value={form.provider}
              placeholder="openai"
              onChange={(e) => setForm({ ...form, provider: e.target.value })}
            />
          </div>
          <div className="field-group">
            <label className="detail-field-label">API Key</label>
            <input
              type="password"
              className="sw-input"
              style={{ width: "100%", marginTop: 4 }}
              value={form.api_key}
              placeholder="sk-..."
              onChange={(e) => setForm({ ...form, api_key: e.target.value })}
            />
          </div>
          <div className="field-group">
            <label className="detail-field-label">GitHub Token (PAT)</label>
            <input
              type="password"
              className="sw-input"
              style={{ width: "100%", marginTop: 4 }}
              value={form.github_token}
              placeholder="ghp_..."
              onChange={(e) => setForm({ ...form, github_token: e.target.value })}
            />
          </div>
          <div className="field-group">
            <label className="detail-field-label">GitHub Repo (owner/repo)</label>
            <input
              className="sw-input"
              style={{ width: "100%", marginTop: 4 }}
              value={form.github_repo}
              placeholder="owner/repo"
              onChange={(e) => setForm({ ...form, github_repo: e.target.value })}
            />
          </div>
          <div
            className="field-group"
            style={{
              gridColumn: "span 2",
              display: "flex",
              alignItems: "center",
              gap: 12,
              marginTop: 8,
            }}
          >
            <input
              type="checkbox"
              id="feedback_llm_enabled"
              checked={form.feedback_llm_enabled}
              onChange={(e) => setForm({ ...form, feedback_llm_enabled: e.target.checked })}
              style={{ width: 18, height: 18, cursor: "pointer" }}
            />
            <label
              htmlFor="feedback_llm_enabled"
              style={{ fontSize: 13, fontWeight: 600, cursor: "pointer" }}
            >
              AI Feedback Analysis (Analyze user reports and logs before creating GitHub issues)
            </label>
          </div>
        </div>

        {testResult && (
          <div
            style={{
              marginTop: 16,
              padding: 12,
              borderRadius: 4,
              background: testResult.success ? "rgba(34, 197, 94, 0.1)" : "rgba(239, 68, 68, 0.1)",
              border: `1px solid ${testResult.success ? "var(--accent)" : "var(--danger)"}`,
              fontSize: 12,
            }}
          >
            <strong>{testResult.success ? "Success" : "Error"}:</strong>{" "}
            {testResult.content || testResult.error}
          </div>
        )}

        <div style={{ marginTop: 16, display: "flex", justifyContent: "flex-end", gap: 12 }}>
          <button
            className="sw-btn"
            onClick={handleTestLlm}
            disabled={isTesting}
            style={{ borderColor: "var(--accent)", color: "var(--accent)" }}
          >
            {isTesting ? "Testing..." : "Test AI Connection"}
          </button>
          <button
            className="sw-btn sw-btn-primary"
            onClick={handleSaveLlm}
            disabled={saveLlmMutation.isPending}
          >
            {saveLlmMutation.isPending ? "Saving..." : "Save AI Config"}
          </button>
        </div>
      </section>
    </div>
  );
}
