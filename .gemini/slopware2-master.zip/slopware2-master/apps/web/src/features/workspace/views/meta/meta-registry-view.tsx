import { ENTITY_REGISTRY, ICONS } from "../../registry";
import { VIEW_REGISTRY } from "../../view-registry";
import { useWorkspaceContext } from "../../workspace-context";

export default function MetaRegistryView() {
  const { t } = useWorkspaceContext();
  return (
    <div style={{ padding: 16 }}>
      <div className="section-heading" style={{ marginBottom: 12 }}>
        {t("reg.title")}
      </div>
      <div style={{ marginBottom: 16, fontSize: 12, color: "var(--text-muted)" }}>
        {t("reg.path")}
      </div>
      <table className="datagrid" style={{ marginBottom: 24 }}>
        <thead>
          <tr>
            <th>{t("reg.col.entity")}</th>
            <th>{t("reg.col.icon")}</th>
            <th>Label (DE/EN)</th>
            <th>Group</th>
            <th>{t("reg.col.paths")}</th>
          </tr>
        </thead>
        <tbody>
          {Object.entries(ENTITY_REGISTRY).map(([k, v]) => (
            <tr key={k}>
              <td className="mono" style={{ fontWeight: 600, color: "var(--accent)" }}>
                {k}
              </td>
              <td>
                <div
                  style={{
                    width: 24,
                    height: 24,
                    background: "var(--bg)",
                    borderRadius: 4,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "var(--text-muted)",
                  }}
                >
                  {ICONS[v.icon]}
                </div>
              </td>
              <td>
                {v.label_de} / {v.label_en}
              </td>
              <td>{v.group}</td>
              <td className="mono" style={{ fontSize: 10.5, color: "var(--text-muted)" }}>
                {Object.entries(v.paths ?? {})
                  .map(([pk, pv]) => `${pk}=[${(pv as string[]).join(",")}]`)
                  .join(" ")}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="section-heading" style={{ marginBottom: 12 }}>
        VIEW_REGISTRY
      </div>
      <table className="datagrid">
        <thead>
          <tr>
            <th>Key</th>
            <th>Entity</th>
            <th>Label (DE/EN)</th>
            <th>Section</th>
          </tr>
        </thead>
        <tbody>
          {VIEW_REGISTRY.map((v, i) => (
            <tr key={i}>
              <td className="mono" style={{ fontWeight: 600 }}>
                {v.key}
              </td>
              <td className="mono" style={{ color: "var(--text-muted)" }}>
                {v.entity ?? "—"}
              </td>
              <td>
                {v.label_de} / {v.label_en}
              </td>
              <td>
                {v.section_de} / {v.section_en}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div
        style={{
          marginTop: 24,
          padding: 12,
          background: "var(--bg)",
          borderRadius: 6,
          fontSize: 12,
          color: "var(--text-muted)",
          border: "1px solid var(--border)",
        }}
      >
        <strong>Architecture Note:</strong> {t("reg.note")}
      </div>
    </div>
  );
}
