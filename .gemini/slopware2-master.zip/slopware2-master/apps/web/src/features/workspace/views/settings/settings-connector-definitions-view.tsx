import { EntityDataTable } from "../../components/data-table/entity-data-table";
import { useWorkspaceContext } from "../../workspace-context";

export default function SettingsConnectorDefinitionsView() {
  const { lang, t } = useWorkspaceContext();

  return (
    <EntityDataTable
      entityName="connector_definition"
      mode="paginated"
      t={t}
      lang={lang as "de" | "en"}
      // fallow-ignore-next-line complexity
      renderRowActions={(row: Record<string, unknown>) => {
        const label = row.label as Record<string, string> | undefined;
        const labelDe = label?.de ?? label?.["de"] ?? "-";
        const labelEn = label?.en ?? label?.["en"] ?? "-";
        return (
          <span className="sw-table-cell" style={{ fontFamily: "var(--font-mono)", fontSize: 11 }}>
            {lang === "de" ? labelDe : labelEn}
          </span>
        );
      }}
    />
  );
}
