import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Lock } from "lucide-react";

import { closePeriodFn } from "../../../../server/server-functions";
import { EntityDataTable } from "../../components/data-table/entity-data-table";
import { useWorkspaceContext } from "../../workspace-context";

export default function SettingsFiscalPeriodView() {
  const { lang, t } = useWorkspaceContext();
  const queryClient = useQueryClient();

  const closeMutation = useMutation({
    mutationFn: (id: string) => closePeriodFn({ data: { fiscalPeriodId: id } }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["entity-list", "fiscal_period"] });
    },
  });

  return (
    <EntityDataTable
      entityName="fiscal_period"
      mode="paginated"
      t={t}
      lang={lang as "de" | "en"}
      renderRowActions={(row: Record<string, unknown>) => {
        const isClosed = !!row.is_closed;
        if (isClosed) return null;
        const fpId = String(row.fiscal_period_id);
        return (
          <button
            className="sw-btn sw-btn-xs sw-btn-danger"
            onClick={(e) => {
              e.stopPropagation();
              closeMutation.mutate(fpId);
            }}
            title={lang === "de" ? "Periode schließen" : "Close period"}
          >
            <Lock size={11} />
            {lang === "de" ? "Schließen" : "Close"}
          </button>
        );
      }}
    />
  );
}
