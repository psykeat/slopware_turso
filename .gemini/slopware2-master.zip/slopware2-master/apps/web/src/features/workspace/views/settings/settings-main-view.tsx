import { useQuery } from "@tanstack/react-query";
import {
  Building2,
  Briefcase,
  Box,
  Coins,
  Globe,
  ChevronRight,
  Plus,
  FileText,
} from "lucide-react";
import React, { useState, useMemo, useCallback } from "react";

import { listEntityFn } from "../../../../server/server-functions";
import { useHotkeyLayer } from "../../../hotkeys/use-hotkey-layer";
import { useScopedHotkey } from "../../../hotkeys/use-scoped-hotkey";
import { CrudDialog } from "../../components/crud-dialog";
import { EntityDataTable } from "../../components/data-table/entity-data-table";
import type { GridRow } from "../../components/grid/grid-types";
import { ENTITY_REGISTRY, ICONS } from "../../registry";
import { useWorkspaceContext } from "../../workspace-context";

// Define the groups and their labels
const GROUPS = {
  organisation: { de: "Organisation", en: "Organisation", icon: <Building2 size={14} /> },
  vertrieb: { de: "Vertrieb", en: "Sales", icon: <Briefcase size={14} /> },
  lager_artikel: { de: "Lager & Artikel", en: "Warehouse & Items", icon: <Box size={14} /> },
  finanzen: { de: "Finanzen", en: "Finance", icon: <Coins size={14} /> },
  geodaten: { de: "Geodaten", en: "Geo Data", icon: <Globe size={14} /> },
} as const;

export default function SettingsView() {
  const { lang, t } = useWorkspaceContext();
  const [selectedEntity, setSelectedEntity] = useState("company");
  const [crudMode, setCrudMode] = useState<"create" | "edit" | "delete" | null>(null);
  const [selectedRow, setSelectedRow] = useState<GridRow | null>(null);

  useHotkeyLayer("settings-nav");

  useScopedHotkey(
    "settings-nav",
    "Ctrl+ArrowDown",
    useCallback(() => {
      const grid = document.querySelector('[role="grid"]') as HTMLElement;
      if (grid) grid.focus();
    }, []),
  );

  useScopedHotkey(
    "settings-nav",
    "Ctrl+ArrowUp",
    useCallback(() => {
      const activeItem = document.querySelector(".tree-item.active") as HTMLElement;
      if (activeItem) {
        activeItem.focus();
      } else {
        const firstItem = document.querySelector(".tree-item") as HTMLElement;
        firstItem?.focus();
      }
    }, []),
  );

  useScopedHotkey(
    "settings-nav",
    "ArrowDown",
    useCallback((e) => {
      e.preventDefault();
      const items = Array.from(document.querySelectorAll(".tree-item")) as HTMLElement[];
      const active = document.activeElement as HTMLElement;
      const index = items.indexOf(active);
      if (index !== -1 && index < items.length - 1) {
        items[index + 1].focus();
      } else if (items.length > 0) {
        items[0].focus();
      }
    }, []),
  );

  useScopedHotkey(
    "settings-nav",
    "ArrowUp",
    useCallback((e) => {
      e.preventDefault();
      const items = Array.from(document.querySelectorAll(".tree-item")) as HTMLElement[];
      const active = document.activeElement as HTMLElement;
      const index = items.indexOf(active);
      if (index > 0) {
        items[index - 1].focus();
      } else if (items.length > 0) {
        items[items.length - 1].focus();
      }
    }, []),
  );

  useScopedHotkey(
    "settings-nav",
    "Enter",
    useCallback((e) => {
      const active = document.activeElement as HTMLElement;
      if (active.classList.contains("tree-item")) {
        active.click();
      }
    }, []),
  );

  const restoreFocus = React.useCallback(() => {
    requestAnimationFrame(() => {
      // 1. Focus the active row to satisfy visual/tabindex expectations
      const activeRow = document.querySelector(".row-active") as HTMLElement;
      if (activeRow) {
        activeRow.focus();
      } else {
        const firstRow = document.querySelector('tr[role="row"]') as HTMLElement;
        if (firstRow) {
          firstRow.focus();
        }
      }

      // 2. Also try to focus the grid container to ensure key events bubble correctly
      const grid = document.querySelector('[role="grid"]') as HTMLElement;
      if (grid) {
        grid.focus();
      }
    });
  }, []);

  const groupedEntities = useMemo(() => {
    const groups: Record<string, string[]> = {
      organisation: [],
      vertrieb: [],
      lager_artikel: [],
      finanzen: [],
      geodaten: [],
    };

    Object.entries(ENTITY_REGISTRY).forEach(([key, entity]: [string, any]) => {
      if (entity.category === "settings" && entity.group && groups[entity.group]) {
        groups[entity.group].push(key);
      }
    });

    return groups;
  }, []);

  // Fetch company data if selected (for pseudo-singleton)
  const { data: companyData, isLoading: isLoadingCompany } = useQuery({
    queryKey: ["entity-list", "company", { limit: 1 }],
    queryFn: () => listEntityFn({ data: { entityName: "company", options: { limit: 1 } } }),
    enabled: selectedEntity === "company",
  });

  const companyRow = companyData?.items?.[0] || null;

  const renderContent = () => {
    if (selectedEntity === "company") {
      if (isLoadingCompany)
        return (
          <div className="pane-empty">
            <div className="pane-empty-text">Lade Firmenstamm...</div>
          </div>
        );

      return (
        <div className="pane" style={{ flex: 1 }}>
          <div className="pane-tabbar">
            <div className="pane-subtab active">
              <span className="icon-mark">{ICONS.factory}</span>
              <span>
                {lang === "en"
                  ? ENTITY_REGISTRY.company.label_en
                  : ENTITY_REGISTRY.company.label_de}
              </span>
            </div>
          </div>
          <div className="pane-body" style={{ background: "var(--bg)" }}>
            <div
              className="detail-view"
              style={{
                maxWidth: "800px",
                margin: "0 auto",
                background: "var(--bg-pane)",
                padding: "30px",
                boxShadow: "var(--shadow-sm)",
                borderRadius: "var(--radius)",
                border: "1px solid var(--border)",
                marginTop: "20px",
              }}
            >
              <div className="detail-header" style={{ marginBottom: "24px" }}>
                <div>
                  <div className="detail-title" style={{ color: "var(--text-primary)" }}>
                    {lang === "en"
                      ? ENTITY_REGISTRY.company.label_en
                      : ENTITY_REGISTRY.company.label_de}
                  </div>
                  <div className="detail-subtitle">
                    {lang === "en"
                      ? "Manage your company master data"
                      : "Verwalten Sie Ihre Firmenstammdaten"}
                  </div>
                </div>
              </div>

              {companyRow || !isLoadingCompany ? (
                <CrudDialog
                  entityName="company"
                  mode={companyRow ? "edit" : "create"}
                  row={companyRow as GridRow}
                  lang={lang as any}
                  onClose={() => {}}
                  inline={true}
                />
              ) : (
                <div className="pane-empty">
                  <div className="pane-empty-icon">⚠️</div>
                  <div className="pane-empty-text">
                    {lang === "en" ? "No company record found." : "Kein Firmendatensatz gefunden."}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      );
    }

    // Standard list for other entities
    return (
      <div className="pane" style={{ flex: 1 }}>
        <div className="pane-tabbar">
          <div className="pane-subtab active">
            <span className="icon-mark">
              {ICONS[ENTITY_REGISTRY[selectedEntity].icon] || <FileText size={14} />}
            </span>
            <span>
              {lang === "en"
                ? ENTITY_REGISTRY[selectedEntity].label_en
                : ENTITY_REGISTRY[selectedEntity].label_de}
            </span>
          </div>
          <div className="pane-actions">
            <button
              className="pane-action-btn"
              style={{
                width: "auto",
                padding: "0 10px",
                gap: "4px",
                fontSize: "11px",
                color: "var(--accent)",
                fontWeight: 600,
              }}
              onClick={() => {
                setSelectedRow(null);
                setCrudMode("create");
              }}
            >
              <Plus size={12} />
              {t("list.new")}
            </button>
          </div>
        </div>
        <div className="pane-body">
          <EntityDataTable
            entityName={selectedEntity}
            mode="paginated"
            onRowClick={(row) => {
              setSelectedRow(row as GridRow);
              setCrudMode("edit");
            }}
            t={t}
          />
        </div>

        {crudMode && (
          <CrudDialog
            entityName={selectedEntity}
            mode={crudMode}
            row={selectedRow as any}
            lang={lang as any}
            onClose={() => {
              setCrudMode(null);
              setSelectedRow(null);
              restoreFocus();
            }}
          />
        )}
      </div>
    );
  };

  return (
    <div style={{ display: "flex", height: "100%", gap: "1px", background: "var(--border)" }}>
      {/* Sidebar */}
      <div className="pane" style={{ width: "220px", flexShrink: 0 }}>
        <div className="pane-tabbar">
          <div className="pane-subtab active">
            <span>{t("einstellungen")}</span>
          </div>
        </div>
        <div className="pane-body" style={{ background: "var(--bg)" }}>
          <div className="tree-list" tabIndex={-1}>
            {Object.entries(GROUPS).map(([groupId, groupInfo]) => (
              <React.Fragment key={groupId}>
                <div className="tree-item group">
                  <span className="tree-icon" style={{ color: "var(--accent)" }}>
                    {groupInfo.icon}
                  </span>
                  {lang === "en" ? groupInfo.en : groupInfo.de}
                </div>
                {groupedEntities[groupId]?.map((entityKey) => {
                  const entity = ENTITY_REGISTRY[entityKey];
                  const isActive = selectedEntity === entityKey;
                  return (
                    <div
                      key={entityKey}
                      onClick={() => setSelectedEntity(entityKey)}
                      tabIndex={-1}
                      className={`tree-item ${isActive ? "active" : ""}`}
                      style={{ paddingLeft: "24px" }}
                    >
                      <span className="tree-icon">
                        {ICONS[entity.icon] || <FileText size={14} />}
                      </span>
                      <span
                        style={{
                          flex: 1,
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          whiteSpace: "nowrap",
                        }}
                      >
                        {lang === "en" ? entity.label_en : entity.label_de}
                      </span>
                      {isActive && <ChevronRight size={10} style={{ opacity: 0.5 }} />}
                    </div>
                  );
                })}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      {/* Content Area */}
      {renderContent()}
    </div>
  );
}
