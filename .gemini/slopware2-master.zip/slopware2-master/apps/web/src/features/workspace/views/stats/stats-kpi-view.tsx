import { useQuery } from "@tanstack/react-query";
import { BarChart3Icon, TrendingDownIcon, TrendingUpIcon } from "lucide-react";

import { getDashboardKpisFn } from "../../../../server/server-functions";
import { t, type Lang } from "../../i18n";
import { useWorkspaceContext } from "../../workspace-context";

type KpiCard = {
  label: string;
  value: string;
  delta: string;
  up: boolean;
};

function fmtCurrency(n: number): string {
  return n.toLocaleString("de-DE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function yoyDelta(current: number, prior: number): string {
  if (prior === 0) return current > 0 ? "+∞%" : "—";
  const pct = ((current - prior) / Math.abs(prior)) * 100;
  return `${pct >= 0 ? "+" : ""}${pct.toFixed(1)}%`;
}

function StatsKpiView() {
  const { lang } = useWorkspaceContext();
  const lng = lang as Lang;
  const { data, isLoading } = useQuery({
    queryKey: ["dashboardKpis"],
    queryFn: () => getDashboardKpisFn(),
  });

  if (isLoading) {
    return (
      <div className="sw-kpi-view flex h-full items-center justify-center">
        <div style={{ color: "var(--sw-text-muted, #6b7280)", fontSize: 13 }}>
          {t("kpi.loading", lng)}
        </div>
      </div>
    );
  }

  const k = data;
  if (!k) {
    return (
      <div className="sw-kpi-view flex h-full items-center justify-center">
        <div style={{ color: "var(--sw-text-muted, #6b7280)", fontSize: 13 }}>
          No KPI data available
        </div>
      </div>
    );
  }
  const umsatzDelta = yoyDelta(k.umsatzCurrent, k.umsatzPrior);
  const rohertragDelta = yoyDelta(k.rohertragCurrent, k.rohertragPrior);

  const cards: KpiCard[] = [
    {
      label: t("kpi.umsatz.current", lng),
      value: `${fmtCurrency(k.umsatzCurrent)} €`,
      delta: `${umsatzDelta} ${t("kpi.yoy", lng)}`,
      up: k.umsatzCurrent >= k.umsatzPrior,
    },
    {
      label: t("kpi.rohertrag.current", lng),
      value: `${fmtCurrency(k.rohertragCurrent)} €`,
      delta: `${rohertragDelta} ${t("kpi.yoy", lng)}`,
      up: k.rohertragCurrent >= k.rohertragPrior,
    },
    {
      label: t("kpi.openorders", lng),
      value: String(k.openOrdersCount),
      delta: `${fmtCurrency(k.openOrdersValue)} €`,
      up: k.openOrdersCount > 0,
    },
    {
      label: t("kpi.openinv", lng),
      value: String(k.openInvoicesCount),
      delta: `${fmtCurrency(k.openInvoicesValue)} €`,
      up: k.openInvoicesCount === 0,
    },
    {
      label: t("kpi.stock", lng),
      value: `${fmtCurrency(k.inventoryValue)} €`,
      delta: `GJ ${k.fiscalYear}`,
      up: true,
    },
  ];

  return (
    <div className="sw-kpi-view flex h-full flex-col overflow-auto p-4">
      <div className="sw-kpi-grid grid grid-cols-2 gap-4 sm:grid-cols-3">
        {cards.map((card, i) => (
          <div
            key={i}
            className="sw-kpi-card rounded border border-[var(--sw-border)] bg-[var(--sw-bg)] p-4"
          >
            <div
              className="sw-kpi-label mb-1 flex items-center gap-1 text-xs font-medium"
              style={{ color: "var(--sw-text-muted, #6b7280)" }}
            >
              <BarChart3Icon size={12} />
              {card.label}
            </div>
            <div className="sw-kpi-value text-xl font-bold">{card.value}</div>
            <div
              className={`sw-kpi-delta mt-1 flex items-center gap-1 text-xs font-mono${
                card.up ? " text-green-600" : " text-red-600"
              }`}
            >
              {card.up ? <TrendingUpIcon size={12} /> : <TrendingDownIcon size={12} />}
              {card.delta}
            </div>
          </div>
        ))}
      </div>
      {k.topArticleGroups.length > 0 && (
        <div className="mt-6">
          <div className="mb-2 text-sm font-semibold">{t("kpi.section.topgroups", lng)}</div>
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr>
                <th
                  className="border-b border-[var(--sw-border)] px-3 py-2 text-left text-xs font-medium"
                  style={{ color: "var(--sw-text-muted, #6b7280)" }}
                >
                  {t("kpi.col.group", lng)}
                </th>
                <th
                  className="border-b border-[var(--sw-border)] px-3 py-2 text-right text-xs font-medium"
                  style={{ color: "var(--sw-text-muted, #6b7280)" }}
                >
                  {t("kpi.col.revenue", lng)}
                </th>
                <th
                  className="border-b border-[var(--sw-border)] px-3 py-2 text-right text-xs font-medium"
                  style={{ color: "var(--sw-text-muted, #6b7280)" }}
                >
                  {t("kpi.col.profit", lng)}
                </th>
              </tr>
            </thead>
            <tbody>
              {k.topArticleGroups.map(
                (g: {
                  articleGroupId: string;
                  name: string;
                  totalAmountNet: number;
                  totalProfit: number;
                }) => (
                  <tr key={g.articleGroupId}>
                    <td className="border-b border-[var(--sw-border)] px-3 py-2">{g.name}</td>
                    <td className="border-b border-[var(--sw-border)] px-3 py-2 text-right font-mono">
                      {fmtCurrency(g.totalAmountNet)} €
                    </td>
                    <td className="border-b border-[var(--sw-border)] px-3 py-2 text-right font-mono">
                      {fmtCurrency(g.totalProfit)} €
                    </td>
                  </tr>
                ),
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export { StatsKpiView };
export default StatsKpiView;
