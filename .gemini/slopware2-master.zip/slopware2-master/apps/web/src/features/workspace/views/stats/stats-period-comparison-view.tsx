import { useQuery } from "@tanstack/react-query";
import { BarChart3Icon, ChevronDownIcon, TrendingUpIcon } from "lucide-react";
import { useState } from "react";

import { getPeriodComparisonStatsFn, getFiscalYearsFn } from "../../../../server/server-functions";
import type { PeriodComparisonRow } from "../../../../server/server-functions";
import { t, type Lang } from "../../i18n";
import { useWorkspaceContext } from "../../workspace-context";

function fmtCurrency(n: number): string {
  return n.toLocaleString("de-DE", { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

function PeriodComparisonView() {
  const { lang } = useWorkspaceContext();
  const lng = lang as Lang;
  const [showYoy, setShowYoy] = useState(false);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  const { data: years, isLoading: yearsLoading } = useQuery({
    queryKey: ["fiscalYears"],
    queryFn: () => getFiscalYearsFn(),
  });

  const { data, isLoading: statsLoading } = useQuery({
    queryKey: ["periodComparison", selectedYear],
    queryFn: () => getPeriodComparisonStatsFn({ data: { fiscalYear: selectedYear } }),
  });

  if (yearsLoading || statsLoading) {
    return (
      <div className="sw-period-comparison flex h-full items-center justify-center">
        <div style={{ color: "var(--sw-text-muted)", fontSize: 13 }}>
          {t("period.loading", lng)}
        </div>
      </div>
    );
  }

  const stats = data!;
  const allPeriods = Array.from({ length: 12 }, (_, i) => i + 1);

  const maxVal = Math.max(
    ...stats.currentYear.map((r) => Math.max(r.totalAmountNet, r.totalProfit)),
    ...(showYoy && stats.priorYearData.length
      ? stats.priorYearData.map((r) => Math.max(r.totalAmountNet, r.totalProfit))
      : [0]),
  );

  const getPriorRow = (pn: number): PeriodComparisonRow | undefined =>
    stats.priorYearData.find((r) => r.periodNo === pn);

  return (
    <div className="sw-period-comparison flex h-full flex-col overflow-auto p-4">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BarChart3Icon size={14} style={{ color: "var(--sw-text-muted)" }} />
          <span className="text-sm font-semibold">{t("period.title", lng)}</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <select
              className="appearance-none rounded border border-[var(--sw-border)] bg-[var(--sw-bg)] px-2 py-1 pr-6 text-xs"
              value={selectedYear}
              onChange={(e) => setSelectedYear(Number(e.target.value))}
            >
              {years?.map((yr) => (
                <option key={yr.fiscalYear} value={yr.fiscalYear}>
                  {yr.label}
                </option>
              ))}
            </select>
            <ChevronDownIcon
              size={10}
              className="pointer-events-none absolute top-2 right-1.5"
              style={{ color: "var(--sw-text-muted)" }}
            />
          </div>
          <button
            className={`rounded border px-2 py-1 text-xs font-medium transition-colors ${
              showYoy
                ? "border-[var(--sw-accent)] bg-[var(--sw-accent)] text-white"
                : "border-[var(--sw-border)] bg-[var(--sw-bg)]"
            }`}
            style={{ color: showYoy ? "white" : "var(--sw-text-primary)" }}
            onClick={() => setShowYoy((v) => !v)}
          >
            <TrendingUpIcon size={10} className="mr-1 inline" />
            {t("period.yoy", lng)}
          </button>
        </div>
      </div>

      <div className="mb-3 flex gap-4 text-xs" style={{ color: "var(--sw-text-muted)" }}>
        <span className="flex items-center gap-1">
          <span
            className="inline-block h-2 w-2 rounded-sm"
            style={{ background: "var(--sw-accent)" }}
          />
          {t("period.umsatz", lng)}
        </span>
        <span className="flex items-center gap-1">
          <span
            className="inline-block h-2 w-2 rounded-sm"
            style={{ background: "var(--sw-accent-dark, #1d4ed8)" }}
          />
          {t("period.rohertrag", lng)}
        </span>
        {showYoy && stats.priorYearData.length > 0 && (
          <span className="flex items-center gap-1">
            <span
              className="inline-block h-2 w-2 rounded-sm opacity-40"
              style={{ background: "var(--sw-accent)" }}
            />
            {t("period.prioryear", lng)} {stats.priorYear}
          </span>
        )}
      </div>

      {!stats.currentYear.length && (
        <div className="flex flex-1 items-center justify-center">
          <div style={{ color: "var(--sw-text-muted)", fontSize: 13 }}>
            {t("period.empty", lng)}
          </div>
        </div>
      )}

      {stats.currentYear.length > 0 && (
        <div className="sw-period-chart flex flex-1 items-end gap-1" style={{ minHeight: 200 }}>
          {allPeriods.map((pn) => {
            const cur = stats.currentYear.find((r) => r.periodNo === pn);
            const pri = showYoy ? getPriorRow(pn) : undefined;
            const curNet = cur?.totalAmountNet ?? 0;
            const curProfit = cur?.totalProfit ?? 0;
            const priNet = pri?.totalAmountNet ?? 0;
            const hNet = maxVal > 0 ? (curNet / maxVal) * 100 : 0;
            const hProfit = maxVal > 0 ? (curProfit / maxVal) * 100 : 0;
            const hPriNet = maxVal > 0 ? (priNet / maxVal) * 100 : 0;

            return (
              <div key={pn} className="flex flex-1 flex-col items-center gap-0.5">
                <div
                  className="flex w-full items-end justify-center gap-px"
                  style={{ height: 180 }}
                >
                  {showYoy && pri && (
                    <div
                      className="w-2 rounded-t opacity-30"
                      style={{ height: `${hPriNet}%`, background: "var(--sw-accent)" }}
                    />
                  )}
                  <div
                    className="w-2 rounded-t"
                    style={{ height: `${hNet}%`, background: "var(--sw-accent)" }}
                    title={`${t("period.umsatz", lng)}: ${fmtCurrency(curNet)}`}
                  />
                  <div
                    className="w-2 rounded-t"
                    style={{ height: `${hProfit}%`, background: "var(--sw-accent-dark, #1d4ed8)" }}
                    title={`${t("period.rohertrag", lng)}: ${fmtCurrency(curProfit)}`}
                  />
                </div>
                <div
                  className="text-center font-mono"
                  style={{ fontSize: 9.5, color: "var(--sw-text-muted)" }}
                >
                  {pn}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {stats.currentYear.length > 0 && (
        <table className="mt-4 w-full border-collapse text-xs">
          <thead>
            <tr>
              <th
                className="border-b border-[var(--sw-border)] px-2 py-1 text-left font-medium"
                style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
              >
                {t("period.period", lng)}
              </th>
              {showYoy && stats.priorYearData.length > 0 && (
                <>
                  <th
                    className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
                    style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
                  >
                    {t("period.umsatz", lng)} {stats.priorYear}
                  </th>
                  <th
                    className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
                    style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
                  >
                    {t("period.rohertrag", lng)} {stats.priorYear}
                  </th>
                </>
              )}
              <th
                className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
                style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
              >
                {t("period.umsatz", lng)}
              </th>
              <th
                className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-medium"
                style={{ color: "var(--sw-text-muted)", fontSize: 9.5 }}
              >
                {t("period.rohertrag", lng)}
              </th>
            </tr>
          </thead>
          <tbody>
            {allPeriods.map((pn) => {
              const cur = stats.currentYear.find((r) => r.periodNo === pn);
              const pri = getPriorRow(pn);
              return (
                <tr key={pn}>
                  <td className="border-b border-[var(--sw-border)] px-2 py-1 font-mono">{pn}</td>
                  {showYoy && stats.priorYearData.length > 0 && (
                    <>
                      <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono opacity-50">
                        {pri ? fmtCurrency(pri.totalAmountNet) : "—"}
                      </td>
                      <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono opacity-50">
                        {pri ? fmtCurrency(pri.totalProfit) : "—"}
                      </td>
                    </>
                  )}
                  <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
                    {cur ? fmtCurrency(cur.totalAmountNet) : "—"}
                  </td>
                  <td className="border-b border-[var(--sw-border)] px-2 py-1 text-right font-mono">
                    {cur ? fmtCurrency(cur.totalProfit) : "—"}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
}

export { PeriodComparisonView };
export default PeriodComparisonView;
