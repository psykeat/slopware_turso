import { Info } from "lucide-react";
import { useState } from "react";

import type { Lang } from "../i18n";
import { t } from "../i18n";

export type DocTreeItem = {
  key: string;
  label_de: string;
  label_en: string;
  count: number;
  groupId?: string;
  docType?: string;
  defaultGroupId?: string;
  items?: DocTreeItem[];
};

export type DocTreeCategory = {
  key: string;
  label_de: string;
  label_en: string;
  items: DocTreeItem[];
};

type Props = {
  data: DocTreeCategory[];
  activeKey: string;
  onPick?: (item: {
    key: string;
    docType?: string;
    groupId?: string;
    defaultGroupId?: string;
  }) => void;
  lang: Lang;
};

export function TreeView({ data, activeKey, onPick, lang }: Props) {
  const isEn = lang === "en";
  const [collapsedKeys, setCollapsedKeys] = useState<Set<string>>(new Set());

  const toggle = (key: string) => {
    setCollapsedKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  if (data.length === 0) {
    return (
      <div className="sw-pane-empty flex flex-1 items-center justify-center">
        <div className="flex flex-col items-center gap-2">
          <div className="sw-pane-empty-icon">
            <Info size={32} />
          </div>
          <div style={{ fontSize: 12.5, color: "var(--sw-text-muted, #6b7280)" }}>
            {t("tree.noitems", lang)}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="sw-tree-view flex h-full flex-col overflow-auto p-3">
      <ul className="sw-tree-list flex flex-col gap-0.5">
        {data.map((cat) => (
          <li key={cat.key} className="flex flex-col gap-0.5">
            {/* Level 1: Category */}
            <div
              className="mt-2 mb-1 flex cursor-pointer items-center gap-1.5 px-1 py-0.5 text-[10px] font-bold tracking-tight text-gray-400 uppercase"
              onClick={() => toggle(cat.key)}
            >
              <span className="sw-tree-chevron" style={{ fontSize: 8 }}>
                {collapsedKeys.has(cat.key) ? "▶" : "▼"}
              </span>
              {isEn ? cat.label_en : cat.label_de}
            </div>

            {!collapsedKeys.has(cat.key) && (
              <ul className="flex flex-col gap-px">
                {cat.items.map((type) => {
                  const isTypeSelected = activeKey === type.key;
                  const hasSubGroups = (type.items?.length ?? 0) > 0;
                  const isTypeCollapsed = collapsedKeys.has(type.key);

                  return (
                    <li key={type.key} className="flex flex-col gap-px">
                      {/* Level 2: Document Type (Hauptast) */}
                      <div
                        className={`flex cursor-pointer items-center gap-1.5 rounded px-2 py-1 text-[13px] ${
                          isTypeSelected
                            ? "bg-blue-50/50 font-semibold text-blue-600"
                            : "text-gray-700 hover:bg-gray-100/50"
                        }`}
                        onClick={() => {
                          onPick?.({
                            key: type.key,
                            docType: type.docType,
                            defaultGroupId: type.defaultGroupId,
                          });
                        }}
                      >
                        <span
                          className="sw-tree-chevron text-gray-400"
                          style={{ fontSize: 8, opacity: hasSubGroups ? 1 : 0 }}
                          onClick={(e) => {
                            if (hasSubGroups) {
                              e.stopPropagation();
                              toggle(type.key);
                            }
                          }}
                        >
                          {isTypeCollapsed ? "▶" : "▼"}
                        </span>
                        <span className="flex-1 truncate">
                          {isEn ? type.label_en : type.label_de}
                        </span>
                        {type.count > 0 && (
                          <span className="sw-tree-count font-mono text-[9px] opacity-40">
                            {type.count}
                          </span>
                        )}
                      </div>

                      {/* Level 3: Document Groups 01-99 */}
                      {!isTypeCollapsed && hasSubGroups && (
                        <ul className="flex flex-col gap-px pl-4">
                          {type.items?.map((group) => {
                            const isGroupSelected = activeKey === group.key;
                            return (
                              <li
                                key={group.key}
                                className={`flex cursor-pointer items-center gap-2 rounded px-2 py-0.5 text-[12px] ${
                                  isGroupSelected
                                    ? "bg-blue-50/50 font-medium text-blue-500"
                                    : "text-gray-500 hover:bg-gray-100/50"
                                }`}
                                onClick={() =>
                                  onPick?.({
                                    key: group.key,
                                    groupId: group.groupId,
                                    docType: group.docType,
                                  })
                                }
                              >
                                <span className="flex-1 truncate">
                                  {isEn ? group.label_en : group.label_de}
                                </span>
                                {group.count > 0 && (
                                  <span className="sw-tree-count font-mono text-[8px] opacity-30">
                                    {group.count}
                                  </span>
                                )}
                              </li>
                            );
                          })}
                        </ul>
                      )}
                    </li>
                  );
                })}
              </ul>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
