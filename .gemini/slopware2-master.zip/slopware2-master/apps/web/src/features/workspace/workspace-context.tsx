import React, { createContext, useContext } from "react";

export type SelectedRow = Record<string, unknown>;

export interface WorkspaceContextValue {
  selectedAddress: SelectedRow | null;
  selectedDocument: SelectedRow | null;
  selectedArticle: SelectedRow | null;
  selectedArticleGroup: SelectedRow | null;
  docFilter: string;
  currentTenant: any;
  t: (k: string, vars?: Record<string, string>) => string;
  setSelected: (entity: string | null, row: SelectedRow | null) => void;
  setDocFilter: (f: string) => void;
  applyLayout: (kind: string) => void;
  lang: string;
  toast: (msg: string) => void;
}

export const WorkspaceContext = createContext<WorkspaceContextValue | null>(null);

export function useWorkspaceContext() {
  const ctx = useContext(WorkspaceContext);
  if (!ctx) throw new Error("Missing WorkspaceContext.Provider");
  return ctx;
}
