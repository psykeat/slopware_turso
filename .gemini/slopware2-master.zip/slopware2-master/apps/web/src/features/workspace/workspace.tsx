import { signOut } from "@repo/auth/auth-client";
import { useQuery } from "@tanstack/react-query";

import "./workspace-design.css";
import { MessageSquare } from "lucide-react";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { logger } from "~/lib/logger";
import { getCurrentUserFn, listUserTenantsFn, getTenantFn } from "~/server/server-functions";

import { useHotkeyLayer } from "../hotkeys/use-hotkey-layer";
import { useScopedHotkey } from "../hotkeys/use-scoped-hotkey";
import {
  FeedbackModal,
  captureFeedbackSnapshot,
  type FeedbackSnapshot,
} from "./components/feedback-modal";
import { HotkeyCheatsheet } from "./components/hotkey-cheatsheet";
import { StatisticsDrawer } from "./components/statistics-drawer";
import { ICONS, ENTITY_REGISTRY } from "./registry";
import { VIEW_REGISTRY } from "./view-registry";
import { resolveView } from "./view-resolver";
import {
  WorkspaceContext,
  useWorkspaceContext,
  type WorkspaceContextValue,
  type SelectedRow,
} from "./workspace-context";
import { WORKSPACES } from "./workspace-presets";

/* ════════════════════════════════════════════════════════════
   I18N
   ════════════════════════════════════════════════════════════ */

const I18N: Record<string, Record<string, string>> = {
  de: {
    "app.module": "MANDANT",
    "app.user": "Max Kellner",
    "app.tenant.name": "SLOPware DE GmbH",
    "app.tenant.alt": "SLOPware AT GmbH",
    "header.theme.title": "Farbthema",
    "header.lightmode": "Heller Modus",
    "header.darkmode": "Dunkler Modus",
    "header.notifications": "Benachrichtigungen",
    "header.menu": "Menü",
    "header.language": "Sprache",
    "menu.tenant": "Mandant",
    "menu.user.settings": "Benutzereinstellungen",
    "menu.profile": "Profil bearbeiten",
    "menu.logout": "Abmelden",
    "menu.admin": "System-Administrator-Panel",
    "urlbar.deeplink": "deep-linkbar · reload-stabil",
    "layout.label": "Layout",
    "layout.1pane": "1-Pane",
    "layout.2pane": "2-Pane",
    "layout.3pane": "3-Pane",
    "layout.tip": "Tipp: Artikel aus rechtem Pane → Belegpositionen ziehen (Drag & Drop)",
    "pane.open": "Ansicht in diesem Pane öffnen",
    "pane.add": "Ansicht öffnen",
    "pane.split": "Pane teilen (vertikal)",
    "pane.close": "Pane schließen",
    "pane.empty.noview": "Keine Ansicht ausgewählt",
    "pane.empty.norenderer": "Renderer für {key} fehlt",
    "list.search": "Suchen…",
    "list.filter": "Filter",
    "list.columns": "Spalten",
    "list.new": "Neu",
    "list.entries": "Einträge",
    "list.selected": "1 selektiert",
    "detail.edit": "Bearbeiten",
    "detail.book": "Buchen",
    "detail.create.doc": "Beleg erstellen",
    "addr.field.nr": "Adressnummer",
    "addr.field.type": "Typ",
    "addr.field.status": "Status",
    "addr.field.plzort": "PLZ / Ort",
    "addr.field.country": "Land",
    "addr.field.contact": "Kontakt",
    "addr.section.master": "Stammdaten",
    "addr.section.revenue": "Umsatz & Bewegung",
    "addr.section.links": "Verknüpfungen",
    "addr.field.ytd": "Umsatz YTD",
    "addr.field.openitems": "Offene Posten",
    "addr.field.lastdoc": "Letzter Beleg",
    "addr.field.payterms": "Zahlungsverh.",
    "addr.field.payterms.value": "⌀ 14 Tage",
    "addr.empty": "Keine Adresse ausgewählt",
    "addr.links.orders": "Aufträge (12)",
    "addr.links.deliveries": "Lieferscheine (8)",
    "addr.links.invoices": "Rechnungen (21)",
    "addr.links.notes": "Notizen (3)",
    "doc.field.nr": "Belegnummer",
    "doc.field.type": "Belegart",
    "doc.field.date": "Datum",
    "doc.field.customer": "Kunde",
    "doc.field.total": "Gesamtbetrag",
    "doc.field.tenant": "Mandant",
    "doc.empty": "Kein Beleg ausgewählt",
    "doc.lines.title": "Positionen",
    "doc.lines.add": "Position",
    "doc.lines.empty": "Keine Positionen — Artikel per Drag & Drop hinzufügen",
    "doc.lines.count": "Positionen",
    "col.nr": "Nr.",
    "col.name": "Name",
    "col.city": "Ort",
    "col.type": "Typ",
    "col.revenue": "Umsatz",
    "col.status": "Status",
    "col.artnr": "Art-Nr.",
    "col.descr": "Bezeichnung",
    "col.unit": "EH",
    "col.stock": "Bestand",
    "col.price": "EP",
    "col.docnr": "Beleg-Nr.",
    "col.date": "Datum",
    "col.customer": "Kunde",
    "col.amount": "Betrag",
    "col.delivnr": "Lieferschein",
    "col.recipient": "Empfänger",
    "col.carrier": "Carrier",
    "col.tracking": "Tracking",
    "col.warehouse": "Lager",
    "col.reserved": "Reserviert",
    "col.available": "Verfügbar",
    "col.docref": "Beleg",
    "col.account": "Konto",
    "col.bookingtext": "Buchungstext",
    "col.debit": "Soll",
    "col.credit": "Haben",
    "col.kst": "KST",
    "col.budget": "Budget",
    "col.actual": "Ist",
    "col.variance": "Abweichung",
    "col.fanr": "FA-Nr.",
    "col.article": "Artikel",
    "col.qty": "Menge",
    "col.start": "Start",
    "col.end": "Ende",
    "col.pos": "Pos",
    "col.total": "Gesamt",
    "col.key": "Key",
    "col.value": "Wert",
    "col.scope": "Scope",
    "kpi.section.insights": "KI-Insights · Live",
    "kpi.umsatz": "Umsatz (Mai)",
    "kpi.openorders": "Offene Aufträge",
    "kpi.openinv": "Offene Rechnungen",
    "kpi.stock": "Lagerbestand",
    "kpi.tenants": "Aktive Mandanten",
    "kpi.aisuggest": "KI-Vorschläge",
    "kpi.delta.today": "+3 heute",
    "kpi.delta.docs": "8 Belege",
    "kpi.delta.unchanged": "unverändert",
    "kpi.delta.openai": "+5 offen",
    "kpi.insight1.text": "3 Artikel nähern sich dem Meldepunkt",
    "kpi.insight1.action": "Bestellvorschlag öffnen",
    "kpi.insight2.text": "Umsatz Müller GmbH +34% MoM",
    "kpi.insight2.action": "Adresse öffnen",
    "kpi.insight3.text": "2 Lieferungen verzögert (> 3 Tage)",
    "kpi.insight3.action": "Lieferung öffnen",
    "reg.title": "Entity Registry",
    "reg.path":
      "packages/domain/registry/entities.ts · Q=queries · C=commands · L=lookups · I=imports",
    "reg.col.entity": "Entity",
    "reg.col.icon": "Icon",
    "reg.col.paths": "Pfade",
    "reg.note":
      "Jeder Pane bindet eine Registry-View. Die UI ruft niemals SQL — sie fordert eine Entity-View an, und die Domain-Schicht orchestriert den Server-Function-Aufruf gegen PostgreSQL (mit Tenant-RLS).",
    "status.connected": "verbunden",
    "status.tenant": "Mandant",
    "status.user": "Benutzer",
    "status.workspace": "Arbeitsbereich",
    "status.pane.one": "Pane",
    "status.pane.many": "Panes",
    "admin.system.users": "System-Benutzer",
    "admin.system.tenants": "Mandanten",
    "admin.system.organizations": "Organisationen",
    "admin.system.connector_definitions": "Konnektor-Definitionen",
    "admin.system.companies": "Firmen",
    "admin.system.ai_config": "KI-Konfiguration",
    "cheatsheet.title": "Tastenkürzel",
    "cheatsheet.empty": "Keine Kürzel registriert",
    "cheatsheet.close": "? oder Esc zum Schließen",
    "stats.drawer.title": "Statistik",
    "stats.drawer.noentity": "Keine Entität ausgewählt — wählen Sie einen Datensatz aus",
    "stats.entity.address": "Adresse",
    "stats.entity.document": "Beleg",
    "stats.entity.article": "Artikel",
    "stats.entity.article_group": "Artikelgruppe",
    "stats.address.documents": "Dokumente & Umsatz",
    "stats.article.inventory": "Lagerbestand",
    "stats.document.info": "Belegstatistik wird vorbereitet",
    "stats.articlegroup.info": "Gruppenstatistik wird vorbereitet",
  },
  en: {
    "app.module": "TENANT",
    "app.user": "Max Kellner",
    "app.tenant.name": "SLOPware DE GmbH",
    "app.tenant.alt": "SLOPware AT GmbH",
    "header.theme.title": "Color theme",
    "header.lightmode": "Light mode",
    "header.darkmode": "Dark mode",
    "header.notifications": "Notifications",
    "header.menu": "Menu",
    "header.language": "Language",
    "menu.tenant": "Tenant",
    "menu.user.settings": "User settings",
    "menu.profile": "Edit profile",
    "menu.logout": "Sign out",
    "menu.admin": "System Admin Panel",
    "urlbar.deeplink": "deep-linkable · reload-stable",
    "layout.label": "Layout",
    "layout.1pane": "1-Pane",
    "layout.2pane": "2-Pane",
    "layout.3pane": "3-Pane",
    "layout.tip": "Tip: drag articles from right pane → document lines (drag & drop)",
    "pane.open": "Open view in this pane",
    "pane.add": "Open view",
    "pane.split": "Split pane (vertical)",
    "pane.close": "Close pane",
    "pane.empty.noview": "No view selected",
    "pane.empty.norenderer": "No renderer for {key}",
    "list.search": "Search…",
    "list.filter": "Filter",
    "list.columns": "Columns",
    "list.new": "New",
    "list.entries": "entries",
    "list.selected": "1 selected",
    "detail.edit": "Edit",
    "detail.book": "Post",
    "detail.create.doc": "Create document",
    "addr.field.nr": "Address No.",
    "addr.field.type": "Type",
    "addr.field.status": "Status",
    "addr.field.plzort": "ZIP / City",
    "addr.field.country": "Country",
    "addr.field.contact": "Contact",
    "addr.section.master": "Master data",
    "addr.section.revenue": "Revenue & activity",
    "addr.section.links": "Linked records",
    "addr.field.ytd": "Revenue YTD",
    "addr.field.openitems": "Open items",
    "addr.field.lastdoc": "Last document",
    "addr.field.payterms": "Payment terms",
    "addr.field.payterms.value": "⌀ 14 days",
    "addr.empty": "No address selected",
    "addr.links.orders": "Orders (12)",
    "addr.links.deliveries": "Delivery notes (8)",
    "addr.links.invoices": "Invoices (21)",
    "addr.links.notes": "Notes (3)",
    "doc.field.nr": "Document No.",
    "doc.field.type": "Document type",
    "doc.field.date": "Date",
    "doc.field.customer": "Customer",
    "doc.field.total": "Total",
    "doc.field.tenant": "Tenant",
    "doc.empty": "No document selected",
    "doc.lines.title": "Lines",
    "doc.lines.add": "Line",
    "doc.lines.empty": "No lines — drag & drop articles to add",
    "doc.lines.count": "lines",
    "col.nr": "No.",
    "col.name": "Name",
    "col.city": "City",
    "col.type": "Type",
    "col.revenue": "Revenue",
    "col.status": "Status",
    "col.artnr": "Art. No.",
    "col.descr": "Description",
    "col.unit": "Unit",
    "col.stock": "Stock",
    "col.price": "Price",
    "col.docnr": "Doc. No.",
    "col.date": "Date",
    "col.customer": "Customer",
    "col.amount": "Amount",
    "col.delivnr": "Delivery No.",
    "col.recipient": "Recipient",
    "col.carrier": "Carrier",
    "col.tracking": "Tracking",
    "col.warehouse": "Warehouse",
    "col.reserved": "Reserved",
    "col.available": "Available",
    "col.docref": "Document",
    "col.account": "Account",
    "col.bookingtext": "Description",
    "col.debit": "Debit",
    "col.credit": "Credit",
    "col.kst": "CC",
    "col.budget": "Budget",
    "col.actual": "Actual",
    "col.variance": "Variance",
    "col.fanr": "PO No.",
    "col.article": "Article",
    "col.qty": "Qty",
    "col.start": "Start",
    "col.end": "End",
    "col.pos": "Pos",
    "col.total": "Total",
    "col.key": "Key",
    "col.value": "Value",
    "col.scope": "Scope",
    "kpi.section.insights": "AI insights · Live",
    "kpi.umsatz": "Revenue (May)",
    "kpi.openorders": "Open orders",
    "kpi.openinv": "Open invoices",
    "kpi.stock": "Stock",
    "kpi.tenants": "Active tenants",
    "kpi.aisuggest": "AI suggestions",
    "kpi.delta.today": "+3 today",
    "kpi.delta.docs": "8 documents",
    "kpi.delta.unchanged": "unchanged",
    "kpi.delta.openai": "+5 open",
    "kpi.insight1.text": "3 articles approaching reorder point",
    "kpi.insight1.action": "Open purchase suggestion",
    "kpi.insight2.text": "Revenue Müller GmbH +34% MoM",
    "kpi.insight2.action": "Open address",
    "kpi.insight3.text": "2 deliveries delayed (> 3 days)",
    "kpi.insight3.action": "Open delivery",
    "reg.title": "Entity registry",
    "reg.path":
      "packages/domain/registry/entities.ts · Q=queries · C=commands · L=lookups · I=imports",
    "reg.col.entity": "Entity",
    "reg.col.icon": "Icon",
    "reg.col.paths": "Paths",
    "reg.note":
      "Each pane binds a registry view. The UI never calls SQL — it requests an entity view, and the domain layer orchestrates the server-function call against PostgreSQL (with tenant RLS).",
    "admin.system.users": "System Users",
    "admin.system.tenants": "Tenants",
    "admin.system.organizations": "Organizations",
    "admin.system.connector_definitions": "Connector Definitions",
    "admin.system.companies": "Companies",
    "admin.system.ai_config": "AI Configuration",
    "status.connected": "connected",

    "status.tenant": "tenant",
    "status.user": "user",
    "status.workspace": "workspace",
    "status.pane.one": "Pane",
    "status.pane.many": "Panes",
    "cheatsheet.title": "Keyboard Shortcuts",
    "cheatsheet.empty": "No shortcuts registered",
    "cheatsheet.close": "? or Esc to close",
    "stats.drawer.title": "Statistics",
    "stats.drawer.noentity": "No entity selected — select a record to see statistics",
    "stats.entity.address": "Address",
    "stats.entity.document": "Document",
    "stats.entity.article": "Article",
    "stats.entity.article_group": "Article Group",
    "stats.address.documents": "Documents & Revenue",
    "stats.article.inventory": "Inventory",
    "stats.document.info": "Document statistics coming soon",
    "stats.articlegroup.info": "Group statistics coming soon",
  },
};

const makeT = (lang: string) => (key: string, vars?: Record<string, string>) => {
  const dict = I18N[lang] ?? I18N["de"]!;
  let s = dict[key] ?? I18N["de"]![key] ?? key;
  if (vars)
    Object.keys(vars).forEach((k) => {
      s = s.replace(`{${k}}`, vars[k]!);
    });
  return s;
};

/* ── THEMES ── */
const THEMES = [
  { name: "Grün", accent: "#22c55e", dark: "#16a34a", muted: "rgba(34,197,94,0.12)" },
  { name: "Blau", accent: "#3b82f6", dark: "#1d4ed8", muted: "rgba(59,130,246,0.12)" },
  { name: "Violett", accent: "#8b5cf6", dark: "#6d28d9", muted: "rgba(139,92,246,0.12)" },
  { name: "Orange", accent: "#f97316", dark: "#c2410c", muted: "rgba(249,115,22,0.12)" },
  { name: "Cyan", accent: "#06b6d4", dark: "#0e7490", muted: "rgba(6,182,212,0.12)" },
  { name: "Rose", accent: "#f43f5e", dark: "#be123c", muted: "rgba(244,63,94,0.12)" },
  { name: "Indigo", accent: "#6366f1", dark: "#4338ca", muted: "rgba(99,102,241,0.12)" },
  { name: "Amber", accent: "#f59e0b", dark: "#d97706", muted: "rgba(245,158,11,0.12)" },
  { name: "Teal", accent: "#14b8a6", dark: "#0f766e", muted: "rgba(20,184,166,0.12)" },
  { name: "Slate", accent: "#64748b", dark: "#475569", muted: "rgba(100,116,139,0.12)" },
  { name: "Lime", accent: "#84cc16", dark: "#4d7c0f", muted: "rgba(132,204,22,0.12)" },
  { name: "Pink", accent: "#ec4899", dark: "#9d174d", muted: "rgba(236,72,153,0.12)" },
];

/* ════════════════════════════════════════════════════════════
   URL HASH STATE
   ════════════════════════════════════════════════════════════ */
type HashState = {
  ws: string;
  panes: string[][];
  sel?: string | null;
  lang: string;
  tid?: string;
};

function parseHash(hash: string): HashState {
  const h = (hash || "").replace(/^#/, "");
  const params = new URLSearchParams(h);
  const ws = params.get("ws") || "dashboard";
  const p = params.get("p");
  let panes: string[][];
  if (p) {
    panes = p.split("|").map((seg) => seg.split(",").filter(Boolean));
  } else {
    const wsDef = WORKSPACES.find((w) => w.id === ws) ?? WORKSPACES[0]!;
    panes = wsDef.panes.map((arr) => [...arr]);
  }
  const sel = params.get("sel");
  const lang =
    params.get("lang") ||
    (typeof localStorage !== "undefined" ? localStorage.getItem("slopware.lang") : null) ||
    "de";
  const tid =
    params.get("tid") ||
    (typeof localStorage !== "undefined" ? localStorage.getItem("slopware.tid") : null) ||
    undefined;
  return { ws, panes, sel, lang, tid };
}

function buildHash({ ws, panes, sel, lang, tid }: HashState): string {
  const params = new URLSearchParams();
  params.set("ws", ws);
  params.set("p", panes.map((arr) => arr.join(",")).join("|"));
  if (sel) params.set("sel", sel);
  if (lang && lang !== "de") params.set("lang", lang);
  if (tid) params.set("tid", tid);
  return "#" + params.toString();
}

/* ════════════════════════════════════════════════════════════
   VIEW COMPONENTS
   ════════════════════════════════════════════════════════════ */

function KpiView({ t }: { t: (k: string) => string }) {
  const kpis = [
    { label: t("kpi.umsatz"), value: "84.320 €", delta: "+12.4%", up: true },
    { label: t("kpi.openorders"), value: "47", delta: t("kpi.delta.today"), up: true },
    { label: t("kpi.openinv"), value: "22.180 €", delta: t("kpi.delta.docs"), up: false },
    { label: t("kpi.stock"), value: "1.205", delta: "–14", up: false },
    { label: t("kpi.tenants"), value: "3", delta: t("kpi.delta.unchanged"), up: true },
    { label: t("kpi.aisuggest"), value: "12", delta: t("kpi.delta.openai"), up: true },
  ];
  return (
    <div style={{ height: "100%", overflowY: "auto" }}>
      <div className="kpi-grid">
        {kpis.map((k, i) => (
          <div className="kpi-card" key={i}>
            <div className="kpi-label">{k.label}</div>
            <div className="kpi-value">{k.value}</div>
            <div className={`kpi-delta ${k.up ? "up" : "down"}`}>
              {k.up ? "▲" : "▼"} {k.delta}
            </div>
          </div>
        ))}
      </div>
      <div style={{ padding: "0 14px 14px" }}>
        <div className="section-heading">{t("kpi.section.insights")}</div>
        {[
          { text: t("kpi.insight1.text"), action: t("kpi.insight1.action") },
          { text: t("kpi.insight2.text"), action: t("kpi.insight2.action") },
          { text: t("kpi.insight3.text"), action: t("kpi.insight3.action") },
        ].map((it, i) => (
          <div
            key={i}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              padding: "8px 12px",
              background: "var(--bg-card)",
              border: "1px solid var(--border)",
              borderRadius: "var(--radius)",
              marginBottom: 6,
            }}
          >
            <span style={{ fontSize: 12.5 }}>{it.text}</span>
            <button className="btn btn-ghost btn-xs" style={{ color: "var(--accent)" }}>
              {it.action} →
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ════════════════════════════════════════════════════════════
   PANE
   ════════════════════════════════════════════════════════════ */
function Pane({
  paneIdx,
  viewKeys,
  activeIdx,
  onActivateSubTab,
  onCloseSubTab,
  onAddSubTab,
  onClosePane,
  onSplitPane,
  paneCount,
}: {
  paneIdx: number;
  viewKeys: string[];
  activeIdx: number;
  onActivateSubTab: (pi: number, si: number) => void;
  onCloseSubTab: (pi: number, si: number) => void;
  onAddSubTab: (pi: number, vk: string) => void;
  onClosePane: (pi: number) => void;
  onSplitPane: (pi: number) => void;
  paneCount: number;
}) {
  const { t, lang } = useWorkspaceContext();
  const [showPicker, setShowPicker] = useState(false);
  const pickerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fn = (e: MouseEvent) => {
      if (pickerRef.current && !pickerRef.current.contains(e.target as Node)) setShowPicker(false);
    };
    if (showPicker) document.addEventListener("mousedown", fn);
    return () => document.removeEventListener("mousedown", fn);
  }, [showPicker]);

  const activeKey = viewKeys[activeIdx];

  const renderView = () => {
    if (!activeKey)
      return (
        <div className="pane-empty">
          <div className="pane-empty-icon">{ICONS["detail"]}</div>
          <div className="pane-empty-text">{t("pane.empty.noview")}</div>
        </div>
      );
    if (activeKey === "dashboard:kpi") return <KpiView t={(k) => t(k, lang as any)} />;
    return resolveView(activeKey);
  };
  const groupedRegistry = useMemo(() => {
    const g: Record<string, typeof VIEW_REGISTRY> = {};
    VIEW_REGISTRY.forEach((v) => {
      const sec = lang === "en" ? v.section_en : v.section_de;
      (g[sec] = g[sec] ?? []).push(v);
    });
    return g;
  }, [lang]);

  return (
    <div className="pane">
      <div className="pane-tabbar">
        {viewKeys.map((vk, i) => {
          const r = VIEW_REGISTRY.find((v) => v.key === vk);
          const ent = r?.entity ? ENTITY_REGISTRY[r.entity] : undefined;
          return (
            <div
              key={vk + i}
              className={`pane-subtab${i === activeIdx ? " active" : ""}`}
              onClick={() => onActivateSubTab(paneIdx, i)}
            >
              <span className="icon-mark">{ICONS[ent?.icon ?? "doc"]}</span>
              <span>{r ? (lang === "en" ? r.label_en : r.label_de) : vk}</span>
              {viewKeys.length > 1 && (
                <span
                  className="close-x"
                  onClick={(e) => {
                    e.stopPropagation();
                    onCloseSubTab(paneIdx, i);
                  }}
                >
                  {ICONS["close"]}
                </span>
              )}
            </div>
          );
        })}
        <div style={{ position: "relative" }} ref={pickerRef}>
          <button
            className="pane-add-btn"
            onClick={() => setShowPicker((o) => !o)}
            title={t("pane.add")}
          >
            {ICONS["plus"]}
          </button>
          {showPicker && (
            <div className="entity-picker">
              <div className="entity-picker-section">{t("pane.open")}</div>
              {Object.entries(groupedRegistry).map(([sec, items]) => (
                <React.Fragment key={sec}>
                  <div className="entity-picker-section" style={{ paddingTop: 8 }}>
                    {sec}
                  </div>
                  {items.map((it) => {
                    const ent = it.entity ? ENTITY_REGISTRY[it.entity] : undefined;
                    return (
                      <div
                        key={it.key}
                        className="entity-picker-item"
                        onClick={() => {
                          onAddSubTab(paneIdx, it.key);
                          setShowPicker(false);
                        }}
                      >
                        <span className="ep-icon">{ICONS[ent?.icon ?? "doc"]}</span>
                        <span>{lang === "en" ? it.label_en : it.label_de}</span>
                        <span className="ep-mono">{it.key}</span>
                      </div>
                    );
                  })}
                </React.Fragment>
              ))}
            </div>
          )}
        </div>
        <div className="pane-actions">
          <button
            className="pane-action-btn"
            title={t("pane.split")}
            onClick={() => onSplitPane(paneIdx)}
          >
            {ICONS["split"]}
          </button>
          {paneCount > 1 && (
            <button
              className="pane-action-btn danger"
              title={t("pane.close")}
              onClick={() => onClosePane(paneIdx)}
            >
              {ICONS["close"]}
            </button>
          )}
        </div>
      </div>
      <div className="pane-body">{renderView()}</div>
    </div>
  );
}

/* ════════════════════════════════════════════════════════════
   WORKSPACE
   ════════════════════════════════════════════════════════════ */
export function Workspace() {
  const [dark, setDark] = useState(false);
  const [themeIdx, setThemeIdx] = useState(0);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showLangPicker, setShowLangPicker] = useState(false);
  const [hashState, setHashState] = useState<HashState>(() =>
    typeof window !== "undefined"
      ? parseHash(location.hash)
      : { ws: "dashboard", panes: [["dashboard:kpi"]], lang: "de" },
  );
  const [activeSubIdx, setActiveSubIdx] = useState<Record<number, number>>({});

  const { data: user } = useQuery({
    queryKey: ["auth-user"],
    queryFn: () => getCurrentUserFn(),
  });

  const { data: tenants } = useQuery({
    queryKey: ["user-tenants"],
    queryFn: () => listUserTenantsFn(),
    enabled: !!user,
  });

  const { data: currentTenant } = useQuery({
    queryKey: ["current-tenant"],
    queryFn: () => getTenantFn(),
    enabled: !!user,
  });

  const lang = hashState.lang || "de";
  const t = useMemo(() => makeT(lang), [lang]);

  const setLang = useCallback((l: string) => {
    if (typeof localStorage !== "undefined") localStorage.setItem("slopware.lang", l);
    setHashState((s) => ({ ...s, lang: l }));
  }, []);

  const onLogout = useCallback(async () => {
    await signOut();
    window.location.reload();
  }, []);

  const onSwitchTenant = useCallback((tid: string) => {
    logger.info(`Switching tenant to: ${tid}`, "ui");
    const url = new URL(window.location.href);
    url.searchParams.set("tenantId", tid);
    window.location.href = url.toString();
  }, []);

  const [selectedAddress, setSelectedAddress] = useState<SelectedRow | null>(null);
  const [selectedDocument, setSelectedDocument] = useState<SelectedRow | null>(null);
  const [selectedArticle, setSelectedArticle] = useState<SelectedRow | null>(null);
  const [selectedArticleGroup, setSelectedArticleGroup] = useState<SelectedRow | null>(null);
  const [docFilter, setDocFilter] = useState("auftrag");
  const [toastMsg, setToastMsg] = useState("");

  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [cheatsheetOpen, setCheatsheetOpen] = useState(false);
  const [statsOpen, setStatsOpen] = useState(false);
  const [feedbackSnapshot, setFeedbackSnapshot] = useState<FeedbackSnapshot | null>(null);
  const lastErrorRef = useRef<string | null>(null);

  useEffect(() => {
    const handleError = (
      msg: string | Event,
      url?: string,
      line?: number,
      col?: number,
      error?: Error,
    ) => {
      lastErrorRef.current = `${String(msg)} at ${url}:${line}:${col}${error ? `\n${error.stack}` : ""}`;
      return false;
    };
    window.addEventListener("error", handleError);
    return () => window.removeEventListener("error", handleError);
  }, []);

  useHotkeyLayer("global");

  useScopedHotkey(
    "global",
    "Escape",
    useCallback(
      (e: KeyboardEvent) => {
        e.preventDefault();
        if (feedbackOpen) setFeedbackOpen(false);
        else if (cheatsheetOpen) setCheatsheetOpen(false);
        else if (statsOpen) setStatsOpen(false);
      },
      [feedbackOpen, cheatsheetOpen, statsOpen],
    ) as any,
  );

  useScopedHotkey(
    "global",
    "?",
    useCallback((e: KeyboardEvent) => {
      e.preventDefault();
      setCheatsheetOpen((prev) => !prev);
    }, []) as any,
  );

  useScopedHotkey(
    "global",
    "Alt+I",
    useCallback((e: KeyboardEvent) => {
      e.preventDefault();
      setStatsOpen((prev) => !prev);
    }, []) as any,
  );

  const openFeedback = useCallback(() => {
    logger.info("Feedback modal triggered", "ui");
    const snap = captureFeedbackSnapshot(
      hashState.ws,
      hashState.panes,
      {
        address: selectedAddress,
        document: selectedDocument,
        article: selectedArticle,
        articleGroup: selectedArticleGroup,
      },
      user?.id,
      currentTenant?.tenantId,
      lang,
      lastErrorRef.current,
    );
    setFeedbackSnapshot(snap);
    setFeedbackOpen(true);
  }, [
    hashState.ws,
    hashState.panes,
    selectedAddress,
    selectedDocument,
    selectedArticle,
    selectedArticleGroup,
    user?.id,
    currentTenant?.tenantId,
    lang,
  ]);

  useScopedHotkey(
    "global",
    "Shift+F1",
    useCallback(
      (e: KeyboardEvent) => {
        e.preventDefault();
        openFeedback();
      },
      [openFeedback],
    ) as any,
  );

  const updatePanes = useCallback((mut: (p: string[][]) => string[][]) => {
    setHashState((s) => ({ ...s, panes: mut(s.panes) }));
  }, []);

  const setSelected = useCallback(
    (entity: string | null, row: SelectedRow | null) => {
      logger.info(`Selected ${entity}`, "ui", { id: row?.id || row?.nr || "unknown" });
      if (!entity) {
        setSelectedAddress(null);
        setSelectedDocument(null);
        setSelectedArticle(null);
        setSelectedArticleGroup(null);
        return;
      }
      if (entity === "address") setSelectedAddress(row);
      if (entity === "document") setSelectedDocument(row);
      if (entity === "article") setSelectedArticle(row);
      if (entity === "article_group") setSelectedArticleGroup(row);

      // Auto-activate or add detail view in current pane
      const detailViewKeys: Record<string, string> = {
        address: "address:detail",
        document: "document:unified",
        article: "article:detail",
        article_group: "article:group-detail",
      };
      const key = detailViewKeys[entity];
      if (key && row) {
        const existingPi = hashState.panes.findIndex((p) => p.includes(key));
        if (existingPi !== -1) {
          // Already exists — activate it
          const si = hashState.panes[existingPi].indexOf(key);
          setActiveSubIdx((prev) => ({ ...prev, [existingPi]: si }));
        } else {
          // Find the pane containing the list view for this entity
          const listKey = `${entity}:list`;
          let targetPi = hashState.panes.findIndex((p) => p.includes(listKey));
          if (targetPi === -1) {
            // Fallback: pane with the list adapter view
            const adapterKeys: Record<string, string[]> = {
              document: ["document:list", "document:tree", "document:detail"],
            };
            targetPi = hashState.panes.findIndex((p) =>
              p.some((v) => (adapterKeys[entity] || []).includes(v)),
            );
          }
          if (targetPi === -1) targetPi = 0;
          const currentPane = hashState.panes[targetPi];
          if (currentPane && !currentPane.includes(key)) {
            updatePanes((panes) => panes.map((arr, i) => (i === targetPi ? [...arr, key] : arr)));
            setActiveSubIdx((prev) => ({ ...prev, [targetPi]: currentPane.length }));
          }
        }
      }
    },
    [hashState.panes, updatePanes],
  );

  const toast = useCallback((msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(""), 2400);
  }, []);

  const switchWorkspace = useCallback((wsId: string) => {
    logger.info(`Switching workspace to: ${wsId}`, "ui");
    const wsDef = WORKSPACES.find((w) => w.id === wsId);
    if (!wsDef) return;
    setHashState((s) => ({ ...s, ws: wsId, panes: wsDef.panes.map((arr) => [...arr]) }));
    setActiveSubIdx({});
  }, []);

  const onActivateSubTab = useCallback((pi: number, si: number) => {
    setActiveSubIdx((s) => ({ ...s, [pi]: si }));
  }, []);

  const onCloseSubTab = useCallback(
    (pi: number, si: number) => {
      logger.info(`Closing subtab ${si} in pane ${pi}`, "ui");
      updatePanes((panes) =>
        panes.map((arr, i) => (i === pi ? arr.filter((_, j) => j !== si) : arr)),
      );
      setActiveSubIdx((s) => {
        const cur = s[pi] ?? 0;
        return { ...s, [pi]: Math.max(0, cur - (si <= cur ? 1 : 0)) };
      });
    },
    [updatePanes],
  );

  const onAddSubTab = useCallback(
    (pi: number, vk: string) => {
      logger.info(`Adding subtab ${vk} to pane ${pi}`, "ui");
      updatePanes((panes) => panes.map((arr, i) => (i === pi ? [...arr, vk] : arr)));
      setActiveSubIdx((s) => ({ ...s, [pi]: hashState.panes[pi]?.length ?? 0 }));
    },
    [updatePanes, hashState.panes],
  );

  const onClosePane = useCallback(
    (pi: number) => {
      logger.info(`Closing pane ${pi}`, "ui");
      updatePanes((panes) => panes.filter((_, i) => i !== pi));
    },
    [updatePanes],
  );

  const onSplitPane = useCallback(
    (pi: number) => {
      logger.info(`Splitting pane ${pi}`, "ui");
      updatePanes((panes) => {
        const np = [...panes];
        np.splice(pi + 1, 0, ["address:list"]);
        return np;
      });
    },
    [updatePanes],
  );

  const applyLayout = useCallback(
    (kind: string) => {
      logger.info(`Applying layout preset: ${kind}`, "ui");
      const cur = hashState.panes;
      let np: string[][];
      if (kind === "1") np = [cur[0] ?? ["dashboard:kpi"]];
      else if (kind === "2") np = [cur[0] ?? ["address:list"], cur[1] ?? ["address:detail"]];
      else
        np = [
          ["document:tree"],
          ["document:list", "document:detail"],
          ["document:lines", "article:lookup"],
        ];
      setHashState((s) => ({ ...s, panes: np }));
    },
    [hashState.panes],
  );

  const ctxValue: WorkspaceContextValue = useMemo(
    () => ({
      selectedAddress,
      selectedDocument,
      selectedArticle,
      selectedArticleGroup,
      docFilter,
      currentTenant,
      setSelected,
      setDocFilter,
      applyLayout,
      toast,
      t,
      lang,
    }),
    [
      selectedAddress,
      selectedDocument,
      selectedArticle,
      selectedArticleGroup,
      docFilter,
      currentTenant,
      setSelected,
      setDocFilter,
      applyLayout,
      toast,
      t,
      lang,
    ],
  );

  const theme = THEMES[themeIdx]!;

  useEffect(() => {
    const fn = () => setHashState(parseHash(location.hash));
    window.addEventListener("hashchange", fn);
    return () => window.removeEventListener("hashchange", fn);
  }, []);

  useEffect(() => {
    const newHash = buildHash(hashState);
    if (location.hash !== newHash) history.replaceState(null, "", newHash);
  }, [hashState]);

  const paneCount = hashState.panes.length;
  const gridCols = hashState.panes
    .map((_, i) => (i === 0 && paneCount === 3 ? "minmax(180px, 240px)" : "1fr"))
    .join(" ");

  const closeAllDropdowns = () => {
    setShowColorPicker(false);
    setShowUserMenu(false);
    setShowLangPicker(false);
  };

  return (
    <div
      className="slopware-workspace"
      data-dark={dark ? "true" : "false"}
      style={
        {
          "--accent": theme.accent,
          "--accent-dark": theme.dark,
          "--accent-muted": theme.muted,
        } as React.CSSProperties
      }
    >
      {/* HEADER */}
      <header className="sw-header">
        <div className="header-left">
          <a className="header-logo" href="/">
            <img
              src="/slopware-logo.png"
              alt="SLOPware"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = "none";
              }}
            />
            <span
              style={{
                fontWeight: 800,
                fontSize: 14,
                letterSpacing: "-0.02em",
                color: "var(--accent)",
              }}
            >
              SLOP<span style={{ color: "var(--text-primary)" }}>ware</span>
            </span>
          </a>
          <span className="header-module">{t("app.module")}</span>
        </div>

        <div className="header-tabs">
          {WORKSPACES.map((ws) => (
            <button
              key={ws.id}
              className={`tab-item${hashState.ws === ws.id ? " active" : ""}`}
              onClick={() => switchWorkspace(ws.id)}
            >
              {lang === "en" ? ws.label_en : ws.label_de}
            </button>
          ))}
        </div>

        <div className="header-right">
          <div style={{ position: "relative" }}>
            <div
              className="user-chip"
              role="button"
              tabIndex={0}
              onClick={() => {
                setShowUserMenu((o) => !o);
                setShowColorPicker(false);
                setShowLangPicker(false);
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  setShowUserMenu((o) => !o);
                  setShowColorPicker(false);
                  setShowLangPicker(false);
                }
              }}
            >
              <div className="user-avatar">
                {user?.displayName ? user.displayName.substring(0, 2).toUpperCase() : "U"}
              </div>
              <span>{user?.displayName ?? t("app.user")}</span>
              {ICONS["chev"]}
            </div>
            {showUserMenu && (
              <div className="dropdown-menu">
                <div className="dropdown-section-label">{t("menu.tenant")}</div>
                {tenants?.map((tn: any) => (
                  <div
                    key={tn.tenant_id}
                    className="dropdown-item"
                    onClick={() => onSwitchTenant(tn.tenant_id)}
                  >
                    {tn.tenant_name}{" "}
                    {(currentTenant?.tenantId === tn.tenant_id || (!currentTenant && tn.is_base)) &&
                      "✓"}
                  </div>
                ))}
                <div
                  className="dropdown-item divider"
                  onClick={() => {
                    switchWorkspace("einstellungen");
                    closeAllDropdowns();
                  }}
                >
                  {t("menu.user.settings")}
                </div>
                <div
                  className="dropdown-item"
                  onClick={() => {
                    onAddSubTab(0, "meta:admin"); // Profile view could go here too
                    closeAllDropdowns();
                  }}
                >
                  {t("menu.profile")}
                </div>
                {user?.isSystemAdmin && (
                  <div
                    className="dropdown-item divider"
                    onClick={() => {
                      onAddSubTab(0, "meta:admin");
                      closeAllDropdowns();
                    }}
                    style={{ color: "var(--accent)" }}
                  >
                    {t("menu.admin")}
                  </div>
                )}
                <button
                  className="dropdown-item divider danger w-full text-left"
                  onClick={onLogout}
                  style={{ border: "none", background: "none", cursor: "pointer" }}
                >
                  {t("menu.logout")}
                </button>
              </div>
            )}
          </div>

          <div style={{ position: "relative" }}>
            <button
              className="hdr-btn"
              title="Feedback & Support (Shift+F1)"
              onClick={openFeedback}
              style={{ color: "var(--accent)" }}
            >
              <MessageSquare size={16} />
            </button>
          </div>

          <div
            className="toggle-wrap"
            onClick={() => setDark((d) => !d)}
            title={dark ? t("header.lightmode") : t("header.darkmode")}
          >
            <div style={{ color: "var(--text-muted)", display: "flex" }}>
              {dark ? ICONS["moon"] : ICONS["sun"]}
            </div>
            <div className={`toggle-track${dark ? " on" : ""}`}>
              <div className="toggle-thumb" />
            </div>
          </div>

          <div style={{ position: "relative" }}>
            <button
              className="hdr-btn"
              title={t("header.theme.title")}
              onClick={() => {
                setShowColorPicker((o) => !o);
                setShowUserMenu(false);
                setShowLangPicker(false);
              }}
            >
              {ICONS["palette"]}
            </button>
            {showColorPicker && (
              <div className="color-picker-pop">
                <div className="color-picker-label">{t("header.theme.title")}</div>
                <div className="color-swatches">
                  {THEMES.map((th, i) => (
                    <div
                      key={i}
                      className={`color-swatch${themeIdx === i ? " active" : ""}`}
                      style={{ background: th.accent }}
                      title={th.name}
                      onClick={() => {
                        setThemeIdx(i);
                        setShowColorPicker(false);
                      }}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          <div style={{ position: "relative" }}>
            <button
              className="hdr-btn"
              title={t("header.language")}
              onClick={() => {
                setShowLangPicker((o) => !o);
                setShowUserMenu(false);
                setShowColorPicker(false);
              }}
              style={{ fontFamily: "var(--font-mono)", fontSize: 11, fontWeight: 600 }}
            >
              {lang.toUpperCase()}
            </button>
            {showLangPicker && (
              <div className="dropdown-menu" style={{ minWidth: 140 }}>
                <div className="dropdown-section-label">{t("header.language")}</div>
                <div
                  className="dropdown-item"
                  onClick={() => {
                    setLang("de");
                    setShowLangPicker(false);
                  }}
                >
                  Deutsch {lang === "de" && "✓"}
                </div>
                <div
                  className="dropdown-item"
                  onClick={() => {
                    setLang("en");
                    setShowLangPicker(false);
                  }}
                >
                  English {lang === "en" && "✓"}
                </div>
              </div>
            )}
          </div>

          <button
            className="hdr-btn"
            title={t("header.notifications")}
            style={{ position: "relative" }}
          >
            {ICONS["bell"]}
            <span
              style={{
                position: "absolute",
                top: 4,
                right: 4,
                width: 6,
                height: 6,
                borderRadius: "50%",
                background: "#ef4444",
                border: "2px solid var(--header-bg)",
              }}
            />
          </button>

          <button className="hdr-btn" title={t("header.menu")}>
            {ICONS["menu"]}
          </button>
        </div>
      </header>

      {/* URL BAR */}
      <div className="urlbar">
        <span className="urlbar-protocol">workspace://</span>
        <span className="urlbar-route">{hashState.ws}</span>
        <span className="urlbar-amp">?</span>
        {hashState.panes.map((arr, i) => (
          <React.Fragment key={i}>
            {i > 0 && <span className="urlbar-amp">&amp;</span>}
            <span className="urlbar-key">pane{i + 1}=</span>
            <span className="urlbar-val">{arr.join(",")}</span>
          </React.Fragment>
        ))}
        <span className="urlbar-pin">
          <span className="dot" /> {t("urlbar.deeplink")}
        </span>
      </div>

      {/* LAYOUT PRESETS */}
      <div className="layout-presets">
        <span className="layout-label">{t("layout.label")}</span>
        <button
          className={`layout-btn${paneCount === 1 ? " active" : ""}`}
          onClick={() => applyLayout("1")}
        >
          {ICONS["oneup"]} {t("layout.1pane")}
        </button>
        <button
          className={`layout-btn${paneCount === 2 ? " active" : ""}`}
          onClick={() => applyLayout("2")}
        >
          {ICONS["split"]} {t("layout.2pane")}
        </button>
        <button
          className={`layout-btn${paneCount === 3 ? " active" : ""}`}
          onClick={() => applyLayout("3")}
        >
          {ICONS["three"]} {t("layout.3pane")}
        </button>
        <span
          style={{
            marginLeft: "auto",
            fontSize: 10.5,
            color: "var(--text-muted)",
            fontFamily: "var(--font-mono)",
          }}
        >
          {t("layout.tip")}
        </span>
      </div>

      {/* WORKSPACE */}
      <WorkspaceContext.Provider value={ctxValue}>
        <div className="workspace-area" style={{ gridTemplateColumns: gridCols }}>
          {hashState.panes.map((viewKeys, paneIdx) => (
            <Pane
              key={paneIdx}
              paneIdx={paneIdx}
              viewKeys={viewKeys}
              activeIdx={activeSubIdx[paneIdx] ?? 0}
              paneCount={paneCount}
              onActivateSubTab={onActivateSubTab}
              onCloseSubTab={onCloseSubTab}
              onAddSubTab={onAddSubTab}
              onClosePane={onClosePane}
              onSplitPane={onSplitPane}
            />
          ))}
        </div>

        {feedbackSnapshot && (
          <FeedbackModal
            isOpen={feedbackOpen}
            onClose={() => setFeedbackOpen(false)}
            snapshot={feedbackSnapshot}
            t={t}
          />
        )}

        <HotkeyCheatsheet
          isOpen={cheatsheetOpen}
          onClose={() => setCheatsheetOpen(false)}
          t={t}
          lang={lang}
        />

        <StatisticsDrawer
          isOpen={statsOpen}
          onClose={() => setStatsOpen(false)}
          t={t}
          lang={lang}
        />
      </WorkspaceContext.Provider>

      {/* STATUS BAR */}
      <div className="sw-statusbar">
        <span className="statusbar-item">
          <span className="dot" style={{ background: "var(--accent)" }} /> {t("status.connected")} ·
          postgres://slopware
        </span>
        <span className="statusbar-item">
          {t("status.tenant")}:{" "}
          <span style={{ color: "var(--text-secondary)" }}>
            {currentTenant?.name ?? t("app.tenant.name")}
          </span>
        </span>
        <span className="statusbar-item">
          {t("status.user")}:{" "}
          <span style={{ color: "var(--text-secondary)" }}>
            {user?.displayName ?? user?.email ?? "—"}
          </span>
        </span>
        <span className="statusbar-spacer" />
        {toastMsg && <span className="statusbar-pill">{toastMsg}</span>}
        <span className="statusbar-item">
          {t("status.workspace")}: <span className="statusbar-pill">{hashState.ws}</span>
        </span>
        <span className="statusbar-item">
          {paneCount} {paneCount === 1 ? t("status.pane.one") : t("status.pane.many")}
        </span>
      </div>
    </div>
  );
}
