export interface Breadcrumb {
  ts: string;
  level: "info" | "warn" | "error";
  type: "ui" | "network" | "system" | "console";
  message: string;
  data?: any;
}

const MAX_BREADCRUMBS = 50;
const breadcrumbs: Breadcrumb[] = [];

function sanitizeData(data: any): any {
  if (!data) return data;
  try {
    const str = JSON.stringify(data);
    if (str.length > 1000) {
      return { _truncated: true, length: str.length, preview: str.substring(0, 200) + "..." };
    }
    return JSON.parse(str); // Deep clone to avoid mutations
  } catch (e) {
    return "[Unserializable Data]";
  }
}

export const logger = {
  add(crumb: Omit<Breadcrumb, "ts">) {
    const entry: Breadcrumb = {
      ...crumb,
      ts: new Date().toISOString(),
      data: sanitizeData(crumb.data),
    };
    breadcrumbs.push(entry);
    if (breadcrumbs.length > MAX_BREADCRUMBS) {
      breadcrumbs.shift();
    }
  },

  info(message: string, type: Breadcrumb["type"] = "ui", data?: any) {
    this.add({ level: "info", type, message, data });
  },

  warn(message: string, type: Breadcrumb["type"] = "system", data?: any) {
    this.add({ level: "warn", type, message, data });
  },

  error(message: string, type: Breadcrumb["type"] = "system", data?: any) {
    this.add({ level: "error", type, message, data });
  },

  getBreadcrumbs() {
    return [...breadcrumbs];
  },
};

// Global Listeners
if (typeof window !== "undefined") {
  window.addEventListener("error", (event) => {
    logger.error(`Uncaught Error: ${event.message}`, "system", {
      filename: event.filename,
      lineno: event.lineno,
      colno: event.colno,
    });
  });

  window.addEventListener("unhandledrejection", (event) => {
    logger.error(`Unhandled Rejection: ${event.reason}`, "system");
  });

  // Console Interception
  const originalWarn = console.warn;
  const originalError = console.error;

  console.warn = (...args: any[]) => {
    logger.warn(args.map(String).join(" "), "console");
    originalWarn.apply(console, args);
  };

  console.error = (...args: any[]) => {
    logger.error(args.map(String).join(" "), "console");
    originalError.apply(console, args);
  };
}
