/**
 * Server-side structured logger for Slopware.
 * Outputs JSON to stdout for collection by external log aggregators.
 */

type LogLevel = "info" | "warn" | "error" | "debug";

interface LogEntry {
  ts: string;
  level: LogLevel;
  msg: string;
  service: string;
  env: string;
  requestId?: string;
  traceId?: string;
  userId?: string;
  tenantId?: string;
  route?: string;
  durationMs?: number;
  error?: {
    code?: string;
    message: string;
    stack?: string;
    cause?: any;
  };
  [key: string]: any;
}

const SERVICE_NAME = "slopware-web";
const ENV = typeof process !== "undefined" ? process.env.NODE_ENV || "development" : "development";
const IS_DEV = ENV === "development";
const CWD =
  typeof process !== "undefined" && typeof process.cwd === "function" ? process.cwd() : "";

function cleanStack(stack?: string) {
  if (!stack || !IS_DEV) return stack;
  return stack
    .split("\n")
    .filter((line) => !line.includes("node_modules") && (CWD ? line.includes(CWD) : true))
    .map((line) => (CWD ? line.replace(CWD, ".") : line).trim())
    .join(" | ");
}

function shortenRoute(str?: string) {
  if (!str) return str;
  const truncated = str.length > 500 && IS_DEV ? str.slice(0, 500) + "..." : str;
  return truncated.replace(/\/_serverFn\/([a-zA-Z0-9_-]{8})[a-zA-Z0-9_-]+/g, "/_serverFn/$1...");
}

export const serverLogger = {
  log(level: LogLevel, msg: string, data: Partial<LogEntry> = {}) {
    if (typeof window !== "undefined") return;

    const entry: any = {
      ts: IS_DEV
        ? new Date().toISOString().split("T")[1].replace("Z", "")
        : new Date().toISOString(),
      level,
      msg: shortenRoute(msg),
      ...data,
    };

    if (!IS_DEV) {
      entry.service = SERVICE_NAME;
      entry.env = ENV;
    }

    if (entry.route) entry.route = shortenRoute(entry.route);
    if (entry.durationMs) entry.durationMs = Math.round(entry.durationMs * 100) / 100;

    if (IS_DEV) {
      if (entry.requestId) entry.requestId = entry.requestId.slice(0, 6);
      if (entry.traceId) entry.traceId = entry.traceId.slice(0, 6);
      if (entry.type && entry.msg.includes(entry.type.replace(/_/g, " "))) {
        delete entry.type;
      }
    }

    if (entry.error) {
      entry.err = {
        m: entry.error.message,
        s: cleanStack(entry.error.stack),
      };
      delete entry.error;
    }

    // Use JSON.stringify for structured logging
    try {
      process.stdout.write(JSON.stringify(entry) + "\n");
    } catch (e) {
      // Fallback for environments where stdout.write is not available
      console.log(JSON.stringify(entry));
    }
  },

  info(msg: string, data?: Partial<LogEntry>) {
    this.log("info", msg, data);
  },

  warn(msg: string, data?: Partial<LogEntry>) {
    this.log("warn", msg, data);
  },

  error(msg: string, data?: Partial<LogEntry>) {
    this.log("error", msg, data);
  },

  debug(msg: string, data?: Partial<LogEntry>) {
    if (ENV === "development") {
      this.log("debug", msg, data);
    }
  },
};
