import { ThemeProvider } from "@repo/ui/lib/theme-provider";
import { QueryCache, QueryClient, QueryClientProvider, MutationCache } from "@tanstack/react-query";
import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { Toaster } from "sonner";

import "@repo/ui/styles/base.css";
import { logger } from "../lib/logger";

const queryClient = new QueryClient({
  queryCache: new QueryCache({
    onError: (error, query) => {
      logger.error(`Query Error: ${error.message}`, "network", {
        queryKey: query.queryKey,
      });
    },
  }),
  mutationCache: new MutationCache({
    onError: (error, _variables, _context, mutation) => {
      logger.error(`Mutation Error: ${error.message}`, "network", {
        mutationKey: mutation.options.mutationKey,
      });
    },
  }),
});

export const Route = createRootRoute({
  component: () => (
    <html lang="de">
      <head>
        <HeadContent />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=DM+Mono:ital,wght@0,300;0,400;0,500;1,300;1,400;1,500&family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <ThemeProvider>
          <QueryClientProvider client={queryClient}>
            <Outlet />
            <Toaster position="bottom-right" richColors />
          </QueryClientProvider>
        </ThemeProvider>
        <Scripts />
      </body>
    </html>
  ),
  notFoundComponent: () => (
    <html lang="de">
      <head>
        <title>404 - Not Found</title>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=DM+Mono:ital,wght@0,300;0,400;0,500;1,300;1,400;1,500&family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-[var(--bg)] font-[var(--font-ui)] text-[var(--text-primary)]">
        <div className="flex min-h-screen items-center justify-center">
          <div className="text-center">
            <h1 className="text-[22px] font-bold text-[var(--accent)]">404</h1>
            <p className="mt-2 text-[13px]">Page not found</p>
            <a href="/" className="mt-4 inline-block text-[var(--accent)] hover:underline">
              Go home
            </a>
          </div>
        </div>
        <Scripts />
      </body>
    </html>
  ),
});
