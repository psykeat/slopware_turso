import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import * as React from "react";

import { t } from "~/features/workspace/i18n";
import type { Lang } from "~/features/workspace/i18n";
import {
  listAdminCompaniesFn,
  createAdminCompanyFn,
  updateAdminCompanyFn,
} from "~/server/server-functions";

export const Route = createFileRoute("/_auth+/admin/companies")({
  component: () => <AdminCompanies />,
});

export default function AdminCompanies() {
  const lang = React.useMemo<Lang>(() => "en", []);
  const queryClient = useQueryClient();
  const [search, setSearch] = React.useState("");
  const [debouncedSearch, setDebouncedSearch] = React.useState("");
  const [dialogMode, setDialogMode] = React.useState<"create" | "edit" | null>(null);
  const [editingCompany, setEditingCompany] = React.useState<Record<string, unknown> | null>(null);

  React.useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(search), 300);
    return () => clearTimeout(timer);
  }, [search]);

  const { data, isLoading } = useQuery({
    queryKey: ["admin-companies", debouncedSearch],
    queryFn: () =>
      listAdminCompaniesFn({
        data: {
          limit: 100,
          offset: 0,
          search: debouncedSearch || undefined,
        },
      }),
  });

  const createMutation = useMutation({
    mutationFn: createAdminCompanyFn,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-companies"] });
      setDialogMode(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: updateAdminCompanyFn,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-companies"] });
      setDialogMode(null);
      setEditingCompany(null);
    },
  });

  const [formName, setFormName] = React.useState("");
  const [formCompanyNo, setFormCompanyNo] = React.useState("");
  const [formTenantId, setFormTenantId] = React.useState("");
  const [formCountryCode, setFormCountryCode] = React.useState("DE");
  const [formCurrencyId, setFormCurrencyId] = React.useState("EUR");
  const [formActive, setFormActive] = React.useState(true);
  const [formError, setFormError] = React.useState("");

  const openCreate = () => {
    setFormName("");
    setFormCompanyNo("");
    setFormTenantId("");
    setFormCountryCode("DE");
    setFormCurrencyId("EUR");
    setFormActive(true);
    setFormError("");
    setEditingCompany(null);
    setDialogMode("create");
  };

  const openEdit = (company: Record<string, unknown>) => {
    setFormName(String(company.name ?? ""));
    setFormCompanyNo(String(company.company_no ?? ""));
    setFormTenantId(String(company.tenant_id ?? ""));
    setFormCountryCode(String(company.country_code ?? "DE"));
    setFormCurrencyId(String(company.currency_id ?? "EUR"));
    setFormActive(Boolean(company.is_active));
    setFormError("");
    setEditingCompany(company);
    setDialogMode("edit");
  };

  const handleSubmit = () => {
    setFormError("");
    if (!formName.trim()) {
      setFormError("Name is required");
      return;
    }
    if (!formCompanyNo.trim()) {
      setFormError("Company code is required");
      return;
    }
    if (dialogMode === "create" && !formTenantId) {
      setFormError("Tenant is required");
      return;
    }

    if (dialogMode === "create") {
      createMutation.mutate({
        data: {
          tenantId: formTenantId,
          companyNo: formCompanyNo.trim(),
          name: formName.trim(),
          countryCode: formCountryCode,
          currencyId: formCurrencyId,
          isActive: formActive,
        },
      });
    } else if (dialogMode === "edit" && editingCompany) {
      updateMutation.mutate({
        data: {
          id: String(editingCompany.company_id),
          name: formName.trim(),
          countryCode: formCountryCode,
          currencyId: formCurrencyId,
          isActive: formActive,
        },
      });
    }
  };

  const items = data?.items ?? [];
  const total = data?.total ?? 0;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">{t("admin.companies.title", lang)}</h2>
        <button
          className="sw-btn sw-btn-sm rounded bg-blue-600 px-3 py-1.5 text-sm text-white hover:bg-blue-700"
          onClick={openCreate}
          disabled={createMutation.isPending || updateMutation.isPending}
        >
          {t("admin.companies.create", lang)}
        </button>
      </div>

      <input
        type="text"
        placeholder={t("admin.companies.search", lang)}
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="sw-input rounded border px-3 py-2 text-sm"
      />

      {isLoading ? (
        <p className="text-sm text-gray-500">Loading...</p>
      ) : items.length === 0 ? (
        <p className="text-sm text-gray-500">{t("admin.companies.empty", lang)}</p>
      ) : (
        <div className="overflow-auto rounded border">
          <table className="w-full text-left text-sm">
            <thead className="sticky top-0 bg-gray-50">
              <tr>
                <th className="p-2 font-medium">{t("admin.companies.name", lang)}</th>
                <th className="p-2 font-medium">{t("admin.companies.code", lang)}</th>
                <th className="p-2 font-medium">{t("admin.companies.tenant", lang)}</th>
                <th className="p-2 font-medium">{t("admin.companies.status", lang)}</th>
                <th className="p-2 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((company: Record<string, unknown>) => (
                <tr key={String(company.company_id)} className="border-t hover:bg-gray-50">
                  <td className="p-2">{String(company.name)}</td>
                  <td className="p-2 font-mono text-xs">{String(company.company_no)}</td>
                  <td className="p-2">{String(company.tenant_name ?? "—")}</td>
                  <td className="p-2">
                    <span
                      className={`rounded px-2 py-0.5 text-xs ${
                        company.is_active
                          ? "bg-green-100 text-green-800"
                          : "bg-red-100 text-red-800"
                      }`}
                    >
                      {company.is_active
                        ? t("admin.users.active", lang)
                        : t("admin.users.inactive", lang)}
                    </span>
                  </td>
                  <td className="p-2">
                    <button
                      className="rounded px-2 py-1 text-xs text-blue-600 hover:bg-blue-50"
                      onClick={() => openEdit(company)}
                    >
                      Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="border-t p-2 text-xs text-gray-500">Total: {total}</div>
        </div>
      )}

      {(dialogMode === "create" || dialogMode === "edit") && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm"
          onClick={() => setDialogMode(null)}
        >
          <div
            className="w-[450px] rounded-lg bg-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b p-4">
              <h3 className="text-lg font-bold text-gray-800">
                {dialogMode === "create"
                  ? t("admin.companies.create", lang)
                  : t("admin.companies.edit", lang)}
              </h3>
              <button
                className="rounded p-1.5 text-gray-400 hover:bg-gray-100"
                onClick={() => setDialogMode(null)}
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 p-4">
              {formError && (
                <div className="rounded bg-red-50 p-2 text-xs text-red-600">{formError}</div>
              )}
              <div>
                <label className="mb-1 block text-xs font-medium text-gray-600">
                  {t("admin.companies.name", lang)}
                </label>
                <input
                  type="text"
                  className="sw-input w-full rounded border px-3 py-2 text-sm"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-medium text-gray-600">
                  {t("admin.companies.code", lang)}
                </label>
                <input
                  type="text"
                  className="sw-input w-full rounded border px-3 py-2 text-sm"
                  value={formCompanyNo}
                  onChange={(e) => setFormCompanyNo(e.target.value)}
                  readOnly={dialogMode === "edit"}
                />
              </div>
              {dialogMode === "create" && (
                <div>
                  <label className="mb-1 block text-xs font-medium text-gray-600">
                    {t("admin.companies.tenant", lang)}
                  </label>
                  <input
                    type="text"
                    className="sw-input w-full rounded border px-3 py-2 text-sm"
                    value={formTenantId}
                    onChange={(e) => setFormTenantId(e.target.value)}
                    placeholder="Tenant UUID"
                  />
                </div>
              )}
              <div className="flex gap-3">
                <div className="flex-1">
                  <label className="mb-1 block text-xs font-medium text-gray-600">Country</label>
                  <input
                    type="text"
                    className="sw-input w-full rounded border px-3 py-2 text-sm"
                    value={formCountryCode}
                    onChange={(e) => setFormCountryCode(e.target.value.slice(0, 2).toUpperCase())}
                    maxLength={2}
                  />
                </div>
                <div className="flex-1">
                  <label className="mb-1 block text-xs font-medium text-gray-600">Currency</label>
                  <input
                    type="text"
                    className="sw-input w-full rounded border px-3 py-2 text-sm"
                    value={formCurrencyId}
                    onChange={(e) => setFormCurrencyId(e.target.value.slice(0, 3).toUpperCase())}
                    maxLength={3}
                  />
                </div>
              </div>
              {dialogMode === "edit" && (
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="company-active"
                    checked={formActive}
                    onChange={(e) => setFormActive(e.target.checked)}
                    className="rounded"
                  />
                  <label htmlFor="company-active" className="text-sm text-gray-700">
                    {t("admin.users.active", lang)}
                  </label>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 border-t bg-gray-50 p-4">
              <button
                className="rounded px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-200"
                onClick={() => setDialogMode(null)}
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {t("list.crud.cancel", lang)}
              </button>
              <button
                className="rounded bg-blue-600 px-3 py-1.5 text-sm text-white hover:bg-blue-700 disabled:opacity-50"
                onClick={handleSubmit}
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {t("list.crud.save", lang)}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
