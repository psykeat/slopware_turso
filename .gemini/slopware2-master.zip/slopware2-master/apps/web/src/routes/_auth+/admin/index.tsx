import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import * as React from "react";

import { t } from "~/features/workspace/i18n";
import type { Lang } from "~/features/workspace/i18n";
import { getAdminStatsFn } from "~/server/server-functions";

export const Route = createFileRoute("/_auth+/admin/")({
  component: () => <AdminDashboard />,
});

export default function AdminDashboard() {
  const lang = React.useMemo<Lang>(() => "en", []);

  const { data: stats, isLoading } = useQuery({
    queryKey: ["admin-stats"],
    queryFn: () => getAdminStatsFn({ data: undefined }),
  });

  return (
    <div className="flex flex-col gap-6">
      <h2 className="text-lg font-semibold">{t("admin.dashboard.title", lang)}</h2>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="sw-admin-card rounded-lg border p-4">
          <div className="text-sm font-medium text-gray-500">{t("admin.dashboard.orgs", lang)}</div>
          <div className="mt-1 text-2xl font-bold">
            {isLoading ? "—" : (stats?.organizations ?? 0)}
          </div>
        </div>
        <div className="sw-admin-card rounded-lg border p-4">
          <div className="text-sm font-medium text-gray-500">
            {t("admin.dashboard.tenants", lang)}
          </div>
          <div className="mt-1 text-2xl font-bold">{isLoading ? "—" : (stats?.tenants ?? 0)}</div>
        </div>
        <div className="sw-admin-card rounded-lg border p-4">
          <div className="text-sm font-medium text-gray-500">
            {t("admin.dashboard.users", lang)}
          </div>
          <div className="mt-1 text-2xl font-bold">{isLoading ? "—" : (stats?.users ?? 0)}</div>
        </div>
        <div className="sw-admin-card rounded-lg border p-4">
          <div className="text-sm font-medium text-gray-500">
            {t("admin.dashboard.companies", lang)}
          </div>
          <div className="mt-1 text-2xl font-bold">{isLoading ? "—" : (stats?.companies ?? 0)}</div>
        </div>
      </div>
      <div>
        <h3 className="mb-3 text-sm font-medium text-gray-500">
          {t("admin.dashboard.quickLinks", lang)}
        </h3>
        <div className="grid grid-cols-2 gap-3">
          <a href="/admin/users" className="sw-admin-link rounded-lg border p-3 hover:bg-gray-50">
            {t("admin.dashboard.users", lang)}
          </a>
          <a
            href="/admin/organizations"
            className="sw-admin-link rounded-lg border p-3 hover:bg-gray-50"
          >
            {t("admin.dashboard.organizations", lang)}
          </a>
          <a href="/admin/tenants" className="sw-admin-link rounded-lg border p-3 hover:bg-gray-50">
            {t("admin.dashboard.tenants", lang)}
          </a>
          <a
            href="/admin/companies"
            className="sw-admin-link rounded-lg border p-3 hover:bg-gray-50"
          >
            {t("admin.dashboard.companies", lang)}
          </a>
        </div>
      </div>
    </div>
  );
}
