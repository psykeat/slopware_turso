import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import * as React from "react";

import { t } from "~/features/workspace/i18n";
import type { Lang } from "~/features/workspace/i18n";
import { listConnectorsFn } from "~/server/server-functions";

export const Route = createFileRoute("/_auth+/admin/integration")({
  component: () => <AdminIntegration />,
});

export default function AdminIntegration() {
  const lang = React.useMemo<Lang>(() => "en", []);

  const { data: connectorsData, isLoading } = useQuery({
    queryKey: ["admin-connectors"],
    queryFn: () => listConnectorsFn({ data: undefined }),
  });

  const connectors: Record<string, unknown>[] = Array.isArray(connectorsData) ? connectorsData : [];

  const labelObj = (row: Record<string, unknown>) => {
    const lbl = row.label as Record<string, string> | undefined;
    return lbl?.en ?? lbl?.de ?? String(row.slug ?? "—");
  };

  const formatDate = (val: unknown) => {
    if (!val) return "—";
    return new Date(String(val)).toLocaleDateString("en-GB");
  };

  return (
    <div className="flex flex-col gap-4">
      <h2 className="text-lg font-semibold">{t("admin.integration.title", lang)}</h2>

      {isLoading ? (
        <p className="text-sm text-gray-500">Loading...</p>
      ) : !connectors || connectors.length === 0 ? (
        <p className="text-sm text-gray-500">No connectors configured</p>
      ) : (
        <div className="overflow-auto rounded border">
          <table className="w-full text-left text-sm">
            <thead className="sticky top-0 bg-gray-50">
              <tr>
                <th className="p-2 font-medium">{t("admin.users.name", lang)}</th>
                <th className="p-2 font-medium">Slug</th>
                <th className="p-2 font-medium">Mode</th>
                <th className="p-2 font-medium">{t("admin.integration.status", lang)}</th>
                <th className="p-2 font-medium">{t("admin.integration.lastsync", lang)}</th>
                <th className="p-2 font-medium">Tenant</th>
                <th className="p-2 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {connectors.map((row: Record<string, unknown>, idx: number) => (
                <tr key={String(row.connector_id) + idx} className="border-t hover:bg-gray-50">
                  <td className="p-2">{labelObj(row)}</td>
                  <td className="p-2 font-mono text-xs">{String(row.slug ?? "—")}</td>
                  <td className="p-2">
                    <span className="rounded bg-gray-100 px-2 py-0.5 text-xs font-medium">
                      {String(row.atomicity_mode ?? "—")}
                    </span>
                  </td>
                  <td className="p-2">
                    <span
                      className={`rounded px-2 py-0.5 text-xs ${
                        row.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                      }`}
                    >
                      {row.is_active
                        ? t("admin.integration.enabled", lang)
                        : t("admin.integration.disabled", lang)}
                    </span>
                  </td>
                  <td className="p-2">{formatDate(row.last_run_at)}</td>
                  <td className="p-2 text-xs text-gray-500">{String(row.tenant_name ?? "—")}</td>
                  <td className="p-2">
                    <button className="rounded px-2 py-1 text-xs text-blue-600 hover:bg-blue-50">
                      {t("admin.integration.test", lang)}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
