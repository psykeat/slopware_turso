import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import * as React from "react";

import { t } from "~/features/workspace/i18n";
import type { Lang } from "~/features/workspace/i18n";
import { getLiteLLMConfigFn, saveLiteLLMConfigFn, testLiteLLMFn } from "~/server/server-functions";

export const Route = createFileRoute("/_auth+/admin/litellm")({
  component: () => <AdminLiteLLM />,
});

export default function AdminLiteLLM() {
  const lang = React.useMemo<Lang>(() => "en", []);
  const queryClient = useQueryClient();

  const { data: config, isLoading } = useQuery({
    queryKey: ["admin-litellm-config"],
    queryFn: () => getLiteLLMConfigFn({ data: undefined }),
  });

  const [baseUrl, setBaseUrl] = React.useState("");
  const [apiKey, setApiKey] = React.useState("");
  const [defaultModel, setDefaultModel] = React.useState("");
  const [testResult, setTestResult] = React.useState<string | null>(null);
  const [testLoading, setTestLoading] = React.useState(false);

  React.useEffect(() => {
    if (config) {
      setBaseUrl(config.base_url);
      setApiKey(config.api_key);
      setDefaultModel(config.default_model);
    }
  }, [config]);

  const saveMutation = useMutation({
    mutationFn: () =>
      saveLiteLLMConfigFn({
        data: { base_url: baseUrl, api_key: apiKey, default_model: defaultModel },
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-litellm-config"] });
    },
  });

  const handleTest = async () => {
    setTestLoading(true);
    setTestResult(null);
    try {
      const result = await testLiteLLMFn({ data: { base_url: baseUrl, api_key: apiKey } });
      if (result.success) {
        const models = (result as any).models as string[] | undefined;
        setTestResult(
          `Connected! Available models: ${models ? models.slice(0, 5).join(", ") : "none"}`,
        );
      } else {
        setTestResult(`Connection failed: ${(result as any).error}`);
      }
    } catch (e) {
      setTestResult(`Error: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setTestLoading(false);
    }
  };

  if (isLoading) return <p className="text-sm text-gray-500">Loading...</p>;

  return (
    <div className="flex flex-col gap-4">
      <h2 className="text-lg font-semibold">LiteLLM Configuration</h2>

      <div className="flex flex-col gap-3 rounded border p-4">
        <div className="flex flex-col gap-1">
          <label className="text-xs font-semibold tracking-wide text-gray-500 uppercase">
            Base URL
          </label>
          <input
            type="text"
            className="rounded border px-2 py-1 text-sm"
            value={baseUrl}
            onChange={(e) => setBaseUrl(e.target.value)}
            placeholder="https://api.openai.com"
          />
        </div>

        <div className="flex flex-col gap-1">
          <label className="text-xs font-semibold tracking-wide text-gray-500 uppercase">
            API Key
          </label>
          <input
            type="password"
            className="rounded border px-2 py-1 text-sm"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder="sk-..."
          />
        </div>

        <div className="flex flex-col gap-1">
          <label className="text-xs font-semibold tracking-wide text-gray-500 uppercase">
            Default Model
          </label>
          <input
            type="text"
            className="rounded border px-2 py-1 text-sm"
            value={defaultModel}
            onChange={(e) => setDefaultModel(e.target.value)}
            placeholder="gpt-4o-mini"
          />
        </div>

        <div className="flex gap-2">
          <button
            className="rounded bg-blue-600 px-3 py-1 text-sm text-white hover:bg-blue-700"
            onClick={() => saveMutation.mutate()}
            disabled={saveMutation.isPending}
          >
            {saveMutation.isPending ? "Saving..." : "Save"}
          </button>
          <button
            className="rounded border px-3 py-1 text-sm hover:bg-gray-50"
            onClick={handleTest}
            disabled={testLoading || !baseUrl || !apiKey}
          >
            {testLoading ? "Testing..." : "Test Connection"}
          </button>
        </div>

        {testResult && (
          <div
            className={`rounded p-2 font-mono text-xs ${
              testResult.startsWith("Connected")
                ? "bg-green-50 text-green-800"
                : "bg-red-50 text-red-800"
            }`}
          >
            {testResult}
          </div>
        )}
      </div>
    </div>
  );
}
