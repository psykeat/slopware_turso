import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import * as React from "react";

import { t } from "~/features/workspace/i18n";
import type { Lang } from "~/features/workspace/i18n";
import {
  listOrganizationsFn,
  createOrganizationFn,
  updateOrganizationFn,
} from "~/server/server-functions";

export const Route = createFileRoute("/_auth+/admin/organizations")({
  component: () => <AdminOrganizations />,
});

export default function AdminOrganizations() {
  const lang = React.useMemo<Lang>(() => "en", []);
  const queryClient = useQueryClient();
  const [search, setSearch] = React.useState("");
  const [debouncedSearch, setDebouncedSearch] = React.useState("");
  const [dialogMode, setDialogMode] = React.useState<"create" | "edit" | null>(null);
  const [editingOrg, setEditingOrg] = React.useState<Record<string, unknown> | null>(null);

  React.useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(search), 300);
    return () => clearTimeout(timer);
  }, [search]);

  const { data, isLoading } = useQuery({
    queryKey: ["organizations", debouncedSearch],
    queryFn: () =>
      listOrganizationsFn({
        data: {
          limit: 100,
          offset: 0,
          search: debouncedSearch || undefined,
        },
      }),
  });

  const createMutation = useMutation({
    mutationFn: createOrganizationFn,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["organizations"] });
      setDialogMode(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: updateOrganizationFn,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["organizations"] });
      setDialogMode(null);
      setEditingOrg(null);
    },
  });

  const [formName, setFormName] = React.useState("");
  const [formSlug, setFormSlug] = React.useState("");
  const [formActive, setFormActive] = React.useState(true);
  const [formError, setFormError] = React.useState("");

  const openCreate = () => {
    setFormName("");
    setFormSlug("");
    setFormActive(true);
    setFormError("");
    setEditingOrg(null);
    setDialogMode("create");
  };

  const openEdit = (org: Record<string, unknown>) => {
    setFormName(String(org.name ?? ""));
    setFormSlug(String(org.slug ?? ""));
    setFormActive(Boolean(org.is_active));
    setFormError("");
    setEditingOrg(org);
    setDialogMode("edit");
  };

  const slugFromName = (name: string) =>
    name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 63) || `org-${Date.now()}`;

  const handleSubmit = () => {
    setFormError("");
    if (!formName.trim()) {
      setFormError("Name is required");
      return;
    }
    if (!formSlug.trim()) {
      setFormError("Slug is required");
      return;
    }
    if (!/^[a-z0-9][a-z0-9-]{0,62}$/.test(formSlug)) {
      setFormError("Slug must be lowercase alphanumeric with hyphens, max 63 chars");
      return;
    }

    if (dialogMode === "create") {
      createMutation.mutate({ data: { name: formName.trim(), slug: formSlug.trim() } });
    } else if (dialogMode === "edit" && editingOrg) {
      updateMutation.mutate({
        data: {
          id: String(editingOrg.organization_id),
          name: formName.trim(),
          slug: formSlug.trim(),
          is_active: formActive,
        },
      });
    }
  };

  const items = data?.items ?? [];
  const total = data?.total ?? 0;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">{t("admin.orgs.title", lang)}</h2>
        <button
          className="sw-btn sw-btn-sm rounded bg-blue-600 px-3 py-1.5 text-sm text-white hover:bg-blue-700"
          onClick={openCreate}
          disabled={createMutation.isPending || updateMutation.isPending}
        >
          {t("admin.orgs.create", lang)}
        </button>
      </div>

      <input
        type="text"
        placeholder={t("admin.orgs.search", lang)}
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="sw-input rounded border px-3 py-2 text-sm"
      />

      {isLoading ? (
        <p className="text-sm text-gray-500">Loading...</p>
      ) : items.length === 0 ? (
        <p className="text-sm text-gray-500">{t("admin.orgs.empty", lang)}</p>
      ) : (
        <div className="overflow-auto rounded border">
          <table className="w-full text-left text-sm">
            <thead className="sticky top-0 bg-gray-50">
              <tr>
                <th className="p-2 font-medium">{t("admin.orgs.name", lang)}</th>
                <th className="p-2 font-medium">{t("admin.orgs.slug", lang)}</th>
                <th className="p-2 font-medium">{t("admin.orgs.status", lang)}</th>
                <th className="p-2 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((org: Record<string, unknown>) => (
                <tr key={String(org.organization_id)} className="border-t hover:bg-gray-50">
                  <td className="p-2">{String(org.name)}</td>
                  <td className="p-2 font-mono text-xs">{String(org.slug)}</td>
                  <td className="p-2">
                    <span
                      className={`rounded px-2 py-0.5 text-xs ${
                        org.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                      }`}
                    >
                      {org.is_active
                        ? t("admin.users.active", lang)
                        : t("admin.users.inactive", lang)}
                    </span>
                  </td>
                  <td className="p-2">
                    <button
                      className="rounded px-2 py-1 text-xs text-blue-600 hover:bg-blue-50"
                      onClick={() => openEdit(org)}
                    >
                      Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="border-t p-2 text-xs text-gray-500">Total: {total}</div>
        </div>
      )}

      {(dialogMode === "create" || dialogMode === "edit") && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm"
          onClick={() => setDialogMode(null)}
        >
          <div
            className="w-[450px] rounded-lg bg-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b p-4">
              <h3 className="text-lg font-bold text-gray-800">
                {dialogMode === "create"
                  ? t("list.crud.title.new", lang)
                  : t("list.crud.title.edit", lang)}
              </h3>
              <button
                className="rounded p-1.5 text-gray-400 hover:bg-gray-100"
                onClick={() => setDialogMode(null)}
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 p-4">
              {formError && (
                <div className="rounded bg-red-50 p-2 text-xs text-red-600">{formError}</div>
              )}
              <div>
                <label className="mb-1 block text-xs font-medium text-gray-600">
                  {t("admin.orgs.name", lang)}
                </label>
                <input
                  type="text"
                  className="sw-input w-full rounded border px-3 py-2 text-sm"
                  value={formName}
                  onChange={(e) => {
                    setFormName(e.target.value);
                    if (dialogMode === "create") {
                      setFormSlug(slugFromName(e.target.value));
                    }
                  }}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-medium text-gray-600">
                  {t("admin.orgs.slug", lang)}
                </label>
                <input
                  type="text"
                  className="sw-input w-full rounded border px-3 py-2 font-mono text-sm"
                  value={formSlug}
                  onChange={(e) => setFormSlug(e.target.value)}
                />
              </div>
              {dialogMode === "edit" && (
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="org-active"
                    checked={formActive}
                    onChange={(e) => setFormActive(e.target.checked)}
                    className="rounded"
                  />
                  <label htmlFor="org-active" className="text-sm text-gray-700">
                    {t("admin.users.active", lang)}
                  </label>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 border-t bg-gray-50 p-4">
              <button
                className="rounded px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-200"
                onClick={() => setDialogMode(null)}
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {t("list.crud.cancel", lang)}
              </button>
              <button
                className="rounded bg-blue-600 px-3 py-1.5 text-sm text-white hover:bg-blue-700 disabled:opacity-50"
                onClick={handleSubmit}
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {t("list.crud.save", lang)}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
