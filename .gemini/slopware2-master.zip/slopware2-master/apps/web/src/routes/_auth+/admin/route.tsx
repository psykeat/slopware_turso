import { createFileRoute } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { Outlet } from "@tanstack/react-router";
import * as React from "react";

import { t } from "~/features/workspace/i18n";
import type { Lang } from "~/features/workspace/i18n";

export const Route = createFileRoute("/_auth+/admin")({
  component: AdminLayout,
});

function AdminLayout() {
  const lang = React.useMemo<Lang>(() => "en", []);

  const navItems = [
    { to: "/admin", label: t("admin.dashboard.overview", lang) },
    { to: "/admin/users", label: t("admin.dashboard.users", lang) },
    { to: "/admin/organizations", label: t("admin.dashboard.orgs", lang) },
    { to: "/admin/tenants", label: t("admin.dashboard.tenants", lang) },
    { to: "/admin/companies", label: t("admin.dashboard.companies", lang) },
    { to: "/admin/integration", label: t("admin.integration.title", lang) },
    { to: "/admin/litellm", label: "LiteLLM" },
  ];

  return (
    <div className="sw-root flex h-screen flex-col">
      <header className="sw-header border-b p-4">
        <h1 className="text-xl font-bold">{t("admin.dashboard.title", lang)}</h1>
        <nav className="mt-2 flex gap-4">
          {navItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="sw-btn sw-btn-sm rounded px-3 py-1 text-sm hover:bg-gray-100"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </header>
      <main className="flex-1 overflow-auto p-6">
        <Outlet />
      </main>
    </div>
  );
}
