import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import * as React from "react";

import { t } from "~/features/workspace/i18n";
import type { Lang } from "~/features/workspace/i18n";
import { listTenantsFn, createTenantFn, updateTenantFn } from "~/server/server-functions";

export const Route = createFileRoute("/_auth+/admin/tenants")({
  component: () => <AdminTenants />,
});

export default function AdminTenants() {
  const lang = React.useMemo<Lang>(() => "en", []);
  const queryClient = useQueryClient();
  const [search, setSearch] = React.useState("");
  const [debouncedSearch, setDebouncedSearch] = React.useState("");
  const [dialogMode, setDialogMode] = React.useState<"create" | "edit" | null>(null);
  const [editingTenant, setEditingTenant] = React.useState<Record<string, unknown> | null>(null);

  React.useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(search), 300);
    return () => clearTimeout(timer);
  }, [search]);

  const { data, isLoading } = useQuery({
    queryKey: ["tenants", debouncedSearch],
    queryFn: () =>
      listTenantsFn({
        data: {
          limit: 100,
          offset: 0,
          search: debouncedSearch || undefined,
        },
      }),
  });

  const createMutation = useMutation({
    mutationFn: createTenantFn,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tenants"] });
      setDialogMode(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: updateTenantFn,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["tenants"] });
      setDialogMode(null);
      setEditingTenant(null);
    },
  });

  const [formName, setFormName] = React.useState("");
  const [formSlug, setFormSlug] = React.useState("");
  const [formOrgId, setFormOrgId] = React.useState("");
  const [formActive, setFormActive] = React.useState(true);
  const [formError, setFormError] = React.useState("");

  const openCreate = () => {
    setFormName("");
    setFormSlug("");
    setFormOrgId("");
    setFormActive(true);
    setFormError("");
    setEditingTenant(null);
    setDialogMode("create");
  };

  const openEdit = (tenant: Record<string, unknown>) => {
    setFormName(String(tenant.name ?? ""));
    setFormSlug(String(tenant.slug ?? ""));
    setFormOrgId(String(tenant.organization_id ?? ""));
    setFormActive(Boolean(tenant.is_active));
    setFormError("");
    setEditingTenant(tenant);
    setDialogMode("edit");
  };

  const slugFromName = (name: string) =>
    name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 63) || `tenant-${Date.now()}`;

  const isBase = editingTenant?.is_base === true;

  const handleSubmit = () => {
    setFormError("");
    if (!formName.trim()) {
      setFormError("Name is required");
      return;
    }
    if (!formSlug.trim()) {
      setFormError("Slug is required");
      return;
    }
    if (!/^[a-z0-9][a-z0-9-]{0,62}$/.test(formSlug)) {
      setFormError("Slug must be lowercase alphanumeric with hyphens, max 63 chars");
      return;
    }
    if (dialogMode === "create" && !formOrgId) {
      setFormError("Organization is required");
      return;
    }

    if (dialogMode === "create") {
      createMutation.mutate({
        data: { name: formName.trim(), slug: formSlug.trim(), organizationId: formOrgId },
      });
    } else if (dialogMode === "edit" && editingTenant) {
      updateMutation.mutate({
        data: {
          id: String(editingTenant.tenant_id),
          name: formName.trim(),
          slug: formSlug.trim(),
          organizationId: formOrgId || undefined,
          is_active: formActive,
        },
      });
    }
  };

  const items = data?.items ?? [];
  const total = data?.total ?? 0;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">{t("admin.tenants.title", lang)}</h2>
        <button
          className="sw-btn sw-btn-sm rounded bg-blue-600 px-3 py-1.5 text-sm text-white hover:bg-blue-700"
          onClick={openCreate}
          disabled={createMutation.isPending || updateMutation.isPending}
        >
          {t("admin.tenants.create", lang)}
        </button>
      </div>

      <input
        type="text"
        placeholder={t("admin.tenants.search", lang)}
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="sw-input rounded border px-3 py-2 text-sm"
      />

      {isLoading ? (
        <p className="text-sm text-gray-500">Loading...</p>
      ) : items.length === 0 ? (
        <p className="text-sm text-gray-500">{t("admin.tenants.empty", lang)}</p>
      ) : (
        <div className="overflow-auto rounded border">
          <table className="w-full text-left text-sm">
            <thead className="sticky top-0 bg-gray-50">
              <tr>
                <th className="p-2 font-medium">{t("admin.tenants.name", lang)}</th>
                <th className="p-2 font-medium">{t("admin.tenants.slug", lang)}</th>
                <th className="p-2 font-medium">{t("admin.tenants.org", lang)}</th>
                <th className="p-2 font-medium">{t("admin.tenants.isbase", lang)}</th>
                <th className="p-2 font-medium">{t("admin.tenants.status", lang)}</th>
                <th className="p-2 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((tenant: Record<string, unknown>) => (
                <tr key={String(tenant.tenant_id)} className="border-t hover:bg-gray-50">
                  <td className="p-2">{String(tenant.name)}</td>
                  <td className="p-2 font-mono text-xs">{String(tenant.slug)}</td>
                  <td className="p-2">{String(tenant.organization_name ?? "—")}</td>
                  <td className="p-2">{tenant.is_base ? "Yes" : "No"}</td>
                  <td className="p-2">
                    <span
                      className={`rounded px-2 py-0.5 text-xs ${
                        tenant.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                      }`}
                    >
                      {tenant.is_active
                        ? t("admin.users.active", lang)
                        : t("admin.users.inactive", lang)}
                    </span>
                  </td>
                  <td className="p-2">
                    <button
                      className="rounded px-2 py-1 text-xs text-blue-600 hover:bg-blue-50"
                      onClick={() => openEdit(tenant)}
                      disabled={isBase}
                    >
                      Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="border-t p-2 text-xs text-gray-500">Total: {total}</div>
        </div>
      )}

      {(dialogMode === "create" || dialogMode === "edit") && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm"
          onClick={() => setDialogMode(null)}
        >
          <div
            className="w-[450px] rounded-lg bg-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b p-4">
              <h3 className="text-lg font-bold text-gray-800">
                {dialogMode === "create"
                  ? t("admin.tenants.create", lang)
                  : t("admin.tenants.edit", lang)}
              </h3>
              <button
                className="rounded p-1.5 text-gray-400 hover:bg-gray-100"
                onClick={() => setDialogMode(null)}
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 p-4">
              {formError && (
                <div className="rounded bg-red-50 p-2 text-xs text-red-600">{formError}</div>
              )}
              <div>
                <label className="mb-1 block text-xs font-medium text-gray-600">
                  {t("admin.tenants.name", lang)}
                </label>
                <input
                  type="text"
                  className="sw-input w-full rounded border px-3 py-2 text-sm"
                  value={formName}
                  onChange={(e) => {
                    setFormName(e.target.value);
                    if (dialogMode === "create") {
                      setFormSlug(slugFromName(e.target.value));
                    }
                  }}
                  readOnly={isBase}
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-medium text-gray-600">
                  {t("admin.tenants.slug", lang)}
                </label>
                <input
                  type="text"
                  className="sw-input w-full rounded border px-3 py-2 font-mono text-sm"
                  value={formSlug}
                  onChange={(e) => setFormSlug(e.target.value)}
                  readOnly={isBase}
                />
              </div>
              {dialogMode === "create" && (
                <div>
                  <label className="mb-1 block text-xs font-medium text-gray-600">
                    {t("admin.tenants.org", lang)}
                  </label>
                  <input
                    type="text"
                    className="sw-input w-full rounded border px-3 py-2 text-sm"
                    value={formOrgId}
                    onChange={(e) => setFormOrgId(e.target.value)}
                    placeholder="Organization UUID"
                  />
                </div>
              )}
              {dialogMode === "edit" && (
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="tenant-active"
                    checked={formActive}
                    onChange={(e) => setFormActive(e.target.checked)}
                    className="rounded"
                    disabled={isBase}
                  />
                  <label htmlFor="tenant-active" className="text-sm text-gray-700">
                    {t("admin.users.active", lang)}
                  </label>
                </div>
              )}
              {isBase && (
                <div className="rounded bg-yellow-50 p-2 text-xs text-yellow-700">
                  Base tenant — editing restricted
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 border-t bg-gray-50 p-4">
              <button
                className="rounded px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-200"
                onClick={() => setDialogMode(null)}
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {t("list.crud.cancel", lang)}
              </button>
              <button
                className="rounded bg-blue-600 px-3 py-1.5 text-sm text-white hover:bg-blue-700 disabled:opacity-50"
                onClick={handleSubmit}
                disabled={createMutation.isPending || updateMutation.isPending || isBase}
              >
                {t("list.crud.save", lang)}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
