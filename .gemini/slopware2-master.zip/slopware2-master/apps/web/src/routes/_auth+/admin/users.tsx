import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import * as React from "react";

import { t } from "~/features/workspace/i18n";
import type { Lang } from "~/features/workspace/i18n";
import {
  listAdminUsersFn,
  createUserFn,
  updateUserFn,
  deactivateUserFn,
  resetUserPasswordFn,
} from "~/server/server-functions";

export const Route = createFileRoute("/_auth+/admin/users")({
  component: () => <AdminUsers />,
});

type UserRole = "system_admin" | "org_admin" | "tenant_admin" | "tenant_user";

const ROLES: { value: UserRole; label: string }[] = [
  { value: "tenant_user", label: "User" },
  { value: "tenant_admin", label: "Tenant Admin" },
  { value: "org_admin", label: "Org Admin" },
  { value: "system_admin", label: "System Admin" },
];

export default function AdminUsers() {
  const lang = React.useMemo<Lang>(() => "en", []);
  const queryClient = useQueryClient();
  const [search, setSearch] = React.useState("");
  const [debouncedSearch, setDebouncedSearch] = React.useState("");
  const [dialogMode, setDialogMode] = React.useState<
    "create" | "edit" | "deactivate" | "password" | null
  >(null);
  const [editingUser, setEditingUser] = React.useState<Record<string, unknown> | null>(null);
  const [formEmail, setFormEmail] = React.useState("");
  const [formPassword, setFormPassword] = React.useState("");
  const [formName, setFormName] = React.useState("");
  const [formRole, setFormRole] = React.useState<UserRole>("tenant_user");
  const [formActive, setFormActive] = React.useState(true);
  const [formError, setFormError] = React.useState("");

  React.useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(search), 300);
    return () => clearTimeout(timer);
  }, [search]);

  const { data, isLoading } = useQuery({
    queryKey: ["admin-users", debouncedSearch],
    queryFn: () =>
      listAdminUsersFn({
        data: { limit: 100, offset: 0, search: debouncedSearch || undefined },
      }),
  });

  const createMutation = useMutation({
    mutationFn: createUserFn,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-users"] });
      setDialogMode(null);
      resetForm();
    },
    onError: () => setFormError("Failed to create user"),
  });

  const updateMutation = useMutation({
    mutationFn: updateUserFn,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-users"] });
      setDialogMode(null);
      resetForm();
    },
    onError: () => setFormError("Failed to update user"),
  });

  const deactivateMutation = useMutation({
    mutationFn: deactivateUserFn,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-users"] });
      setDialogMode(null);
      resetForm();
    },
    onError: () => setFormError("Failed to deactivate user"),
  });

  const resetPasswordMutation = useMutation({
    mutationFn: resetUserPasswordFn,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-users"] });
      setDialogMode(null);
      resetForm();
    },
    onError: () => setFormError("Failed to reset password"),
  });

  const resetForm = () => {
    setFormEmail("");
    setFormPassword("");
    setFormName("");
    setFormRole("tenant_user");
    setFormActive(true);
    setFormError("");
    setEditingUser(null);
  };

  const openCreate = () => {
    resetForm();
    setDialogMode("create");
  };

  const openEdit = (user: Record<string, unknown>) => {
    setFormEmail(String(user.email ?? ""));
    setFormName(String(user.display_name ?? ""));
    setFormRole((user.role as UserRole) ?? "tenant_user");
    setFormActive(Boolean(user.is_active));
    setFormPassword("");
    setFormError("");
    setEditingUser(user);
    setDialogMode("edit");
  };

  const openDeactivate = (user: Record<string, unknown>) => {
    setEditingUser(user);
    setFormError("");
    setDialogMode("deactivate");
  };

  const openPassword = (user: Record<string, unknown>) => {
    setEditingUser(user);
    setFormPassword("");
    setFormError("");
    setDialogMode("password");
  };

  const isPending =
    createMutation.isPending ||
    updateMutation.isPending ||
    deactivateMutation.isPending ||
    resetPasswordMutation.isPending;

  const handleSubmit = () => {
    setFormError("");
    if (dialogMode === "create") {
      if (!formEmail.trim() || !formEmail.includes("@")) {
        setFormError("Valid email is required");
        return;
      }
      if (!formPassword.trim() || formPassword.length < 6) {
        setFormError("Password must be at least 6 characters");
        return;
      }
      createMutation.mutate({
        data: {
          email: formEmail.trim(),
          password: formPassword,
          displayName: formName.trim() || undefined,
          role: formRole,
        },
      });
    } else if (dialogMode === "edit" && editingUser) {
      if (!formEmail.trim() || !formEmail.includes("@")) {
        setFormError("Valid email is required");
        return;
      }
      updateMutation.mutate({
        data: {
          userId: String(editingUser.user_id),
          displayName: formName.trim() || undefined,
          role: formRole,
          is_active: formActive,
        },
      });
    } else if (dialogMode === "deactivate" && editingUser) {
      deactivateMutation.mutate({
        data: { userId: String(editingUser.user_id) },
      });
    } else if (dialogMode === "password" && editingUser) {
      if (!formPassword.trim() || formPassword.length < 6) {
        setFormError("Password must be at least 6 characters");
        return;
      }
      resetPasswordMutation.mutate({
        data: {
          userId: String(editingUser.user_id),
          password: formPassword,
        },
      });
    }
  };

  const items = data?.items ?? [];
  const total = data?.total ?? 0;

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">{t("admin.users.title", lang)}</h2>
        <button
          className="sw-btn sw-btn-sm rounded bg-blue-600 px-3 py-1.5 text-sm text-white hover:bg-blue-700"
          onClick={openCreate}
          disabled={isPending}
        >
          {t("admin.users.create", lang)}
        </button>
      </div>

      <input
        type="text"
        placeholder={t("admin.users.search", lang)}
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="sw-input rounded border px-3 py-2 text-sm"
      />

      {isLoading ? (
        <p className="text-sm text-gray-500">Loading...</p>
      ) : items.length === 0 ? (
        <p className="text-sm text-gray-500">{t("admin.users.empty", lang)}</p>
      ) : (
        <div className="overflow-auto rounded border">
          <table className="w-full text-left text-sm">
            <thead className="sticky top-0 bg-gray-50">
              <tr>
                <th className="p-2 font-medium">{t("admin.users.email", lang)}</th>
                <th className="p-2 font-medium">{t("admin.users.name", lang)}</th>
                <th className="p-2 font-medium">{t("admin.users.role", lang)}</th>
                <th className="p-2 font-medium">{t("admin.users.status", lang)}</th>
                <th className="p-2 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((user: Record<string, unknown>) => (
                <tr key={String(user.user_id)} className="border-t hover:bg-gray-50">
                  <td className="p-2 font-mono text-xs">{String(user.email)}</td>
                  <td className="p-2">{String(user.display_name ?? "—")}</td>
                  <td className="p-2">
                    <span className="rounded bg-gray-100 px-2 py-0.5 text-xs font-medium">
                      {ROLES.find((r) => r.value === user.role)?.label ?? String(user.role)}
                    </span>
                  </td>
                  <td className="p-2">
                    <span
                      className={`rounded px-2 py-0.5 text-xs ${
                        user.is_active ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                      }`}
                    >
                      {user.is_active
                        ? t("admin.users.active", lang)
                        : t("admin.users.inactive", lang)}
                    </span>
                  </td>
                  <td className="flex gap-2 p-2">
                    <button
                      className="rounded px-2 py-1 text-xs text-blue-600 hover:bg-blue-50"
                      onClick={() => openEdit(user)}
                    >
                      Edit
                    </button>
                    <button
                      className="rounded px-2 py-1 text-xs text-orange-600 hover:bg-orange-50"
                      onClick={() => openPassword(user)}
                    >
                      Reset PW
                    </button>
                    <button
                      className="rounded px-2 py-1 text-xs text-red-600 hover:bg-red-50"
                      onClick={() => openDeactivate(user)}
                      disabled={Boolean(user.is_active) === false}
                    >
                      Deactivate
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="border-t p-2 text-xs text-gray-500">Total: {total}</div>
        </div>
      )}

      {dialogMode && (
        <div
          role="presentation"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm"
          onClick={() => {
            setDialogMode(null);
            resetForm();
          }}
        >
          <div
            role="dialog"
            className="w-[450px] rounded-lg bg-white shadow-2xl"
            onClick={(e) => e.stopPropagation()}
            onKeyDown={() => {}}
          >
            <div className="flex items-center justify-between border-b p-4">
              <h3 className="text-lg font-bold text-gray-800">
                {dialogMode === "create"
                  ? t("admin.users.create", lang)
                  : dialogMode === "edit"
                    ? t("admin.users.edit", lang)
                    : dialogMode === "deactivate"
                      ? t("admin.users.delete", lang)
                      : "Reset Password"}
              </h3>
              <button
                className="rounded p-1.5 text-gray-400 hover:bg-gray-100"
                onClick={() => {
                  setDialogMode(null);
                  resetForm();
                }}
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 p-4">
              {formError && (
                <div className="rounded bg-red-50 p-2 text-xs text-red-600">{formError}</div>
              )}

              {dialogMode === "deactivate" && editingUser && (
                <p className="text-sm text-gray-600">
                  Deactivate{" "}
                  <strong>
                    {String(editingUser.email)}
                    {editingUser.display_name ? ` (${String(editingUser.display_name)})` : ""}
                  </strong>
                  ?
                </p>
              )}

              {(dialogMode === "create" || dialogMode === "edit") && (
                <>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-gray-600">
                      {t("admin.users.email", lang)}
                    </label>
                    <input
                      type="email"
                      className="sw-input w-full rounded border px-3 py-2 text-sm"
                      value={formEmail}
                      onChange={(e) => setFormEmail(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-gray-600">
                      {t("admin.users.name", lang)}
                    </label>
                    <input
                      type="text"
                      className="sw-input w-full rounded border px-3 py-2 text-sm"
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-gray-600">
                      {t("admin.users.role", lang)}
                    </label>
                    <select
                      className="sw-input w-full rounded border px-3 py-2 text-sm"
                      value={formRole}
                      onChange={(e) => setFormRole(e.target.value as UserRole)}
                    >
                      {ROLES.map((r) => (
                        <option key={r.value} value={r.value}>
                          {r.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  {dialogMode === "create" && (
                    <div>
                      <label
                        htmlFor="user-password"
                        className="mb-1 block text-xs font-medium text-gray-600"
                      >
                        Password
                      </label>
                      <input
                        id="user-password"
                        type="password"
                        className="sw-input w-full rounded border px-3 py-2 text-sm"
                        value={formPassword}
                        onChange={(e) => setFormPassword(e.target.value)}
                        placeholder="Min. 6 characters"
                      />
                    </div>
                  )}
                  {dialogMode === "edit" && (
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="user-active"
                        checked={formActive}
                        onChange={(e) => setFormActive(e.target.checked)}
                        className="rounded"
                      />
                      <label htmlFor="user-active" className="text-sm text-gray-700">
                        {t("admin.users.active", lang)}
                      </label>
                    </div>
                  )}
                </>
              )}

              {dialogMode === "password" && (
                <div>
                  <label
                    htmlFor="user-new-password"
                    className="mb-1 block text-xs font-medium text-gray-600"
                  >
                    New Password
                  </label>
                  <input
                    id="user-new-password"
                    type="password"
                    className="sw-input w-full rounded border px-3 py-2 text-sm"
                    value={formPassword}
                    onChange={(e) => setFormPassword(e.target.value)}
                    placeholder="Min. 6 characters"
                  />
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 border-t bg-gray-50 p-4">
              <button
                className="rounded px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-200"
                onClick={() => {
                  setDialogMode(null);
                  resetForm();
                }}
                disabled={isPending}
              >
                {t("list.crud.cancel", lang)}
              </button>
              <button
                className={`rounded px-3 py-1.5 text-sm text-white disabled:opacity-50 ${
                  dialogMode === "deactivate"
                    ? "bg-red-600 hover:bg-red-700"
                    : "bg-blue-600 hover:bg-blue-700"
                }`}
                onClick={handleSubmit}
                disabled={isPending}
              >
                {dialogMode === "deactivate"
                  ? t("admin.users.delete", lang)
                  : t("list.crud.save", lang)}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
