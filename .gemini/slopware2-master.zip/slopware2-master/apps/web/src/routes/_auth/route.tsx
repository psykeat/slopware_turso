import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_auth")({
  beforeLoad: async () => {
    if (typeof window !== "undefined") return;
    const { _getUser } = await import("@repo/auth/functions");
    const user = await _getUser();
    if (!user) throw redirect({ to: "/login" });
  },
  component: () => <Outlet />,
});
