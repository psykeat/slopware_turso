import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";

import "~/features/workspace/workspace.css";

export const Route = createFileRoute("/_guest")({
  beforeLoad: async () => {
    if (typeof window !== "undefined") return;
    const { _getUser } = await import("@repo/auth/functions");
    const user = await _getUser();
    if (user) throw redirect({ to: "/app" });
  },
  component: () => <Outlet />,
});
