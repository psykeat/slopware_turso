import { signUp } from "@repo/auth/auth-client";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { FormEvent, useState } from "react";
import { toast } from "sonner";

import "../../features/workspace/workspace-design.css";

export const Route = createFileRoute("/_guest/signup")({
  component: SignupPage,
});

function SignupPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    const formData = new FormData(e.currentTarget);
    const name = formData.get("name") as string;
    const email = formData.get("email") as string;
    const password = formData.get("password") as string;

    try {
      const { data, error } = await signUp.email({
        email,
        password,
        name,
        callbackURL: "/",
      });

      if (error) {
        toast.error(error.message || "Registrierung fehlgeschlagen");
      } else {
        toast.success("Account erfolgreich erstellt!");
        navigate({ to: "/app" });
      }
    } catch (err) {
      toast.error("Ein unerwarteter Fehler ist aufgetreten");
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div
      className="slopware-workspace"
      data-dark="false"
      style={{
        height: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "var(--bg)",
      }}
    >
      <div
        className="kpi-card"
        style={{
          width: "100%",
          maxWidth: "400px",
          padding: "40px",
          boxShadow: "var(--shadow-lg)",
          animation: "sw-dropIn 0.3s ease-out",
        }}
      >
        <div style={{ textAlign: "center", marginBottom: "32px" }}>
          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "10px",
              marginBottom: "20px",
            }}
          >
            <img
              src="/slopware-logo.png"
              alt="SLOPware"
              style={{ height: "32px" }}
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = "none";
              }}
            />
            <span
              style={{
                fontWeight: 800,
                fontSize: 22,
                letterSpacing: "-0.02em",
                color: "var(--accent)",
              }}
            >
              SLOP<span style={{ color: "var(--text-primary)" }}>ware</span>
            </span>
          </div>
          <h1
            style={{
              fontSize: "20px",
              fontWeight: 700,
              color: "var(--text-primary)",
              letterSpacing: "-0.01em",
            }}
          >
            Account erstellen
          </h1>
          <p style={{ fontSize: "13px", color: "var(--text-secondary)", marginTop: "6px" }}>
            Starten Sie jetzt mit Ihrem neuen Workspace
          </p>
        </div>

        <form
          onSubmit={handleSubmit}
          style={{ display: "flex", flexDirection: "column", gap: "20px" }}
        >
          <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
            <label
              style={{
                fontSize: "10px",
                fontWeight: 700,
                color: "var(--text-muted)",
                textTransform: "uppercase",
                letterSpacing: "0.05em",
              }}
            >
              Vollständiger Name
            </label>
            <input
              name="name"
              type="text"
              placeholder="Max Mustermann"
              required
              className="input"
              style={{ height: "36px" }}
              disabled={loading}
            />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
            <label
              style={{
                fontSize: "10px",
                fontWeight: 700,
                color: "var(--text-muted)",
                textTransform: "uppercase",
                letterSpacing: "0.05em",
              }}
            >
              Email Adresse
            </label>
            <input
              name="email"
              type="email"
              placeholder="name@company.com"
              required
              className="input"
              style={{ height: "36px" }}
              disabled={loading}
            />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
            <label
              style={{
                fontSize: "10px",
                fontWeight: 700,
                color: "var(--text-muted)",
                textTransform: "uppercase",
                letterSpacing: "0.05em",
              }}
            >
              Passwort
            </label>
            <input
              name="password"
              type="password"
              placeholder="••••••••"
              required
              minLength={8}
              className="input"
              style={{ height: "36px" }}
              disabled={loading}
            />
          </div>
          <button
            type="submit"
            className="btn btn-primary"
            style={{
              height: "38px",
              justifyContent: "center",
              fontSize: "13px",
              fontWeight: 600,
              marginTop: "8px",
            }}
            disabled={loading}
          >
            {loading ? "Wird erstellt..." : "Registrieren"}
          </button>
        </form>

        <div
          style={{
            marginTop: "32px",
            paddingTop: "20px",
            borderTop: "1px solid var(--border)",
            textAlign: "center",
            fontSize: "12.5px",
            color: "var(--text-secondary)",
          }}
        >
          Bereits einen Account?{" "}
          <a
            href="/login"
            style={{
              color: "var(--accent)",
              textDecoration: "none",
              fontWeight: 600,
            }}
          >
            Anmelden
          </a>
        </div>
      </div>
    </div>
  );
}
