import { auth } from "@repo/auth/auth";
import { createFileRoute } from "@tanstack/react-router";

function isConnectionError(err: unknown): boolean {
  const code = (err as { cause?: { code?: string } })?.cause?.code;
  return code === "ECONNREFUSED" || code === "ENOTFOUND" || code === "ETIMEDOUT";
}

async function handle(request: Request): Promise<Response> {
  try {
    return await auth.handler(request);
  } catch (err) {
    if (isConnectionError(err)) {
      console.error("[Auth] Database unreachable — is the DB container running?");
      return Response.json({ error: "Service temporarily unavailable" }, { status: 503 });
    }
    throw err;
  }
}

export const Route = createFileRoute("/api/auth/$")({
  server: {
    handlers: {
      GET: ({ request }) => handle(request),
      POST: ({ request }) => handle(request),
    },
  },
});
