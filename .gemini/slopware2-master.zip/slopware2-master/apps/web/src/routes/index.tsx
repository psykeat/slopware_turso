import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  beforeLoad: async () => {
    if (typeof window !== "undefined") return;
    const { _getUser } = await import("@repo/auth/functions");
    const user = await _getUser();
    throw redirect({ to: user ? "/app" : "/login" });
  },
  component: () => null,
});
