import { describe, it, expect } from "vitest";

describe("getAddressStatsFn", () => {
  it("address stats function is exported", async () => {
    const { getAddressStatsFn } = await import("../server-functions");
    expect(getAddressStatsFn).toBeDefined();
  });

  it("AddressStatsShapeCheck returns correct shape", async () => {
    const { AddressStatsShapeCheck } = await import("../server-functions");
    const sample = AddressStatsShapeCheck();
    expect(sample.stats).toHaveLength(2);
    expect(sample.stats[0]).toHaveProperty("periodNo");
    expect(sample.stats[0]).toHaveProperty("totalAmountNet");
    expect(sample.stats[0]).toHaveProperty("totalProfit");
    expect(sample.openItems).toHaveLength(1);
    expect(sample.openItems[0]).toHaveProperty("documentId");
    expect(sample.openItems[0]).toHaveProperty("dueDate");
    expect(sample.movements).toHaveLength(1);
    expect(sample.movements[0]).toHaveProperty("articleNo");
    expect(sample.movements[0]).toHaveProperty("quantity");
    expect(sample.documents).toHaveLength(1);
    expect(sample.documents[0]).toHaveProperty("status");
    expect(sample.isCustomer).toBe(true);
  });
});
