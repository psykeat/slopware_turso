import { describe, it, expect } from "vitest";

describe("getArticleGroupStatsFn", () => {
  it("article group stats function is exported", async () => {
    const { getArticleGroupStatsFn } = await import("../server-functions");
    expect(getArticleGroupStatsFn).toBeDefined();
  });

  it("ArticleGroupStatsShapeCheck returns correct shape", async () => {
    const { ArticleGroupStatsShapeCheck } = await import("../server-functions");
    const sample = ArticleGroupStatsShapeCheck();
    expect(sample.stats).toHaveLength(2);
    expect(sample.stats[0]).toHaveProperty("periodNo");
    expect(sample.stats[0]).toHaveProperty("totalQty");
    expect(sample.stats[0]).toHaveProperty("totalAmountNet");
    expect(sample.stats[0]).toHaveProperty("totalProfit");
    expect(sample.stats[0]).toHaveProperty("purchaseQty");
  });

  it("stats have correct aggregate values", async () => {
    const { ArticleGroupStatsShapeCheck } = await import("../server-functions");
    const sample = ArticleGroupStatsShapeCheck();
    expect(sample.stats[0].totalAmountNet).toBe(12000);
    expect(sample.stats[0].totalProfit).toBe(3500);
    expect(sample.stats[1].totalAmountNet).toBe(11000);
  });

  it("movements and documents have correct shape", async () => {
    const { ArticleGroupStatsShapeCheck } = await import("../server-functions");
    const sample = ArticleGroupStatsShapeCheck();
    expect(sample.movements).toHaveLength(1);
    expect(sample.movements[0]).toHaveProperty("documentDate");
    expect(sample.movements[0]).toHaveProperty("articleNo");
    expect(sample.movements[0]).toHaveProperty("quantity");
    expect(sample.documents).toHaveLength(1);
    expect(sample.documents[0]).toHaveProperty("status");
    expect(sample.documents[0]).toHaveProperty("totalGross");
  });
});
