import { describe, it, expect } from "vitest";

describe("getArticleStatsFn", () => {
  it("article stats function is exported", async () => {
    const { getArticleStatsFn } = await import("../server-functions");
    expect(getArticleStatsFn).toBeDefined();
  });

  it("ArticleStatsShapeCheck returns correct shape", async () => {
    const { ArticleStatsShapeCheck } = await import("../server-functions");
    const sample = ArticleStatsShapeCheck();
    expect(sample.stats).toHaveLength(2);
    expect(sample.stats[0]).toHaveProperty("periodNo");
    expect(sample.stats[0]).toHaveProperty("totalQty");
    expect(sample.stats[0]).toHaveProperty("totalAmountNet");
    expect(sample.stats[0]).toHaveProperty("totalProfit");
    expect(sample.stats[0]).toHaveProperty("purchaseQty");
  });

  it("stock journal has running balance", async () => {
    const { ArticleStatsShapeCheck } = await import("../server-functions");
    const sample = ArticleStatsShapeCheck();
    expect(sample.stockJournal).toHaveLength(2);
    expect(sample.stockJournal[0].runningBalance).toBe(100);
    expect(sample.stockJournal[1].runningBalance).toBe(90);
  });

  it("reserved and expected purchase qty are present", async () => {
    const { ArticleStatsShapeCheck } = await import("../server-functions");
    const sample = ArticleStatsShapeCheck();
    expect(sample.reservedQty).toBe(15);
    expect(sample.expectedPurchaseQty).toBe(50);
  });

  it("movements and documents have correct shape", async () => {
    const { ArticleStatsShapeCheck } = await import("../server-functions");
    const sample = ArticleStatsShapeCheck();
    expect(sample.movements).toHaveLength(1);
    expect(sample.movements[0]).toHaveProperty("documentDate");
    expect(sample.movements[0]).toHaveProperty("quantity");
    expect(sample.documents).toHaveLength(1);
    expect(sample.documents[0]).toHaveProperty("status");
    expect(sample.documents[0]).toHaveProperty("totalGross");
  });
});
