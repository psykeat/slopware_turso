import { encryptConnectorCredentials, decryptConnectorCredentials } from "@repo/integration";
import { describe, it, expect, beforeEach } from "vitest";

const testKey = "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2";

beforeEach(() => {
  process.env.CREDENTIALS_ENCRYPTION_KEY = testKey;
});

describe("connector activation credentials", () => {
  it("credentials are encrypted before storage", async () => {
    const creds = { api_key: "sk-secret-123", endpoint: "https://api.test.com" };
    const encrypted = await encryptConnectorCredentials(creds);
    expect(encrypted).not.toContain("sk-secret-123");
    expect(encrypted).not.toContain("api.test.com");
    expect(encrypted.length).toBeGreaterThan(40);
  });

  it("encrypted credentials decrypt to original", async () => {
    const creds = { api_key: "sk-secret-123", endpoint: "https://api.test.com" };
    const encrypted = await encryptConnectorCredentials(creds);
    const decrypted = await decryptConnectorCredentials(encrypted);
    expect(decrypted).toEqual(creds);
  });

  it("activation creates tenant_connector with encrypted credentials", async () => {
    const creds = { api_key: "sk-test-key" };
    const encrypted = await encryptConnectorCredentials(creds);
    expect(typeof encrypted).toBe("string");
    const decrypted = await decryptConnectorCredentials(encrypted);
    expect(decrypted.api_key).toBe("sk-test-key");
  });
});
