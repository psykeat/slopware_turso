import { describe, it, expect, vi, beforeEach } from "vitest";

vi.mock("@repo/auth/functions", () => ({
  _getUser: vi.fn().mockResolvedValue({ id: "user-1", name: "Test" }),
}));

vi.mock("@tanstack/react-start/server", () => ({
  getRequest: vi.fn(),
  setResponseStatus: vi.fn(),
  createServerFn: vi.fn().mockReturnValue({
    inputValidator: vi.fn().mockReturnThis(),
    handler: vi.fn().mockReturnThis(),
  }),
}));

vi.mock("../context", () => ({
  $getTenantId: vi.fn().mockResolvedValue("11111111-1111-1111-1111-111111111111"),
}));

describe("connector server functions", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("activateConnectorFn is exported", async () => {
    const { activateConnectorFn } = await import("../server-functions");
    expect(activateConnectorFn).toBeDefined();
  });

  it("deactivateConnectorFn is exported", async () => {
    const { deactivateConnectorFn } = await import("../server-functions");
    expect(deactivateConnectorFn).toBeDefined();
  });

  it("saveConnectorCredentialsFn is exported", async () => {
    const { saveConnectorCredentialsFn } = await import("../server-functions");
    expect(saveConnectorCredentialsFn).toBeDefined();
  });

  it("listTenantConnectorsFn is exported", async () => {
    const { listTenantConnectorsFn } = await import("../server-functions");
    expect(listTenantConnectorsFn).toBeDefined();
  });
});
