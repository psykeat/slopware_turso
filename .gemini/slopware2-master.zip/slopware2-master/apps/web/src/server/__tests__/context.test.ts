import { describe, it, expect, vi, beforeEach } from "vitest";

vi.mock("@repo/domain", () => ({
  validateTenantId: vi.fn(),
  BASE_TENANT_ID: "00000000-0000-0000-0000-000000000002",
}));

describe("extractTenantId", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("returns base tenant ID when no header or param", async () => {
    const { extractTenantId } = await import("../context");
    const { validateTenantId } = await import("@repo/domain");
    vi.mocked(validateTenantId).mockReturnValue(false);

    const headers = new Headers();
    const result = extractTenantId(headers, "http://localhost:3000/app");

    expect(result).toBe("00000000-0000-0000-0000-000000000002");
  });

  it("returns tenant ID from x-tenant-id header when valid", async () => {
    const testTenantId = "11111111-1111-1111-1111-111111111111";
    const { extractTenantId } = await import("../context");
    const { validateTenantId } = await import("@repo/domain");
    vi.mocked(validateTenantId).mockReturnValue(true);

    const headers = new Headers({ "x-tenant-id": testTenantId });
    const result = extractTenantId(headers, "http://localhost:3000/app");

    expect(result).toBe(testTenantId);
  });

  it("returns tenant ID from search param when valid", async () => {
    const testTenantId = "22222222-2222-2222-2222-222222222222";
    const { extractTenantId } = await import("../context");
    const { validateTenantId } = await import("@repo/domain");
    vi.mocked(validateTenantId).mockImplementation((id: unknown) => {
      if (typeof id !== "string") return false;
      return id === testTenantId;
    });

    const headers = new Headers();
    const result = extractTenantId(headers, `http://localhost:3000/app?tenantId=${testTenantId}`);

    expect(result).toBe(testTenantId);
  });

  it("prefers header over search param", async () => {
    const headerTenantId = "11111111-1111-1111-1111-111111111111";
    const paramTenantId = "22222222-2222-2222-2222-222222222222";
    const { extractTenantId } = await import("../context");
    const { validateTenantId } = await import("@repo/domain");
    vi.mocked(validateTenantId).mockReturnValue(true);

    const headers = new Headers({ "x-tenant-id": headerTenantId });
    const result = extractTenantId(headers, `http://localhost:3000/app?tenantId=${paramTenantId}`);

    expect(result).toBe(headerTenantId);
  });
});
