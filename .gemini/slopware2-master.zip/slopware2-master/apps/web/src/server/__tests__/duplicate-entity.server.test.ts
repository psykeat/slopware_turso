import { describe, it, expect, vi, beforeEach } from "vitest";

const mockDuplicateEntity = vi.fn();

vi.mock("@repo/db", () => ({
  db: {
    $client: {},
  },
}));

vi.mock("@repo/domain", () => ({
  duplicateEntity: mockDuplicateEntity,
  withTenant: vi.fn().mockImplementation(async (_sql, _tenantId, fn) => {
    const mockTx = { unsafe: vi.fn() };
    return fn({}, mockTx);
  }),
  validateTenantId: vi.fn(),
  BASE_TENANT_ID: "00000000-0000-0000-0000-000000000002",
}));

describe("duplicateEntity.server", () => {
  const tenantId = "11111111-1111-1111-1111-111111111111";

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("duplicates entity via domain layer with tenant context", async () => {
    mockDuplicateEntity.mockResolvedValue({
      success: true,
      id: "new-copy-id-456",
    });

    const { $duplicateEntity } = await import("../entity-ops.server");
    const result = await $duplicateEntity({
      entityName: "companies",
      tenantId,
      sourceId: "company-123",
    });

    expect(result.success).toBe(true);
    expect(result.id).toBe("new-copy-id-456");
    expect(mockDuplicateEntity).toHaveBeenCalledWith(expect.anything(), "companies", "company-123");
  });

  it("returns error when duplicate fails", async () => {
    mockDuplicateEntity.mockResolvedValue({
      success: false,
      error: "Entity 'unknown_entity' is not generically duplicable",
    });

    const { $duplicateEntity } = await import("../entity-ops.server");
    const result = await $duplicateEntity({
      entityName: "unknown_entity",
      tenantId,
      sourceId: "some-id",
    });

    expect(result.success).toBe(false);
    expect(result.error).toContain("not generically duplicable");
  });
});
