import { describe, it, expect, vi, beforeEach } from "vitest";

const mockListEntity = vi.fn();
const mockCreateEntity = vi.fn();
const mockPatchEntity = vi.fn();
const mockDeleteEntity = vi.fn();

vi.mock("@repo/db", () => ({
  db: {
    $client: {},
  },
}));

vi.mock("@repo/domain", () => ({
  listEntity: mockListEntity,
  createEntity: mockCreateEntity,
  patchEntity: mockPatchEntity,
  deleteEntity: mockDeleteEntity,
  withTenant: vi.fn().mockImplementation(async (_sql, _tenantId, fn) => {
    const mockTx = { unsafe: vi.fn() };
    return fn({}, mockTx);
  }),
  validateTenantId: vi.fn(),
  BASE_TENANT_ID: "00000000-0000-0000-0000-000000000002",
}));

describe("entity-ops.server", () => {
  const tenantId = "11111111-1111-1111-1111-111111111111";

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("lists entities from domain layer with tenant context", async () => {
    mockListEntity.mockResolvedValue({
      items: [{ name: "Test Org" }],
      total: 1,
      limit: 10,
      offset: 0,
    });

    const { $listEntity } = await import("../entity-ops.server");
    const result = await $listEntity({
      entityName: "organizations",
      tenantId,
      options: { limit: 10, offset: 0 },
    });

    expect(result.items).toHaveLength(1);
    expect(result.total).toBe(1);
    expect(mockListEntity).toHaveBeenCalledWith(expect.anything(), "organizations", {
      limit: 10,
      offset: 0,
    });
  });

  it("creates entity via domain layer with tenant context", async () => {
    mockCreateEntity.mockResolvedValue({
      success: true,
      id: "new-id-123",
    });

    const { $createEntity } = await import("../entity-ops.server");
    const result = await $createEntity({
      entityName: "organizations",
      tenantId,
      payload: { name: "New Org" },
    });

    expect(result.success).toBe(true);
    expect(result.id).toBe("new-id-123");
    expect(mockCreateEntity).toHaveBeenCalledWith(expect.anything(), "organizations", {
      name: "New Org",
    });
  });

  it("patches entity via domain layer with tenant context", async () => {
    mockPatchEntity.mockResolvedValue({ success: true });

    const { $patchEntity } = await import("../entity-ops.server");
    const result = await $patchEntity({
      entityName: "organizations",
      tenantId,
      id: "org-123",
      payload: { name: "Updated" },
    });

    expect(result.success).toBe(true);
    expect(mockPatchEntity).toHaveBeenCalledWith(expect.anything(), "organizations", "org-123", {
      name: "Updated",
    });
  });

  it("deletes entity via domain layer with tenant context", async () => {
    mockDeleteEntity.mockResolvedValue({
      success: true,
      action: "soft_delete",
    });

    const { $deleteEntity } = await import("../entity-ops.server");
    const result = await $deleteEntity({
      entityName: "organizations",
      tenantId,
      id: "org-123",
    });

    expect(result.success).toBe(true);
    expect(result.action).toBe("soft_delete");
    expect(mockDeleteEntity).toHaveBeenCalledWith(expect.anything(), "organizations", "org-123");
  });

  it("falls back to BASE_TENANT_ID when tenantId is empty", async () => {
    mockListEntity.mockResolvedValue({
      items: [],
      total: 0,
      limit: 100,
      offset: 0,
    });

    const { withTenant, BASE_TENANT_ID } = await import("@repo/domain");

    const { $listEntity } = await import("../entity-ops.server");
    await $listEntity({
      entityName: "organizations",
      tenantId: "",
    });

    expect(withTenant).toHaveBeenCalledWith(
      expect.anything(),
      BASE_TENANT_ID,
      expect.any(Function),
    );
  });

  it("supports different entity types", async () => {
    mockListEntity.mockResolvedValue({
      items: [{ id: "1", name: "Company A" }],
      total: 1,
      limit: 5,
      offset: 0,
    });

    const { $listEntity } = await import("../entity-ops.server");
    const result = await $listEntity({
      entityName: "companies",
      tenantId,
      options: { limit: 5, sortBy: "name", sortOrder: "DESC" },
    });

    expect(result.items).toHaveLength(1);
    expect(mockListEntity).toHaveBeenCalledWith(expect.anything(), "companies", {
      limit: 5,
      sortBy: "name",
      sortOrder: "DESC",
    });
  });
});
