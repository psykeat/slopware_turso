import { describe, it, expect, vi, beforeEach } from "vitest";

const mockGetUser = vi.fn().mockResolvedValue({ id: "user-1", name: "Test User" });
const mockGetTenantId = vi.fn();
const mockListEntity = vi.fn();
const mockCreateEntity = vi.fn();
const mockPatchEntity = vi.fn();
const mockDeleteEntity = vi.fn();

vi.mock("@repo/auth/functions", () => ({
  _getUser: mockGetUser,
}));

vi.mock("@tanstack/react-start/server", () => ({
  getRequest: vi.fn(),
  setResponseStatus: vi.fn(),
  createServerFn: vi.fn().mockReturnValue({
    inputValidator: vi.fn().mockReturnThis(),
    handler: vi.fn().mockReturnThis(),
  }),
}));

vi.mock("../context", () => ({
  $getTenantId: mockGetTenantId,
}));

vi.mock("../entity-ops.server", () => ({
  $listEntity: mockListEntity,
  $createEntity: mockCreateEntity,
  $patchEntity: mockPatchEntity,
  $deleteEntity: mockDeleteEntity,
}));

const testTenantId = "11111111-1111-1111-1111-111111111111";

describe("server-functions", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockGetUser.mockResolvedValue({ id: "user-1", name: "Test User" });
    mockGetTenantId.mockResolvedValue(testTenantId);
  });

  it("server functions are exported", async () => {
    const { listEntityFn, createEntityFn, updateEntityFn, deleteEntityFn } =
      await import("../server-functions");
    expect(listEntityFn).toBeDefined();
    expect(createEntityFn).toBeDefined();
    expect(updateEntityFn).toBeDefined();
    expect(deleteEntityFn).toBeDefined();
  });

  it("organization admin functions are exported", async () => {
    const { listOrganizationsFn, createOrganizationFn, requireAdminRole } =
      await import("../server-functions");
    expect(listOrganizationsFn).toBeDefined();
    expect(createOrganizationFn).toBeDefined();
    expect(typeof requireAdminRole).toBe("function");
  });

  it("tenant admin functions are exported", async () => {
    const { listTenantsFn, createTenantFn, updateTenantFn } = await import("../server-functions");
    expect(listTenantsFn).toBeDefined();
    expect(createTenantFn).toBeDefined();
    expect(updateTenantFn).toBeDefined();
  });

  it("company admin functions are exported", async () => {
    const { listAdminCompaniesFn, createAdminCompanyFn, updateAdminCompanyFn } =
      await import("../server-functions");
    expect(listAdminCompaniesFn).toBeDefined();
    expect(createAdminCompanyFn).toBeDefined();
    expect(updateAdminCompanyFn).toBeDefined();
  });

  it("dashboard stats function is exported", async () => {
    const { getAdminStatsFn } = await import("../server-functions");
    expect(getAdminStatsFn).toBeDefined();
  });

  it("connectors list function is exported", async () => {
    const { listConnectorsFn } = await import("../server-functions");
    expect(listConnectorsFn).toBeDefined();
  });

  it("document list functions are exported", async () => {
    const { listDocumentsFn, listDocumentTreeFn } = await import("../server-functions");
    expect(listDocumentsFn).toBeDefined();
    expect(listDocumentTreeFn).toBeDefined();
  });

  it("document update function is exported", async () => {
    const { updateDocumentFn } = await import("../server-functions");
    expect(updateDocumentFn).toBeDefined();
  });

  it("document create function is exported", async () => {
    const { createDocumentFn } = await import("../server-functions");
    expect(createDocumentFn).toBeDefined();
  });

  it("getCompanyDefaultsFn is exported", async () => {
    const { getCompanyDefaultsFn } = await import("../server-functions");
    expect(getCompanyDefaultsFn).toBeDefined();
  });

  it("updateDocumentFn accepts lines array in payload", async () => {
    const src = await import("fs").then((m) =>
      m.default.readFileSync(import.meta.dirname + "/../server-functions.ts", "utf-8"),
    );
    expect(src).toContain("updateDocumentFn");
    expect(src).toContain("documentLineSchema");
    expect(src).toContain("lines:");
  });

  it("createDocumentFn accepts lines array in payload", async () => {
    const src = await import("fs").then((m) =>
      m.default.readFileSync(import.meta.dirname + "/../server-functions.ts", "utf-8"),
    );
    expect(src).toContain("createDocumentFn");
    expect(src).toContain("lines: z.array(documentLineSchema)");
  });

  it("documentLineSchema includes required fields for line persistence", async () => {
    const src = await import("fs").then((m) =>
      m.default.readFileSync(import.meta.dirname + "/../server-functions.ts", "utf-8"),
    );
    expect(src).toContain("lineNo: z.number()");
    expect(src).toContain("quantity: z.number()");
    expect(src).toContain("netPrice: z.number()");
    expect(src).toContain("articleId:");
  });

  it("article pricing function is exported", async () => {
    const { resolveArticlePricingFn } = await import("../server-functions");
    expect(resolveArticlePricingFn).toBeDefined();
  });

  it("seedDocumentDefaults is imported from domain", async () => {
    const { seedDocumentDefaults } = await import("@repo/domain");
    expect(typeof seedDocumentDefaults).toBe("function");
  });

  it("dashboard KPIs function is exported", async () => {
    const { getDashboardKpisFn } = await import("../server-functions");
    expect(getDashboardKpisFn).toBeDefined();
  });

  it("period comparison function is exported", async () => {
    const { getPeriodComparisonStatsFn, getFiscalYearsFn } = await import("../server-functions");
    expect(getPeriodComparisonStatsFn).toBeDefined();
    expect(getFiscalYearsFn).toBeDefined();
  });

  it("PeriodComparisonStats shape check returns 12 periods", async () => {
    const { PeriodComparisonShapeCheck } = await import("../server-functions");
    const sample = PeriodComparisonShapeCheck();
    expect(sample.fiscalYear).toBe(2026);
    expect(sample.priorYear).toBe(2025);
    expect(sample.currentYear).toHaveLength(12);
    expect(sample.priorYearData).toHaveLength(12);
    expect(sample.currentYear[0].periodNo).toBe(1);
    expect(sample.currentYear[11].periodNo).toBe(12);
    expect(sample.currentYear[0]).toHaveProperty("totalAmountNet");
    expect(sample.currentYear[0]).toHaveProperty("totalProfit");
  });

  it("DashboardKpis interface has correct shape", async () => {
    const { DashboardKpisShapeCheck } = await import("../server-functions");
    const sample = DashboardKpisShapeCheck();
    expect(sample.fiscalYear).toBe(2026);
    expect(sample.umsatzCurrent).toBe(10000);
    expect(sample.umsatzPrior).toBe(8000);
    expect(sample.rohertragCurrent).toBe(3000);
    expect(sample.rohertragPrior).toBe(2500);
    expect(sample.openOrdersCount).toBe(5);
    expect(sample.openOrdersValue).toBe(15000);
    expect(sample.openInvoicesCount).toBe(3);
    expect(sample.openInvoicesValue).toBe(9000);
    expect(sample.inventoryValue).toBe(50000);
    expect(sample.topArticleGroups).toHaveLength(1);
    expect(sample.topArticleGroups[0]).toMatchObject({
      articleGroupId: "test-id",
      name: "Test Group",
      totalAmountNet: 5000,
      totalProfit: 1500,
    });
  });
});
