import { db } from "@repo/db";

export function getDb() {
  return db;
}
