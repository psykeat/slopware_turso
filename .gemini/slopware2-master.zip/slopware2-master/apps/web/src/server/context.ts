import { $getUser } from "@repo/auth/functions";
import { validateTenantId, BASE_TENANT_ID } from "@repo/domain";
import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";

export function extractTenantId(
  headers: Headers | undefined,
  requestUrl: string | undefined,
): string {
  if (!headers || !requestUrl) return BASE_TENANT_ID;

  const tenantHeader = headers.get("x-tenant-id");
  if (tenantHeader && validateTenantId(tenantHeader)) {
    return tenantHeader;
  }

  try {
    const url = new URL(requestUrl);
    const tenantParam = url.searchParams.get("tenantId");
    if (tenantParam && validateTenantId(tenantParam)) {
      return tenantParam;
    }
  } catch (e) {
    // Invalid URL
  }

  return BASE_TENANT_ID;
}

export const $getTenantId = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const request = getRequest();
    return extractTenantId(request?.headers, request?.url);
  } catch (e) {
    return BASE_TENANT_ID;
  }
});

export interface RequestContext {
  tenantId: string;
  user: Awaited<ReturnType<typeof $getUser>>;
  headers: Record<string, string>;
}

export const $getRequestContext = createServerFn({ method: "GET" }).handler(
  async (): Promise<RequestContext> => {
    const tenantId = await $getTenantId();
    const user = await $getUser();

    let requestHeaders: Headers | undefined;
    try {
      requestHeaders = getRequest()?.headers;
    } catch (e) {
      // Ignore
    }

    const headers: Record<string, string> = {};
    if (requestHeaders) {
      for (const [key, value] of requestHeaders.entries()) {
        headers[key] = value;
      }
    }

    return { tenantId, user, headers };
  },
);
