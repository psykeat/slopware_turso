import { createServerFn as tanstackCreateServerFn } from "@tanstack/react-start";

import { telemetryMiddleware } from "./telemetry-middleware";

/**
 * Custom wrapper for createServerFn that automatically injects telemetry.
 */
export const createServerFn: typeof tanstackCreateServerFn = (options) => {
  const fn = tanstackCreateServerFn(options);
  // We apply the middleware here so all functions created with this wrapper have it.
  // Note: .middleware() returns a new instance, so we need to be careful with the typing if we want to support chaining.
  // For now, let's keep it simple and just return the original if we can't easily wrap the builder.
  return fn.middleware([telemetryMiddleware]) as any;
};
