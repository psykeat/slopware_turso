import { db } from "@repo/db";
import {
  listEntity,
  createEntity,
  patchEntity,
  deleteEntity,
  duplicateEntity,
  getEntityById,
  withTenant,
  BASE_TENANT_ID,
} from "@repo/domain";
import type { SqlClient, ListEntityOptions } from "@repo/domain";

const sql = db.$client as unknown as SqlClient;

export interface ListEntityInput {
  entityName: string;
  tenantId: string;
  options?: ListEntityOptions;
}

export interface CreateEntityInput {
  entityName: string;
  tenantId: string;
  payload: Record<string, unknown>;
}

export interface PatchEntityInput {
  entityName: string;
  tenantId: string;
  id: string;
  payload: Record<string, unknown>;
}

export interface DeleteEntityInput {
  entityName: string;
  tenantId: string;
  id: string;
}

export interface DuplicateEntityInput {
  entityName: string;
  tenantId: string;
  sourceId: string;
}

export interface ReadEntityInput {
  entityName: string;
  tenantId: string;
  id: string;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function $listEntity({ entityName, tenantId, options }: ListEntityInput): Promise<{
  items: Record<string, unknown>[];
  total: number;
  limit: number;
  offset: number;
}> {
  const effectiveTenantId = tenantId || BASE_TENANT_ID;
  const result = await withTenant(sql, effectiveTenantId, async (_, tx) => {
    return listEntity(tx, entityName, options);
  });
  return {
    items: result.items as Record<string, unknown>[],
    total: result.total,
    limit: result.limit,
    offset: result.offset,
  };
}

export async function $createEntity({
  entityName,
  tenantId,
  payload,
}: CreateEntityInput): Promise<{ success: boolean; id?: string; error?: string }> {
  const effectiveTenantId = tenantId || BASE_TENANT_ID;
  const result = await withTenant(sql, effectiveTenantId, async (_, tx) => {
    return createEntity(tx, entityName, payload);
  });
  return {
    success: result.success,
    id: result.id,
    error: result.error,
  };
}

export async function $patchEntity({
  entityName,
  tenantId,
  id,
  payload,
}: PatchEntityInput): Promise<{ success: boolean; error?: string }> {
  const effectiveTenantId = tenantId || BASE_TENANT_ID;
  const result = await withTenant(sql, effectiveTenantId, async (_, tx) => {
    return patchEntity(tx, entityName, id, payload);
  });
  return {
    success: result.success,
    error: result.error,
  };
}

export async function $deleteEntity({
  entityName,
  tenantId,
  id,
}: DeleteEntityInput): Promise<{ success: boolean; error?: string; action?: string }> {
  const effectiveTenantId = tenantId || BASE_TENANT_ID;
  const result = await withTenant(sql, effectiveTenantId, async (_, tx) => {
    return deleteEntity(tx, entityName, id);
  });
  return {
    success: result.success,
    error: result.error,
    action: result.action,
  };
}

export async function $duplicateEntity({
  entityName,
  tenantId,
  sourceId,
}: DuplicateEntityInput): Promise<{ success: boolean; id?: string; error?: string }> {
  const effectiveTenantId = tenantId || BASE_TENANT_ID;
  const result = await withTenant(sql, effectiveTenantId, async (_, tx) => {
    return duplicateEntity(tx, entityName, sourceId);
  });
  return {
    success: result.success,
    id: result.id,
    error: result.error,
  };
}

export async function $readEntity({
  entityName,
  tenantId,
  id,
}: ReadEntityInput): Promise<Record<string, unknown> | null> {
  const effectiveTenantId = tenantId || BASE_TENANT_ID;
  return withTenant(sql, effectiveTenantId, async (_, tx) => {
    return getEntityById(tx, entityName, id) as Promise<Record<string, unknown> | null>;
  });
}
