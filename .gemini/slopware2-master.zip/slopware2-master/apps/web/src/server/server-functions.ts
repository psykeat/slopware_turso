import { ValueType } from "@opentelemetry/api";
import { appUser, tenant } from "@repo/db/schema";
import {
  getEffectiveFields,
  getHelperTableItems,
  listEntity,
  createEntity,
  patchEntity,
  deleteEntity,
  duplicateEntity,
  withTenant,
  withSystemContext,
  listAdminUsers,
  getAdminUser,
  getUserTenants,
  createUser,
  updateUser,
  deactivateUser,
  resetUserPassword,
  assignUserTenant,
  removeUserTenant,
  createDocument,
  deleteDocument,
  updateDocument,
  postDocument,
  convertDocument,
  stornoDocument,
  applyDeltaEffect,
  explodeDocumentBom,
  rerunImportBatch,
  rejectImportBatch,
  closePeriod,
  createAuditEvent,
  resolveArticlePricing,
  getInventoryBalance,
  getCustomerDocuments,
  getCustomerYearlyRevenue,
  seedDocumentDefaults,
  getLlmConfig,
  saveLlmConfig,
  getLiteLLMConfig,
  saveLiteLLMConfig,
} from "@repo/domain";
import type { ListEntityOptions, LlmConfig, LiteLLMConfig } from "@repo/domain";
import { createServerFn } from "@tanstack/react-start";
import { eq } from "drizzle-orm";
import { z, ZodError } from "zod";

import { getTraceId } from "../telemetry";
import { meter } from "../telemetry";
import { $getTenantId } from "./context";
import { telemetryMiddleware } from "./telemetry-middleware";
import { createDynamicZodSchema } from "./validation";

const dbDuration = meter.createHistogram("db_query_duration_milliseconds", {
  description: "Duration of database queries",
  valueType: ValueType.DOUBLE,
  advice: {
    explicitBucketBoundaries: [1, 2, 5, 10, 20, 50, 100, 250, 500, 1000],
  },
});

async function getDb() {
  const { db, pool } = await import("@repo/db");

  const wrapClient = (client: any, type: "pool" | "tx") => {
    return new Proxy(client, {
      apply(target, thisArg, args) {
        const start = performance.now();
        const result = target.apply(thisArg, args as any);
        if (result instanceof Promise) {
          return result.finally(() => {
            dbDuration.record(performance.now() - start, { "db.op": "query", "db.client": type });
          });
        }
        return result;
      },
      get(target, prop, receiver) {
        if (prop === "unsafe") {
          return (...args: any[]) => {
            const start = performance.now();
            const result = target.unsafe(...(args as [any]));
            if (result instanceof Promise) {
              return result.finally(() => {
                dbDuration.record(performance.now() - start, {
                  "db.op": "unsafe",
                  "db.client": type,
                });
              });
            }
            return result;
          };
        }
        if (prop === "begin" && type === "pool") {
          return async (cb: (tx: any) => Promise<any>) => {
            return target.begin(async (tx: any) => {
              return cb(wrapClient(tx, "tx"));
            });
          };
        }
        return Reflect.get(target, prop, receiver);
      },
    });
  };

  return { db, sql: wrapClient(pool, "pool") as any };
}

async function getUser() {
  const { _getUser } = await import("@repo/auth/functions");
  return _getUser();
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function runWithTenant<T>(tenantId: string, fn: (...args: any[]) => Promise<T>): Promise<T> {
  const { sql } = await getDb();
  return withTenant(sql, tenantId, fn);
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function runWithSystem<T>(fn: (...args: any[]) => Promise<T>): Promise<T> {
  const { sql } = await getDb();
  return withSystemContext(sql, fn);
}

export async function requireAdminRole(): Promise<void> {
  const user = await getUser();
  if (!user) throw new Error("Unauthorized");
  const { db: dbClient } = await getDb();
  const userRecord = await dbClient
    .select({ role: appUser.role })
    .from(appUser)
    .where(eq(appUser.email, user.email))
    .limit(1);
  const baseRole = userRecord[0]?.role ?? "tenant_user";
  const isAdmin =
    baseRole === "system_admin" || baseRole === "org_admin" || baseRole === "tenant_admin";
  if (!isAdmin) throw new Error("Forbidden: admin role required");
}

export async function requireSystemAdmin(): Promise<void> {
  const user = await getUser();
  if (!user) throw new Error("Unauthorized");
  const { db: dbClient } = await getDb();
  const userRecord = await dbClient
    .select({ isSystemAdmin: appUser.isSystemAdmin })
    .from(appUser)
    .where(eq(appUser.email, user.email))
    .limit(1);
  if (!userRecord[0]?.isSystemAdmin) throw new Error("Forbidden: system admin required");
}

export interface ListEntityRequest {
  entityName: string;
  options?: ListEntityOptions;
}

export interface CreateEntityRequest {
  entityName: string;
  payload: Record<string, unknown>;
}

export interface UpdateEntityRequest {
  entityName: string;
  id: string;
  payload: Record<string, unknown>;
}

export interface DeleteEntityRequest {
  entityName: string;
  id: string;
}

export interface DuplicateEntityRequest {
  entityName: string;
  sourceId: string;
}

export interface LookupRequest {
  tableName: string;
  search?: string;
  limit?: number;
  offset?: number;
}

export async function requireAuth(): Promise<void> {
  const user = await getUser();
  if (!user) throw new Error("Unauthorized");
}

export const getCurrentUserFn = createServerFn({ method: "GET" }).handler(async () => {
  const user = await getUser();
  if (!user) return null;

  const { db: dbClient } = await getDb();
  const userRecord = await dbClient
    .select({
      isSystemAdmin: appUser.isSystemAdmin,
      role: appUser.role,
      displayName: appUser.displayName,
      email: appUser.email,
    })
    .from(appUser)
    .where(eq(appUser.email, user.email))
    .limit(1);

  return {
    ...user,
    isSystemAdmin: userRecord[0]?.isSystemAdmin ?? false,
    role: userRecord[0]?.role ?? "tenant_user",
    displayName: userRecord[0]?.displayName ?? user.name,
    email: userRecord[0]?.email ?? user.email,
  };
});

export const getTenantFn = createServerFn({ method: "GET" }).handler(async () => {
  await requireAuth();
  const tenantId = await $getTenantId();
  const { db: dbClient } = await getDb();
  const tenantRecord = await dbClient
    .select()
    .from(tenant)
    .where(eq(tenant.tenantId, tenantId))
    .limit(1);
  return (tenantRecord[0] as any) ?? null;
});

export const listUserTenantsFn = createServerFn({ method: "GET" }).handler(async () => {
  const user = await getUser();
  if (!user) return [];

  const { db: dbClient, sql } = await getDb();

  // Check if system admin
  const userRecord = await dbClient
    .select({ isSystemAdmin: appUser.isSystemAdmin })
    .from(appUser)
    .where(eq(appUser.email, user.email))
    .limit(1);

  if (userRecord[0]?.isSystemAdmin) {
    const allTenants = await dbClient.select().from(tenant).where(eq(tenant.isActive, true));
    return allTenants.map((t) => ({
      tenant_id: t.tenantId,
      tenant_name: t.name,
      tenant_slug: t.slug,
    })) as any;
  }

  const result = await getUserTenants(sql as any, user.id);
  return result as any;
});

export const getEffectiveFieldsFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(z.object({ entityName: z.string() }))
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    return runWithTenant(tenantId, async (_, tx) => {
      return getEffectiveFields(tx, { entityName: data.entityName });
    });
  });

export const getEntityFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(z.object({ entityName: z.string(), id: z.string() }))
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const { $readEntity } = await import("./entity-ops.server");
    return $readEntity({ entityName: data.entityName, tenantId, id: data.id });
  });

export const lookupHelperTableFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(
    z.object({
      tableName: z.string(),
      search: z.string().optional(),
      limit: z.number().optional(),
      offset: z.number().optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    return runWithTenant(tenantId, async (_, tx) => {
      return getHelperTableItems(tx, data.tableName, {
        search: data.search,
        limit: data.limit,
        offset: data.offset,
      });
    });
  });

export const listEntityFn = createServerFn({ method: "POST", strict: false })
  .middleware([telemetryMiddleware])
  .inputValidator((data: unknown) => data as ListEntityRequest)
  .handler(async ({ data }) => {
    const tenantId = await $getTenantId();
    await requireAuth();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      return listEntity(tx, data.entityName, data.options);
    });
    return {
      items: result.items as Record<string, unknown>[],
      total: result.total,
      limit: result.limit,
      offset: result.offset,
      tenantId,
    };
  });

export const createEntityFn = createServerFn({ method: "POST", strict: false })
  .middleware([telemetryMiddleware])
  .inputValidator((data: unknown) => data as CreateEntityRequest)
  .handler(async ({ data }) => {
    try {
      const tenantId = await $getTenantId();
      const user = await getUser();
      if (!user) throw new Error("Unauthorized");

      const result = await runWithTenant(tenantId, async (_, tx) => {
        const fields = await getEffectiveFields(tx, { entityName: data.entityName });
        const schema = createDynamicZodSchema(fields);
        const validatedPayload = schema.parse(data.payload);
        const res = await createEntity(tx, data.entityName, validatedPayload);

        if (res.success) {
          await createAuditEvent(tx, {
            tenantId,
            userId: user.id,
            eventType: "entity_created",
            severity: "info",
            message: `Created ${data.entityName}: ${res.id}`,
            traceId: getTraceId(),
            data: { entity: data.entityName, id: res.id },
          });
        }
        return res;
      });
      return {
        success: result.success,
        id: result.id,
        error: result.error,
      };
    } catch (e: any) {
      if (e instanceof ZodError) {
        return { success: false, error: JSON.stringify(e.issues) };
      }
      return {
        success: false,
        error: e.message || "Internal Server Error",
      };
    }
  });

export const updateEntityFn = createServerFn({ method: "POST", strict: false })
  .middleware([telemetryMiddleware])
  .inputValidator((data: unknown) => data as UpdateEntityRequest)
  .handler(async ({ data }) => {
    try {
      const tenantId = await $getTenantId();
      const user = await getUser();
      if (!user) throw new Error("Unauthorized");

      const result = await runWithTenant(tenantId, async (_, tx) => {
        const fields = await getEffectiveFields(tx, { entityName: data.entityName });
        const schema = createDynamicZodSchema(fields);
        const validatedPayload = schema.parse(data.payload);
        const res = await patchEntity(tx, data.entityName, data.id, validatedPayload);

        if (res.success) {
          await createAuditEvent(tx, {
            tenantId,
            userId: user.id,
            eventType: "entity_updated",
            severity: "info",
            message: `Updated ${data.entityName}: ${data.id}`,
            traceId: getTraceId(),
            data: { entity: data.entityName, id: data.id },
          });
        }
        return res;
      });
      return {
        success: result.success,
        error: result.error,
      };
    } catch (e: any) {
      if (e instanceof ZodError) {
        return { success: false, error: JSON.stringify(e.issues) };
      }
      return {
        success: false,
        error: e.message || "Internal Server Error",
      };
    }
  });

export const deleteEntityFn = createServerFn({ method: "POST", strict: false })
  .middleware([telemetryMiddleware])
  .inputValidator((data: unknown) => data as DeleteEntityRequest)
  .handler(async ({ data }) => {
    const tenantId = await $getTenantId();
    const user = await getUser();
    if (!user) throw new Error("Unauthorized");

    const result = await runWithTenant(tenantId, async (_, tx) => {
      const res = await deleteEntity(tx, data.entityName, data.id);
      if (res.success) {
        await createAuditEvent(tx, {
          tenantId,
          userId: user.id,
          eventType: "entity_deleted",
          severity: "warn",
          message: `Deleted ${data.entityName}: ${data.id}`,
          traceId: getTraceId(),
          data: { entity: data.entityName, id: data.id, action: res.action },
        });
      }
      return res;
    });
    return {
      success: result.success,
      error: result.error,
      action: result.action,
    };
  });

export const duplicateEntityFn = createServerFn({ method: "POST", strict: false })
  .inputValidator((data: unknown) => data as DuplicateEntityRequest)
  .handler(async ({ data }) => {
    const tenantId = await $getTenantId();
    await requireAuth();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      return duplicateEntity(tx, data.entityName, data.sourceId);
    });
    return {
      success: result.success,
      id: result.id,
      error: result.error,
    };
  });

export const saveTenantFieldFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      entityName: z.string(),
      fieldName: z.string(),
      fieldType: z.string(),
      label: z.record(z.string(), z.string()).optional(),
      isRequired: z.boolean().optional(),
      isVisible: z.boolean().optional(),
      displayOrder: z.number().optional(),
      lookupTable: z.string().optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    return runWithTenant(tenantId, async (_, tx) => {
      const existing = await getEffectiveFields(tx, {
        entityName: data.entityName,
        fieldName: data.fieldName,
      });

      const payload = {
        entity_name: data.entityName,
        field_name: data.fieldName,
        field_type: data.fieldType,
        label: data.label,
        is_required: data.isRequired,
        is_visible: data.isVisible,
        display_order: data.displayOrder,
        lookup_table: data.lookupTable,
        scope: "tenant",
        tenant_id: tenantId,
      };

      if (existing.length > 0 && existing[0].scope === "tenant") {
        return patchEntity(tx, "tenant_fields", existing[0].fieldId, payload);
      } else {
        return createEntity(tx, "tenant_fields", payload);
      }
    });
  });

// --- Organization admin server functions (non-tenant-scoped) ---

export const listOrganizationsFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(
    z
      .object({
        limit: z.number().optional(),
        offset: z.number().optional(),
        search: z.string().optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    await requireAdminRole();
    const limit = data?.limit ?? 100;
    const offset = data?.offset ?? 0;
    const search = data?.search;

    const result = await runWithSystem(async (_, tx) => {
      let whereClause = "";
      const params: unknown[] = [];
      if (search) {
        params.push(`%${search}%`);
        whereClause = ` WHERE (name ILIKE $${params.length} OR slug ILIKE $${params.length})`;
      }
      const countQuery = `SELECT COUNT(*) as total FROM organization${whereClause}`;
      const countRows = await tx.unsafe(countQuery, params);
      const total = Number((countRows[0] as Record<string, unknown>).total);

      const dataParams = [...params];
      const dataQuery = `SELECT * FROM organization${whereClause} ORDER BY organization_id ASC LIMIT $${dataParams.length + 1} OFFSET $${dataParams.length + 2}`;
      dataParams.push(limit, offset);
      const items = await tx.unsafe(dataQuery, dataParams);
      return { items, total, limit, offset };
    });

    return {
      items: result.items as Record<string, unknown>[],
      total: result.total,
      limit: result.limit,
      offset: result.offset,
    };
  });

export const createOrganizationFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      name: z.string().min(1),
      slug: z
        .string()
        .min(1)
        .regex(
          /^[a-z0-9][a-z0-9-]{0,62}$/,
          "Slug must be lowercase alphanumeric with hyphens, max 63 chars",
        ),
    }),
  )
  .handler(async ({ data }) => {
    await requireAdminRole();
    const result = await runWithSystem(async (_, tx) => {
      try {
        const res = await tx.unsafe(
          `INSERT INTO organization (name, slug, is_active) VALUES ($1, $2, true) RETURNING organization_id`,
          [data.name, data.slug],
        );
        return { success: true as const, id: String(res[0]?.organization_id) };
      } catch (e: unknown) {
        return {
          success: false as const,
          error: e instanceof Error ? e.message : "Failed to create organization",
        };
      }
    });
    return result;
  });

export const updateOrganizationFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      id: z.string().uuid(),
      name: z.string().min(1).optional(),
      slug: z
        .string()
        .min(1)
        .regex(
          /^[a-z0-9][a-z0-9-]{0,62}$/,
          "Slug must be lowercase alphanumeric with hyphens, max 63 chars",
        )
        .optional(),
      is_active: z.boolean().optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAdminRole();

    const updates: string[] = [];
    const params: unknown[] = [];

    if (data.name !== undefined) {
      params.push(data.name);
      updates.push(`name = $${params.length}`);
    }
    if (data.slug !== undefined) {
      params.push(data.slug);
      updates.push(`slug = $${params.length}`);
    }
    if (data.is_active !== undefined) {
      params.push(data.is_active);
      updates.push(`is_active = $${params.length}`);
    }

    if (updates.length === 0) {
      return { success: false, error: "No fields to update" };
    }

    params.push(data.id);
    const result = await runWithSystem(async (_, tx) => {
      try {
        await tx.unsafe(
          `UPDATE organization SET ${updates.join(", ")} WHERE organization_id = $${params.length}`,
          params,
        );
        return { success: true as const };
      } catch (e: unknown) {
        return {
          success: false as const,
          error: e instanceof Error ? e.message : "Failed to update organization",
        };
      }
    });
    return result;
  });

// --- Document list with filters ---

export const listDocumentsFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(
    z.object({
      documentType: z.string().optional(),
      documentGroupId: z.string().optional(),
      search: z.string().optional(),
      limit: z.number().optional(),
      offset: z.number().optional(),
      sortBy: z.string().optional(),
      sortOrder: z.enum(["ASC", "DESC"]).optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      const limit = data.limit ?? 50;
      const offset = data.offset ?? 0;
      const sortBy = data.sortBy ?? "document_date";
      const sortOrder = data.sortOrder ?? "DESC";

      const conditions: string[] = [];
      const params: unknown[] = [];

      if (data.documentType) {
        params.push(data.documentType);
        conditions.push(`d.document_type = $${params.length}`);
      }
      if (data.documentGroupId) {
        params.push(data.documentGroupId);
        conditions.push(`d.document_group_id = $${params.length}`);
      }
      if (data.search) {
        params.push(`%${data.search}%`);
        conditions.push(
          `(d.document_no ILIKE $${params.length} OR d.status ILIKE $${params.length})`,
        );
      }

      const whereClause = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

      const countParams = [...params];
      const countRows = await tx.unsafe(
        `SELECT COUNT(*) as total FROM document d ${whereClause}`,
        countParams,
      );
      const total = Number((countRows[0] as Record<string, unknown>).total);

      const dataParams = [...params, limit, offset];
      const items = (await tx.unsafe(
        `SELECT d.*, dt.name as type_name, dg.name as group_name
         FROM document d
         LEFT JOIN document_type dt ON d.document_type_id = dt.document_type_id
         LEFT JOIN document_group dg ON d.document_group_id = dg.document_group_id
         ${whereClause}
         ORDER BY d.${sortBy} ${sortOrder} LIMIT $${dataParams.length - 1} OFFSET $${dataParams.length}`,
        dataParams,
      )) as Record<string, unknown>[];

      return { items, total, limit, offset };
    });
    return result;
  });

// --- Document tree (types + groups) ---

export const listDocumentTreeFn = createServerFn({ method: "GET", strict: false }).handler(
  async () => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      const rows = await tx.unsafe(
        `SELECT
          dt.code as doc_type_code,
          dt.name as doc_type_name,
          dt.movement_type,
          dt.sort_order,
          dg.document_group_id,
          dg.name as group_name,
          dg.group_number,
          (SELECT COUNT(*) FROM document d WHERE d.document_group_id = dg.document_group_id) as doc_count,
          (SELECT COUNT(*) FROM document d WHERE d.document_type_id = dt.document_type_id) as type_count
        FROM document_type dt
        LEFT JOIN document_group dg ON dt.code = dg.document_type
        WHERE dt.is_active = true AND (dg.is_active = true OR dg.is_active IS NULL)
        ORDER BY dt.sort_order, dg.group_number`,
      );

      const outbound = new Set(["N", "A", "L", "R", "G"]);
      const inbound = new Set(["b", "l", "r"]);

      const getCategory = (mt: string) => {
        if (outbound.has(mt))
          return { de: "Warenausgang Belege", en: "Outgoing Documents", key: "out" };
        if (inbound.has(mt))
          return { de: "Wareneingang Belege", en: "Incoming Documents", key: "in" };
        return { de: "Lagerbuchungen", en: "Inventory Postings", key: "inv" };
      };

      const categories: any[] = [];

      const getTypeLabels = (code: string, name: string) => {
        const map: Record<string, string> = {
          N: "Offer",
          A: "Order",
          L: "Delivery Note",
          R: "Invoice",
          G: "Credit Note",
          b: "Purchase Order",
          l: "Goods Receipt",
          r: "Purchase Invoice",
          g: "Inventory Posting",
        };
        return { de: name, en: map[code] || name };
      };

      for (const row of rows) {
        const cat = getCategory(row.movement_type as string);
        let category = categories.find((c) => c.key === cat.key);
        if (!category) {
          category = {
            key: cat.key,
            label_de: cat.de,
            label_en: cat.en,
            items: [],
          };
          categories.push(category);
        }

        const typeCode = row.doc_type_code as string;
        let typeNode = category.items.find((t: any) => t.docType === typeCode);
        if (!typeNode) {
          const labels = getTypeLabels(typeCode, row.doc_type_name as string);
          typeNode = {
            key: `dt-${typeCode}`,
            docType: typeCode,
            label_de: labels.de,
            label_en: labels.en,
            count: Number(row.type_count) || 0,
            defaultGroupId: null,
            items: [],
          };
          category.items.push(typeNode);
        }

        if (row.document_group_id) {
          if (row.group_number === 0) {
            typeNode.defaultGroupId = row.document_group_id;
          } else {
            typeNode.items.push({
              key: `dg-${row.document_group_id}`,
              groupId: row.document_group_id,
              docType: typeCode,
              label_de: row.group_name || `${typeCode}${row.group_number}`,
              label_en: row.group_name || `${typeCode}${row.group_number}`,
              count: Number(row.doc_count) || 0,
            });
          }
        }
      }

      return categories;
    });
    return result;
  },
);

// --- Tenant admin server functions (non-tenant-scoped, base-tenant protected) ---

export const listTenantsFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(
    z
      .object({
        limit: z.number().optional(),
        offset: z.number().optional(),
        search: z.string().optional(),
        organizationId: z.string().optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    await requireAdminRole();
    const limit = data?.limit ?? 100;
    const offset = data?.offset ?? 0;
    const search = data?.search;
    const organizationId = data?.organizationId;

    const result = await runWithSystem(async (_, tx) => {
      let whereClause = "";
      const params: unknown[] = [];
      const conditions: string[] = [];
      if (search) {
        params.push(`%${search}%`);
        conditions.push(`(t.name ILIKE $${params.length} OR t.slug ILIKE $${params.length})`);
      }
      if (organizationId) {
        params.push(organizationId);
        conditions.push(`t.organization_id = $${params.length}`);
      }
      if (conditions.length > 0) {
        whereClause = ` WHERE ${conditions.join(" AND ")}`;
      }
      const countQuery = `SELECT COUNT(*) as total FROM tenant t${whereClause}`;
      const countRows = await tx.unsafe(countQuery, params);
      const total = Number((countRows[0] as Record<string, unknown>).total);

      const dataParams = [...params];
      const dataQuery = `SELECT t.*, o.name as organization_name FROM tenant t LEFT JOIN organization o ON t.organization_id = o.organization_id${whereClause} ORDER BY t.tenant_id ASC LIMIT $${dataParams.length + 1} OFFSET $${dataParams.length + 2}`;
      dataParams.push(limit, offset);
      const items = await tx.unsafe(dataQuery, dataParams);
      return { items, total, limit, offset };
    });

    return {
      items: result.items as Record<string, unknown>[],
      total: result.total,
      limit: result.limit,
      offset: result.offset,
    };
  });

export const createTenantFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      name: z.string().min(1),
      slug: z
        .string()
        .min(1)
        .regex(
          /^[a-z0-9][a-z0-9-]{0,62}$/,
          "Slug must be lowercase alphanumeric with hyphens, max 63 chars",
        ),
      organizationId: z.string().uuid(),
      isBase: z.boolean().optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAdminRole();
    const result = await runWithSystem(async (_, tx) => {
      try {
        const res = await tx.unsafe(
          `INSERT INTO tenant (name, slug, organization_id, is_base, is_active) VALUES ($1, $2, $3, COALESCE($4, false), true) RETURNING tenant_id`,
          [data.name, data.slug, data.organizationId, data.isBase ?? false],
        );
        return { success: true as const, id: String(res[0]?.tenant_id) };
      } catch (e: unknown) {
        return {
          success: false as const,
          error: e instanceof Error ? e.message : "Failed to create tenant",
        };
      }
    });
    return result;
  });

export const updateTenantFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      id: z.string().uuid(),
      name: z.string().min(1).optional(),
      slug: z
        .string()
        .min(1)
        .regex(
          /^[a-z0-9][a-z0-9-]{0,62}$/,
          "Slug must be lowercase alphanumeric with hyphens, max 63 chars",
        )
        .optional(),
      organizationId: z.string().uuid().optional(),
      is_active: z.boolean().optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAdminRole();

    const updates: string[] = [];
    const params: unknown[] = [];

    if (data.name !== undefined) {
      params.push(data.name);
      updates.push(`name = $${params.length}`);
    }
    if (data.slug !== undefined) {
      params.push(data.slug);
      updates.push(`slug = $${params.length}`);
    }
    if (data.organizationId !== undefined) {
      params.push(data.organizationId);
      updates.push(`organization_id = $${params.length}`);
    }
    if (data.is_active !== undefined) {
      params.push(data.is_active);
      updates.push(`is_active = $${params.length}`);
    }

    if (updates.length === 0) {
      return { success: false, error: "No fields to update" };
    }

    params.push(data.id);
    const result = await runWithSystem(async (_, tx) => {
      try {
        await tx.unsafe(
          `UPDATE tenant SET ${updates.join(", ")} WHERE tenant_id = $${params.length}`,
          params,
        );
        return { success: true as const };
      } catch (e: unknown) {
        return {
          success: false as const,
          error: e instanceof Error ? e.message : "Failed to update tenant",
        };
      }
    });
    return result;
  });

// --- User admin server functions (non-tenant-scoped, role-aware) ---

async function getUserRole(): Promise<string> {
  const user = await getUser();
  if (!user) throw new Error("Unauthorized");
  const { db: dbClient } = await getDb();
  const userRecord = await dbClient
    .select({ role: appUser.role })
    .from(appUser)
    .where(eq(appUser.email, user.email))
    .limit(1);
  return userRecord[0]?.role ?? "tenant_user";
}

async function getUserTenantIds(): Promise<string[]> {
  const user = await getUser();
  if (!user) return [];
  const { sql } = await getDb();
  const tenantRows = await sql.unsafe(`SELECT tenant_id FROM user_tenant WHERE user_id = $1`, [
    user.id,
  ]);
  return tenantRows.map((r: Record<string, unknown>) => String(r.tenant_id));
}

export const listAdminUsersFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(
    z
      .object({
        limit: z.number().optional(),
        offset: z.number().optional(),
        search: z.string().optional(),
        role: z.string().optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    await requireAdminRole();
    const baseRole = await getUserRole();
    const limit = data?.limit ?? 100;
    const offset = data?.offset ?? 0;
    const search = data?.search;
    const role = data?.role;

    let tenantId: string | undefined;
    if (baseRole === "tenant_admin") {
      const tenantIds = await getUserTenantIds();
      if (tenantIds.length === 0) {
        return { items: [] as Record<string, unknown>[], total: 0, limit, offset };
      }
      tenantId = tenantIds[0];
    }

    const result = await runWithSystem(async (_, tx) => {
      return listAdminUsers(tx, { limit, offset, search, role, tenantId });
    });

    return {
      items: result.items as unknown as Record<string, unknown>[],
      total: result.total,
      limit: result.limit,
      offset: result.offset,
    };
  });

export const getAdminUserFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(z.object({ userId: z.string().uuid() }))
  .handler(async ({ data }) => {
    await requireAdminRole();
    const baseRole = await getUserRole();

    if (baseRole === "tenant_admin") {
      const tenantIds = await getUserTenantIds();
      if (!tenantIds.includes(data.userId)) {
        throw new Error("Forbidden: can only view users in your tenants");
      }
    }

    const result = await runWithSystem(async (_, tx) => {
      return getAdminUser(tx, data.userId);
    });

    return result as Record<string, unknown> | null;
  });

export const getUserTenantsFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(z.object({ userId: z.string().uuid() }))
  .handler(async ({ data }) => {
    await requireAdminRole();
    const result = await runWithSystem(async (_, tx) => {
      return getUserTenants(tx, data.userId);
    });
    return result;
  });

export const createUserFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      email: z.string().email(),
      password: z.string().min(4),
      displayName: z.string().optional(),
      role: z.enum(["system_admin", "org_admin", "tenant_admin", "tenant_user"]).optional(),
      locale: z.string().optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAdminRole();
    const baseRole = await getUserRole();

    if (
      baseRole === "tenant_admin" &&
      (data.role === "system_admin" || data.role === "org_admin")
    ) {
      throw new Error("Forbidden: tenant_admin cannot create higher-level roles");
    }

    const result = await runWithSystem(async (_, tx) => {
      return createUser(tx, {
        email: data.email,
        password: data.password,
        displayName: data.displayName,
        role: data.role,
        locale: data.locale,
      });
    });
    return result;
  });

export const updateUserFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      userId: z.string().uuid(),
      displayName: z.string().optional(),
      role: z.enum(["system_admin", "org_admin", "tenant_admin", "tenant_user"]).optional(),
      is_active: z.boolean().optional(),
      locale: z.string().optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAdminRole();
    const baseRole = await getUserRole();

    if (baseRole === "tenant_admin") {
      const tenantIds = await getUserTenantIds();
      if (!tenantIds.includes(data.userId)) {
        throw new Error("Forbidden: can only update users in your tenants");
      }
      if (data.role === "system_admin" || data.role === "org_admin") {
        throw new Error("Forbidden: tenant_admin cannot assign higher-level roles");
      }
    }

    const result = await runWithSystem(async (_, tx) => {
      return updateUser(tx, data.userId, {
        displayName: data.displayName,
        role: data.role,
        is_active: data.is_active,
        locale: data.locale,
      });
    });
    return result;
  });

export const deactivateUserFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(z.object({ userId: z.string().uuid() }))
  .handler(async ({ data }) => {
    await requireAdminRole();
    const baseRole = await getUserRole();

    if (baseRole === "tenant_admin") {
      const tenantIds = await getUserTenantIds();
      if (!tenantIds.includes(data.userId)) {
        throw new Error("Forbidden: can only deactivate users in your tenants");
      }
    }

    const result = await runWithSystem(async (_, tx) => {
      return deactivateUser(tx, data.userId);
    });
    return result;
  });

export const resetUserPasswordFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      userId: z.string().uuid(),
      password: z.string().min(4),
    }),
  )
  .handler(async ({ data }) => {
    await requireAdminRole();
    const baseRole = await getUserRole();

    if (baseRole === "tenant_admin") {
      const tenantIds = await getUserTenantIds();
      if (!tenantIds.includes(data.userId)) {
        throw new Error("Forbidden: can only reset passwords for users in your tenants");
      }
    }

    const result = await runWithSystem(async (_, tx) => {
      return resetUserPassword(tx, data.userId, data.password);
    });
    return result;
  });

export const assignUserTenantFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      userId: z.string().uuid(),
      tenantId: z.string().uuid(),
      role: z.string().optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAdminRole();
    const result = await runWithSystem(async (_, tx) => {
      return assignUserTenant(tx, data.userId, data.tenantId, data.role ?? "tenant_user");
    });
    return result;
  });

export const removeUserTenantFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      userId: z.string().uuid(),
      tenantId: z.string().uuid(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAdminRole();
    const result = await runWithSystem(async (_, tx) => {
      return removeUserTenant(tx, data.userId, data.tenantId);
    });
    return result;
  });

// --- Company admin server functions (role-aware tenant filtering) ---

export const listAdminCompaniesFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(
    z
      .object({
        limit: z.number().optional(),
        offset: z.number().optional(),
        search: z.string().optional(),
        tenantId: z.string().uuid().optional(),
      })
      .optional(),
  )
  .handler(async ({ data }) => {
    await requireAdminRole();
    const baseRole = await getUserRole();
    const limit = data?.limit ?? 100;
    const offset = data?.offset ?? 0;
    const search = data?.search;
    const filterTenantId = data?.tenantId;

    let tenantId: string | undefined;
    if (baseRole === "tenant_admin") {
      const tenantIds = await getUserTenantIds();
      if (tenantIds.length === 0) {
        return { items: [] as Record<string, unknown>[], total: 0, limit, offset };
      }
      tenantId = tenantIds[0];
    }

    const result = await runWithSystem(async (_, tx) => {
      let whereClause = "";
      const params: unknown[] = [];
      const conditions: string[] = [];

      if (search) {
        params.push(`%${search}%`);
        conditions.push(`(c.name ILIKE $${params.length} OR c.company_no ILIKE $${params.length})`);
      }
      if (filterTenantId) {
        params.push(filterTenantId);
        conditions.push(`c.tenant_id = $${params.length}`);
      }
      if (tenantId) {
        params.push(tenantId);
        conditions.push(`c.tenant_id = $${params.length}`);
      }
      if (conditions.length > 0) {
        whereClause = ` WHERE ${conditions.join(" AND ")}`;
      }

      const countQuery = `SELECT COUNT(*) as total FROM company c${whereClause}`;
      const countRows = await tx.unsafe(countQuery, params);
      const total = Number((countRows[0] as Record<string, unknown>).total);

      const dataParams = [...params];
      const dataQuery = `SELECT c.*, t.name as tenant_name, t.slug as tenant_slug FROM company c LEFT JOIN tenant t ON c.tenant_id = t.tenant_id${whereClause} ORDER BY c.company_id ASC LIMIT $${dataParams.length + 1} OFFSET $${dataParams.length + 2}`;
      dataParams.push(limit, offset);
      const items = await tx.unsafe(dataQuery, dataParams);
      return { items, total, limit, offset };
    });

    return {
      items: result.items as Record<string, unknown>[],
      total: result.total,
      limit: result.limit,
      offset: result.offset,
    };
  });

export const createAdminCompanyFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      tenantId: z.string().uuid(),
      companyNo: z.string().min(1),
      name: z.string().min(1),
      legalName: z.string().optional(),
      countryCode: z.string().length(2).optional(),
      currencyId: z.string().length(3).optional(),
      vatId: z.string().optional(),
      isActive: z.boolean().optional(),
      addressLine1: z.string().optional(),
      addressLine2: z.string().optional(),
      city: z.string().optional(),
      postalCode: z.string().optional(),
      phoneLandline: z.string().optional(),
      phoneMobile: z.string().optional(),
      email: z.string().email().optional(),
      homepage: z.string().url().optional(),
      taxNumber: z.string().optional(),
      taxAuthority: z.string().optional(),
      gln: z.string().optional(),
      eoriNo: z.string().optional(),
      dunsNo: z.string().optional(),
      bankName: z.string().optional(),
      bankBic: z.string().optional(),
      bankIban: z.string().optional(),
      fiscalYearStartMonth: z.number().min(1).max(12).optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAdminRole();
    const baseRole = await getUserRole();

    if (baseRole === "tenant_admin") {
      const tenantIds = await getUserTenantIds();
      if (!tenantIds.includes(data.tenantId)) {
        throw new Error("Forbidden: can only create companies in your tenants");
      }
    }

    const result = await runWithSystem(async (_, tx) => {
      try {
        const res = await tx.unsafe(
          `INSERT INTO company (tenant_id, company_no, name, legal_name, country_code, currency_id, vat_id, is_active, address_line_1, address_line_2, city, postal_code, phone_landline, phone_mobile, email, homepage, tax_number, tax_authority, gln, eori_no, duns_no, bank_name, bank_bic, bank_iban, fiscal_year_start_month) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25) RETURNING company_id`,
          [
            data.tenantId,
            data.companyNo,
            data.name,
            data.legalName ?? null,
            data.countryCode ?? "DE",
            data.currencyId ?? "EUR",
            data.vatId ?? null,
            data.isActive ?? true,
            data.addressLine1 ?? null,
            data.addressLine2 ?? null,
            data.city ?? null,
            data.postalCode ?? null,
            data.phoneLandline ?? null,
            data.phoneMobile ?? null,
            data.email ?? null,
            data.homepage ?? null,
            data.taxNumber ?? null,
            data.taxAuthority ?? null,
            data.gln ?? null,
            data.eoriNo ?? null,
            data.dunsNo ?? null,
            data.bankName ?? null,
            data.bankBic ?? null,
            data.bankIban ?? null,
            data.fiscalYearStartMonth ?? 1,
          ],
        );
        const companyId = String(res[0]?.company_id);
        const seedResult = await seedDocumentDefaults(tx, data.tenantId, companyId);
        if (!seedResult.success) {
          throw new Error(`Document defaults seeding failed: ${seedResult.error}`);
        }
        return { success: true as const, id: companyId, seedResult };
      } catch (e: unknown) {
        return {
          success: false as const,
          error: e instanceof Error ? e.message : "Failed to create company",
        };
      }
    });
    return result;
  });

export const updateAdminCompanyFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      id: z.string().uuid(),
      name: z.string().min(1).optional(),
      legalName: z.string().optional(),
      countryCode: z.string().length(2).optional(),
      currencyId: z.string().length(3).optional(),
      vatId: z.string().optional(),
      isActive: z.boolean().optional(),
      addressLine1: z.string().optional(),
      addressLine2: z.string().optional(),
      city: z.string().optional(),
      postalCode: z.string().optional(),
      phoneLandline: z.string().optional(),
      phoneMobile: z.string().optional(),
      email: z.string().email().optional(),
      homepage: z.string().url().optional(),
      taxNumber: z.string().optional(),
      taxAuthority: z.string().optional(),
      gln: z.string().optional(),
      eoriNo: z.string().optional(),
      dunsNo: z.string().optional(),
      bankName: z.string().optional(),
      bankBic: z.string().optional(),
      bankIban: z.string().optional(),
      fiscalYearStartMonth: z.number().min(1).max(12).optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAdminRole();
    const baseRole = await getUserRole();

    if (baseRole === "tenant_admin") {
      const tenantIds = await getUserTenantIds();
      const { sql } = await getDb();
      const companyRows = await sql.unsafe(`SELECT tenant_id FROM company WHERE company_id = $1`, [
        data.id,
      ]);
      const companyTenantId = String(companyRows[0]?.tenant_id);
      if (!tenantIds.includes(companyTenantId)) {
        throw new Error("Forbidden: can only update companies in your tenants");
      }
    }

    const updates: string[] = [];
    const params: unknown[] = [];

    const fields: Record<string, string> = {
      name: "name",
      legalName: "legal_name",
      countryCode: "country_code",
      currencyId: "currency_id",
      vatId: "vat_id",
      isActive: "is_active",
      addressLine1: "address_line_1",
      addressLine2: "address_line_2",
      city: "city",
      postalCode: "postal_code",
      phoneLandline: "phone_landline",
      phoneMobile: "phone_mobile",
      email: "email",
      homepage: "homepage",
      taxNumber: "tax_number",
      taxAuthority: "tax_authority",
      gln: "gln",
      eoriNo: "eori_no",
      dunsNo: "duns_no",
      bankName: "bank_name",
      bankBic: "bank_bic",
      bankIban: "bank_iban",
      fiscalYearStartMonth: "fiscal_year_start_month",
    };

    for (const [key, col] of Object.entries(fields)) {
      if (data[key as keyof typeof data] !== undefined) {
        params.push(data[key as keyof typeof data]);
        updates.push(`${col} = $${params.length}`);
      }
    }

    if (updates.length === 0) {
      return { success: false, error: "No fields to update" };
    }

    params.push(data.id);
    const result = await runWithSystem(async (_, tx) => {
      try {
        await tx.unsafe(
          `UPDATE company SET ${updates.join(", ")} WHERE company_id = $${params.length}`,
          params,
        );
        return { success: true as const };
      } catch (e: unknown) {
        return {
          success: false as const,
          error: e instanceof Error ? e.message : "Failed to update company",
        };
      }
    });
    return result;
  });

// --- Admin dashboard stats (real counts) ---

export const getAdminStatsFn = createServerFn({ method: "GET", strict: false }).handler(
  async () => {
    await requireAdminRole();
    const result = await runWithSystem(async (_, tx) => {
      const [orgRow] = await tx.unsafe("SELECT COUNT(*) as total FROM organization");
      const [tenantRow] = await tx.unsafe("SELECT COUNT(*) as total FROM tenant");
      const [userRow] = await tx.unsafe("SELECT COUNT(*) as total FROM app_user");
      const [companyRow] = await tx.unsafe("SELECT COUNT(*) as total FROM company");
      return {
        organizations: Number((orgRow[0] as Record<string, unknown>).total),
        tenants: Number((tenantRow[0] as Record<string, unknown>).total),
        users: Number((userRow[0] as Record<string, unknown>).total),
        companies: Number((companyRow[0] as Record<string, unknown>).total),
      };
    });
    return result;
  },
);

// --- Integration connectors (real data) ---

export const listConnectorsFn = createServerFn({ method: "GET", strict: false }).handler(
  async () => {
    await requireAdminRole();
    const result = await runWithSystem(async (_, tx) => {
      const rows = await tx.unsafe(
        `SELECT
          cd.connector_id,
          cd.slug,
          cd.label,
          cd.atomicity_mode,
          tc.tenant_connector_id,
          tc.is_active,
          tc.last_run_at,
          tc.cron_expression,
          t.name as tenant_name
        FROM connector_definition cd
        LEFT JOIN tenant_connector tc ON cd.connector_id = tc.connector_id
        LEFT JOIN tenant t ON tc.tenant_id = t.tenant_id
        ORDER BY cd.slug ASC`,
      );
      return rows;
    });
    return result;
  },
);

// --- Connector activation + credentials ---

export const activateConnectorFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      connectorId: z.string(),
      credentials: z.record(z.string(), z.any()).optional(),
      cronExpression: z.string().nullable().optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const { encryptConnectorCredentials } = await import("@repo/integration");
    const encryptedCreds = data.credentials
      ? await encryptConnectorCredentials(data.credentials)
      : "{}";
    const result = await runWithTenant(tenantId, async (_, tx) => {
      const rows = await tx.unsafe(
        `INSERT INTO tenant_connector (connector_id, tenant_id, credentials, is_active, cron_expression)
         VALUES ($1, $2, $3::jsonb, true, $4)
         RETURNING tenant_connector_id, connector_id, tenant_id, is_active, cron_expression, created_at`,
        [data.connectorId, tenantId, encryptedCreds, data.cronExpression ?? null],
      );
      return rows[0];
    });
    return result;
  });

export const deactivateConnectorFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      tenantConnectorId: z.string(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    await runWithTenant(tenantId, async (_, tx) => {
      await tx.unsafe(
        `UPDATE tenant_connector SET is_active = false, updated_at = now()
         WHERE tenant_connector_id = $1 AND tenant_id = $2`,
        [data.tenantConnectorId, tenantId],
      );
    });
    return { success: true };
  });

export const saveConnectorCredentialsFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      tenantConnectorId: z.string(),
      credentials: z.record(z.string(), z.any()),
      cronExpression: z.string().nullable().optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const { encryptConnectorCredentials } = await import("@repo/integration");
    const encryptedCreds = await encryptConnectorCredentials(data.credentials);
    await runWithTenant(tenantId, async (_, tx) => {
      await tx.unsafe(
        `UPDATE tenant_connector
         SET credentials = $1::jsonb, cron_expression = $2, updated_at = now()
         WHERE tenant_connector_id = $3 AND tenant_id = $4`,
        [encryptedCreds, data.cronExpression ?? null, data.tenantConnectorId, tenantId],
      );
    });
    return { success: true };
  });

export const listTenantConnectorsFn = createServerFn({ method: "GET", strict: false }).handler(
  async () => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      const rows = await tx.unsafe(
        `SELECT
           tc.tenant_connector_id,
           tc.connector_id,
           tc.is_active,
           tc.cron_expression,
           tc.last_run_at,
           tc.created_at,
           cd.slug,
           cd.label,
           cd.atomicity_mode
         FROM tenant_connector tc
         JOIN connector_definition cd ON tc.connector_id = cd.connector_id
         ORDER BY cd.slug ASC`,
      );
      return rows;
    });
    return result;
  },
);

export const listImportQueueFn = createServerFn({ method: "GET", strict: false }).handler(
  async () => {
    await requireAuth();
    const tenantId = await $getTenantId();
    return runWithTenant(tenantId, async (_, tx) => {
      const rows = await tx.unsafe(
        `SELECT
            b.batch_id, b.connector_id, b.atomicity_mode, b.status,
            b.is_rerun, b.source_batch_id, b.posted_entity_count,
            b.error_summary, b.created_at, b.processed_at,
            b.target_entity, b.target_command_key,
            cd.label as connector_label, cd.slug as connector_slug,
            (SELECT COUNT(*) FROM import_row ir WHERE ir.batch_id = b.batch_id) as total_rows,
            (SELECT COUNT(*) FROM import_row ir WHERE ir.batch_id = b.batch_id AND ir.status = 'failed') as error_count
          FROM import_batch b
          LEFT JOIN connector_definition cd ON b.connector_id = cd.connector_id
          WHERE b.status = 'failed' AND b.tenant_id = $1
          ORDER BY b.created_at DESC`,
        [tenantId],
      );
      return rows;
    });
  },
);

export const rerunImportBatchFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(z.object({ batchId: z.string() }))
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    return runWithTenant(tenantId, async (_, tx) => {
      return rerunImportBatch(tx, data.batchId);
    });
  });

export const rejectImportBatchFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(z.object({ batchId: z.string() }))
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    return runWithTenant(tenantId, async (_, tx) => {
      return rejectImportBatch(tx, data.batchId);
    });
  });

// --- XRechnung Connector ---

export const triggerXrechnungImportFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(z.object({ tenantConnectorId: z.string() }))
  .handler(async ({ data }) => {
    await requireAuth();
    const { runConnector } = await import("@repo/integration");
    const result = await runConnector(data.tenantConnectorId, {
      scriptBasePath: process.env.CONNECTOR_SCRIPTS_PATH,
    });
    return result;
  });

export const validateXrechnungBatchFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(z.object({ batchId: z.string() }))
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const { validateXrechnungBatch } = await import("@repo/domain");
    return runWithTenant(tenantId, async (_, tx) => {
      return validateXrechnungBatch(tx, data.batchId);
    });
  });

// --- Connector Mappings ---

export const listConnectorMappingsFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(z.object({ tenantConnectorId: z.string() }))
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      const rows = await tx.unsafe(
        `SELECT tcm.mapping_id, tcm.source_field, tcm.target_table, tcm.target_column,
                tcm.transform, tcm.default_value,
                cd.locked_fields, cd.slug as connector_slug
         FROM tenant_connector_mapping tcm
         JOIN tenant_connector tc ON tcm.tenant_connector_id = tc.tenant_connector_id
         JOIN connector_definition cd ON tc.connector_id = cd.connector_id
         WHERE tcm.tenant_connector_id = $1
         ORDER BY tcm.source_field`,
        [data.tenantConnectorId],
      );
      return rows;
    });
    return result;
  });

export const patchConnectorMappingsFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      tenantConnectorId: z.string(),
      mappings: z.array(
        z.object({
          source_field: z.string(),
          target_table: z.string(),
          target_column: z.string(),
          transform: z.record(z.string(), z.unknown()).optional(),
          default_value: z.unknown().optional().nullable(),
        }),
      ),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      for (const mapping of data.mappings) {
        const defRows = await tx.unsafe(
          `SELECT cd.locked_fields, cd.slug FROM tenant_connector tc
           JOIN connector_definition cd ON tc.connector_id = cd.connector_id
           WHERE tc.tenant_connector_id = $1 LIMIT 1`,
          [data.tenantConnectorId],
        );
        if (defRows.length === 0) {
          throw new Error("Tenant connector not found");
        }
        const def = defRows[0] as Record<string, unknown>;
        const lockedFields = (def.locked_fields as unknown[]) ?? [];
        if (lockedFields.includes(mapping.source_field)) {
          throw new Error(`source_locked:${mapping.source_field}`);
        }
        const slug = String(def.slug);
        const annRows = await tx.unsafe(
          `SELECT locked_for FROM schema_annotations WHERE table_name = $1 AND column_name = $2 LIMIT 1`,
          [mapping.target_table, mapping.target_column],
        );
        if (annRows.length > 0) {
          const lockedFor = (annRows[0] as Record<string, unknown>).locked_for as unknown[];
          if (lockedFor?.includes(slug)) {
            throw new Error(`target_locked:${mapping.target_column}`);
          }
        }
      }
      for (const mapping of data.mappings) {
        await tx.unsafe(
          `INSERT INTO tenant_connector_mapping
             (tenant_connector_id, tenant_id, source_field, target_table, target_column, transform, default_value)
           VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7::jsonb)
           ON CONFLICT (tenant_connector_id, source_field)
           DO UPDATE SET target_table = EXCLUDED.target_table, target_column = EXCLUDED.target_column,
             transform = EXCLUDED.transform, default_value = EXCLUDED.default_value`,
          [
            data.tenantConnectorId,
            tenantId,
            mapping.source_field,
            mapping.target_table,
            mapping.target_column,
            JSON.stringify(mapping.transform ?? { type: "direct" }),
            mapping.default_value != null ? JSON.stringify(mapping.default_value) : null,
          ],
        );
      }
      return { success: true, count: data.mappings.length };
    });
    return result;
  });

export const getConnectorDefinitionFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(z.object({ tenantConnectorId: z.string() }))
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      const rows = await tx.unsafe(
        `SELECT cd.connector_id, cd.slug, cd.label, cd.default_mappings, cd.locked_fields, cd.atomicity_mode
         FROM tenant_connector tc
         JOIN connector_definition cd ON tc.connector_id = cd.connector_id
         WHERE tc.tenant_connector_id = $1 LIMIT 1`,
        [data.tenantConnectorId],
      );
      return rows[0] ?? null;
    });
    return result;
  });

export const getSchemaAnnotationsFn = createServerFn({ method: "GET", strict: false }).handler(
  async () => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      const rows = await tx.unsafe(
        `SELECT table_name, column_name, business_name, data_class, mandatory_for, locked_for
         FROM schema_annotations WHERE column_name != '' ORDER BY table_name, column_name`,
      );
      return rows;
    });
    return result;
  },
);

// --- Document specialized fetch ---

export const getDocumentFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(z.object({ documentId: z.string() }))
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      const rows = (await tx.unsafe(
        `SELECT d.*, dt.code as type_code, dt.name as type_name, dg.group_number, dg.name as group_name
         FROM document d
         LEFT JOIN document_type dt ON d.document_type_id = dt.document_type_id
         LEFT JOIN document_group dg ON d.document_group_id = dg.document_group_id
         WHERE d.document_id = $1`,
        [data.documentId],
      )) as Record<string, unknown>[];
      return rows[0] ?? null;
    });
    return result;
  });

// --- Document CRUD ---

const documentLineSchema = z.object({
  lineNo: z.number(),
  articleId: z.string().optional(),
  quantity: z.number(),
  netPrice: z.number(),
  taxCodeId: z.string().optional(),
  warehouseId: z.string().optional(),
  costCenterId: z.string().optional(),
  targetWarehouseId: z.string().optional(),
  lineType: z.string().optional(),
  movementType: z.string().optional(),
  unit: z.string().optional(),
  discountPercentage: z.number().optional(),
  articleTextSnapshot: z.string().optional(),
});

export const createDocumentFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      companyId: z.string(),
      documentType: z.string(),
      documentDirection: z.string(),
      documentDate: z.string(),
      customerId: z.string().optional(),
      currencyId: z.string().optional(),
      documentGroupId: z.string().optional(),
      documentTypeId: z.string().optional(),
      warehouseId: z.string().optional(),
      targetWarehouseId: z.string().optional(),
      paymentTermId: z.string().optional(),
      shippingMethodId: z.string().optional(),
      deliveryAddressId: z.string().optional(),
      parentDocumentId: z.string().optional(),
      postingDate: z.string().optional(),
      lines: z.array(documentLineSchema).optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    try {
      const result = await runWithTenant(tenantId, async (_, tx) => {
        return createDocument(tx, data);
      });
      return result;
    } catch (err: any) {
      console.error("[createDocumentFn] Backend Error:", err);
      throw err;
    }
  });

export const deleteDocumentFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(z.object({ documentId: z.string() }))
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      return deleteDocument(tx, data.documentId);
    });
    return result;
  });

export const updateDocumentFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      documentId: z.string(),
      companyId: z.string(),
      documentDate: z.string().optional(),
      customerId: z.string().nullable().optional(),
      currencyId: z.string().nullable().optional(),
      documentGroupId: z.string().nullable().optional(),
      documentTypeId: z.string().nullable().optional(),
      warehouseId: z.string().nullable().optional(),
      targetWarehouseId: z.string().nullable().optional(),
      paymentTermId: z.string().nullable().optional(),
      shippingMethodId: z.string().nullable().optional(),
      deliveryAddressId: z.string().nullable().optional(),
      postingDate: z.string().nullable().optional(),
      lines: z.array(documentLineSchema).optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const { documentId, companyId, ...payload } = data;
    const result = await runWithTenant(tenantId, async (_, tx) => {
      return updateDocument(tx, documentId, { companyId, ...payload });
    });
    return result;
  });

export const postDocumentFn = createServerFn({ method: "POST", strict: false })
  .middleware([telemetryMiddleware])
  .inputValidator(z.object({ documentId: z.string() }))
  .handler(async ({ data }) => {
    await requireAuth();
    const user = await getUser();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      const res = await postDocument(tx, {
        documentId: data.documentId,
        userId: user?.id ?? "system",
      });
      if (res.success) {
        await createAuditEvent(tx, {
          tenantId,
          userId: user?.id,
          eventType: "document_posted",
          severity: "info",
          message: `Posted document: ${data.documentId}`,
          traceId: getTraceId(),
          data: { documentId: data.documentId },
        });
      }
      return res;
    });
    return result;
  });

export const applyDeltaEffectFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      documentLineId: z.string(),
      qtyDelta: z.number(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      return applyDeltaEffect(tx, {
        documentLineId: data.documentLineId,
        qtyDelta: data.qtyDelta,
      });
    });
    return result;
  });

export const explodeDocumentBomFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(z.object({ documentId: z.string() }))
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      return explodeDocumentBom(tx, { documentId: data.documentId, tenantId });
    });
    return result;
  });

export const closePeriodFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(z.object({ fiscalPeriodId: z.string() }))
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      return closePeriod(tx, { fiscalPeriodId: data.fiscalPeriodId });
    });
    return result;
  });

export const convertDocumentFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      documentId: z.string(),
      targetGroupId: z.string().optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      return convertDocument(tx, {
        documentId: data.documentId,
        targetGroupId: data.targetGroupId,
      });
    });
    return result;
  });

const CONVERSION_MAP: Record<string, string> = {
  N: "A",
  A: "L",
  L: "R",
  b: "l",
  l: "r",
};

export const getDocumentConvertInfoFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(z.object({ documentId: z.string() }))
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      const docRows = (await tx.unsafe(
        `SELECT d.document_id, d.document_no, d.document_type, d.document_group_id, dg.next_group_id
         FROM document d
         LEFT JOIN document_group dg ON d.document_group_id = dg.document_group_id
         WHERE d.document_id = $1`,
        [data.documentId],
      )) as Record<string, unknown>[];

      if (docRows.length === 0) {
        return null;
      }

      const doc = docRows[0];
      const docType = doc.document_type as string;
      const targetDocType = CONVERSION_MAP[docType];

      if (!targetDocType) {
        return null;
      }

      const groups = (await tx.unsafe(
        `SELECT document_group_id, name, group_number FROM document_group
         WHERE document_type = $1 AND is_active = true ORDER BY group_number`,
        [targetDocType],
      )) as Record<string, unknown>[];

      return {
        sourceDocNo: doc.document_no as string,
        sourceDocType: docType,
        targetDocType,
        nextGroupId: doc.next_group_id as string | null,
        targetGroups: groups,
      };
    });
    return result;
  });

export const stornoDocumentFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(z.object({ documentId: z.string() }))
  .handler(async ({ data }) => {
    await requireAuth();
    const user = await getUser();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      return stornoDocument(tx, {
        documentId: data.documentId,
        userId: user?.id ?? "system",
      });
    });
    return result;
  });

// --- Document header form helpers ---

export const listDocumentTypesFn = createServerFn({ method: "GET", strict: false }).handler(
  async () => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      const rows = (await tx.unsafe(
        `SELECT code, name, movement_type, sort_order FROM document_type WHERE is_active = true ORDER BY sort_order`,
      )) as Record<string, unknown>[];
      const outbound: typeof rows = [];
      const inbound: typeof rows = [];
      const adjustment: typeof rows = [];
      for (const r of rows) {
        const mt = String(r.movement_type);
        if (["N", "A", "L", "R", "G"].includes(mt)) outbound.push(r);
        else if (["b", "l", "r", "g"].includes(mt)) inbound.push(r);
        else adjustment.push(r);
      }
      return { outbound, inbound, adjustment };
    });
    return result;
  },
);

export const listDocumentGroupsFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(z.object({ documentType: z.string() }))
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      const rows = (await tx.unsafe(
        `SELECT document_group_id, name, group_number, default_warehouse_id, default_tax_code_id FROM document_group WHERE document_type = $1 AND is_active = true ORDER BY group_number`,
        [data.documentType],
      )) as Record<string, unknown>[];
      return rows;
    });
    return result;
  });

export const searchAddressFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(
    z.object({
      query: z.string(),
      limit: z.number().optional().default(50),
    }),
  )
  .handler(async ({ data }) => {
    try {
      await requireAuth();
      const tenantId = await $getTenantId();
      const result = await runWithTenant(tenantId, async (_, tx) => {
        console.log(`[searchAddressFn] tenant=${tenantId} query="${data.query}"`);
        const q = `%${data.query}%`;
        const rows = (await tx.unsafe(
          `SELECT address_id, address_no, company_name, first_name, last_name,
                  address_line_1, address_line_2, postal_code, city, country_code,
                  currency_id, vat_id, payment_term_id
           FROM address
           WHERE (address_no ILIKE $1
               OR company_name ILIKE $1
               OR first_name ILIKE $1
               OR last_name ILIKE $1
               OR address_line_1 ILIKE $1
               OR postal_code ILIKE $1
               OR city ILIKE $1
               OR country_code ILIKE $1
               OR vat_id ILIKE $1
               OR search_text ILIKE $1)
              AND is_active = true
            LIMIT $2`,
          [q, data.limit],
        )) as Record<string, unknown>[];
        console.log(`[searchAddressFn] found ${rows.length} rows`);
        return rows;
      });
      return result;
    } catch (e) {
      console.error("[searchAddressFn] ERROR:", e);
      throw e;
    }
  });

export const getCompanyDefaultsFn = createServerFn({ method: "GET", strict: false }).handler(
  async () => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (_, tx) => {
      const rows = (await tx.unsafe(
        `SELECT company_id, name, currency_id FROM company WHERE is_active = true LIMIT 1`,
      )) as Record<string, unknown>[];
      return rows[0] ?? null;
    });
    return result;
  },
);

// --- Article pricing resolution (autocomplete) ---

export const resolveArticlePricingFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(
    z.object({
      articleId: z.string().uuid(),
      addressId: z.string().uuid(),
      documentDate: z.string(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (ctx, tx) => {
      return resolveArticlePricing(tx, {
        articleId: data.articleId,
        addressId: data.addressId,
        documentDate: data.documentDate,
      });
    });
    return result;
  });

// --- Inventory balance per warehouse ---

export const getInventoryBalanceFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(
    z.object({
      articleId: z.string().uuid(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (ctx, tx) => {
      return getInventoryBalance(tx, {
        articleId: data.articleId,
      });
    });
    return result;
  });

// --- Customer stats ---

export const getCustomerDocumentsFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(
    z.object({
      customerId: z.string().uuid(),
      limit: z.number().optional().default(10),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (ctx, tx) => {
      return getCustomerDocuments(tx, {
        customerId: data.customerId,
        limit: data.limit,
      });
    });
    return result;
  });

export const getCustomerYearlyRevenueFn = createServerFn({ method: "GET", strict: false })
  .inputValidator(
    z.object({
      customerId: z.string().uuid(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const result = await runWithTenant(tenantId, async (ctx, tx) => {
      return getCustomerYearlyRevenue(tx, {
        customerId: data.customerId,
      });
    });
    return result;
  });

export const getLlmConfigFn = createServerFn({ method: "GET", strict: false }).handler(async () => {
  await requireSystemAdmin();
  return runWithSystem(async (_, tx) => {
    return getLlmConfig(tx);
  });
});

export const saveLlmConfigFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      endpoint_url: z.string(),
      model: z.string(),
      provider: z.string(),
      api_key: z.string(),
      github_token: z.string().optional(),
      github_repo: z.string().optional(),
      feedback_llm_enabled: z.boolean().optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireSystemAdmin();
    return runWithSystem(async (_, tx) => {
      const current = await getLlmConfig(tx);
      const updated = {
        ...data,
        github_token: data.github_token ?? current.github_token ?? "",
        github_repo: data.github_repo ?? current.github_repo ?? "",
        feedback_llm_enabled: data.feedback_llm_enabled ?? current.feedback_llm_enabled ?? true,
      };
      return saveLlmConfig(tx, updated as LlmConfig);
    });
  });

export const testLlmFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      endpoint_url: z.string(),
      model: z.string(),
      provider: z.string(),
      api_key: z.string(),
    }),
  )
  .handler(async ({ data }) => {
    await requireSystemAdmin();
    const serviceUrl = process.env.LLM_SERVICE_URL || "http://localhost:11435";
    try {
      const res = await fetch(`${serviceUrl}/complete`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: "Say 'Hello World' and nothing else.",
          model: data.model,
          endpoint_url: data.endpoint_url,
          api_key: data.api_key,
          provider: data.provider,
        }),
      });
      if (!res.ok) {
        const err = await res.text();
        return { success: false, error: err };
      }
      const json = (await res.json()) as { content: string };
      return { success: true, content: json.content };
    } catch (e) {
      return { success: false, error: e instanceof Error ? e.message : String(e) };
    }
  });

// --- LiteLLM Admin Config ---

export const getLiteLLMConfigFn = createServerFn({ method: "GET", strict: false }).handler(
  async () => {
    await requireSystemAdmin();
    return runWithSystem(async (_, tx) => {
      return getLiteLLMConfig(tx);
    });
  },
);

export const saveLiteLLMConfigFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      base_url: z.string().url().or(z.string().max(0)),
      api_key: z.string(),
      default_model: z.string(),
    }),
  )
  .handler(async ({ data }) => {
    await requireSystemAdmin();
    return runWithSystem(async (_, tx) => {
      return saveLiteLLMConfig(tx, data as LiteLLMConfig);
    });
  });

export const testLiteLLMFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      base_url: z.string().min(1),
      api_key: z.string().min(1),
    }),
  )
  .handler(async ({ data }) => {
    await requireSystemAdmin();
    try {
      const res = await fetch(`${data.base_url.replace(/\/+$/, "")}/models`, {
        headers: {
          Authorization: `Bearer ${data.api_key}`,
          "Content-Type": "application/json",
        },
        signal: AbortSignal.timeout(10000),
      });
      if (!res.ok) {
        const err = await res.text();
        return { success: false, error: `HTTP ${res.status}: ${err}` };
      }
      const json = (await res.json()) as { data?: Array<{ id: string }> };
      const models = json.data?.map((m) => m.id) ?? [];
      return { success: true, models: models.slice(0, 50) };
    } catch (e) {
      return { success: false, error: e instanceof Error ? e.message : String(e) };
    }
  });

// --- Dashboard KPIs (real data from MVs + live queries) ---

export interface DashboardKpis {
  fiscalYear: number;
  umsatzCurrent: number;
  umsatzPrior: number;
  rohertragCurrent: number;
  rohertragPrior: number;
  openOrdersCount: number;
  openOrdersValue: number;
  openInvoicesCount: number;
  openInvoicesValue: number;
  inventoryValue: number;
  topArticleGroups: Array<{
    articleGroupId: string;
    name: string;
    totalAmountNet: number;
    totalProfit: number;
  }>;
}

export interface PeriodComparisonRow {
  periodNo: number;
  totalAmountNet: number;
  totalProfit: number;
}

export interface PeriodComparisonStats {
  fiscalYear: number;
  priorYear: number | null;
  currentYear: PeriodComparisonRow[];
  priorYearData: PeriodComparisonRow[];
}

export function PeriodComparisonShapeCheck(): PeriodComparisonStats {
  return {
    fiscalYear: 2026,
    priorYear: 2025,
    currentYear: Array.from({ length: 12 }, (_, i) => ({
      periodNo: i + 1,
      totalAmountNet: 1000 * (i + 1),
      totalProfit: 300 * (i + 1),
    })),
    priorYearData: Array.from({ length: 12 }, (_, i) => ({
      periodNo: i + 1,
      totalAmountNet: 900 * (i + 1),
      totalProfit: 250 * (i + 1),
    })),
  };
}

export function DashboardKpisShapeCheck(): DashboardKpis {
  return {
    fiscalYear: 2026,
    umsatzCurrent: 10000,
    umsatzPrior: 8000,
    rohertragCurrent: 3000,
    rohertragPrior: 2500,
    openOrdersCount: 5,
    openOrdersValue: 15000,
    openInvoicesCount: 3,
    openInvoicesValue: 9000,
    inventoryValue: 50000,
    topArticleGroups: [
      {
        articleGroupId: "test-id",
        name: "Test Group",
        totalAmountNet: 5000,
        totalProfit: 1500,
      },
    ],
  };
}

export const getPeriodComparisonStatsFn = createServerFn({
  method: "GET",
  strict: false,
})
  .inputValidator(z.object({ fiscalYear: z.number().int().min(2000).max(2100) }))
  .handler(async ({ data }): Promise<PeriodComparisonStats> => {
    await requireAuth();
    const tenantId = await $getTenantId();
    const priorYear = data.fiscalYear - 1;

    return runWithTenant(tenantId, async (_, tx) => {
      const currentRows = await tx.unsafe(
        `SELECT period_no, COALESCE(SUM(total_amount_net), 0) as total_amount_net, COALESCE(SUM(total_profit), 0) as total_profit
         FROM mv_sales_period WHERE fiscal_year = $1
         GROUP BY period_no ORDER BY period_no`,
        [data.fiscalYear],
      );

      const currentYear: PeriodComparisonRow[] = (currentRows as Record<string, unknown>[]).map(
        (r) => ({
          periodNo: Number(r.period_no),
          totalAmountNet: Number(r.total_amount_net),
          totalProfit: Number(r.total_profit),
        }),
      );

      const priorRows = await tx.unsafe(
        `SELECT period_no, COALESCE(SUM(total_amount_net), 0) as total_amount_net, COALESCE(SUM(total_profit), 0) as total_profit
         FROM mv_sales_period WHERE fiscal_year = $1
         GROUP BY period_no ORDER BY period_no`,
        [priorYear],
      );

      const priorYearData: PeriodComparisonRow[] = (priorRows as Record<string, unknown>[]).map(
        (r) => ({
          periodNo: Number(r.period_no),
          totalAmountNet: Number(r.total_amount_net),
          totalProfit: Number(r.total_profit),
        }),
      );

      return {
        fiscalYear: data.fiscalYear,
        priorYear: priorYearData.length > 0 ? priorYear : null,
        currentYear,
        priorYearData,
      };
    });
  });

export const getFiscalYearsFn = createServerFn({
  method: "GET",
  strict: false,
}).handler(async (): Promise<{ fiscalYear: number; label: string }[]> => {
  await requireAuth();
  const tenantId = await $getTenantId();

  return runWithTenant(tenantId, async (_, tx) => {
    const rows = await tx.unsafe(
      `SELECT DISTINCT fiscal_year FROM fiscal_period ORDER BY fiscal_year DESC`,
    );
    return (rows as Record<string, unknown>[]).map((r) => {
      const y = Number(r.fiscal_year);
      return { fiscalYear: y, label: String(y) };
    });
  });
});

export const getDashboardKpisFn = createServerFn({
  method: "GET",
  strict: false,
}).handler(async (): Promise<DashboardKpis> => {
  await requireAuth();
  const tenantId = await $getTenantId();

  return runWithTenant(tenantId, async (_, tx) => {
    const currentYear = new Date().getFullYear();
    const priorYear = currentYear - 1;

    // Current year sales from mv_sales_period
    const currentRows = await tx.unsafe(
      `SELECT COALESCE(SUM(total_amount_net), 0) as umsatz, COALESCE(SUM(total_profit), 0) as rohertrag
       FROM mv_sales_period WHERE fiscal_year = $1`,
      [currentYear],
    );
    const umsatzCurrent = Number(
      (currentRows[0] as Record<string, unknown> | undefined)?.umsatz ?? 0,
    );
    const rohertragCurrent = Number(
      (currentRows[0] as Record<string, unknown> | undefined)?.rohertrag ?? 0,
    );

    // Prior year sales
    const priorRows = await tx.unsafe(
      `SELECT COALESCE(SUM(total_amount_net), 0) as umsatz, COALESCE(SUM(total_profit), 0) as rohertrag
       FROM mv_sales_period WHERE fiscal_year = $1`,
      [priorYear],
    );
    const umsatzPrior = Number((priorRows[0] as Record<string, unknown> | undefined)?.umsatz ?? 0);
    const rohertragPrior = Number(
      (priorRows[0] as Record<string, unknown> | undefined)?.rohertrag ?? 0,
    );

    // Open orders: status != 'posted', outbound document types
    const openOrdersRows = await tx.unsafe(
      `SELECT COUNT(*) as cnt, COALESCE(SUM(total_net), 0) as val
       FROM document
       WHERE status != 'posted' AND document_type IN ('N', 'A', 'L', 'R', 'G')`,
    );
    const openOrdersCount = Number(
      (openOrdersRows[0] as Record<string, unknown> | undefined)?.cnt ?? 0,
    );
    const openOrdersValue = Number(
      (openOrdersRows[0] as Record<string, unknown> | undefined)?.val ?? 0,
    );

    // Open invoices: is_paid = false, invoice types
    const openInvRows = await tx.unsafe(
      `SELECT COUNT(*) as cnt, COALESCE(SUM(total_net), 0) as val
       FROM document
       WHERE is_paid = false AND document_type IN ('N', 'A')`,
    );
    const openInvoicesCount = Number(
      (openInvRows[0] as Record<string, unknown> | undefined)?.cnt ?? 0,
    );
    const openInvoicesValue = Number(
      (openInvRows[0] as Record<string, unknown> | undefined)?.val ?? 0,
    );

    // Inventory value: SUM(on_hand_qty * COALESCE(gld_purchase, 0))
    const invRows = await tx.unsafe(
      `SELECT COALESCE(SUM(on_hand_qty * COALESCE(gld_purchase, 0)), 0) as total
       FROM inventory_balance WHERE on_hand_qty > 0`,
    );
    const inventoryValue = Number((invRows[0] as Record<string, unknown> | undefined)?.total ?? 0);

    // Top 5 article groups by revenue (current year)
    const groupRows = await tx.unsafe(
      `SELECT ag.article_group_id,
              COALESCE(ag.name, 'Ungrouped') as name,
              COALESCE(SUM(mv.total_amount_net), 0) as total_amount_net,
              COALESCE(SUM(mv.total_profit), 0) as total_profit
       FROM mv_sales_period_article_group mv
       JOIN fiscal_period fp ON fp.fiscal_period_id = mv.fiscal_period_id
       JOIN article_group ag ON ag.article_group_id = mv.article_group_id
       WHERE fp.fiscal_year = $1
       GROUP BY ag.article_group_id, ag.name
       ORDER BY total_amount_net DESC
       LIMIT 5`,
      [currentYear],
    );

    const topArticleGroups = (groupRows as Record<string, unknown>[]).map((r) => ({
      articleGroupId: String(r.article_group_id),
      name: String(r.name),
      totalAmountNet: Number(r.total_amount_net),
      totalProfit: Number(r.total_profit),
    }));

    return {
      fiscalYear: currentYear,
      umsatzCurrent,
      umsatzPrior,
      rohertragCurrent,
      rohertragPrior,
      openOrdersCount,
      openOrdersValue,
      openInvoicesCount,
      openInvoicesValue,
      inventoryValue,
      topArticleGroups,
    };
  });
});

export const submitFeedbackFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      description: z.string().min(10),
      snapshot: z.record(z.string(), z.unknown()),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const { sql } = await getDb();
    const config = await getLlmConfig(sql as any);

    if (!config.endpoint_url || !config.github_token || !config.github_repo) {
      throw new Error("Feedback system not configured correctly.");
    }

    const serviceUrl = process.env.LLM_SERVICE_URL || "http://localhost:11435";

    let issueData;

    if (config.feedback_llm_enabled) {
      const prompt = `You are an AI assistant that formats user bug reports/feedback into structured GitHub issues.
The user provided the following description:
"${data.description}"

The following system context was captured:
${JSON.stringify(data.snapshot, null, 2)}

IMPORTANT: You MUST respond ONLY with a raw JSON object. No markdown blocks, no preamble.
Format:
{
  "title": "Clear English title",
  "body": "Detailed Markdown body. Make sure to prominently list the 'activeFiles', any captured 'selection' context, and a summary of the 'breadcrumbs' (flight recorder) at the top of the body so developers/agents know exactly what happened before the report.",
  "label": "bug"
}`;

      try {
        const llmRes = await fetch(`${serviceUrl}/complete`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            prompt,
            model: config.model,
            endpoint_url: config.endpoint_url,
            api_key: config.api_key,
            provider: config.provider,
          }),
        });

        if (!llmRes.ok) throw new Error("LLM service failed");
        const llmJson = (await llmRes.json()) as { content: string };

        // Try to parse JSON from LLM response
        // Handle cases where LLM might still include markdown blocks
        const cleanContent = llmJson.content.replace(/```json\n?|\n?```/g, "").trim();
        const firstBrace = cleanContent.indexOf("{");
        const lastBrace = cleanContent.lastIndexOf("}");
        if (firstBrace !== -1 && lastBrace !== -1) {
          issueData = JSON.parse(cleanContent.substring(firstBrace, lastBrace + 1));
        } else {
          throw new Error("No JSON object found");
        }
      } catch (e) {
        console.error("LLM Feedback failed, falling back to static template", e);
        // Fallback below
      }
    }

    if (!issueData) {
      // Static template logic
      const snap = data.snapshot as any;
      const title = `Feedback: ${data.description.substring(0, 50)}${data.description.length > 50 ? "..." : ""}`;

      let body = `## User Description\n${data.description}\n\n`;
      body += `### Active Components\n${snap.activeFiles?.map((f: string) => `- \`${f}\``).join("\n") || "None"}\n\n`;

      if (snap.selection) {
        body += `### Selection Context\n\`\`\`json\n${JSON.stringify(snap.selection, null, 2)}\n\`\`\`\n\n`;
      }

      if (snap.breadcrumbs?.length > 0) {
        body += `### Flight Recorder (Last ${snap.breadcrumbs.length} events)\n`;
        body += "| Time | Type | Level | Message |\n| --- | --- | --- | --- |\n";
        body += snap.breadcrumbs
          .map(
            (b: any) =>
              `| ${b.ts?.split("T")[1]?.split(".")[0] || "—"} | ${b.type} | ${b.level} | ${b.message} |`,
          )
          .join("\n");
        body += "\n\n";
      }

      body += `---\n**System Info:**\n- URL: ${snap.url}\n- User Agent: ${snap.userAgent}\n- Viewport: ${snap.viewport?.width}x${snap.viewport?.height}\n- Timestamp: ${snap.timestamp}`;

      issueData = {
        title,
        body,
        label: "bug",
      };
    }

    try {
      // Create GitHub issue
      const repoPath = config.github_repo.trim().replace(/^\/+|\/+$/g, "");
      const ghRes = await fetch(`https://api.github.com/repos/${repoPath}/issues`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${config.github_token.trim()}`,
          Accept: "application/vnd.github.v3+json",
          "Content-Type": "application/json",
          "User-Agent": "Slopware-Feedback-Service",
        },
        body: JSON.stringify({
          title: issueData.title,
          body: issueData.body,
          labels: [issueData.label || "bug"],
        }),
      });

      if (!ghRes.ok) {
        const ghErr = await ghRes.text();
        console.error(`GitHub API Error for ${repoPath}:`, ghErr);
        throw new Error(`GitHub API failed: ${ghErr}`);
      }

      const ghJson = (await ghRes.json()) as { html_url: string };

      const res = { success: true, issueUrl: ghJson.html_url };

      // Audit Event for feedback
      await runWithTenant(await $getTenantId(), async (_, tx) => {
        await createAuditEvent(tx, {
          tenantId: await $getTenantId(),
          userId: (await getUser())?.id,
          eventType: "feedback_submitted",
          severity: "info",
          message: `Feedback submitted: ${ghJson.html_url}`,
          traceId: getTraceId(),
          data: { issueUrl: ghJson.html_url, description: data.description },
        });
      });

      return res;
    } catch (e) {
      return { success: false, error: e instanceof Error ? e.message : String(e) };
    }
  });

// --- Address stats (Statistik, Offene Posten, Bewegungen, Belege) ---

export interface AddressStatsRow {
  periodNo: number;
  fiscalYear: number;
  totalAmountNet: number;
  totalProfit: number;
}

export interface OpenItemRow {
  documentId: string;
  documentNo: string;
  documentType: string;
  documentDate: string;
  dueDate: string | null;
  totalGross: number;
}

export interface MovementRow {
  documentDate: string;
  documentNo: string;
  articleNo: string;
  quantity: number;
  netPrice: number;
}

export interface DocumentRow {
  documentId: string;
  documentNo: string;
  documentType: string;
  status: string;
  documentDate: string;
  totalGross: number;
}

export interface AddressStats {
  stats: AddressStatsRow[];
  openItems: OpenItemRow[];
  movements: MovementRow[];
  documents: DocumentRow[];
  isCustomer: boolean;
}

export const getAddressStatsFn = createServerFn({
  method: "GET",
  strict: false,
})
  .inputValidator(z.object({ addressId: z.string().uuid() }))
  .handler(async ({ data }): Promise<AddressStats> => {
    await requireAuth();
    const tenantId = await $getTenantId();

    return runWithTenant(tenantId, async (_, tx) => {
      const addrRows = await tx.unsafe(
        `SELECT COALESCE(is_customer, false) as is_customer FROM address WHERE address_id = $1`,
        [data.addressId],
      );
      const isCustomer = Boolean((addrRows[0] as Record<string, unknown>)?.is_customer);

      const statRows = await tx.unsafe(
        `SELECT fp.period_no, fp.fiscal_year,
                COALESCE(SUM(mv.total_amount_net), 0) as total_amount_net,
                COALESCE(SUM(mv.total_profit), 0) as total_profit
         FROM mv_sales_period_customer mv
         JOIN fiscal_period fp ON fp.fiscal_period_id = mv.fiscal_period_id
         WHERE mv.customer_id = $1
         GROUP BY fp.period_no, fp.fiscal_year
         ORDER BY fp.fiscal_year DESC, fp.period_no`,
        [data.addressId],
      );
      const stats: AddressStatsRow[] = (statRows as Record<string, unknown>[]).map((r) => ({
        periodNo: Number(r.period_no),
        fiscalYear: Number(r.fiscal_year),
        totalAmountNet: Number(r.total_amount_net),
        totalProfit: Number(r.total_profit),
      }));

      const oiRows = await tx.unsafe(
        `SELECT d.document_id, d.document_no, d.document_type,
                d.document_date::text as document_date,
                d.due_date::text as due_date,
                COALESCE(d.total_gross::float, 0) as total_gross
         FROM document d
         WHERE d.customer_id = $1 AND d.is_paid = false
         ORDER BY d.due_date ASC, d.document_date DESC`,
        [data.addressId],
      );
      const openItems: OpenItemRow[] = (oiRows as Record<string, unknown>[]).map((r) => ({
        documentId: String(r.document_id),
        documentNo: String(r.document_no),
        documentType: String(r.document_type),
        documentDate: String(r.document_date),
        dueDate: r.due_date ? String(r.due_date) : null,
        totalGross: Number(r.total_gross),
      }));

      const movRows = await tx.unsafe(
        `SELECT d.document_date::text as document_date,
                d.document_no,
                COALESCE(a.article_no, dil.article_text_snapshot) as article_no,
                dil.quantity,
                dil.net_price
         FROM document_line dil
         JOIN document d ON d.document_id = dil.document_id
         LEFT JOIN article a ON a.article_id = dil.article_id
         WHERE d.customer_id = $1
         ORDER BY d.document_date DESC, d.document_no DESC, dil.line_no`,
        [data.addressId],
      );
      const movements: MovementRow[] = (movRows as Record<string, unknown>[]).map((r) => ({
        documentDate: String(r.document_date),
        documentNo: String(r.document_no),
        articleNo: String(r.article_no ?? ""),
        quantity: Number(r.quantity),
        netPrice: Number(r.net_price),
      }));

      const docRows = await tx.unsafe(
        `SELECT d.document_id, d.document_no, d.document_type, d.status,
                d.document_date::text as document_date,
                COALESCE(d.total_gross::float, 0) as total_gross
         FROM document d
         WHERE d.customer_id = $1
         ORDER BY d.document_date DESC, d.document_no DESC`,
        [data.addressId],
      );
      const documents: DocumentRow[] = (docRows as Record<string, unknown>[]).map((r) => ({
        documentId: String(r.document_id),
        documentNo: String(r.document_no),
        documentType: String(r.document_type),
        status: String(r.status),
        documentDate: String(r.document_date),
        totalGross: Number(r.total_gross),
      }));

      return { stats, openItems, movements, documents, isCustomer };
    });
  });

export function AddressStatsShapeCheck(): AddressStats {
  return {
    stats: [
      { periodNo: 1, fiscalYear: 2026, totalAmountNet: 5000, totalProfit: 1500 },
      { periodNo: 2, fiscalYear: 2026, totalAmountNet: 6000, totalProfit: 1800 },
    ],
    openItems: [
      {
        documentId: "test-oid",
        documentNo: "RE-00001",
        documentType: "R",
        documentDate: "2026-01-15",
        dueDate: "2026-02-14",
        totalGross: 5950,
      },
    ],
    movements: [
      {
        documentDate: "2026-01-15",
        documentNo: "LI-00001",
        articleNo: "ART-001",
        quantity: 10,
        netPrice: 500,
      },
    ],
    documents: [
      {
        documentId: "test-did",
        documentNo: "RE-00001",
        documentType: "R",
        status: "posted",
        documentDate: "2026-01-15",
        totalGross: 5950,
      },
    ],
    isCustomer: true,
  };
}

// --- Article stats (Statistik, Lagerjournal, Bewegungen, Belege) ---

export interface ArticleStatsRow {
  periodNo: number;
  fiscalYear: number;
  totalQty: number;
  totalAmountNet: number;
  totalProfit: number;
  purchaseQty: number;
}

export interface StockJournalRow {
  movementDate: string;
  movementType: string;
  warehouseId: string;
  warehouseName: string;
  qtyDelta: number;
  runningBalance: number;
  referenceText: string | null;
}

export interface ArticleMovementRow {
  documentDate: string;
  documentNo: string;
  articleNo: string;
  quantity: number;
  netPrice: number;
}

export interface ArticleDocumentRow {
  documentId: string;
  documentNo: string;
  documentType: string;
  status: string;
  documentDate: string;
  totalGross: number;
}

export interface ArticleStats {
  stats: ArticleStatsRow[];
  stockJournal: StockJournalRow[];
  movements: ArticleMovementRow[];
  documents: ArticleDocumentRow[];
  reservedQty: number;
  expectedPurchaseQty: number;
}

export const getArticleStatsFn = createServerFn({
  method: "GET",
  strict: false,
})
  .inputValidator(
    z.object({ articleId: z.string().uuid(), warehouseId: z.string().uuid().optional() }),
  )
  .handler(async ({ data }): Promise<ArticleStats> => {
    await requireAuth();
    const tenantId = await $getTenantId();

    return runWithTenant(tenantId, async (_, tx) => {
      const whFilter = data.warehouseId
        ? `AND mv.article_id = $1 AND mv.company_id = fp.company_id`
        : `AND mv.article_id = $1 AND mv.company_id = fp.company_id`;

      const statRows = await tx.unsafe(
        `SELECT fp.period_no, fp.fiscal_year,
                COALESCE(SUM(mv.total_qty), 0) as total_qty,
                COALESCE(SUM(mv.total_amount_net), 0) as total_amount_net,
                COALESCE(SUM(mv.total_profit), 0) as total_profit,
                COALESCE(SUM(mp.total_qty), 0) as purchase_qty
         FROM fiscal_period fp
         LEFT JOIN mv_sales_period_article mv ON mv.fiscal_period_id = fp.fiscal_period_id AND mv.article_id = $1
         LEFT JOIN mv_purchase_period_article mp ON mp.fiscal_period_id = fp.fiscal_period_id AND mp.article_id = $1
         WHERE fp.fiscal_period_id IS NOT NULL
         GROUP BY fp.period_no, fp.fiscal_year
         ORDER BY fp.fiscal_year DESC, fp.period_no`,
        [data.articleId],
      );
      const stats: ArticleStatsRow[] = (statRows as Record<string, unknown>[]).map((r) => ({
        periodNo: Number(r.period_no),
        fiscalYear: Number(r.fiscal_year),
        totalQty: Number(r.total_qty),
        totalAmountNet: Number(r.total_amount_net),
        totalProfit: Number(r.total_profit),
        purchaseQty: Number(r.purchase_qty),
      }));

      const whClause = data.warehouseId ? "AND im.warehouse_id = $2" : "";
      const journalRows = await tx.unsafe(
        `SELECT im.movement_date::text as movement_date,
                im.movement_type,
                im.warehouse_id,
                COALESCE(w.name, im.warehouse_id::text) as warehouse_name,
                COALESCE(im.qty_delta::float, 0) as qty_delta,
                SUM(COALESCE(im.qty_delta::float, 0)) OVER (ORDER BY im.movement_date, im.created_at) as running_balance,
                im.reference_text
         FROM inventory_movement im
         LEFT JOIN warehouse w ON w.warehouse_id = im.warehouse_id
         WHERE im.article_id = $1 ${whClause}
         ORDER BY im.movement_date, im.created_at`,
        data.warehouseId ? [data.articleId, data.warehouseId] : [data.articleId],
      );
      const stockJournal: StockJournalRow[] = (journalRows as Record<string, unknown>[]).map(
        (r) => ({
          movementDate: String(r.movement_date),
          movementType: String(r.movement_type),
          warehouseId: String(r.warehouse_id),
          warehouseName: String(r.warehouse_name),
          qtyDelta: Number(r.qty_delta),
          runningBalance: Number(r.running_balance),
          referenceText: r.reference_text ? String(r.reference_text) : null,
        }),
      );

      const movRows = await tx.unsafe(
        `SELECT d.document_date::text as document_date,
                d.document_no,
                COALESCE(a.article_no, dil.article_text_snapshot) as article_no,
                dil.quantity,
                dil.net_price
         FROM document_line dil
         JOIN document d ON d.document_id = dil.document_id
         LEFT JOIN article a ON a.article_id = dil.article_id
         WHERE dil.article_id = $1
         ORDER BY d.document_date DESC, d.document_no DESC, dil.line_no`,
        [data.articleId],
      );
      const movements: ArticleMovementRow[] = (movRows as Record<string, unknown>[]).map((r) => ({
        documentDate: String(r.document_date),
        documentNo: String(r.document_no),
        articleNo: String(r.article_no ?? ""),
        quantity: Number(r.quantity),
        netPrice: Number(r.net_price),
      }));

      const docRows = await tx.unsafe(
        `SELECT d.document_id, d.document_no, d.document_type, d.status,
                d.document_date::text as document_date,
                COALESCE(d.total_gross::float, 0) as total_gross
         FROM document d
         WHERE d.document_id IN (
           SELECT DISTINCT dil.document_id FROM document_line dil WHERE dil.article_id = $1
         )
         ORDER BY d.document_date DESC, d.document_no DESC`,
        [data.articleId],
      );
      const documents: ArticleDocumentRow[] = (docRows as Record<string, unknown>[]).map((r) => ({
        documentId: String(r.document_id),
        documentNo: String(r.document_no),
        documentType: String(r.document_type),
        status: String(r.status),
        documentDate: String(r.document_date),
        totalGross: Number(r.total_gross),
      }));

      const balRows = await tx.unsafe(
        `SELECT COALESCE(SUM(ib.reserved_qty::float), 0) as reserved_qty,
                COALESCE(SUM(ib.expected_purchase_qty::float), 0) as expected_purchase_qty
         FROM inventory_balance ib
         WHERE ib.article_id = $1`,
        [data.articleId],
      );
      const reservedQty = Number((balRows[0] as Record<string, unknown>)?.reserved_qty ?? 0);
      const expectedPurchaseQty = Number(
        (balRows[0] as Record<string, unknown>)?.expected_purchase_qty ?? 0,
      );

      return { stats, stockJournal, movements, documents, reservedQty, expectedPurchaseQty };
    });
  });

export function ArticleStatsShapeCheck(): ArticleStats {
  return {
    stats: [
      {
        periodNo: 1,
        fiscalYear: 2026,
        totalQty: 100,
        totalAmountNet: 5000,
        totalProfit: 1500,
        purchaseQty: 120,
      },
      {
        periodNo: 2,
        fiscalYear: 2026,
        totalQty: 80,
        totalAmountNet: 6000,
        totalProfit: 1800,
        purchaseQty: 90,
      },
    ],
    stockJournal: [
      {
        movementDate: "2026-01-15",
        movementType: "N",
        warehouseId: "wh-001",
        warehouseName: "Main Warehouse",
        qtyDelta: 100,
        runningBalance: 100,
        referenceText: "Initial stock",
      },
      {
        movementDate: "2026-01-20",
        movementType: "L",
        warehouseId: "wh-001",
        warehouseName: "Main Warehouse",
        qtyDelta: -10,
        runningBalance: 90,
        referenceText: "Delivery LI-00001",
      },
    ],
    movements: [
      {
        documentDate: "2026-01-15",
        documentNo: "LI-00001",
        articleNo: "ART-001",
        quantity: 10,
        netPrice: 500,
      },
    ],
    documents: [
      {
        documentId: "test-did",
        documentNo: "RE-00001",
        documentType: "R",
        status: "posted",
        documentDate: "2026-01-15",
        totalGross: 5950,
      },
    ],
    reservedQty: 15,
    expectedPurchaseQty: 50,
  };
}

// --- Article Group stats (Statistik, Bewegungen, Belege) ---

export interface ArticleGroupStatsRow {
  periodNo: number;
  fiscalYear: number;
  totalQty: number;
  totalAmountNet: number;
  totalProfit: number;
  purchaseQty: number;
}

export interface ArticleGroupMovementRow {
  documentDate: string;
  documentNo: string;
  articleNo: string;
  quantity: number;
  netPrice: number;
}

export interface ArticleGroupDocumentRow {
  documentId: string;
  documentNo: string;
  documentType: string;
  status: string;
  documentDate: string;
  totalGross: number;
}

export interface ArticleGroupStats {
  stats: ArticleGroupStatsRow[];
  movements: ArticleGroupMovementRow[];
  documents: ArticleGroupDocumentRow[];
}

export const getArticleGroupStatsFn = createServerFn({
  method: "GET",
  strict: false,
})
  .inputValidator(z.object({ articleGroupId: z.string().uuid() }))
  .handler(async ({ data }): Promise<ArticleGroupStats> => {
    await requireAuth();
    const tenantId = await $getTenantId();

    return runWithTenant(tenantId, async (_, tx) => {
      const statRows = await tx.unsafe(
        `SELECT fp.period_no, fp.fiscal_year,
                COALESCE(SUM(mv.total_qty), 0) as total_qty,
                COALESCE(SUM(mv.total_amount_net), 0) as total_amount_net,
                COALESCE(SUM(mv.total_profit), 0) as total_profit,
                COALESCE(SUM(mp.total_qty), 0) as purchase_qty
         FROM fiscal_period fp
         LEFT JOIN mv_sales_period_article_group mv ON mv.fiscal_period_id = fp.fiscal_period_id AND mv.article_group_id = $1
         LEFT JOIN mv_purchase_period_article mp ON mp.fiscal_period_id = fp.fiscal_period_id
           AND mp.article_id IN (SELECT a.article_id FROM article a WHERE a.article_group_id = $1)
         WHERE fp.fiscal_period_id IS NOT NULL
         GROUP BY fp.period_no, fp.fiscal_year
         ORDER BY fp.fiscal_year DESC, fp.period_no`,
        [data.articleGroupId],
      );
      const stats: ArticleGroupStatsRow[] = (statRows as Record<string, unknown>[]).map((r) => ({
        periodNo: Number(r.period_no),
        fiscalYear: Number(r.fiscal_year),
        totalQty: Number(r.total_qty),
        totalAmountNet: Number(r.total_amount_net),
        totalProfit: Number(r.total_profit),
        purchaseQty: Number(r.purchase_qty),
      }));

      const movRows = await tx.unsafe(
        `SELECT d.document_date::text as document_date,
                d.document_no,
                COALESCE(a.article_no, dil.article_text_snapshot) as article_no,
                dil.quantity,
                dil.net_price
         FROM document_line dil
         JOIN document d ON d.document_id = dil.document_id
         LEFT JOIN article a ON a.article_id = dil.article_id
         WHERE dil.article_id IN (SELECT article_id FROM article WHERE article_group_id = $1)
         ORDER BY d.document_date DESC, d.document_no DESC, dil.line_no`,
        [data.articleGroupId],
      );
      const movements: ArticleGroupMovementRow[] = (movRows as Record<string, unknown>[]).map(
        (r) => ({
          documentDate: String(r.document_date),
          documentNo: String(r.document_no),
          articleNo: String(r.article_no ?? ""),
          quantity: Number(r.quantity),
          netPrice: Number(r.net_price),
        }),
      );

      const docRows = await tx.unsafe(
        `SELECT d.document_id, d.document_no, d.document_type, d.status,
                d.document_date::text as document_date,
                COALESCE(d.total_gross::float, 0) as total_gross
         FROM document d
         WHERE d.document_id IN (
           SELECT DISTINCT dil.document_id FROM document_line dil
           WHERE dil.article_id IN (SELECT article_id FROM article WHERE article_group_id = $1)
         )
         ORDER BY d.document_date DESC, d.document_no DESC`,
        [data.articleGroupId],
      );
      const documents: ArticleGroupDocumentRow[] = (docRows as Record<string, unknown>[]).map(
        (r) => ({
          documentId: String(r.document_id),
          documentNo: String(r.document_no),
          documentType: String(r.document_type),
          status: String(r.status),
          documentDate: String(r.document_date),
          totalGross: Number(r.total_gross),
        }),
      );

      return { stats, movements, documents };
    });
  });

export const createAuditEventFn = createServerFn({ method: "POST", strict: false })
  .inputValidator(
    z.object({
      eventType: z.string(),
      severity: z.enum(["info", "warn", "error"]).optional(),
      message: z.string(),
      data: z.any().optional(),
    }),
  )
  .handler(async ({ data }) => {
    await requireAuth();
    const user = await getUser();
    const tenantId = await $getTenantId();
    const traceId = getTraceId();

    return runWithTenant(tenantId, async (_, tx) => {
      return createAuditEvent(tx, {
        tenantId,
        userId: user?.id,
        eventType: data.eventType,
        severity: data.severity,
        message: data.message,
        traceId,
        data: data.data,
      });
    });
  });

export function ArticleGroupStatsShapeCheck(): ArticleGroupStats {
  return {
    stats: [
      {
        periodNo: 1,
        fiscalYear: 2026,
        totalQty: 200,
        totalAmountNet: 12000,
        totalProfit: 3500,
        purchaseQty: 250,
      },
      {
        periodNo: 2,
        fiscalYear: 2026,
        totalQty: 180,
        totalAmountNet: 11000,
        totalProfit: 3200,
        purchaseQty: 200,
      },
    ],
    movements: [
      {
        documentDate: "2026-01-15",
        documentNo: "RE-00001",
        articleNo: "ART-001",
        quantity: 10,
        netPrice: 500,
      },
    ],
    documents: [
      {
        documentId: "test-did",
        documentNo: "RE-00001",
        documentType: "R",
        status: "posted",
        documentDate: "2026-01-15",
        totalGross: 5950,
      },
    ],
  };
}
