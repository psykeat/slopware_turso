import { ValueType } from "@opentelemetry/api";
import { createMiddleware } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { nanoid } from "nanoid";

import { serverLogger } from "../lib/server-logger";
import { getTraceId, meter } from "../telemetry";

const functionDuration = meter.createHistogram("server_function_duration_milliseconds", {
  description: "Duration of server function execution",
  valueType: ValueType.DOUBLE,
  advice: {
    explicitBucketBoundaries: [5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000],
  },
});

const functionErrors = meter.createCounter("server_function_errors", {
  description: "Count of server function errors",
  valueType: ValueType.INT,
});

export const telemetryMiddleware = createMiddleware().server(async ({ next }) => {
  if (typeof window !== "undefined") return next();

  const start = performance.now();
  const requestId = nanoid();
  const traceId = getTraceId();

  let route = "unknown";
  try {
    const request = getRequest();
    if (request) {
      const url = new URL(request.url);
      route = url.pathname; // Just pathname, no search params
    }
  } catch (e) {
    // getRequest might throw if context is not available
  }

  serverLogger.info(`Server Function Start: ${route}`, {
    requestId,
    traceId,
    route,
    type: "server_function_start",
  });

  try {
    const result = await next();
    const durationMs = performance.now() - start;

    functionDuration.record(durationMs, {
      "server.function.route": route,
      "server.function.status": "success",
    });

    serverLogger.info(`Server Function End: ${route}`, {
      requestId,
      traceId,
      route,
      durationMs,
      type: "server_function_end",
    });

    return result;
  } catch (error: any) {
    const durationMs = performance.now() - start;

    functionDuration.record(durationMs, {
      "server.function.route": route,
      "server.function.status": "error",
    });

    functionErrors.add(1, {
      "server.function.route": route,
      "server.function.error": error.name || "Error",
    });

    serverLogger.error(`Server Function Error: ${route}`, {
      requestId,
      traceId,
      route,
      durationMs,
      type: "server_function_error",
      error: {
        message: error.message,
        stack: error.stack,
        code: error.code,
      },
    });

    throw error;
  }
});
