import type { EffectiveField } from "@repo/domain";
import { z } from "zod";

export function createDynamicZodSchema(fields: EffectiveField[]) {
  const shape: Record<string, z.ZodTypeAny> = {};

  for (const field of fields) {
    let schema: z.ZodTypeAny;
    const type = (field.fieldType || "varchar").toLowerCase();

    switch (type) {
      case "boolean":
      case "bool":
        schema = z.coerce.boolean();
        break;
      case "integer":
      case "int":
      case "smallint":
      case "bigint":
      case "number":
      case "decimal":
      case "numeric":
      case "real":
      case "double":
      case "float":
        schema = z.coerce.number();
        break;
      case "timestamp":
      case "date":
        schema = z.string().or(z.date());
        break;
      case "jsonb":
      case "json":
        schema = z.any();
        break;
      case "uuid":
        schema = z.string().uuid();
        break;
      default:
        // Special case for common i18n fields if they are not explicitly typed as jsonb
        if (
          field.fieldName === "name" ||
          field.fieldName === "label" ||
          field.fieldName === "description"
        ) {
          schema = z.union([z.string(), z.record(z.string(), z.any())]);
        } else {
          schema = z.string();
        }
    }

    if (!field.isRequired) {
      schema = schema.nullable().optional();
    }

    shape[field.fieldName] = schema;
  }

  return z.object(shape);
}
