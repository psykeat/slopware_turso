import * as fs from "node:fs";
import * as path from "node:path";

import { trace, metrics, context, type Span } from "@opentelemetry/api";

import { serverLogger } from "./lib/server-logger";

/**
 * Initialize OpenTelemetry for Slopware.
 * This should be imported as early as possible in the server lifecycle.
 */

/**
 * Global meter for the application.
 */
export const meter =
  typeof window !== "undefined"
    ? {
        createHistogram: () => ({ record: () => {} }),
        createCounter: () => ({ add: () => {} }),
        createUpDownCounter: () => ({ add: () => {} }),
        createObservableGauge: () => ({ addCallback: () => {}, removeCallback: () => {} }),
      }
    : metrics.getMeter("slopware-web");

if (typeof window === "undefined") {
  // Manual .env loading because Vite dev might not inject them early enough
  try {
    const envPath = path.resolve(process.cwd(), "../../.env");
    if (fs.existsSync(envPath)) {
      const envContent = fs.readFileSync(envPath, "utf-8");
      envContent.split("\n").forEach((line) => {
        const [key, ...valueParts] = line.split("=");
        if (key && valueParts.length > 0) {
          const value = valueParts.join("=").trim();
          if (!process.env[key.trim()]) {
            process.env[key.trim()] = value;
          }
        }
      });
    }
  } catch (e) {
    // Ignore env loading errors
  }

  const OTEL_ENDPOINT =
    process.env.OTEL_EXPORTER_OTLP_ENDPOINT || process.env.VITE_OTEL_EXPORTER_OTLP_ENDPOINT;
  const OTEL_HEADERS =
    process.env.OTEL_EXPORTER_OTLP_HEADERS || process.env.VITE_OTEL_EXPORTER_OTLP_HEADERS;
  const OTEL_SERVICE_NAME_ENV = process.env.OTEL_SERVICE_NAME || process.env.VITE_OTEL_SERVICE_NAME;
  const ENABLE_OTEL = OTEL_ENDPOINT !== undefined;

  serverLogger.info("OTel Environment Check", {
    endpoint: OTEL_ENDPOINT,
    hasHeaders: !!OTEL_HEADERS,
    serviceName: OTEL_SERVICE_NAME_ENV,
    allKeys: Object.keys(process.env).filter((k) => k.startsWith("VITE_") || k.startsWith("OTEL_")),
  });

  if (ENABLE_OTEL) {
    // Dynamic import to prevent client-side leakage
    const initialize = async () => {
      const { NodeSDK } = await import("@opentelemetry/sdk-node");
      const { getNodeAutoInstrumentations } =
        await import("@opentelemetry/auto-instrumentations-node");
      const { OTLPTraceExporter } = await import("@opentelemetry/exporter-trace-otlp-http");
      const { OTLPMetricExporter } = await import("@opentelemetry/exporter-metrics-otlp-http");
      const { PeriodicExportingMetricReader } = await import("@opentelemetry/sdk-metrics");
      const { resourceFromAttributes } = await import("@opentelemetry/resources");
      const { SEMRESATTRS_SERVICE_NAME } = await import("@opentelemetry/semantic-conventions");

      // Parse headers if they exist (format: "key1=value1,key2=value2")
      const headers: Record<string, string> = {};
      if (OTEL_HEADERS) {
        OTEL_HEADERS.split(",").forEach((header) => {
          const [key, value] = header.split("=");
          if (key && value) {
            headers[key.trim()] = value.trim();
          }
        });
      }

      const sdk = new NodeSDK({
        resource: resourceFromAttributes({
          [SEMRESATTRS_SERVICE_NAME]: OTEL_SERVICE_NAME_ENV || "slopware-web",
        }),
        traceExporter: new OTLPTraceExporter({
          url: OTEL_ENDPOINT.endsWith("/v1/traces") ? OTEL_ENDPOINT : `${OTEL_ENDPOINT}/v1/traces`,
          headers,
        }),
        metricReader: new PeriodicExportingMetricReader({
          exporter: new OTLPMetricExporter({
            url: OTEL_ENDPOINT.endsWith("/v1/metrics")
              ? OTEL_ENDPOINT
              : `${OTEL_ENDPOINT}/v1/metrics`,
            headers,
          }),
          exportIntervalMillis: 10000,
        }),
        instrumentations: [
          getNodeAutoInstrumentations({
            // We might want to disable some instrumentations if they are too noisy
            "@opentelemetry/instrumentation-fs": { enabled: false },
          }),
        ],
      });

      sdk.start();
      serverLogger.info(`OpenTelemetry SDK started (Target: ${OTEL_ENDPOINT})`);

      // Handle shutdown
      process.on("SIGTERM", () => {
        sdk
          .shutdown()
          .then(() => serverLogger.info("OTel SDK shut down"))
          .catch((err) => serverLogger.error("Error shutting down OTel SDK", { error: err }))
          .finally(() => process.exit(0));
      });
    };

    initialize().catch((err) => {
      serverLogger.error("Failed to initialize OTel SDK", { error: err });
    });
  } else {
    serverLogger.info("OpenTelemetry disabled (OTEL_EXPORTER_OTLP_ENDPOINT not set)");
  }
}

/**
 * Helper to get the current trace ID from the active span context.
 */
export function getTraceId(): string | undefined {
  if (typeof window !== "undefined") return undefined;
  const activeSpan = trace.getSpan(context.active());
  return activeSpan?.spanContext().traceId;
}

/**
 * Helper to wrap a function in a manual span if needed.
 */
export async function withSpan<T>(name: string, fn: (span: Span) => Promise<T>): Promise<T> {
  if (typeof window !== "undefined") return fn({} as any);
  const tracer = trace.getTracer("slopware-web");
  return tracer.startActiveSpan(name, async (span) => {
    try {
      const result = await fn(span);
      return result;
    } catch (error: any) {
      span.recordException(error);
      span.setStatus({ code: 2 }); // Error
      throw error;
    } finally {
      span.end();
    }
  });
}
