# SLOPware – Design System & Code-Konventionen

Diese Datei beschreibt die Design-Entscheidungen, an denen sich jeder neue Code orientieren muss. **Keine Werte hardcoden** — immer die hier dokumentierten CSS-Variablen, Tokens und Patterns verwenden.

---

## 1. Grundprinzipien

1. **Workspace-Metapher.** Die App ist ein IDE-artiger Arbeitsbereich aus mehreren Panes (1–3 vertikal), nicht eine klassische Sidebar-Webapp. Jeder Pane hält eine _View_ aus der Registry; die UI ruft niemals SQL — sie fordert eine View an, und die Domain-Schicht orchestriert.
2. **Deep-Link-stabil.** Der Workspace-Zustand (Workspace + aktive Views pro Pane) lebt im URL-Hash. Reload reproduziert exakt das gleiche Bild. URL-Bar oben rendert das sichtbar.
3. **Registry-getrieben.** Entities (`address`, `document`, `article`, …) und Views (`address:list`, `document:lines`, …) sind in `ENTITY_REGISTRY` und `VIEW_REGISTRY` deklariert. UI-Komponenten lesen von dort.
4. **i18n-First.** Alle UI-Strings durch `t(key)`; Domain-Labels (Entity-Namen, Workspace-Namen) tragen `label_de` / `label_en` direkt in der Registry. Keine Inline-Strings.
5. **Information dicht, ruhig, professionell.** ERP-Kontext: kleine Schrift (12–13 px Baseline), schmale Zeilen, viel Tabelle, wenig Whitespace, kaum Iconographie. Keine emojis (außer Sprach-Flag-Icons), keine Farb-Verläufe, keine handgezeichneten Illustrationen.

---

## 2. Typografie

| Token         | Wert                    | Verwendung                              |
| ------------- | ----------------------- | --------------------------------------- |
| `--font-ui`   | `'DM Sans', sans-serif` | Alles UI                                |
| `--font-mono` | `'DM Mono', monospace`  | IDs, Pfade, Beträge, KPI-Werte, URL-Bar |

**Größen-Skala (px, niemals abweichen):**

- `9.5` – Section-Labels (UPPERCASE, letter-spacing 0.10em)
- `10` – KPI-Label, Badge-Text
- `10.5` – Footer, Statusbar, Mikro-Hints
- `11` – Section-Heading
- `11.5` – Inputs, Buttons, Tab-Subtext, Lookup-Werte
- `12` – Table-Body
- `12.5` – Tab-Item, Tree-Item, Detail-Field-Value
- `13` – Body-Default
- `18` – Detail-Title
- `22` – KPI-Value

**Weights:** 300 / 400 / 500 / 600 / 700. UPPERCASE-Labels sind immer 700 + `letter-spacing: 0.08–0.10em`. Negative Letter-Spacing nur bei großen Werten (KPI, Detail-Title): `-0.01em` bis `-0.02em`.

---

## 3. Farben

### Neutralpalette (Light)

```
--bg            #f8fafc   App-Hintergrund / Header-Hover-Surface
--bg-card       #ffffff   Karten, Dropdowns, Toolbar-Buttons
--bg-hover      #f1f5f9   Row-Hover, Pane-Tab-Bg
--bg-pane       #ffffff   Pane-Body
--border        #e2e8f0   1-px-Linien (überall)
--border-strong #cbd5e1   Sekundär-Buttons-Border, Toggle-Off
--text-primary   #0f172a
--text-secondary #475569
--text-muted     #94a3b8
```

### Dark-Modus (`[data-dark="true"]`)

```
--bg            #0d1117
--bg-card       #161b22
--bg-hover      #1e2530
--bg-pane       #161b22
--border        #21262d
--border-strong #30363d
--text-primary   #e6edf3
--text-secondary #8b949e
--text-muted     #484f58
```

Dunkler Modus ist GitHub-artig — niemals reines Schwarz.

### Akzent (themable über Color-Picker)

12 Themes verfügbar; jedes Theme stellt drei Werte:
`--accent` (Haupt), `--accent-dark` (Hover), `--accent-muted` (12 % alpha-Fill).

| Name    | accent  | dark    |
| ------- | ------- | ------- |
| Grün†   | #22c55e | #16a34a |
| Blau    | #3b82f6 | #1d4ed8 |
| Violett | #8b5cf6 | #6d28d9 |
| Orange  | #f97316 | #c2410c |
| Cyan    | #06b6d4 | #0e7490 |
| Rose    | #f43f5e | #be123c |
| Indigo  | #6366f1 | #4338ca |
| Amber   | #f59e0b | #d97706 |
| Teal    | #14b8a6 | #0f766e |
| Slate   | #64748b | #475569 |
| Lime    | #84cc16 | #4d7c0f |
| Pink    | #ec4899 | #9d174d |

† Default. **Niemals Akzentfarben hardcoden** — immer `var(--accent)` etc., sonst zerstört das Theme-Switching.

### Status-/Badge-Farben (fix, themen-unabhängig)

```
.badge-green   bg #dcfce7  fg #16a34a    OK / Aktiv / Gebucht
.badge-blue    bg #dbeafe  fg #1d4ed8    Info / In Arbeit
.badge-orange  bg #ffedd5  fg #c2410c    Warnung / Verzögert
.badge-red     bg #fee2e2  fg #b91c1c    Fehler / Storno
.badge-gray    bg var(--bg-hover) fg var(--text-secondary)   Neutral
```

Im Dark-Mode jeweils mit dunkleren BG und helleren FG (siehe CSS).

---

## 4. Spacing, Radien, Shadows

**Radien:** nur zwei Stufen.

- `--radius-sm` = `4px` — Buttons, Inputs, Mini-Chips
- `--radius` = `8px` — Karten, Dropdowns, Popover

Pillen / Kreise nur dort, wo semantisch (Badge: `border-radius: 9px`; Avatar/Status-Dot: `50 %`). Keine Mid-Range-Radien (12, 16 px).

**Shadows:**

- `--shadow-sm` — Header
- `--shadow-md` — Dropdowns, Popover, Drag-Ghost
- `--shadow-lg` — Modals (selten)

**Padding/Gap-Patterns (px):**

- Dichte Toolbar-Zeile: `padding: 6px 10px`, `gap: 8px`
- Tabellenzelle: `padding: 6px 10px`
- Detail-View: `padding: 14px 16px`
- KPI-Karte: `padding: 12px 14px`
- Dropdown-Item: `padding: 7px 12px`
- Tree-Item: `padding: 5px 12px`

**Höhen (fix):**

- `--header-h` = `48px`
- `--pane-tabbar-h` = `32px`
- `--statusbar-h` = `24px`
- URL-Bar = `26px`
- Layout-Preset-Bar = ca. `34px`
- Buttons / Inputs default = `26px`, `btn-xs` = `22px`
- Header-Buttons (`.hdr-btn`) = `30 × 30 px`
- User-Avatar = `20 px`, im KPI-Card-Avatar `20 × 20`

---

## 5. Layout-Skelett (von oben nach unten)

```
┌─ HEADER (48 px, sticky)
│   logo  | TENANT | <Tabs: Workspaces>            | user · theme · DE/EN · 🔔 · ☰
├─ URL-BAR (26 px, monospace, deep-link sichtbar)
├─ LAYOUT-PRESETS (1-Pane / 2-Pane / 3-Pane)
├─ WORKSPACE  (grid, 1px gaps = border-Linien)
│   ├─ Pane #1 ┬ pane-tabbar (32 px) ── pane-body (overflow auto)
│   ├─ Pane #2 ┘
│   └─ Pane #3
└─ STATUSBAR (24 px, monospace, links Verbindungs-/Mandant-/User-Info, rechts Pane-Count)
```

Globale `body` setzt `overflow: hidden; height: 100vh`. Nichts scrollt außer den Pane-Bodies.

---

## 6. Komponenten-Vokabular

### 6.1 Tabs (Header-Workspace-Tabs)

- 12.5 px, weight 500, `border-bottom: 2px transparent` → bei `.active` 2 px `var(--accent)` und weight 600.
- Hover: nur Textfarbe → `var(--text-primary)`.

### 6.2 Pane-Subtab

- 11.5 px, weight 500. Aktiv: weiß-Background (= `bg-pane`), unten 2-px-Akzent-Linie (überlappt 1 px in den Body via `margin-bottom: -1px`).
- Schließen-X erscheint erst beim Hover (`opacity: 0.4` → `1`).

### 6.3 Buttons

| Klasse           | BG          | FG                 | Border            | Hover                             |
| ---------------- | ----------- | ------------------ | ----------------- | --------------------------------- |
| `.btn-primary`   | `--accent`  | `#fff`             | `--accent`        | `--accent-dark`                   |
| `.btn-secondary` | `--bg-card` | `--text-primary`   | `--border-strong` | `--bg-hover`, Border `--accent`   |
| `.btn-ghost`     | transparent | `--text-secondary` | none              | `--bg-hover`, FG `--text-primary` |

Höhen: `26 px` default, `22 px` für `.btn-xs`. Icon-only nutzt `.btn-icon` (= 26 × 26).

### 6.4 Inputs / Select

26 px hoch, 1 px `--border`, `:focus` → Border `--accent` (kein Glow / Outline-Ring). Select hat eigenen SVG-Chevron (kein nativer Pfeil).

### 6.5 Datagrid (Tabellen)

- `<thead th>`: 10.5 px, weight 600, UPPERCASE, `letter-spacing 0.06em`, sticky `top:0`.
- `<tr>` Hover: BG `--bg-hover`. Selected: BG `--accent-muted`.
- Spalten-Klassen: `.mono` (DM Mono, secondary-Text), `.num` (mono + `text-align: right`).
- Sortspalte: `.sorted` → FG `--accent`.
- Drop-Target (Drag & Drop von Artikeln): BG `--accent-muted` + `box-shadow: inset 0 -2px 0 var(--accent)`.
- Footer 10.5 px monospace, mutemuted; zeigt Anzahl Einträge, Selektionsstatus.

### 6.6 Tree

- `.tree-item.group`: UPPERCASE 9.5 px, weight 700, nicht klickbar.
- `.tree-item.active`: linke 2-px-Akzent-Border, BG `--accent-muted`, FG `--accent`, weight 600.
- Optionaler `.tree-count` rechts in Mono.

### 6.7 Detail-View

- `.detail-title`: 18 px, weight 700, FG `--accent`.
- `.detail-subtitle`: 11.5 px Mono, muted.
- `.detail-grid`: `repeat(auto-fit, minmax(180px, 1fr))`, `gap: 14px 20px`.
- `.detail-field-label`: 9.5 px UPPERCASE 0.10em.
- `.section-heading`: 11 px UPPERCASE 0.10em, FG `--accent`, mit Bottom-Border.

### 6.8 KPI-Karten

- Grid `repeat(auto-fit, minmax(180px, 1fr))`, `gap: 12px`, Container-Padding `14px`.
- Karte: `--bg-card` + 1 px Border + 8 px radius, Padding `12px 14px`.
- Reihenfolge: 10 px UPPERCASE Label → 22 px Mono Value → 10.5 px Delta (`up` = `--accent`, `down` = `#ef4444`).

### 6.9 Badges & Mini-Chips

- `.badge`: 18 px hoch, `padding: 0 7px`, `border-radius: 9px`, 10 px / 600.
- `.chip-mini`: 16 px hoch, 9.5 px / 600, monospace, optional `q/c/l/i` Varianten für Registry-Pfade (Q=blue, C=green, L=violet, I=orange).

### 6.10 Toggle (Dark-Switch)

- Track 32 × 18 px, radius 9; Thumb 14 × 14, weiß, transition 0.2 s.

### 6.11 Dropdowns / Popover

- `.dropdown-menu`, `.color-picker-pop`, `.entity-picker`: alle `--bg-card`, 1 px Border, 8 px radius, `--shadow-md`, Mount-Animation `dropIn` (12 ms ease, opacity + translateY 4 px).
- Section-Label im Dropdown: 9.5 px UPPERCASE 0.10em muted.
- `.dropdown-item.divider` zieht Top-Border. `.danger` → FG `#ef4444`.

### 6.12 Statusbar / URL-Bar

- Monospace, 10.5 / 11 px, `--text-muted` als Default-FG.
- Status-Pill: `--accent-muted` + `--accent`, 600 weight, `padding: 2px 7px`, radius 9.
- URL-Bar Tokens haben semantische Farben: `protocol`/`amp`/`key` muted, `route` secondary, `val` accent. Live-Dot `pulse 1.6s infinite`.

---

## 7. Workspace- & Pane-System (Code-Verträge)

### 7.1 Hash-Format

```
#ws=<workspaceId>&pane1=<viewKey,viewKey,…>&pane2=…&pane3=…
```

- 1–3 Panes. Mehrere Views pro Pane werden als Subtabs gerendert.
- Beim Switch eines Workspace: das `WORKSPACES`-Preset überschreibt vollständig.

### 7.2 Registry-Verträge

- **`ENTITY_REGISTRY[<entityKey>]`** muss enthalten: `label_de`, `label_en`, `icon` (Key in `ICONS`), `paths: { Q[], C[], L[], I[] }` mit Pfad-Bezeichnern (`list`, `byId`, `search`, `create`, `update`, `book`, `lookup`, `jtl`, …).
- **`VIEW_REGISTRY`** Entries: `key` (`<entity>:<view>`), `entity`, `view`, `label_de`, `label_en`, `section_de`, `section_en`. Jede neue View MUSS hier registriert werden, sonst kann der Entity-Picker sie nicht öffnen.
- **`WORKSPACES`** Entries: `id`, `label_de/_en`, `layout` (`'1' | '2' | '3' | '3-tlr'`), `panes: ViewKey[][]`.

### 7.3 Pane-Renderer

Jeder View-Key `<entity>:<view>` wird durch den Renderer-Switch in `<Pane>` gemappt. **Renderer fehlt** → leere Pane mit `t('pane.empty.norenderer', { key })`. Einen Renderer hinzuzufügen heißt: View in der Registry deklarieren _und_ Switch-Branch ergänzen.

### 7.4 Drag & Drop

- Quelle: Artikel-Listen-View.
- Ziel: Belegpositionen-View.
- Ghost: `.drag-ghost` (fixed, accent-BG, weiß, monospace nicht nötig).
- Drop-Target-Highlight: siehe 6.5.

---

## 8. i18n-Verträge

- Jeder UI-String geht durch `t(key, vars?)`. Keys sind dot-segmentiert nach Domäne (`addr.field.nr`, `kpi.umsatz`, `pane.empty.noview`).
- **Spalten-Header** kommen aus `col.*`-Keys, unabhängig von der Entity, damit gemeinsame Begriffe (Nr., Datum, Betrag, …) konsistent bleiben.
- Domain-Labels (Entities, Workspaces, View-Sections) NICHT in `I18N` sondern als `*_de` / `*_en` direkt am Registry-Eintrag — Registry ist Quelle der Wahrheit.
- Default-Sprache `de`. Fallback in `makeT`: gewählte Sprache → `de` → Key (sichtbar).
- Sprache wird im LocalStorage und im User-Header-Picker (`DE` / `EN`) persistiert.

---

## 9. Iconographie

- **Quelle:** zentrales `ICONS`-Objekt (Lucide-Style: 24×24 viewBox, `stroke="currentColor"`, `stroke-width=2`, round caps/joins). Render-Größen 11–14 px.
- **Niemals** neue Icons inline in JSX zeichnen — immer in `ICONS` ergänzen und referenzieren.
- Funktionen ohne klares Icon → kein Icon. Lieber Text-Label.

---

## 10. Animation

Sehr zurückhaltend. Erlaubt:

- `dropIn` 0.12 s ease (Dropdown / Popover Mount).
- `pulse` 1.6 s ease-in-out infinite (Live-Dot URL-Bar).
- Hover-Transitions: `0.1 – 0.15 s` auf `background`, `color`, `border-color`, `transform`.
- Toggle-Thumb: 0.2 s `transform`.

Keine grossen Bewegungen, keine Spring-Physics, kein Skeleton-Shimmer.

---

## 11. Hard-Don'ts

- ❌ Hex-Werte direkt im Komponenten-Code (außer für die fixen Status-Badges) — immer CSS-Variable.
- ❌ Inline UI-Strings — immer `t()`.
- ❌ Eigene Schatten-Werte / Radien außer den drei bzw. zwei Token-Stufen.
- ❌ Schriftgrößen außerhalb der Skala in §2.
- ❌ Gradients, Glassmorphism, Glows, neon-Akzente.
- ❌ Emojis (Sprach-Flags ausgenommen).
- ❌ Icons hand-codieren statt `ICONS` zu erweitern.
- ❌ Direkte SQL-Aufrufe aus der UI; jede Datenanforderung geht über die Registry-View / Domain-Funktion (Tenant-RLS).
- ❌ State, der nicht im Hash lebt, aber sichtbar das Workspace-Bild ändert (Reload muss reproduzierbar sein).

---

## 12. Beim Hinzufügen neuer Funktionalität — Checkliste

1. Entity in `ENTITY_REGISTRY` deklariert? (Label DE/EN, Icon, Q/C/L/I-Pfade)
2. View in `VIEW_REGISTRY` deklariert? (Key, Section DE/EN)
3. Falls neuer Workspace: `WORKSPACES`-Eintrag inkl. Default-Layout & Pane-Composition?
4. Renderer-Branch in `<Pane>` für den View-Key?
5. Alle neuen Strings in `I18N.de` UND `I18N.en`?
6. Spalten-Header über `col.*`-Keys?
7. Farben/Größen aus den Tokens — kein neuer Hex, keine neue px-Konstante?
8. Hash-Format updated, falls neue persistente Achse hinzukommt?
9. Dark-Mode geprüft (alle Farben fließen über `var(--…)`)?
10. Keyboard / Pane-Close / Subtab-Add für die neue View funktional?

---

_Diese Datei ist die Quelle der Wahrheit. Bei Konflikt zwischen ihr und Code: Code anpassen, nicht das Dokument._
