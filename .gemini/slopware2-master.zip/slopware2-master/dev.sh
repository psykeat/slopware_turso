#!/bin/bash

export FORCE_COLOR=1
export CLICOLOR_FORCE=1

echo "Initiating dev setup with local PostgreSQL instance..."

if command -v podman-compose > /dev/null 2>&1; then
    COMPOSE_CMD="podman-compose"
elif command -v docker-compose > /dev/null 2>&1; then
    COMPOSE_CMD="docker-compose"
else
    echo "Error: Neither podman-compose nor docker-compose found!"
    exit 1
fi

CLEANUP_RAN=0
cleanup() {
    if [ "$CLEANUP_RAN" -eq 1 ]; then
        return
    fi

    CLEANUP_RAN=1

    echo "Shutting down..."
    # Kill all child processes
    pkill -P $$
    $COMPOSE_CMD down
}
trap cleanup INT TERM EXIT

echo "Using: $COMPOSE_CMD"

echo "Starting PostgreSQL..."
$COMPOSE_CMD up -d

echo "Updating database schema..."
pnpm db generate
pnpm db migrate

if [ -n "$1" ]; then
    DEV_CMD="--filter=@repo/$1 dev"
    echo "Starting $1 development server..."
else
    DEV_CMD="--recursive --parallel dev"
    echo "Starting all development servers..."
fi

pnpm run $DEV_CMD &

echo "Starting MV refresh listener..."
pnpm --filter=@repo/integration dev &

echo "Starting LiteLLM proxy service..."
if [ -f "services/llm/main.py" ]; then
    # Try to install dependencies if possible, or just try to run
    # (In a real environment, we'd use a venv)
    python3 services/llm/main.py &
fi

# Wait for background processes
wait
