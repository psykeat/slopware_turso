import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

vi.mock("@repo/domain", () => ({
  createSqlClient: vi.fn(() => ({
    unsafe: vi.fn().mockResolvedValue([]),
    end: vi.fn().mockResolvedValue(undefined),
    begin: vi.fn().mockImplementation(async (cb) => cb({} as any)),
  })),
  validateTenantId: vi.fn(),
}));

import * as domain from "@repo/domain";

import {
  handleAuth,
  handleSession,
  handleLogout,
  handleTokenRefresh,
  handleRoleCheck,
  handleValidateTenant,
  authRouter,
} from "../auth-handlers";

const mockValidateTenantId = vi.mocked(domain.validateTenantId);

describe("Auth Handlers", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe("handleAuth", () => {
    it("returns 405 for non-GET methods", async () => {
      const req = new Request("http://localhost/auth", { method: "POST" });
      const res = await handleAuth(req);
      expect(res.status).toBe(405);
    });

    it("returns 401 for no credentials", async () => {
      const req = new Request("http://localhost/auth");
      const res = await handleAuth(req);
      expect(res.status).toBe(401);
    });

    it("returns 200 with cookie auth", async () => {
      const req = new Request("http://localhost/auth", {
        headers: { cookie: "session=abc123" },
      });
      const res = await handleAuth(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.method).toBe("cookie");
    });

    it("returns 200 with bearer auth", async () => {
      const req = new Request("http://localhost/auth", {
        headers: { authorization: "Bearer token123" },
      });
      const res = await handleAuth(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.method).toBe("bearer");
    });
  });

  describe("handleSession", () => {
    it("returns 405 for non-GET methods", async () => {
      const req = new Request("http://localhost/auth/session", { method: "POST" });
      const res = await handleSession(req);
      expect(res.status).toBe(405);
    });

    it("returns null session without cookie", async () => {
      const req = new Request("http://localhost/auth/session");
      const res = await handleSession(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.session).toBeNull();
    });

    it("returns active session with cookie", async () => {
      const req = new Request("http://localhost/auth/session", {
        headers: { cookie: "session=abc123" },
      });
      const res = await handleSession(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.session?.active).toBe(true);
    });
  });

  describe("handleLogout", () => {
    it("returns 405 for non-POST methods", async () => {
      const req = new Request("http://localhost/auth/logout", { method: "GET" });
      const res = await handleLogout(req);
      expect(res.status).toBe(405);
    });

    it("returns 200 on logout", async () => {
      const req = new Request("http://localhost/auth/logout", { method: "POST" });
      const res = await handleLogout(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.loggedOut).toBe(true);
    });
  });

  describe("handleTokenRefresh", () => {
    it("returns 405 for non-POST methods", async () => {
      const req = new Request("http://localhost/auth/refresh", { method: "GET" });
      const res = await handleTokenRefresh(req);
      expect(res.status).toBe(405);
    });

    it("returns 401 for missing auth header", async () => {
      const req = new Request("http://localhost/auth/refresh", { method: "POST" });
      const res = await handleTokenRefresh(req);
      expect(res.status).toBe(401);
    });

    it("returns 401 for non-bearer header", async () => {
      const req = new Request("http://localhost/auth/refresh", {
        method: "POST",
        headers: { authorization: "Basic abc123" },
      });
      const res = await handleTokenRefresh(req);
      expect(res.status).toBe(401);
    });

    it("returns 401 for empty token", async () => {
      const req = new Request("http://localhost/auth/refresh", {
        method: "POST",
        headers: { authorization: "Bearer " },
      });
      const res = await handleTokenRefresh(req);
      expect(res.status).toBe(401);
    });

    it("returns 200 with refreshed token", async () => {
      const req = new Request("http://localhost/auth/refresh", {
        method: "POST",
        headers: { authorization: "Bearer refresh-token-123" },
      });
      const res = await handleTokenRefresh(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.refreshed).toBe(true);
      expect(body.token).toBe("refresh-token-123");
    });
  });

  describe("handleRoleCheck", () => {
    it("returns 405 for non-POST methods", async () => {
      const req = new Request("http://localhost/auth/role", { method: "GET" });
      const res = await handleRoleCheck(req);
      expect(res.status).toBe(405);
    });

    it("returns 400 for missing role", async () => {
      const req = new Request("http://localhost/auth/role", {
        method: "POST",
        body: JSON.stringify({}),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleRoleCheck(req);
      expect(res.status).toBe(400);
    });

    it("returns admin permissions for admin role", async () => {
      const req = new Request("http://localhost/auth/role", {
        method: "POST",
        body: JSON.stringify({ role: "admin", resource: "users", action: "delete" }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleRoleCheck(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.hasPermission).toBe(true);
      expect(body.permissions).toContain("delete");
    });

    it("denies viewer write access", async () => {
      const req = new Request("http://localhost/auth/role", {
        method: "POST",
        body: JSON.stringify({ role: "viewer", resource: "users", action: "write" }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleRoleCheck(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.hasPermission).toBe(false);
    });

    it("returns empty permissions for unknown role", async () => {
      const req = new Request("http://localhost/auth/role", {
        method: "POST",
        body: JSON.stringify({ role: "unknown" }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleRoleCheck(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.permissions).toHaveLength(0);
      expect(body.hasPermission).toBe(false);
    });
  });

  describe("handleValidateTenant", () => {
    it("returns 405 for non-POST methods", async () => {
      const req = new Request("http://localhost/auth/tenant", { method: "GET" });
      const res = await handleValidateTenant(req);
      expect(res.status).toBe(405);
    });

    it("returns 400 for missing tenantId", async () => {
      const req = new Request("http://localhost/auth/tenant", {
        method: "POST",
        body: JSON.stringify({}),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleValidateTenant(req);
      expect(res.status).toBe(400);
    });

    it("returns valid=true for valid UUID", async () => {
      mockValidateTenantId.mockReturnValue(true);
      const req = new Request("http://localhost/auth/tenant", {
        method: "POST",
        body: JSON.stringify({ tenantId: "00000000-0000-0000-0000-000000000002" }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleValidateTenant(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.valid).toBe(true);
    });

    it("returns valid=false for invalid UUID", async () => {
      mockValidateTenantId.mockReturnValue(false);
      const req = new Request("http://localhost/auth/tenant", {
        method: "POST",
        body: JSON.stringify({ tenantId: "not-a-uuid" }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleValidateTenant(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.valid).toBe(false);
    });
  });

  describe("authRouter", () => {
    it("routes /session to handleSession", async () => {
      const req = new Request("http://localhost/auth/session");
      const res = await authRouter(req);
      expect(res.status).toBe(200);
    });

    it("routes /logout to handleLogout", async () => {
      const req = new Request("http://localhost/auth/logout", { method: "POST" });
      const res = await authRouter(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.loggedOut).toBe(true);
    });

    it("routes /refresh to handleTokenRefresh", async () => {
      const req = new Request("http://localhost/auth/refresh", {
        method: "POST",
        headers: { authorization: "Bearer token" },
      });
      const res = await authRouter(req);
      expect(res.status).toBe(200);
    });

    it("routes /role to handleRoleCheck", async () => {
      const req = new Request("http://localhost/auth/role", {
        method: "POST",
        body: JSON.stringify({ role: "admin" }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await authRouter(req);
      expect(res.status).toBe(200);
    });

    it("routes /tenant to handleValidateTenant", async () => {
      mockValidateTenantId.mockReturnValue(true);
      const req = new Request("http://localhost/auth/tenant", {
        method: "POST",
        body: JSON.stringify({ tenantId: "00000000-0000-0000-0000-000000000002" }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await authRouter(req);
      expect(res.status).toBe(200);
    });

    it("routes default to handleAuth", async () => {
      const req = new Request("http://localhost/auth", {
        headers: { cookie: "session=abc" },
      });
      const res = await authRouter(req);
      expect(res.status).toBe(200);
    });
  });
});
