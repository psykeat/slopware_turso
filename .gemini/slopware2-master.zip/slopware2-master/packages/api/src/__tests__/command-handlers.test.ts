import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

vi.mock("@repo/domain", () => ({
  createEntity: vi.fn(),
  patchEntity: vi.fn(),
  deleteEntity: vi.fn(),
  deactivateEntity: vi.fn(),
  createSqlClient: vi.fn(() => ({
    unsafe: vi.fn().mockResolvedValue([]),
    end: vi.fn().mockResolvedValue(undefined),
    begin: vi.fn().mockImplementation(async (cb) => cb({} as any)),
  })),
}));

import * as domain from "@repo/domain";

import {
  handleExecuteCommand,
  handleCreateCommand,
  handleActivateEntity,
  handleBulkCommand,
  commandRouter,
} from "../command-handlers";

const mockCreateEntity = vi.mocked(domain.createEntity);
const mockPatchEntity = vi.mocked(domain.patchEntity);
const mockDeleteEntity = vi.mocked(domain.deleteEntity);
const mockDeactivateEntity = vi.mocked(domain.deactivateEntity);

describe("Command Handlers", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe("handleExecuteCommand", () => {
    it("returns 405 for non-POST methods", async () => {
      const req = new Request("http://localhost/commands?entity=article&command=create", {
        method: "GET",
      });
      const res = await handleExecuteCommand(req);
      expect(res.status).toBe(405);
    });

    it("returns 400 for missing params", async () => {
      const req = new Request("http://localhost/commands", {
        method: "POST",
        body: JSON.stringify({}),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleExecuteCommand(req);
      expect(res.status).toBe(400);
      const body = await res.json();
      expect(body.error).toContain("Missing");
    });

    it("executes create command successfully", async () => {
      mockCreateEntity.mockResolvedValue({ success: true, id: "new-id" });
      const req = new Request("http://localhost/commands?entity=article&command=create", {
        method: "POST",
        body: JSON.stringify({ name: "New" }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleExecuteCommand(req);
      expect(res.status).toBe(201);
      const body = await res.json();
      expect(body.command).toBe("create");
      expect(body.result.success).toBe(true);
    });

    it("executes update command successfully", async () => {
      mockPatchEntity.mockResolvedValue({ success: true });
      const req = new Request("http://localhost/commands?entity=article&id=1&command=update", {
        method: "POST",
        body: JSON.stringify({ name: "Updated" }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleExecuteCommand(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.command).toBe("update");
    });

    it("executes delete command successfully", async () => {
      mockDeleteEntity.mockResolvedValue({ success: true, action: "hard_delete" });
      const req = new Request("http://localhost/commands?entity=article&id=1&command=delete", {
        method: "POST",
        body: JSON.stringify({}),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleExecuteCommand(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.command).toBe("delete");
    });

    it("executes deactivate command successfully", async () => {
      mockDeactivateEntity.mockResolvedValue({ success: true });
      const req = new Request("http://localhost/commands?entity=article&id=1&command=deactivate", {
        method: "POST",
        body: JSON.stringify({}),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleExecuteCommand(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.command).toBe("deactivate");
    });

    it("returns 400 for unknown command", async () => {
      const req = new Request("http://localhost/commands?entity=article&command=unknown", {
        method: "POST",
        body: JSON.stringify({}),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleExecuteCommand(req);
      expect(res.status).toBe(400);
      const body = await res.json();
      expect(body.error).toContain("Unknown command");
    });

    it("returns 400 for update without id", async () => {
      const req = new Request("http://localhost/commands?entity=article&command=update", {
        method: "POST",
        body: JSON.stringify({ name: "Updated" }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleExecuteCommand(req);
      expect(res.status).toBe(400);
    });
  });

  describe("handleCreateCommand", () => {
    it("delegates to handleExecuteCommand", async () => {
      mockCreateEntity.mockResolvedValue({ success: true, id: "new" });
      const req = new Request("http://localhost/commands?entity=article&command=create", {
        method: "POST",
        body: JSON.stringify({ name: "New" }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleCreateCommand(req);
      expect(res.status).toBe(201);
    });
  });

  describe("handleActivateEntity", () => {
    it("returns 405 for non-POST methods", async () => {
      const req = new Request("http://localhost/commands?entity=article&id=1", { method: "GET" });
      const res = await handleActivateEntity(req);
      expect(res.status).toBe(405);
    });

    it("activates entity via patch", async () => {
      mockPatchEntity.mockResolvedValue({ success: true });
      const req = new Request("http://localhost/commands?entity=article&id=1", { method: "POST" });
      const res = await handleActivateEntity(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.command).toBe("activate");
    });
  });

  describe("handleBulkCommand", () => {
    it("returns 405 for non-POST methods", async () => {
      const req = new Request("http://localhost/commands?entity=article&command=delete", {
        method: "GET",
      });
      const res = await handleBulkCommand(req);
      expect(res.status).toBe(405);
    });

    it("returns 400 for empty ids array", async () => {
      const req = new Request("http://localhost/commands/bulk?entity=article&command=delete", {
        method: "POST",
        body: JSON.stringify({ ids: [] }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleBulkCommand(req);
      expect(res.status).toBe(400);
    });

    it("executes bulk delete", async () => {
      mockDeleteEntity.mockResolvedValue({ success: true, action: "hard_delete" });
      const req = new Request("http://localhost/commands/bulk?entity=article&command=delete", {
        method: "POST",
        body: JSON.stringify({ ids: ["1", "2"] }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleBulkCommand(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.results).toHaveLength(2);
    });

    it("returns 400 for unsupported bulk command", async () => {
      const req = new Request("http://localhost/commands/bulk?entity=article&command=create", {
        method: "POST",
        body: JSON.stringify({ ids: ["1"] }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleBulkCommand(req);
      expect(res.status).toBe(400);
    });
  });

  describe("commandRouter", () => {
    it("routes /activate to handleActivateEntity", async () => {
      mockPatchEntity.mockResolvedValue({ success: true });
      const req = new Request("http://localhost/commands/activate?entity=article&id=1", {
        method: "POST",
      });
      const res = await commandRouter(req);
      expect(res.status).toBe(200);
    });

    it("routes /bulk to handleBulkCommand", async () => {
      mockDeleteEntity.mockResolvedValue({ success: true, action: "hard_delete" });
      const req = new Request("http://localhost/commands/bulk?entity=article&command=delete", {
        method: "POST",
        body: JSON.stringify({ ids: ["1"] }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await commandRouter(req);
      expect(res.status).toBe(200);
    });

    it("routes default to handleExecuteCommand", async () => {
      mockCreateEntity.mockResolvedValue({ success: true, id: "new" });
      const req = new Request("http://localhost/commands?entity=article&command=create", {
        method: "POST",
        body: JSON.stringify({ name: "New" }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await commandRouter(req);
      expect(res.status).toBe(201);
    });
  });
});
