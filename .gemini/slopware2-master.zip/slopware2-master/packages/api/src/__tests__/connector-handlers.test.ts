import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

vi.mock("@repo/domain", () => ({
  createSqlClient: vi.fn(),
}));

import * as domain from "@repo/domain";

import {
  handlePatchConnectorMappings,
  handleListConnectorMappings,
  handleGetConnectorDefinition,
  handleGetSchemaAnnotations,
} from "../connector-handlers";

const mockSql = {
  unsafe: vi.fn(),
  end: vi.fn().mockResolvedValue(undefined),
};

beforeEach(() => {
  vi.clearAllMocks();
  (domain.createSqlClient as any).mockReturnValue(mockSql);
});

afterEach(() => {
  vi.restoreAllMocks();
});

describe("handlePatchConnectorMappings", () => {
  it("returns 405 for non-PATCH methods", async () => {
    const req = new Request("http://localhost/connectors/tc1/mappings", { method: "GET" });
    const res = await handlePatchConnectorMappings(req);
    expect(res.status).toBe(405);
  });

  it("returns 400 for missing tenantConnectorId", async () => {
    const req = new Request("http://localhost/connectors/mappings", {
      method: "PATCH",
      body: JSON.stringify({ mappings: [] }),
      headers: { "Content-Type": "application/json" },
    });
    const res = await handlePatchConnectorMappings(req);
    expect(res.status).toBe(400);
  });

  it("returns 400 for non-array mappings", async () => {
    const req = new Request("http://localhost/connectors/tc1/mappings", {
      method: "PATCH",
      body: JSON.stringify({ mappings: "not-array" }),
      headers: { "Content-Type": "application/json" },
    });
    const res = await handlePatchConnectorMappings(req);
    expect(res.status).toBe(400);
  });

  it("returns 404 when tenant connector not found", async () => {
    mockSql.unsafe.mockResolvedValue([]);
    const req = new Request("http://localhost/connectors/tc1/mappings", {
      method: "PATCH",
      body: JSON.stringify({
        mappings: [{ source_field: "f1", target_table: "t", target_column: "c" }],
      }),
      headers: { "Content-Type": "application/json" },
    });
    const res = await handlePatchConnectorMappings(req);
    expect(res.status).toBe(404);
  });

  it("returns 409 with reason source_locked when field is locked", async () => {
    mockSql.unsafe.mockResolvedValueOnce([
      { locked_fields: ["name", "id"], slug: "test-connector" },
    ]);
    const req = new Request("http://localhost/connectors/tc1/mappings", {
      method: "PATCH",
      body: JSON.stringify({
        mappings: [
          {
            source_field: "name",
            target_table: "address",
            target_column: "address_name",
            tenant_id: "t1",
          },
        ],
      }),
      headers: { "Content-Type": "application/json" },
    });
    const res = await handlePatchConnectorMappings(req);
    expect(res.status).toBe(409);
    const body = await res.json();
    expect(body.reason).toBe("source_locked");
  });

  it("returns 409 with reason target_locked when column is locked for connector", async () => {
    mockSql.unsafe
      .mockResolvedValueOnce([{ locked_fields: [], slug: "test-connector" }])
      .mockResolvedValueOnce([{ locked_for: ["test-connector", "other"] }]);
    const req = new Request("http://localhost/connectors/tc1/mappings", {
      method: "PATCH",
      body: JSON.stringify({
        mappings: [
          {
            source_field: "ext_code",
            target_table: "address",
            target_column: "address_code",
            tenant_id: "t1",
          },
        ],
      }),
      headers: { "Content-Type": "application/json" },
    });
    const res = await handlePatchConnectorMappings(req);
    expect(res.status).toBe(409);
    const body = await res.json();
    expect(body.reason).toBe("target_locked");
  });

  it("returns 200 when all guards pass and upserts mappings", async () => {
    mockSql.unsafe
      .mockResolvedValueOnce([{ locked_fields: [], slug: "test-connector" }])
      .mockResolvedValueOnce([{ locked_for: ["other-connector"] }])
      .mockResolvedValueOnce(undefined);
    const req = new Request("http://localhost/connectors/tc1/mappings", {
      method: "PATCH",
      body: JSON.stringify({
        mappings: [
          {
            source_field: "ext_code",
            target_table: "address",
            target_column: "address_code",
            tenant_id: "t1",
            transform: { type: "direct" },
          },
        ],
      }),
      headers: { "Content-Type": "application/json" },
    });
    const res = await handlePatchConnectorMappings(req);
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.success).toBe(true);
    expect(body.count).toBe(1);
  });
});

describe("handleListConnectorMappings", () => {
  it("returns 405 for non-GET methods", async () => {
    const req = new Request("http://localhost/connectors/tc1/mappings", { method: "POST" });
    const res = await handleListConnectorMappings(req);
    expect(res.status).toBe(405);
  });

  it("returns mappings ordered by source_field", async () => {
    mockSql.unsafe.mockResolvedValue([
      { mapping_id: "m1", source_field: "b", target_table: "t", target_column: "c" },
      { mapping_id: "m2", source_field: "a", target_table: "t", target_column: "c" },
    ]);
    const req = new Request("http://localhost/connectors/tc1/mappings");
    const res = await handleListConnectorMappings(req);
    expect(res.status).toBe(200);
  });
});

describe("handleGetConnectorDefinition", () => {
  it("returns 405 for non-GET methods", async () => {
    const req = new Request("http://localhost/connectors/tc1/definition", { method: "POST" });
    const res = await handleGetConnectorDefinition(req);
    expect(res.status).toBe(405);
  });

  it("returns 404 when connector not found", async () => {
    mockSql.unsafe.mockResolvedValue([]);
    const req = new Request("http://localhost/connectors/tc1/definition");
    const res = await handleGetConnectorDefinition(req);
    expect(res.status).toBe(404);
  });

  it("returns connector definition with locked_fields and default_mappings", async () => {
    mockSql.unsafe.mockResolvedValue([
      {
        connector_id: "c1",
        slug: "test",
        locked_fields: ["name"],
        default_mappings: { name: "address_name" },
      },
    ]);
    const req = new Request("http://localhost/connectors/tc1/definition");
    const res = await handleGetConnectorDefinition(req);
    expect(res.status).toBe(200);
  });
});

describe("handleGetSchemaAnnotations", () => {
  it("returns 405 for non-GET methods", async () => {
    const req = new Request("http://localhost/schema-annotations", { method: "POST" });
    const res = await handleGetSchemaAnnotations(req);
    expect(res.status).toBe(405);
  });

  it("returns schema annotations with mandatory_for and locked_for", async () => {
    mockSql.unsafe.mockResolvedValue([
      {
        table_name: "address",
        column_name: "address_name",
        business_name: "Name",
        mandatory_for: ["address"],
        locked_for: ["system"],
      },
    ]);
    const req = new Request("http://localhost/schema-annotations");
    const res = await handleGetSchemaAnnotations(req);
    expect(res.status).toBe(200);
  });
});
