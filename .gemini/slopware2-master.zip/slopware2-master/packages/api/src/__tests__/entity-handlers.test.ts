import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

vi.mock("@repo/domain", () => ({
  listEntity: vi.fn(),
  getEntityById: vi.fn(),
  createEntity: vi.fn(),
  patchEntity: vi.fn(),
  deleteEntity: vi.fn(),
  deactivateEntity: vi.fn(),
  validateAgainstEffectiveFields: vi.fn(),
  createSqlClient: vi.fn(() => ({
    unsafe: vi.fn().mockResolvedValue([]),
    end: vi.fn().mockResolvedValue(undefined),
    begin: vi.fn().mockImplementation(async (cb) => cb({} as any)),
  })),
  getEntityDescriptor: vi.fn(),
  ENTITY_REGISTRY: new Map([
    [
      "article",
      {
        entityName: "article",
        tableName: "article",
        kind: "master",
        tenantScoped: true,
        genericRead: true,
        genericPatch: true,
        genericDelete: false,
        idColumn: "article_id",
        defaultSort: "article_id",
        allowedFilters: ["tenant_id"],
        sortableFields: ["article_id"],
        label: { en: "Article" },
      },
    ],
  ]),
}));

import * as domain from "@repo/domain";

import {
  handleListEntities,
  handleGetEntity,
  handleCreateEntity,
  handlePatchEntity,
  handleDeleteEntity,
  handleDeactivateEntity,
  entityRouter,
} from "../entity-handlers";

const mockListEntity = vi.mocked(domain.listEntity);
const mockGetEntityById = vi.mocked(domain.getEntityById);
const mockCreateEntity = vi.mocked(domain.createEntity);
const mockPatchEntity = vi.mocked(domain.patchEntity);
const mockDeleteEntity = vi.mocked(domain.deleteEntity);
const mockDeactivateEntity = vi.mocked(domain.deactivateEntity);

describe("Entity Handlers", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe("handleListEntities", () => {
    it("returns 405 for non-GET methods", async () => {
      const req = new Request("http://localhost/entities?entity=article", { method: "POST" });
      const res = await handleListEntities(req);
      expect(res.status).toBe(405);
    });

    it("returns 400 for missing entity parameter", async () => {
      const req = new Request("http://localhost/entities");
      const res = await handleListEntities(req);
      expect(res.status).toBe(400);
      const body = await res.json();
      expect(body.error).toContain("Missing");
    });

    it("calls listEntity with correct params", async () => {
      mockListEntity.mockResolvedValue({ items: [{ id: "1" }], total: 1, limit: 10, offset: 0 });
      const req = new Request("http://localhost/entities?entity=article&limit=10&offset=0");
      const res = await handleListEntities(req);
      expect(res.status).toBe(200);
      expect(mockListEntity).toHaveBeenCalledWith(expect.anything(), "article", {
        limit: 10,
        offset: 0,
        sortBy: undefined,
        sortOrder: "ASC",
      });
    });

    it("returns error response on domain error", async () => {
      mockListEntity.mockRejectedValue(new Error("Entity not registered"));
      const req = new Request("http://localhost/entities?entity=nonexistent");
      const res = await handleListEntities(req);
      expect(res.status).toBe(400);
      const body = await res.json();
      expect(body.error).toBe("Entity not registered");
    });
  });

  describe("handleGetEntity", () => {
    it("returns 405 for non-GET methods", async () => {
      const req = new Request("http://localhost/entities?entity=article&id=1", { method: "POST" });
      const res = await handleGetEntity(req);
      expect(res.status).toBe(405);
    });

    it("returns 400 for missing params", async () => {
      const req = new Request("http://localhost/entities?entity=article");
      const res = await handleGetEntity(req);
      expect(res.status).toBe(400);
    });

    it("returns 404 when entity not found", async () => {
      mockGetEntityById.mockResolvedValue(null);
      const req = new Request("http://localhost/entities?entity=article&id=missing");
      const res = await handleGetEntity(req);
      expect(res.status).toBe(404);
    });

    it("returns entity data on success", async () => {
      mockGetEntityById.mockResolvedValue({ article_id: "1", name: "Test" });
      const req = new Request("http://localhost/entities?entity=article&id=1");
      const res = await handleGetEntity(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body).toEqual({ article_id: "1", name: "Test" });
    });
  });

  describe("handleCreateEntity", () => {
    it("returns 405 for non-POST methods", async () => {
      const req = new Request("http://localhost/entities?entity=article", { method: "GET" });
      const res = await handleCreateEntity(req);
      expect(res.status).toBe(405);
    });

    it("returns 201 on success", async () => {
      mockCreateEntity.mockResolvedValue({ success: true, id: "new-id" });
      const req = new Request("http://localhost/entities?entity=article", {
        method: "POST",
        body: JSON.stringify({ name: "New" }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleCreateEntity(req);
      expect(res.status).toBe(201);
      const body = await res.json();
      expect(body.success).toBe(true);
    });

    it("returns 400 on domain error", async () => {
      mockCreateEntity.mockResolvedValue({ success: false, error: "Validation failed" });
      const req = new Request("http://localhost/entities?entity=article", {
        method: "POST",
        body: JSON.stringify({}),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handleCreateEntity(req);
      expect(res.status).toBe(400);
    });
  });

  describe("handlePatchEntity", () => {
    it("returns 405 for non-PATCH methods", async () => {
      const req = new Request("http://localhost/entities?entity=article&id=1", { method: "GET" });
      const res = await handlePatchEntity(req);
      expect(res.status).toBe(405);
    });

    it("returns 200 on success", async () => {
      mockPatchEntity.mockResolvedValue({ success: true });
      const req = new Request("http://localhost/entities?entity=article&id=1", {
        method: "PATCH",
        body: JSON.stringify({ name: "Updated" }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await handlePatchEntity(req);
      expect(res.status).toBe(200);
    });
  });

  describe("handleDeleteEntity", () => {
    it("returns 405 for non-DELETE methods", async () => {
      const req = new Request("http://localhost/entities?entity=article&id=1", { method: "GET" });
      const res = await handleDeleteEntity(req);
      expect(res.status).toBe(405);
    });

    it("returns 200 on success", async () => {
      mockDeleteEntity.mockResolvedValue({ success: true, action: "hard_delete" });
      const req = new Request("http://localhost/entities?entity=article&id=1", {
        method: "DELETE",
      });
      const res = await handleDeleteEntity(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.action).toBe("hard_delete");
    });
  });

  describe("handleDeactivateEntity", () => {
    it("returns 200 on success", async () => {
      mockDeactivateEntity.mockResolvedValue({ success: true });
      const req = new Request("http://localhost/entities?entity=article&id=1", { method: "POST" });
      const res = await handleDeactivateEntity(req);
      expect(res.status).toBe(200);
    });

    it("returns 400 on domain error", async () => {
      mockDeactivateEntity.mockResolvedValue({ success: false, error: "not master data" });
      const req = new Request("http://localhost/entities?entity=article&id=1", { method: "POST" });
      const res = await handleDeactivateEntity(req);
      expect(res.status).toBe(400);
    });
  });

  describe("entityRouter", () => {
    it("routes GET with id to handleGetEntity", async () => {
      mockGetEntityById.mockResolvedValue({ article_id: "1" });
      const req = new Request("http://localhost/entities?entity=article&id=1");
      const res = await entityRouter(req);
      expect(res.status).toBe(200);
    });

    it("routes GET without id to handleListEntities", async () => {
      mockListEntity.mockResolvedValue({ items: [], total: 0, limit: 100, offset: 0 });
      const req = new Request("http://localhost/entities?entity=article");
      const res = await entityRouter(req);
      expect(res.status).toBe(200);
    });

    it("routes POST to handleCreateEntity", async () => {
      mockCreateEntity.mockResolvedValue({ success: true, id: "new" });
      const req = new Request("http://localhost/entities?entity=article", {
        method: "POST",
        body: JSON.stringify({ name: "New" }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await entityRouter(req);
      expect(res.status).toBe(201);
    });

    it("routes PATCH to handlePatchEntity", async () => {
      mockPatchEntity.mockResolvedValue({ success: true });
      const req = new Request("http://localhost/entities?entity=article&id=1", {
        method: "PATCH",
        body: JSON.stringify({ name: "Updated" }),
        headers: { "Content-Type": "application/json" },
      });
      const res = await entityRouter(req);
      expect(res.status).toBe(200);
    });

    it("routes DELETE to handleDeleteEntity", async () => {
      mockDeleteEntity.mockResolvedValue({ success: true, action: "hard_delete" });
      const req = new Request("http://localhost/entities?entity=article&id=1", {
        method: "DELETE",
      });
      const res = await entityRouter(req);
      expect(res.status).toBe(200);
    });

    it("returns 405 for unsupported methods", async () => {
      const req = new Request("http://localhost/entities?entity=article", { method: "OPTIONS" });
      const res = await entityRouter(req);
      expect(res.status).toBe(405);
    });
  });
});
