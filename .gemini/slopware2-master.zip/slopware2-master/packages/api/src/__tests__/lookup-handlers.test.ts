import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

vi.mock("@repo/domain", () => ({
  listHelperTables: vi.fn(),
  getHelperTableItems: vi.fn(),
  createSqlClient: vi.fn(() => ({
    unsafe: vi.fn().mockResolvedValue([]),
    end: vi.fn().mockResolvedValue(undefined),
    begin: vi.fn().mockImplementation(async (cb) => cb({} as any)),
  })),
}));

import * as domain from "@repo/domain";

import { handleListLookups, handleGetLookupItems, lookupRouter } from "../lookup-handlers";

const mockListHelperTables = vi.mocked(domain.listHelperTables);
const mockGetHelperTableItems = vi.mocked(domain.getHelperTableItems);

describe("Lookup Handlers", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe("handleListLookups", () => {
    it("returns 405 for non-GET methods", async () => {
      const req = new Request("http://localhost/lookups", { method: "POST" });
      const res = await handleListLookups(req);
      expect(res.status).toBe(405);
    });

    it("returns list of helper tables", async () => {
      mockListHelperTables.mockResolvedValue([
        {
          tableName: "uom",
          label: { en: "UOM" },
          pkColumn: "uom_id",
          displayColumn: "name",
          displayIsI18n: false,
          codeColumn: "code",
          isTenantScoped: false,
          sortColumn: "name",
          valueColumn: null,
        },
      ]);
      const req = new Request("http://localhost/lookups");
      const res = await handleListLookups(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body).toHaveLength(1);
      expect(body[0].tableName).toBe("uom");
    });

    it("returns 500 on domain error", async () => {
      mockListHelperTables.mockRejectedValue(new Error("DB error"));
      const req = new Request("http://localhost/lookups");
      const res = await handleListLookups(req);
      expect(res.status).toBe(500);
    });
  });

  describe("handleGetLookupItems", () => {
    it("returns 405 for non-GET methods", async () => {
      const req = new Request("http://localhost/lookups?table=uom", { method: "POST" });
      const res = await handleGetLookupItems(req);
      expect(res.status).toBe(405);
    });

    it("returns 400 for missing table parameter", async () => {
      const req = new Request("http://localhost/lookups");
      const res = await handleGetLookupItems(req);
      expect(res.status).toBe(400);
    });

    it("returns lookup items with search params", async () => {
      mockGetHelperTableItems.mockResolvedValue([
        { value: "1", label: "PCS" },
        { value: "2", label: "KG" },
      ]);
      const req = new Request("http://localhost/lookups?table=uom&search=pcs&limit=10");
      const res = await handleGetLookupItems(req);
      expect(res.status).toBe(200);
      expect(mockGetHelperTableItems).toHaveBeenCalledWith(expect.anything(), "uom", {
        search: "pcs",
        limit: 10,
        offset: 0,
      });
    });

    it("returns 400 on domain error", async () => {
      mockGetHelperTableItems.mockRejectedValue(new Error("Table not found"));
      const req = new Request("http://localhost/lookups?table=nonexistent");
      const res = await handleGetLookupItems(req);
      expect(res.status).toBe(400);
    });
  });

  describe("lookupRouter", () => {
    it("routes with table param to handleGetLookupItems", async () => {
      mockGetHelperTableItems.mockResolvedValue([{ value: "1", label: "PCS" }]);
      const req = new Request("http://localhost/lookups?table=uom");
      const res = await lookupRouter(req);
      expect(res.status).toBe(200);
    });

    it("routes without table param to handleListLookups", async () => {
      mockListHelperTables.mockResolvedValue([
        {
          tableName: "uom",
          label: { en: "UOM" },
          pkColumn: "uom_id",
          displayColumn: "name",
          displayIsI18n: false,
          codeColumn: null,
          isTenantScoped: false,
          sortColumn: "name",
          valueColumn: null,
        },
      ]);
      const req = new Request("http://localhost/lookups");
      const res = await lookupRouter(req);
      expect(res.status).toBe(200);
    });
  });
});
