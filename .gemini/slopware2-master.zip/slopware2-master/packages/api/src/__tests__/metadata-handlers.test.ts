import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

vi.mock("@repo/domain", () => ({
  getEffectiveFields: vi.fn(),
  getEffectiveLayout: vi.fn(),
  getEffectiveRules: vi.fn(),
  getEffectiveSettings: vi.fn(),
  createSqlClient: vi.fn(() => ({
    unsafe: vi.fn().mockResolvedValue([]),
    end: vi.fn().mockResolvedValue(undefined),
    begin: vi.fn().mockImplementation(async (cb) => cb({} as any)),
  })),
  getEntityDescriptor: vi.fn(),
  ENTITY_REGISTRY: new Map([
    [
      "article",
      {
        entityName: "article",
        tableName: "article",
        kind: "master",
        tenantScoped: true,
        genericRead: true,
        genericPatch: true,
        genericDelete: false,
        idColumn: "article_id",
        defaultSort: "article_id",
        allowedFilters: ["tenant_id"],
        sortableFields: ["article_id"],
        label: { en: "Article" },
      },
    ],
  ]),
}));

import * as domain from "@repo/domain";

import {
  handleListMetadata,
  handleGetEntityDefinition,
  handleGetFields,
  handleGetLayout,
  handleGetRules,
  handleGetSettings,
  metadataRouter,
} from "../metadata-handlers";

const mockGetEffectiveFields = vi.mocked(domain.getEffectiveFields);
const mockGetEffectiveLayout = vi.mocked(domain.getEffectiveLayout);
const mockGetEffectiveRules = vi.mocked(domain.getEffectiveRules);
const mockGetEffectiveSettings = vi.mocked(domain.getEffectiveSettings);
const mockGetEntityDescriptor = vi.mocked(domain.getEntityDescriptor);

describe("Metadata Handlers", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe("handleListMetadata", () => {
    it("returns 405 for non-GET methods", async () => {
      const req = new Request("http://localhost/metadata", { method: "POST" });
      const res = await handleListMetadata(req);
      expect(res.status).toBe(405);
    });

    it("returns list of entity definitions", async () => {
      const req = new Request("http://localhost/metadata");
      const res = await handleListMetadata(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body).toHaveLength(1);
      expect(body[0].entityName).toBe("article");
    });
  });

  describe("handleGetEntityDefinition", () => {
    it("returns 405 for non-GET methods", async () => {
      const req = new Request("http://localhost/metadata?entity=article", { method: "POST" });
      const res = await handleGetEntityDefinition(req);
      expect(res.status).toBe(405);
    });

    it("returns 400 for missing entity param", async () => {
      const req = new Request("http://localhost/metadata");
      const res = await handleGetEntityDefinition(req);
      expect(res.status).toBe(400);
    });

    it("returns 404 for unknown entity", async () => {
      mockGetEntityDescriptor.mockReturnValue(undefined);
      const req = new Request("http://localhost/metadata?entity=nonexistent");
      const res = await handleGetEntityDefinition(req);
      expect(res.status).toBe(404);
    });

    it("returns entity descriptor on success", async () => {
      mockGetEntityDescriptor.mockReturnValue({
        entityName: "article",
        tableName: "article",
        kind: "master",
        tenantScoped: true,
        genericRead: true,
        genericPatch: true,
        genericDelete: false,
        idColumn: "article_id",
        defaultSort: "article_id",
        allowedFilters: [],
        sortableFields: [],
      });
      const req = new Request("http://localhost/metadata?entity=article");
      const res = await handleGetEntityDefinition(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body.entityName).toBe("article");
    });
  });

  describe("handleGetFields", () => {
    it("returns 405 for non-GET methods", async () => {
      const req = new Request("http://localhost/metadata/fields?entity=article", {
        method: "POST",
      });
      const res = await handleGetFields(req);
      expect(res.status).toBe(405);
    });

    it("returns 400 for missing entity param", async () => {
      const req = new Request("http://localhost/metadata/fields");
      const res = await handleGetFields(req);
      expect(res.status).toBe(400);
    });

    it("returns effective fields", async () => {
      mockGetEffectiveFields.mockResolvedValue([
        {
          fieldId: "f1",
          scope: "tenant",
          organizationId: null,
          tenantId: "t1",
          entityName: "article",
          fieldName: "name",
          fieldType: "varchar",
          isRequired: true,
          customAttributes: null,
          label: { en: "Name" },
          helpText: null,
          isVisible: true,
          displayOrder: 1,
          groupId: null,
          lookupTable: null,
          lookupFilter: null,
        },
      ]);
      const req = new Request("http://localhost/metadata/fields?entity=article");
      const res = await handleGetFields(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body[0].fieldName).toBe("name");
    });
  });

  describe("handleGetLayout", () => {
    it("returns 405 for non-GET methods", async () => {
      const req = new Request("http://localhost/metadata/layout?entity=article", {
        method: "POST",
      });
      const res = await handleGetLayout(req);
      expect(res.status).toBe(405);
    });

    it("returns 400 for missing entity param", async () => {
      const req = new Request("http://localhost/metadata/layout");
      const res = await handleGetLayout(req);
      expect(res.status).toBe(400);
    });

    it("returns effective layouts", async () => {
      mockGetEffectiveLayout.mockResolvedValue([
        {
          layoutId: "l1",
          scope: "tenant",
          organizationId: null,
          tenantId: "t1",
          entityName: "article",
          layoutKey: "list",
          layoutDefinition: { columns: ["name"] },
        },
      ]);
      const req = new Request("http://localhost/metadata/layout?entity=article");
      const res = await handleGetLayout(req);
      expect(res.status).toBe(200);
    });
  });

  describe("handleGetRules", () => {
    it("returns effective rules", async () => {
      mockGetEffectiveRules.mockResolvedValue([
        {
          ruleId: "r1",
          scope: "tenant",
          organizationId: null,
          tenantId: "t1",
          entityName: "article",
          hookName: "before_create",
          ruleState: "active",
          ruleDefinition: null,
        },
      ]);
      const req = new Request("http://localhost/metadata/rules?entity=article");
      const res = await handleGetRules(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body[0].hookName).toBe("before_create");
    });
  });

  describe("handleGetSettings", () => {
    it("returns effective settings", async () => {
      mockGetEffectiveSettings.mockResolvedValue([
        {
          settingId: "s1",
          scope: "tenant",
          organizationId: null,
          tenantId: "t1",
          key: "app.name",
          value: "Slopware",
        },
      ]);
      const req = new Request("http://localhost/metadata/settings");
      const res = await handleGetSettings(req);
      expect(res.status).toBe(200);
      const body = await res.json();
      expect(body[0].key).toBe("app.name");
    });
  });

  describe("metadataRouter", () => {
    it("routes /fields to handleGetFields", async () => {
      mockGetEffectiveFields.mockResolvedValue([]);
      const req = new Request("http://localhost/metadata/fields?entity=article");
      const res = await metadataRouter(req);
      expect(res.status).toBe(200);
    });

    it("routes /layout to handleGetLayout", async () => {
      mockGetEffectiveLayout.mockResolvedValue([]);
      const req = new Request("http://localhost/metadata/layout?entity=article");
      const res = await metadataRouter(req);
      expect(res.status).toBe(200);
    });

    it("routes /rules to handleGetRules", async () => {
      mockGetEffectiveRules.mockResolvedValue([]);
      const req = new Request("http://localhost/metadata/rules?entity=article");
      const res = await metadataRouter(req);
      expect(res.status).toBe(200);
    });

    it("routes /settings to handleGetSettings", async () => {
      mockGetEffectiveSettings.mockResolvedValue([]);
      const req = new Request("http://localhost/metadata/settings");
      const res = await metadataRouter(req);
      expect(res.status).toBe(200);
    });

    it("routes with entity param to handleGetEntityDefinition", async () => {
      mockGetEntityDescriptor.mockReturnValue({
        entityName: "article",
        tableName: "article",
        kind: "master",
        tenantScoped: true,
        genericRead: true,
        genericPatch: true,
        genericDelete: false,
        idColumn: "article_id",
        defaultSort: "article_id",
        allowedFilters: [],
        sortableFields: [],
      });
      const req = new Request("http://localhost/metadata?entity=article");
      const res = await metadataRouter(req);
      expect(res.status).toBe(200);
    });

    it("routes default to handleListMetadata", async () => {
      const req = new Request("http://localhost/metadata");
      const res = await metadataRouter(req);
      expect(res.status).toBe(200);
    });
  });
});
