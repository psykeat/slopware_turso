import { validateTenantId } from "@repo/domain";

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function jsonError(message: string, status: number) {
  return jsonResponse({ error: message }, status);
}

export async function handleAuth(req: Request) {
  if (req.method !== "GET") {
    return jsonError("Method not allowed", 405);
  }

  const cookieHeader = req.headers.get("cookie") ?? "";
  const authHeader = req.headers.get("authorization") ?? "";

  const hasCookie = cookieHeader.length > 0;
  const hasBearer = authHeader.startsWith("Bearer ");

  if (!hasCookie && !hasBearer) {
    return jsonError("No authentication credentials provided", 401);
  }

  return jsonResponse({
    authenticated: true,
    method: hasCookie ? "cookie" : "bearer",
  });
}

export async function handleSession(req: Request) {
  if (req.method !== "GET") {
    return jsonError("Method not allowed", 405);
  }

  const cookieHeader = req.headers.get("cookie") ?? "";

  if (!cookieHeader) {
    return jsonResponse({ session: null, user: null });
  }

  return jsonResponse({
    session: { active: true },
    user: { authenticated: true },
  });
}

export async function handleLogout(req: Request) {
  if (req.method !== "POST") {
    return jsonError("Method not allowed", 405);
  }

  return jsonResponse({ loggedOut: true }, 200);
}

export async function handleTokenRefresh(req: Request) {
  if (req.method !== "POST") {
    return jsonError("Method not allowed", 405);
  }

  const authHeader = req.headers.get("authorization") ?? "";

  if (!authHeader.startsWith("Bearer ")) {
    return jsonError("Missing refresh token", 401);
  }

  const token = authHeader.substring(7);

  if (token.length === 0) {
    return jsonError("Empty refresh token", 401);
  }

  return jsonResponse({
    refreshed: true,
    token: token,
  });
}

export async function handleRoleCheck(req: Request) {
  if (req.method !== "POST") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { role, resource, action } = await req.json();

    if (!role) {
      return jsonError("Missing 'role' in request body", 400);
    }

    const allowedRoles: Record<string, string[]> = {
      admin: ["read", "write", "delete", "manage"],
      editor: ["read", "write"],
      viewer: ["read"],
    };

    const userPermissions = allowedRoles[role] ?? [];
    const hasPermission = resource
      ? userPermissions.includes(action ?? "read")
      : userPermissions.length > 0;

    return jsonResponse({
      role,
      permissions: userPermissions,
      hasPermission,
      resource,
      action,
    });
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Role check failed";
    return jsonError(message, 400);
  }
}

export async function handleValidateTenant(req: Request) {
  if (req.method !== "POST") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { tenantId } = await req.json();

    if (!tenantId) {
      return jsonError("Missing 'tenantId' in request body", 400);
    }

    const valid = validateTenantId(tenantId);

    return jsonResponse({
      tenantId,
      valid,
    });
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Tenant validation failed";
    return jsonError(message, 400);
  }
}

export function authRouter(req: Request): Promise<Response> {
  const url = new URL(req.url);
  const path = url.pathname;

  if (path.endsWith("/session")) {
    return handleSession(req);
  }
  if (path.endsWith("/logout")) {
    return handleLogout(req);
  }
  if (path.endsWith("/refresh")) {
    return handleTokenRefresh(req);
  }
  if (path.endsWith("/role")) {
    return handleRoleCheck(req);
  }
  if (path.endsWith("/tenant")) {
    return handleValidateTenant(req);
  }
  return handleAuth(req);
}
