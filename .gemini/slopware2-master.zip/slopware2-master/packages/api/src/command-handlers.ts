import { createEntity, patchEntity, deleteEntity, deactivateEntity } from "@repo/domain";
import { createSqlClient } from "@repo/domain";

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function jsonError(message: string, status: number) {
  return jsonResponse({ error: message }, status);
}

function parseUrl(url: string) {
  const parsed = new URL(url);
  return {
    entityName: parsed.searchParams.get("entity") ?? "",
    id: parsed.searchParams.get("id") ?? "",
    command: parsed.searchParams.get("command") ?? "",
  };
}

export async function handleExecuteCommand(req: Request) {
  if (req.method !== "POST") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { entityName, id, command } = parseUrl(req.url);

    if (!entityName || !command) {
      return jsonError("Missing 'entity' or 'command' query parameter", 400);
    }

    const payload = await req.json().catch(() => ({}));
    const sql = createSqlClient();

    switch (command) {
      case "create": {
        const result = await createEntity(sql, entityName, payload);
        await sql.end();
        if (!result.success) {
          return jsonError(result.error ?? "Command failed", 400);
        }
        return jsonResponse({ command, result }, 201);
      }

      case "update": {
        if (!id) {
          return jsonError("Missing 'id' for update command", 400);
        }
        const patchResult = await patchEntity(sql, entityName, id, payload);
        await sql.end();
        if (!patchResult.success) {
          return jsonError(patchResult.error ?? "Command failed", 400);
        }
        return jsonResponse({ command, result: patchResult });
      }

      case "delete": {
        if (!id) {
          return jsonError("Missing 'id' for delete command", 400);
        }
        const deleteResult = await deleteEntity(sql, entityName, id);
        await sql.end();
        if (!deleteResult.success) {
          return jsonError(deleteResult.error ?? "Command failed", 400);
        }
        return jsonResponse({ command, result: deleteResult });
      }

      case "deactivate": {
        if (!id) {
          return jsonError("Missing 'id' for deactivate command", 400);
        }
        const deactivateResult = await deactivateEntity(sql, entityName, id);
        await sql.end();
        if (!deactivateResult.success) {
          return jsonError(deactivateResult.error ?? "Command failed", 400);
        }
        return jsonResponse({ command, result: deactivateResult });
      }

      default:
        await sql.end();
        return jsonError(`Unknown command '${command}'`, 400);
    }
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Command execution failed";
    return jsonError(message, 400);
  }
}

export async function handleCreateCommand(req: Request) {
  return handleExecuteCommand(req);
}

export async function handleActivateEntity(req: Request) {
  if (req.method !== "POST") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { entityName, id } = parseUrl(req.url);

    if (!entityName || !id) {
      return jsonError("Missing 'entity' or 'id' query parameter", 400);
    }

    const sql = createSqlClient();
    const result = await patchEntity(sql, entityName, id, { is_active: true });
    await sql.end();

    if (!result.success) {
      return jsonError(result.error ?? "Failed to activate entity", 400);
    }

    return jsonResponse({ command: "activate", result });
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to activate entity";
    return jsonError(message, 400);
  }
}

export async function handleBulkCommand(req: Request) {
  if (req.method !== "POST") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { entityName, command } = parseUrl(req.url);

    if (!entityName || !command) {
      return jsonError("Missing 'entity' or 'command' query parameter", 400);
    }

    const { ids } = await req.json();

    if (!Array.isArray(ids) || ids.length === 0) {
      return jsonError("'ids' must be a non-empty array", 400);
    }

    const sql = createSqlClient();
    const results = [];

    for (const id of ids) {
      let result;
      switch (command) {
        case "delete":
          result = await deleteEntity(sql, entityName, String(id));
          break;
        case "deactivate":
          result = await deactivateEntity(sql, entityName, String(id));
          break;
        default:
          await sql.end();
          return jsonError(`Bulk command '${command}' not supported`, 400);
      }
      results.push({ id, ...result });
    }

    await sql.end();
    return jsonResponse({ command, results });
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Bulk command failed";
    return jsonError(message, 400);
  }
}

export function commandRouter(req: Request): Promise<Response> {
  const url = new URL(req.url);
  const path = url.pathname;

  if (path.endsWith("/activate")) {
    return handleActivateEntity(req);
  }
  if (path.endsWith("/bulk")) {
    return handleBulkCommand(req);
  }
  return handleExecuteCommand(req);
}
