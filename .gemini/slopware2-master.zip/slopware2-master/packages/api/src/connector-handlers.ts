import { createSqlClient } from "@repo/domain";

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function jsonError(message: string, status: number) {
  return jsonResponse({ error: message }, status);
}

function jsonConflict(reason: string) {
  return jsonResponse({ reason }, 409);
}

function parseUrl(url: string) {
  const parsed = new URL(url);
  const pathParts = parsed.pathname.split("/").filter(Boolean);
  // Expected: /connectors/:tenantConnectorId/mappings or /connectors/:tenantConnectorId/definition
  const connectorsIdx = pathParts.indexOf("connectors");
  if (connectorsIdx >= 0 && pathParts.length > connectorsIdx + 2) {
    const action = pathParts[pathParts.length - 1];
    if (action === "mappings" || action === "definition") {
      return { tenantConnectorId: pathParts[connectorsIdx + 1] ?? "" };
    }
  }
  return { tenantConnectorId: "" };
}

// fallow-ignore-next-line complexity
export async function handlePatchConnectorMappings(req: Request) {
  if (req.method !== "PATCH") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { tenantConnectorId } = parseUrl(req.url);

    if (!tenantConnectorId) {
      return jsonError("Missing tenantConnectorId in path", 400);
    }

    const payload = await req.json().catch(() => ({}));
    const mappings = payload.mappings as Array<Record<string, unknown>> | undefined;

    if (!Array.isArray(mappings)) {
      return jsonError("'mappings' must be an array", 400);
    }

    const sql = createSqlClient();

    for (const mapping of mappings) {
      const sourceField = String(mapping.source_field ?? "");
      const targetColumn = String(mapping.target_column ?? "");
      const targetTable = String(mapping.target_table ?? "");

      // Check 1: source_locked — source_field IN connector_definition.locked_fields
      const defRows = await sql.unsafe(
        `SELECT cd.locked_fields, cd.slug
         FROM tenant_connector tc
         JOIN connector_definition cd ON tc.connector_id = cd.connector_id
         WHERE tc.tenant_connector_id = $1
         LIMIT 1`,
        [tenantConnectorId],
      );

      if (defRows.length === 0) {
        await sql.end();
        return jsonError("Tenant connector not found", 404);
      }

      const def = defRows[0] as Record<string, unknown>;
      const lockedFields = (def.locked_fields as unknown[]) ?? [];

      if (lockedFields.includes(sourceField)) {
        await sql.end();
        return jsonConflict("source_locked");
      }

      // Check 2: target_locked — connector_definition.slug IN schema_annotations.locked_for
      const slug = String(def.slug);
      const annRows = await sql.unsafe(
        `SELECT sa.locked_for
         FROM schema_annotations sa
         WHERE sa.table_name = $1 AND sa.column_name = $2
         LIMIT 1`,
        [targetTable, targetColumn],
      );

      if (annRows.length > 0) {
        const ann = annRows[0] as Record<string, unknown>;
        const lockedFor = (ann.locked_for as unknown[]) ?? [];

        if (lockedFor.includes(slug)) {
          await sql.end();
          return jsonConflict("target_locked");
        }
      }
    }

    // All guards passed — upsert mappings
    for (const mapping of mappings) {
      const sourceField = String(mapping.source_field ?? "");
      const targetTable = String(mapping.target_table ?? "");
      const targetColumn = String(mapping.target_column ?? "");
      const transform = mapping.transform ?? { type: "direct" };
      const defaultValue = mapping.default_value ?? null;

      await sql.unsafe(
        `INSERT INTO tenant_connector_mapping
           (tenant_connector_id, tenant_id, source_field, target_table, target_column, transform, default_value)
         VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7::jsonb)
         ON CONFLICT (tenant_connector_id, source_field)
         DO UPDATE SET
           target_table = EXCLUDED.target_table,
           target_column = EXCLUDED.target_column,
           transform = EXCLUDED.transform,
           default_value = EXCLUDED.default_value`,
        [
          tenantConnectorId,
          String(mapping.tenant_id ?? ""),
          sourceField,
          targetTable,
          targetColumn,
          JSON.stringify(transform),
          defaultValue !== null ? JSON.stringify(defaultValue) : null,
        ],
      );
    }

    await sql.end();
    return jsonResponse({ success: true, count: mappings.length });
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to patch mappings";
    return jsonError(message, 400);
  }
}

export async function handleListConnectorMappings(req: Request) {
  if (req.method !== "GET") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { tenantConnectorId } = parseUrl(req.url);

    if (!tenantConnectorId) {
      return jsonError("Missing tenantConnectorId in path", 400);
    }

    const sql = createSqlClient();

    const rows = await sql.unsafe(
      `SELECT
         tcm.mapping_id,
         tcm.source_field,
         tcm.target_table,
         tcm.target_column,
         tcm.transform,
         tcm.default_value,
         cd.locked_fields,
         cd.slug as connector_slug
       FROM tenant_connector_mapping tcm
       JOIN tenant_connector tc ON tcm.tenant_connector_id = tc.tenant_connector_id
       JOIN connector_definition cd ON tc.connector_id = cd.connector_id
       WHERE tcm.tenant_connector_id = $1
       ORDER BY tcm.source_field`,
      [tenantConnectorId],
    );

    await sql.end();
    return jsonResponse(rows);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to list mappings";
    return jsonError(message, 400);
  }
}

export async function handleGetConnectorDefinition(req: Request) {
  if (req.method !== "GET") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { tenantConnectorId } = parseUrl(req.url);

    if (!tenantConnectorId) {
      return jsonError("Missing tenantConnectorId in path", 400);
    }

    const sql = createSqlClient();

    const rows = await sql.unsafe(
      `SELECT
         cd.connector_id,
         cd.slug,
         cd.label,
         cd.default_mappings,
         cd.locked_fields,
         cd.atomicity_mode
       FROM tenant_connector tc
       JOIN connector_definition cd ON tc.connector_id = cd.connector_id
       WHERE tc.tenant_connector_id = $1
       LIMIT 1`,
      [tenantConnectorId],
    );

    await sql.end();

    if (rows.length === 0) {
      return jsonError("Tenant connector not found", 404);
    }

    return jsonResponse(rows[0]);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to get connector definition";
    return jsonError(message, 400);
  }
}

export async function handleGetSchemaAnnotations(req: Request) {
  if (req.method !== "GET") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const sql = createSqlClient();

    const rows = await sql.unsafe(
      `SELECT
         table_name,
         column_name,
         business_name,
         data_class,
         mandatory_for,
         locked_for
       FROM schema_annotations
       WHERE column_name != ''
       ORDER BY table_name, column_name`,
    );

    await sql.end();
    return jsonResponse(rows);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to get schema annotations";
    return jsonError(message, 400);
  }
}
