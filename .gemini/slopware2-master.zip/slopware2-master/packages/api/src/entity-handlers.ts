import {
  listEntity,
  getEntityById,
  createEntity,
  patchEntity,
  deleteEntity,
  deactivateEntity,
  validateAgainstEffectiveFields,
} from "@repo/domain";
import { createSqlClient } from "@repo/domain";

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function jsonError(message: string, status: number) {
  return jsonResponse({ error: message }, status);
}

function parseUrl(url: string) {
  const parsed = new URL(url);
  return {
    entityName: parsed.searchParams.get("entity") ?? "",
    id: parsed.searchParams.get("id") ?? "",
    tenantId: parsed.searchParams.get("tenant_id") ?? "",
    limit: Number(parsed.searchParams.get("limit")) || 100,
    offset: Number(parsed.searchParams.get("offset")) || 0,
    sortBy: parsed.searchParams.get("sort_by") ?? undefined,
    sortOrder: (parsed.searchParams.get("sort_order") as "ASC" | "DESC") ?? "ASC",
  };
}

export async function handleListEntities(req: Request) {
  if (req.method !== "GET") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { entityName, limit, offset, sortBy, sortOrder } = parseUrl(req.url);

    if (!entityName) {
      return jsonError("Missing 'entity' query parameter", 400);
    }

    const sql = createSqlClient();
    const result = await listEntity(sql, entityName, {
      limit,
      offset,
      sortBy,
      sortOrder,
    });
    await sql.end();
    return jsonResponse(result);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to list entities";
    return jsonError(message, 400);
  }
}

export async function handleGetEntity(req: Request) {
  if (req.method !== "GET") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { entityName, id } = parseUrl(req.url);

    if (!entityName || !id) {
      return jsonError("Missing 'entity' or 'id' query parameter", 400);
    }

    const sql = createSqlClient();
    const result = await getEntityById(sql, entityName, id);
    await sql.end();

    if (!result) {
      return jsonError(`Entity '${entityName}' with id '${id}' not found`, 404);
    }

    return jsonResponse(result);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to get entity";
    return jsonError(message, 400);
  }
}

export async function handleCreateEntity(req: Request) {
  if (req.method !== "POST") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { entityName } = parseUrl(req.url);

    if (!entityName) {
      return jsonError("Missing 'entity' query parameter", 400);
    }

    const payload = await req.json();
    const sql = createSqlClient();
    const result = await createEntity(sql, entityName, payload);
    await sql.end();

    if (!result.success) {
      return jsonError(result.error ?? "Failed to create entity", 400);
    }

    return jsonResponse(result, 201);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to create entity";
    return jsonError(message, 400);
  }
}

export async function handlePatchEntity(req: Request) {
  if (req.method !== "PATCH") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { entityName, id } = parseUrl(req.url);

    if (!entityName || !id) {
      return jsonError("Missing 'entity' or 'id' query parameter", 400);
    }

    const payload = await req.json();
    const sql = createSqlClient();
    const result = await patchEntity(sql, entityName, id, payload);
    await sql.end();

    if (!result.success) {
      return jsonError(result.error ?? "Failed to patch entity", 400);
    }

    return jsonResponse(result);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to patch entity";
    return jsonError(message, 400);
  }
}

export async function handleDeleteEntity(req: Request) {
  if (req.method !== "DELETE") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { entityName, id } = parseUrl(req.url);

    if (!entityName || !id) {
      return jsonError("Missing 'entity' or 'id' query parameter", 400);
    }

    const sql = createSqlClient();
    const result = await deleteEntity(sql, entityName, id);
    await sql.end();

    if (!result.success) {
      return jsonError(result.error ?? "Failed to delete entity", 400);
    }

    return jsonResponse(result);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to delete entity";
    return jsonError(message, 400);
  }
}

export async function handleDeactivateEntity(req: Request) {
  if (req.method !== "POST") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { entityName, id } = parseUrl(req.url);

    if (!entityName || !id) {
      return jsonError("Missing 'entity' or 'id' query parameter", 400);
    }

    const sql = createSqlClient();
    const result = await deactivateEntity(sql, entityName, id);
    await sql.end();

    if (!result.success) {
      return jsonError(result.error ?? "Failed to deactivate entity", 400);
    }

    return jsonResponse(result);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to deactivate entity";
    return jsonError(message, 400);
  }
}

export async function handleValidateEntity(req: Request) {
  if (req.method !== "POST") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { entityName } = parseUrl(req.url);

    if (!entityName) {
      return jsonError("Missing 'entity' query parameter", 400);
    }

    const payload = await req.json();
    const sql = createSqlClient();
    const result = await validateAgainstEffectiveFields(sql, entityName, payload);
    await sql.end();

    return jsonResponse(result);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Validation failed";
    return jsonError(message, 400);
  }
}

export function entityRouter(req: Request): Promise<Response> {
  const url = new URL(req.url);
  const path = url.pathname;

  if (path.endsWith("/validate")) {
    return handleValidateEntity(req);
  }
  if (path.endsWith("/deactivate")) {
    return handleDeactivateEntity(req);
  }
  if (req.method === "POST" && !path.endsWith("/validate") && !path.endsWith("/deactivate")) {
    return handleCreateEntity(req);
  }
  if (req.method === "PATCH") {
    return handlePatchEntity(req);
  }
  if (req.method === "DELETE") {
    return handleDeleteEntity(req);
  }
  if (req.method === "GET") {
    const id = url.searchParams.get("id");
    if (id) {
      return handleGetEntity(req);
    }
    return handleListEntities(req);
  }

  return Promise.resolve(jsonError("Method not allowed", 405));
}
