import { listHelperTables, getHelperTableItems } from "@repo/domain";
import { createSqlClient } from "@repo/domain";

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function jsonError(message: string, status: number) {
  return jsonResponse({ error: message }, status);
}

function parseUrl(url: string) {
  const parsed = new URL(url);
  return {
    tableName: parsed.searchParams.get("table") ?? "",
    search: parsed.searchParams.get("search") ?? undefined,
    limit: Number(parsed.searchParams.get("limit")) || 100,
    offset: Number(parsed.searchParams.get("offset")) || 0,
  };
}

export async function handleListLookups(req: Request) {
  if (req.method !== "GET") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const sql = createSqlClient();
    const tables = await listHelperTables(sql);
    await sql.end();
    return jsonResponse(tables);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to list helper tables";
    return jsonError(message, 500);
  }
}

export async function handleGetLookupItems(req: Request) {
  if (req.method !== "GET") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { tableName, search, limit, offset } = parseUrl(req.url);

    if (!tableName) {
      return jsonError("Missing 'table' query parameter", 400);
    }

    const sql = createSqlClient();
    const items = await getHelperTableItems(sql, tableName, {
      search,
      limit,
      offset,
    });
    await sql.end();
    return jsonResponse(items);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to get lookup items";
    return jsonError(message, 400);
  }
}

export function lookupRouter(req: Request): Promise<Response> {
  const url = new URL(req.url);
  const tableName = url.searchParams.get("table");

  if (tableName) {
    return handleGetLookupItems(req);
  }
  return handleListLookups(req);
}
