import {
  getEffectiveFields,
  getEffectiveLayout,
  getEffectiveRules,
  getEffectiveSettings,
} from "@repo/domain";
import { getEntityDescriptor, ENTITY_REGISTRY } from "@repo/domain";
import { createSqlClient } from "@repo/domain";

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function jsonError(message: string, status: number) {
  return jsonResponse({ error: message }, status);
}

function parseUrl(url: string) {
  const parsed = new URL(url);
  return {
    entityName: parsed.searchParams.get("entity") ?? "",
    fieldName: parsed.searchParams.get("field") ?? undefined,
    layoutKey: parsed.searchParams.get("layout_key") ?? undefined,
    hookName: parsed.searchParams.get("hook") ?? undefined,
    prefix: parsed.searchParams.get("prefix") ?? undefined,
  };
}

export async function handleListMetadata(req: Request) {
  if (req.method !== "GET") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const entities = Array.from(ENTITY_REGISTRY.entries()).map(([_name, desc]) => ({
      entityName: desc.entityName,
      tableName: desc.tableName,
      kind: desc.kind,
      tenantScoped: desc.tenantScoped,
      genericRead: desc.genericRead,
      genericPatch: desc.genericPatch,
      genericDelete: desc.genericDelete,
      idColumn: desc.idColumn,
      label: desc.label,
    }));
    return jsonResponse(entities);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to list metadata";
    return jsonError(message, 500);
  }
}

export async function handleGetEntityDefinition(req: Request) {
  if (req.method !== "GET") {
    return jsonError("Method not allowed", 405);
  }

  const { entityName } = parseUrl(req.url);

  if (!entityName) {
    return jsonError("Missing 'entity' query parameter", 400);
  }

  const descriptor = getEntityDescriptor(entityName);
  if (!descriptor) {
    return jsonError(`Entity '${entityName}' not found`, 404);
  }

  return jsonResponse(descriptor);
}

export async function handleGetFields(req: Request) {
  if (req.method !== "GET") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { entityName, fieldName } = parseUrl(req.url);

    if (!entityName) {
      return jsonError("Missing 'entity' query parameter", 400);
    }

    const sql = createSqlClient();
    const fields = await getEffectiveFields(sql, { entityName, fieldName });
    await sql.end();
    return jsonResponse(fields);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to get fields";
    return jsonError(message, 500);
  }
}

export async function handleGetLayout(req: Request) {
  if (req.method !== "GET") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { entityName, layoutKey } = parseUrl(req.url);

    if (!entityName) {
      return jsonError("Missing 'entity' query parameter", 400);
    }

    const sql = createSqlClient();
    const layouts = await getEffectiveLayout(sql, { entityName, layoutKey });
    await sql.end();
    return jsonResponse(layouts);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to get layout";
    return jsonError(message, 500);
  }
}

export async function handleGetRules(req: Request) {
  if (req.method !== "GET") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { entityName, hookName } = parseUrl(req.url);

    if (!entityName) {
      return jsonError("Missing 'entity' query parameter", 400);
    }

    const sql = createSqlClient();
    const rules = await getEffectiveRules(sql, { entityName, hookName });
    await sql.end();
    return jsonResponse(rules);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to get rules";
    return jsonError(message, 500);
  }
}

export async function handleGetSettings(req: Request) {
  if (req.method !== "GET") {
    return jsonError("Method not allowed", 405);
  }

  try {
    const { prefix } = parseUrl(req.url);

    const sql = createSqlClient();
    const settings = await getEffectiveSettings(sql, { prefix });
    await sql.end();
    return jsonResponse(settings);
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Failed to get settings";
    return jsonError(message, 500);
  }
}

export function metadataRouter(req: Request): Promise<Response> {
  const url = new URL(req.url);
  const path = url.pathname;

  if (path.endsWith("/fields")) {
    return handleGetFields(req);
  }
  if (path.endsWith("/layout")) {
    return handleGetLayout(req);
  }
  if (path.endsWith("/rules")) {
    return handleGetRules(req);
  }
  if (path.endsWith("/settings")) {
    return handleGetSettings(req);
  }
  if (url.searchParams.has("entity")) {
    return handleGetEntityDefinition(req);
  }
  return handleListMetadata(req);
}
