import { db } from "@repo/db";
import { appUser, userTenant } from "@repo/db/schema";
import { createServerFn } from "@tanstack/react-start";
import { eq } from "drizzle-orm";

export type UserRole = "system_admin" | "org_admin" | "tenant_admin" | "tenant_user";

type ResolveRoleInput = { userId?: string; tenantId?: string };

const roleHierarchy: Record<UserRole, number> = {
  tenant_user: 0,
  tenant_admin: 1,
  org_admin: 2,
  system_admin: 3,
};

async function resolveRoleInternal(userId?: string, tenantId?: string): Promise<UserRole> {
  if (!userId) {
    return "tenant_user";
  }

  if (tenantId) {
    const ut = await db
      .select({ role: userTenant.role })
      .from(userTenant)
      .where(eq(userTenant.userId, userId))
      .limit(1);

    if (ut.length > 0) {
      return ut[0].role as UserRole;
    }
  }

  const user = await db
    .select({ role: appUser.role })
    .from(appUser)
    .where(eq(appUser.userId, userId))
    .limit(1);

  return (user[0]?.role ?? "tenant_user") as UserRole;
}

export const $resolveUserRole = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => data as ResolveRoleInput)
  .handler(async ({ data }) => {
    const role = await resolveRoleInternal(data?.userId, data?.tenantId);
    return { role };
  });

type HasRoleInput = { userId?: string; tenantId?: string; requiredRole?: string };

export const $hasRole = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => data as HasRoleInput)
  .handler(async ({ data }) => {
    const userId = data?.userId;
    const tenantId = data?.tenantId;
    const requiredRole = data?.requiredRole;

    if (!userId || !requiredRole) {
      return { hasRole: false };
    }

    const role = await resolveRoleInternal(userId, tenantId);
    const userLevel = roleHierarchy[role] ?? 0;
    const requiredLevel = roleHierarchy[requiredRole as UserRole] ?? 0;

    return { hasRole: userLevel >= requiredLevel };
  });
