import { describe, it, expect } from "vitest";

describe("Role resolution logic", () => {
  const roleHierarchy: Record<string, number> = {
    tenant_user: 0,
    tenant_admin: 1,
    org_admin: 2,
    system_admin: 3,
  };

  const hasRole = (userLevel: string, requiredLevel: string) => {
    const u = roleHierarchy[userLevel] ?? 0;
    const r = roleHierarchy[requiredLevel] ?? 0;
    return u >= r;
  };

  it("system_admin has access to all roles", () => {
    expect(hasRole("system_admin", "tenant_user")).toBe(true);
    expect(hasRole("system_admin", "tenant_admin")).toBe(true);
    expect(hasRole("system_admin", "org_admin")).toBe(true);
    expect(hasRole("system_admin", "system_admin")).toBe(true);
  });

  it("tenant_user only has access to tenant_user", () => {
    expect(hasRole("tenant_user", "tenant_user")).toBe(true);
    expect(hasRole("tenant_user", "tenant_admin")).toBe(false);
    expect(hasRole("tenant_user", "org_admin")).toBe(false);
    expect(hasRole("tenant_user", "system_admin")).toBe(false);
  });

  it("tenant_admin has access to tenant_user and tenant_admin", () => {
    expect(hasRole("tenant_admin", "tenant_user")).toBe(true);
    expect(hasRole("tenant_admin", "tenant_admin")).toBe(true);
    expect(hasRole("tenant_admin", "org_admin")).toBe(false);
    expect(hasRole("tenant_admin", "system_admin")).toBe(false);
  });

  it("org_admin has access to tenant_user, tenant_admin, org_admin", () => {
    expect(hasRole("org_admin", "tenant_user")).toBe(true);
    expect(hasRole("org_admin", "tenant_admin")).toBe(true);
    expect(hasRole("org_admin", "org_admin")).toBe(true);
    expect(hasRole("org_admin", "system_admin")).toBe(false);
  });

  it("unknown role defaults to lowest level (tenant_user equivalent)", () => {
    expect(hasRole("unknown", "tenant_user")).toBe(true);
    expect(hasRole("unknown", "system_admin")).toBe(false);
  });

  it("admin check: system_admin is admin", () => {
    const baseRole: string = "system_admin";
    const isAdmin =
      baseRole === "system_admin" || baseRole === "org_admin" || baseRole === "tenant_admin";
    expect(isAdmin).toBe(true);
  });

  it("admin check: tenant_user is not admin", () => {
    const baseRole: string = "tenant_user";
    const isAdmin =
      baseRole === "system_admin" || baseRole === "org_admin" || baseRole === "tenant_admin";
    expect(isAdmin).toBe(false);
  });

  it("admin check: tenant_user is not admin (literal type)", () => {
    const baseRole: string = "tenant_user";
    const isAdmin =
      baseRole === "system_admin" || baseRole === "org_admin" || baseRole === "tenant_admin";
    expect(isAdmin).toBe(false);
  });

  it("admin check: tenant_admin is admin", () => {
    const baseRole: string = "tenant_admin";
    const isAdmin =
      baseRole === "system_admin" || baseRole === "org_admin" || baseRole === "tenant_admin";
    expect(isAdmin).toBe(true);
  });
});

describe("Migration SQL correctness", () => {
  const migrationPath =
    "/home/joerg/slopwarev2/new/packages/db/migrations/20260507200000_add_user_role/migration.sql";

  it("migration file exists and contains role column", async () => {
    const fs = await import("fs");
    const exists = fs.existsSync(migrationPath);
    expect(exists).toBe(true);
  });

  it("migration adds role column with default", async () => {
    const fs = await import("fs");
    const content = fs.readFileSync(migrationPath, "utf-8");
    expect(content).toContain('ADD COLUMN "role"');
    expect(content).toContain("DEFAULT 'tenant_user'");
  });

  it("migration adds CHECK constraint", async () => {
    const fs = await import("fs");
    const content = fs.readFileSync(migrationPath, "utf-8");
    expect(content).toContain("CHECK");
    expect(content).toContain("system_admin");
    expect(content).toContain("tenant_user");
  });

  it("migration backfills is_system_admin users", async () => {
    const fs = await import("fs");
    const content = fs.readFileSync(migrationPath, "utf-8");
    expect(content).toContain("is_system_admin");
    expect(content).toContain("UPDATE");
  });
});
