import { db } from "@repo/db";
import { appUser } from "@repo/db/schema";
import { createMiddleware } from "@tanstack/react-start";
import { setResponseStatus } from "@tanstack/react-start/server";
import { eq } from "drizzle-orm";

import { _getUser } from "./tanstack/functions";

export const adminGuard = createMiddleware().server(async ({ next, request: _request }) => {
  const user = await _getUser();

  if (!user) {
    setResponseStatus(401);
    throw new Error("Unauthorized");
  }

  const userRecord = await db
    .select({ role: appUser.role })
    .from(appUser)
    .where(eq(appUser.userId, user.id))
    .limit(1);

  const baseRole = userRecord[0]?.role ?? "tenant_user";

  const isAdmin =
    baseRole === "system_admin" || baseRole === "org_admin" || baseRole === "tenant_admin";

  if (!isAdmin) {
    setResponseStatus(403);
    throw new Error("Forbidden: admin role required");
  }

  return next({ context: { user, role: baseRole } });
});
