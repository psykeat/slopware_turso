import { createAuthClient } from "better-auth/client";

export const authClient = createAuthClient({
  // baseURL is optional and will default to the current origin in the browser
  baseURL: typeof window !== "undefined" ? undefined : process.env.VITE_BASE_URL,
});

export const { signIn, signOut, signUp, useSession } = authClient;
