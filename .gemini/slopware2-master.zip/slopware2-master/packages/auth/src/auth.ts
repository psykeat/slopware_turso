import "@tanstack/react-start/server-only";
import { drizzleAdapter } from "@better-auth/drizzle-adapter/relations-v2";
import { metrics } from "@opentelemetry/api";
import { db } from "@repo/db";
import * as schema from "@repo/db/schema";
import { betterAuth } from "better-auth/minimal";
import { tanstackStartCookies } from "better-auth/tanstack-start";

const meter = metrics.getMeter("slopware-auth");
const loginCounter = meter.createCounter("auth_login_count", {
  description: "Count of login attempts",
});

export const auth = betterAuth({
  baseURL: process.env.BETTER_AUTH_URL || process.env.VITE_BASE_URL || "http://localhost:3000",
  secret: process.env.BETTER_AUTH_SECRET || "dev-secret-change-me-in-production",
  telemetry: {
    enabled: false,
  },
  database: drizzleAdapter(db, {
    provider: "pg",
    schema,
  }),
  plugins: [tanstackStartCookies()],
  hooks: {
    after: async (ctx) => {
      // Record login metrics
      // Better Auth MiddlewareInputContext has request
      if (!ctx.request) return ctx;

      const url = new URL(ctx.request.url);
      if (url.pathname.includes("/sign-in/") && ctx.request.method === "POST") {
        const provider = url.pathname.split("/").pop() || "unknown";
        // We use any here because Better Auth hook types are complex and sometimes internal
        const response = (ctx as any).response || (ctx as any).asResponse;
        loginCounter.add(1, {
          status: response?.status === 200 ? "success" : "failure",
          provider,
        });
      }
      return ctx;
    },
  },
  session: {
    cookieCache: {
      enabled: true,
      maxAge: 5 * 60,
    },
  },
  socialProviders: {
    ...(process.env.GITHUB_CLIENT_ID && process.env.GITHUB_CLIENT_SECRET
      ? {
          github: {
            clientId: process.env.GITHUB_CLIENT_ID,
            clientSecret: process.env.GITHUB_CLIENT_SECRET,
          },
        }
      : {}),
    ...(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET
      ? {
          google: {
            clientId: process.env.GOOGLE_CLIENT_ID,
            clientSecret: process.env.GOOGLE_CLIENT_SECRET,
          },
        }
      : {}),
  },
  emailAndPassword: {
    enabled: true,
  },
  experimental: {
    joins: true,
  },
});
