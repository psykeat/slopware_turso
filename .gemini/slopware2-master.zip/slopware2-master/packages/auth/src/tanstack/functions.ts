import { createServerFn, createServerOnlyFn } from "@tanstack/react-start";
import { getRequest, setResponseHeader } from "@tanstack/react-start/server";

import { auth } from "../auth";

export const $getUser = createServerFn({ method: "GET" }).handler(async () => {
  const user = await _getUser();
  return user;
});

interface GetUserServerQuery {
  disableCookieCache?: boolean | undefined;
  disableRefresh?: boolean | undefined;
}

export const _getUser = createServerOnlyFn(async (query?: GetUserServerQuery) => {
  try {
    const request = getRequest();
    if (!request?.headers) return null;

    const session = await auth.api.getSession({
      headers: request.headers,
    });

    return session?.user || null;
  } catch (error) {
    return null;
  }
});
