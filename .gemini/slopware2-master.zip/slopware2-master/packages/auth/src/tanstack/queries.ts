import { queryOptions } from "@tanstack/react-query";

import { $getUser } from "./functions";

export function authQueryOptions() {
  return queryOptions({
    queryKey: ["auth", "user"],
    queryFn: () => $getUser(),
  });
}
