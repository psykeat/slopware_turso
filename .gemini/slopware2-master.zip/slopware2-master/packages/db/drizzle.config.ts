import { readFileSync } from "fs";
import { resolve } from "path";

import { defineConfig } from "drizzle-kit";

try {
  for (const line of readFileSync(resolve(import.meta.dirname, "../../.env"), "utf8").split(
    /\r?\n/,
  )) {
    const m = line.match(/^([^#\s=][^=]*)=(.*)/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].trim();
  }
} catch {}

if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is not set");

export default defineConfig({
  schema: "./src/schema/index.ts",
  out: "./drizzle",
  dialect: "postgresql",
  dbCredentials: {
    url: process.env.DATABASE_URL,
  },
});
