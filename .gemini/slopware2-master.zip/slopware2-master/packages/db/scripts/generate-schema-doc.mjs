import { writeFileSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";

import postgres from "postgres";

const __dirname = dirname(fileURLToPath(import.meta.url));
const OUTPUT_PATH = resolve(__dirname, "../../../.agents/schema.md");
const { DATABASE_URL } = process.env;
if (!DATABASE_URL) throw new Error("DATABASE_URL is not set");

const url = new URL(DATABASE_URL);
const sql = postgres({
  host: url.hostname,
  port: parseInt(url.port || "5432"),
  database: url.pathname.slice(1),
  user: url.username,
  password: url.password,
  max: 1,
});

async function generate() {
  const [tables, columns, primaryKeys, uniqueConstraints, indexes, checks] = await Promise.all([
    sql`
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
        ORDER BY table_name
      `,
    sql`
        SELECT table_name, column_name, data_type, character_maximum_length,
               is_nullable, column_default, ordinal_position
        FROM information_schema.columns
        WHERE table_schema = 'public'
        ORDER BY table_name, ordinal_position
      `,
    sql`
        SELECT tc.table_name, kcu.column_name
        FROM information_schema.table_constraints tc
        JOIN information_schema.key_column_usage kcu
          ON tc.constraint_name = kcu.constraint_name
          AND tc.table_schema = kcu.table_schema
        WHERE tc.constraint_type = 'PRIMARY KEY' AND tc.table_schema = 'public'
      `,
    sql`
        SELECT tc.table_name,
               string_agg(kcu.column_name, ', ' ORDER BY kcu.ordinal_position) AS columns
        FROM information_schema.table_constraints tc
        JOIN information_schema.key_column_usage kcu
          ON tc.constraint_name = kcu.constraint_name
          AND tc.table_schema = kcu.table_schema
        WHERE tc.constraint_type = 'UNIQUE' AND tc.table_schema = 'public'
        GROUP BY tc.table_name, tc.constraint_name
        ORDER BY tc.table_name, tc.constraint_name
      `,
    sql`
        SELECT t.relname AS table_name, i.relname AS index_name,
               ix.indisunique AS is_unique,
               string_agg(a.attname, ', ' ORDER BY k.ord) AS columns,
               am.amname AS method
        FROM pg_class t
        JOIN pg_index ix ON t.oid = ix.indrelid
        JOIN pg_class i ON i.oid = ix.indexrelid
        JOIN pg_namespace n ON t.relnamespace = n.oid
        JOIN pg_am am ON i.relam = am.oid
        JOIN LATERAL unnest(ix.indkey) WITH ORDINALITY AS k(attnum, ord) ON true
        JOIN pg_attribute a ON a.attrelid = t.oid AND a.attnum = k.attnum AND k.attnum > 0
        WHERE n.nspname = 'public' AND t.relkind = 'r'
        GROUP BY t.relname, i.relname, ix.indisunique, am.amname
        ORDER BY t.relname, i.relname
      `,
    sql`
        SELECT tc.table_name, tc.constraint_name, cc.check_clause
        FROM information_schema.table_constraints tc
        JOIN information_schema.check_constraints cc
          ON tc.constraint_name = cc.constraint_name
          AND tc.constraint_schema = cc.constraint_schema
        WHERE tc.constraint_type = 'CHECK' AND tc.table_schema = 'public'
        ORDER BY tc.table_name, tc.constraint_name
      `,
  ]);

  // Build lookup maps
  const pkSet = new Map();
  for (const { table_name, column_name } of primaryKeys) {
    if (!pkSet.has(table_name)) pkSet.set(table_name, new Set());
    pkSet.get(table_name).add(column_name);
  }

  const colMap = new Map();
  for (const col of columns) {
    if (!colMap.has(col.table_name)) colMap.set(col.table_name, []);
    colMap.get(col.table_name).push(col);
  }

  const uniqueMap = new Map();
  for (const u of uniqueConstraints) {
    if (!uniqueMap.has(u.table_name)) uniqueMap.set(u.table_name, []);
    uniqueMap.get(u.table_name).push(u.columns);
  }

  const indexMap = new Map();
  for (const idx of indexes) {
    if (!indexMap.has(idx.table_name)) indexMap.set(idx.table_name, []);
    indexMap.get(idx.table_name).push(idx);
  }

  const checkMap = new Map();
  for (const chk of checks) {
    if (!checkMap.has(chk.table_name)) checkMap.set(chk.table_name, []);
    checkMap.get(chk.table_name).push(chk);
  }

  function formatType(col) {
    if (col.data_type === "character varying") return "character varying";
    if (col.data_type === "character" && col.character_maximum_length)
      return `char(${col.character_maximum_length})`;
    if (col.data_type === "character") return "character";
    return col.data_type;
  }

  function formatConstraints(col, isPk) {
    const parts = [];
    if (col.is_nullable === "NO") parts.push("NOT NULL");
    if (col.column_default != null) {
      // Strip PostgreSQL type casts like ::text, ::regclass, ::jsonb
      const def = col.column_default.replace(/::[a-z_ ]+(\([^)]*\))?/g, "");
      parts.push(`DEFAULT ${def}`);
    }
    return parts.join(", ");
  }

  function pad(s, w) {
    return s + " ".repeat(Math.max(0, w - s.length));
  }

  const now = new Date().toISOString().replace("T", " ").slice(0, 19) + " UTC";

  let md = `# Slopware — Live Schema\n\n`;
  md += `> Generated: ${now}\n`;
  md += `> Tables: ${tables.length}\n\n`;
  md += `## Module: uncategorized\n\n`;

  for (const { table_name } of tables) {
    md += `### \`${table_name}\`\n\n`;
    md += `> _⚠ pending annotation_\n\n`;

    const cols = colMap.get(table_name) ?? [];
    const pks = pkSet.get(table_name) ?? new Set();

    const headers = ["Column", "Business Name", "Type", "Class", "Constraints", "Description"];
    const rows = cols.map((col) => {
      const isPk = pks.has(col.column_name);
      return [
        col.column_name,
        col.column_name,
        formatType(col),
        isPk ? "PK" : "—",
        formatConstraints(col, isPk),
        "",
      ];
    });

    const widths = headers.map((h, i) => Math.max(h.length, ...rows.map((r) => r[i].length)));

    md += `| ${headers.map((h, i) => pad(h, widths[i])).join(" | ")} |\n`;
    md += `| ${widths.map((w) => "-".repeat(w)).join(" | ")} |\n`;
    for (const row of rows) {
      md += `| ${row.map((cell, i) => pad(cell, widths[i])).join(" | ")} |\n`;
    }
    md += "\n";

    const uniqs = uniqueMap.get(table_name) ?? [];
    for (const cols of uniqs) md += `> UNIQUE(${cols})\n`;
    if (uniqs.length) md += "\n";

    const idxs = indexMap.get(table_name) ?? [];
    for (const idx of idxs) {
      const uniq = idx.is_unique ? " UNIQUE" : "";
      md += `> INDEX${uniq} \`${idx.index_name}\` (${idx.columns}) [${idx.method}]\n`;
    }
    if (idxs.length) md += "\n";

    const chks = checkMap.get(table_name) ?? [];
    for (const chk of chks) {
      md += `> CHECK \`${chk.constraint_name}\`: ${chk.check_clause}\n`;
    }
    if (chks.length) md += "\n";
  }

  writeFileSync(OUTPUT_PATH, md);
  console.log(`Schema doc written → .agents/schema.md (${tables.length} tables)`);
}

generate()
  .catch((err) => {
    console.error("Schema doc generation failed:", err.message);
    process.exit(1);
  })
  .finally(() => sql.end());
