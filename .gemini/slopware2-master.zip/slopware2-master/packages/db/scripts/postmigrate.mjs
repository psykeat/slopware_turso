/**
 * IMPORTANT: Uses raw `client` queries, NOT Drizzle ORM.
 *
 * `drizzle(client)` creates its own connection pool that ignores the URL
 * credentials and picks up the OS user — leads to "password auth failed for
 * user <os-user>" errors. The `postgres` client directly respects DATABASE_URL.
 * See: seed-system-metadata.mjs follows the same pattern.
 */
import postgres from "postgres";

const SYSTEM_ORG_ID = "00000000-0000-0000-0000-000000000001";
const BASE_TENANT_ID = "00000000-0000-0000-0000-000000000002";

const { DATABASE_URL } = process.env;
if (!DATABASE_URL) throw new Error("DATABASE_URL is not set");

const client = postgres(DATABASE_URL, { max: 1 });

async function seed() {
  await client`
    INSERT INTO organization (organization_id, slug, name)
    VALUES (${SYSTEM_ORG_ID}, 'system', 'System')
    ON CONFLICT (organization_id) DO NOTHING
  `;

  await client`
    INSERT INTO tenant (tenant_id, organization_id, slug, name, is_base)
    VALUES (${BASE_TENANT_ID}, ${SYSTEM_ORG_ID}, 'base', 'Base', true)
    ON CONFLICT (tenant_id) DO NOTHING
  `;

  const companyRows = await client`
    INSERT INTO company (tenant_id, company_no, name, country_code, currency_id)
    VALUES (${BASE_TENANT_ID}, '100', 'Standard Firma', 'DE', 'EUR')
    ON CONFLICT (tenant_id, company_no) DO NOTHING
    RETURNING company_id
  `;

  let companyId = companyRows.length ? companyRows[0].company_id : null;

  if (!companyId) {
    const existing = await client`
      SELECT company_id FROM company WHERE tenant_id = ${BASE_TENANT_ID} LIMIT 1
    `;
    companyId = existing.length ? existing[0].company_id : null;
  }

  if (!companyId) {
    console.log("Skipping document seed — no company found");
    console.log("Seeded SYSTEM_ORG_ID, BASE_TENANT_ID and default company");
    return;
  }

  const DOCUMENT_TYPES = [
    {
      code: "N",
      name: "Angebot",
      movementType: "N",
      requiresWarehouse: false,
      requiresCostCenter: false,
      sortOrder: 1,
    },
    {
      code: "A",
      name: "Auftrag",
      movementType: "A",
      requiresWarehouse: true,
      requiresCostCenter: false,
      sortOrder: 2,
    },
    {
      code: "L",
      name: "Lieferschein",
      movementType: "L",
      requiresWarehouse: true,
      requiresCostCenter: false,
      sortOrder: 3,
    },
    {
      code: "R",
      name: "Rechnung",
      movementType: "R",
      requiresWarehouse: false,
      requiresCostCenter: false,
      sortOrder: 4,
    },
    {
      code: "G",
      name: "Gutschrift",
      movementType: "G",
      requiresWarehouse: false,
      requiresCostCenter: false,
      sortOrder: 21,
    },
    {
      code: "b",
      name: "Bestellung",
      movementType: "b",
      requiresWarehouse: false,
      requiresCostCenter: false,
      sortOrder: 11,
    },
    {
      code: "l",
      name: "WE-Lieferschein",
      movementType: "l",
      requiresWarehouse: true,
      requiresCostCenter: false,
      sortOrder: 12,
    },
    {
      code: "r",
      name: "WE-Rechnung",
      movementType: "r",
      requiresWarehouse: false,
      requiresCostCenter: false,
      sortOrder: 13,
    },
    {
      code: "g",
      name: "WE-Gutschrift",
      movementType: "g",
      requiresWarehouse: false,
      requiresCostCenter: false,
      sortOrder: 22,
    },
    {
      code: "V",
      name: "Inventurbuchung",
      movementType: "V",
      requiresWarehouse: true,
      requiresCostCenter: false,
      sortOrder: 31,
    },
    {
      code: "Z",
      name: "Zubuchung",
      movementType: "Z",
      requiresWarehouse: true,
      requiresCostCenter: false,
      sortOrder: 32,
    },
    {
      code: "E",
      name: "Entnahme",
      movementType: "E",
      requiresWarehouse: true,
      requiresCostCenter: false,
      sortOrder: 41,
    },
    {
      code: "U",
      name: "Umlagerung",
      movementType: "U",
      requiresWarehouse: true,
      requiresCostCenter: false,
      sortOrder: 51,
    },
    {
      code: "q",
      name: "Produktionsauftrag",
      movementType: "q",
      requiresWarehouse: true,
      requiresCostCenter: false,
      sortOrder: 61,
    },
    {
      code: "p",
      name: "Produktionsbuchung",
      movementType: "p",
      requiresWarehouse: true,
      requiresCostCenter: false,
      sortOrder: 62,
    },
  ];

  const DOCUMENT_GROUPS = [
    {
      name: "N00 — Angebotsysteme",
      documentType: "N",
      groupNumber: 0,
      direction: null,
      description: "System-Beleggruppe Angebote",
    },
    { name: "N01 — Angebote", documentType: "N", groupNumber: 1, direction: null },
    {
      name: "A00 — Auftragssysteme",
      documentType: "A",
      groupNumber: 0,
      direction: "outbound",
      description: "System-Beleggruppe Aufträge",
    },
    { name: "A01 — Aufträge", documentType: "A", groupNumber: 1, direction: "outbound" },
    {
      name: "L00 — Lieferschein-Systeme",
      documentType: "L",
      groupNumber: 0,
      direction: "outbound",
      description: "System-Beleggruppe Lieferscheine",
    },
    { name: "L01 — Lieferscheine", documentType: "L", groupNumber: 1, direction: "outbound" },
    {
      name: "R00 — Rechnungssysteme",
      documentType: "R",
      groupNumber: 0,
      direction: "outbound",
      description: "System-Beleggruppe Rechnungen",
    },
    { name: "R01 — Rechnungen", documentType: "R", groupNumber: 1, direction: "outbound" },
    {
      name: "G00 — Gutschrift-Systeme",
      documentType: "G",
      groupNumber: 0,
      direction: "outbound",
      description: "System-Beleggruppe Gutschriften",
    },
    { name: "G01 — Gutschriften", documentType: "G", groupNumber: 1, direction: "outbound" },
    {
      name: "b00 — Bestellungssysteme",
      documentType: "b",
      groupNumber: 0,
      direction: "inbound",
      description: "System-Beleggruppe Bestellungen",
    },
    { name: "b01 — Bestellungen", documentType: "b", groupNumber: 1, direction: "inbound" },
    {
      name: "l00 — WE-Lieferschein-Systeme",
      documentType: "l",
      groupNumber: 0,
      direction: "inbound",
      description: "System-Beleggruppe WE-Lieferscheine",
    },
    { name: "l01 — WE-Lieferscheine", documentType: "l", groupNumber: 1, direction: "inbound" },
    {
      name: "r00 — WE-Rechnungssysteme",
      documentType: "r",
      groupNumber: 0,
      direction: "inbound",
      description: "System-Beleggruppe WE-Rechnungen",
    },
    { name: "r01 — WE-Rechnungen", documentType: "r", groupNumber: 1, direction: "inbound" },
    {
      name: "g00 — WE-Gutschrift-Systeme",
      documentType: "g",
      groupNumber: 0,
      direction: "inbound",
      description: "System-Beleggruppe WE-Gutschriften",
    },
    { name: "g01 — WE-Gutschriften", documentType: "g", groupNumber: 1, direction: "inbound" },
    {
      name: "V00 — Inventur-Systeme",
      documentType: "V",
      groupNumber: 0,
      direction: null,
      description: "System-Beleggruppe Inventuren",
    },
    { name: "V01 — Inventuren", documentType: "V", groupNumber: 1, direction: null },
    {
      name: "Z00 — Zubuchungssysteme",
      documentType: "Z",
      groupNumber: 0,
      direction: null,
      description: "System-Beleggruppe Zubuchungen",
    },
    { name: "Z01 — Zubuchungen", documentType: "Z", groupNumber: 1, direction: null },
    {
      name: "E00 — Entnahmesysteme",
      documentType: "E",
      groupNumber: 0,
      direction: null,
      description: "System-Beleggruppe Entnahmen",
    },
    { name: "E01 — Entnahmen", documentType: "E", groupNumber: 1, direction: null },
    {
      name: "U00 — Umlagerungssysteme",
      documentType: "U",
      groupNumber: 0,
      direction: null,
      description: "System-Beleggruppe Umlagerungen",
    },
    { name: "U01 — Umlagerungen", documentType: "U", groupNumber: 1, direction: null },
    {
      name: "q00 — ProdAuftrag-Systeme",
      documentType: "q",
      groupNumber: 0,
      direction: "inbound",
      description: "System-Beleggruppe Produktionsaufträge",
    },
    { name: "q01 — Produktionsaufträge", documentType: "q", groupNumber: 1, direction: "inbound" },
    {
      name: "p00 — ProdBuchung-Systeme",
      documentType: "p",
      groupNumber: 0,
      direction: "outbound",
      description: "System-Beleggruppe Produktionsbuchungen",
    },
    {
      name: "p01 — Produktionsbuchungen",
      documentType: "p",
      groupNumber: 1,
      direction: "outbound",
    },
  ];

  const NUMBER_SEQUENCES = [
    { prefix: "ANG-", documentType: "N", padding: 5 },
    { prefix: "AUF-", documentType: "A", padding: 5 },
    { prefix: "LIS-", documentType: "L", padding: 5 },
    { prefix: "RE-", documentType: "R", padding: 5 },
    { prefix: "GU-", documentType: "G", padding: 5 },
    { prefix: "BES-", documentType: "b", padding: 5 },
    { prefix: "WEL-", documentType: "l", padding: 5 },
    { prefix: "WER-", documentType: "r", padding: 5 },
    { prefix: "WEG-", documentType: "g", padding: 5 },
    { prefix: "INV-", documentType: "V", padding: 5 },
    { prefix: "ZUB-", documentType: "Z", padding: 5 },
    { prefix: "ENT-", documentType: "E", padding: 5 },
    { prefix: "UMB-", documentType: "U", padding: 5 },
    { prefix: "PRO-", documentType: "q", padding: 5 },
    { prefix: "PRB-", documentType: "p", padding: 5 },
  ];

  const docTypeIds = {};
  for (const dt of DOCUMENT_TYPES) {
    const rows = await client`
      INSERT INTO document_type (tenant_id, code, name, movement_type, requires_warehouse, requires_cost_center, sort_order, is_active)
      VALUES (${BASE_TENANT_ID}, ${dt.code}, ${dt.name}, ${dt.movementType}, ${dt.requiresWarehouse}, ${dt.requiresCostCenter}, ${dt.sortOrder}, true)
      ON CONFLICT (tenant_id, code) DO UPDATE SET name = EXCLUDED.name
      RETURNING document_type_id
    `;
    docTypeIds[dt.code] = rows[0].document_type_id;
  }

  const docGroupIds = {};
  for (const dg of DOCUMENT_GROUPS) {
    const rows = await client`
      INSERT INTO document_group (tenant_id, company_id, name, document_type, group_number, direction, is_active, sort_order, description)
      VALUES (${BASE_TENANT_ID}, ${companyId}, ${dg.name}, ${dg.documentType}, ${dg.groupNumber}, ${dg.direction}, true, 0, ${dg.description ?? null})
      ON CONFLICT (tenant_id, document_type, group_number) DO UPDATE SET name = EXCLUDED.name
      RETURNING document_group_id
    `;
    docGroupIds[`${dg.documentType}_${dg.groupNumber}`] = rows[0].document_group_id;
  }

  for (const ns of NUMBER_SEQUENCES) {
    await client`
      INSERT INTO number_sequence (tenant_id, company_id, prefix, document_type, next_value, padding)
      VALUES (${BASE_TENANT_ID}, ${companyId}, ${ns.prefix}, ${ns.documentType}, 1, ${ns.padding})
      ON CONFLICT (tenant_id, company_id, document_type) DO UPDATE SET prefix = EXCLUDED.prefix
    `;
  }

  console.log(
    `Seeded SYSTEM_ORG_ID, BASE_TENANT_ID, default company, ${DOCUMENT_TYPES.length} document types, ${DOCUMENT_GROUPS.length} document groups, ${NUMBER_SEQUENCES.length} number sequences`,
  );
}

seed()
  .catch((err) => {
    console.error("Seed failed:", err);
    process.exit(1);
  })
  .finally(async () => {
    await client.end();
  });
