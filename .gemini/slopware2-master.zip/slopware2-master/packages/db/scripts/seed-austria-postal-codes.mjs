import postgres from "postgres";

const { DATABASE_URL } = process.env;
if (!DATABASE_URL) throw new Error("DATABASE_URL is not set");

const client = postgres(DATABASE_URL, { max: 1 });

const BUNDESLAND_MAP = {
  W: "Wien",
  N: "Niederösterreich",
  O: "Oberösterreich",
  B: "Burgenland",
  K: "Kärnten",
  St: "Steiermark",
  T: "Tirol",
  V: "Vorarlberg",
  Sa: "Salzburg",
};

async function seed() {
  console.log("🚀 Fetching Austrian postal codes...");
  const response = await fetch(
    "https://raw.githubusercontent.com/pkolmann/austria-post-and-area-code/main/data/plz.json",
  );
  if (!response.ok) {
    throw new Error(`Failed to fetch: ${response.statusText}`);
  }
  const json = await response.json();
  const data = json.data;

  console.log(`📦 Processing ${data.length} entries...`);

  const currentData = data.filter((item) => item.gueltigbis === null);
  console.log(`🔍 Filtered to ${currentData.length} current entries.`);

  const values = currentData.map((item) => {
    const bundeslandCode = item.bundesland;
    const bundeslandName = BUNDESLAND_MAP[bundeslandCode] || bundeslandCode || null;

    return {
      country_code: "AT",
      plz: item.plz != null ? item.plz.toString() : "",
      city: item.ort || "",
      state: bundeslandName,
    };
  });

  // Batch insert
  const BATCH_SIZE = 1000;
  for (let i = 0; i < values.length; i += BATCH_SIZE) {
    const batch = values.slice(i, i + BATCH_SIZE);
    await client`
      INSERT INTO postal_code
      ${client(batch, "country_code", "plz", "city", "state")}
      ON CONFLICT (country_code, plz, city, state) DO NOTHING
    `;
    console.log(
      `✅ Inserted batch ${Math.floor(i / BATCH_SIZE) + 1} / ${Math.ceil(values.length / BATCH_SIZE)}`,
    );
  }

  console.log("🎉 Austrian postal codes seeded.");
}

seed()
  .catch((err) => {
    console.error("❌ Seed failed:", err);
    process.exit(1);
  })
  .finally(async () => {
    await client.end();
  });
