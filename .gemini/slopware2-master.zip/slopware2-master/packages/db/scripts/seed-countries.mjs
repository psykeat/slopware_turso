import postgres from "postgres";

const { DATABASE_URL } = process.env;
if (!DATABASE_URL) throw new Error("DATABASE_URL is not set");

const client = postgres(DATABASE_URL, { max: 1 });

const EU_COUNTRIES = [
  "AT",
  "BE",
  "BG",
  "CY",
  "CZ",
  "DE",
  "DK",
  "EE",
  "ES",
  "FI",
  "FR",
  "GR",
  "HR",
  "HU",
  "IE",
  "IT",
  "LT",
  "LU",
  "LV",
  "MT",
  "NL",
  "PL",
  "PT",
  "RO",
  "SE",
  "SI",
  "SK",
];

async function seed() {
  console.log("🚀 Fetching countries...");
  const response = await fetch(
    "https://raw.githubusercontent.com/stefangabos/world_countries/master/data/countries/_combined/countries.csv",
  );
  if (!response.ok) {
    throw new Error(`Failed to fetch: ${response.statusText}`);
  }
  const text = await response.text();
  const lines = text.split("\n");

  // Header: id,alpha2,alpha3,ar,bg,br,cs,da,de,el,en,eo,es,et,eu,fa,fi,fr,hr,hu,hy,it,ja,ko,lt,nl,no,pl,pt,ro,ru,sk,sl,sr,sv,th,tr,uk,zh,zh-tw
  // Index (0-based): 1=alpha2, 2=alpha3, 8=de, 10=en

  const data = lines.slice(1).filter((line) => line.trim().length > 0);

  console.log(`📦 Processing ${data.length} countries...`);

  const values = data
    .map((line) => {
      const cols = line.split(",");
      const iso2 = cols[1]?.toUpperCase() || null;
      const iso3 = cols[2]?.toUpperCase() || null;
      const de = cols[8] || "";
      const en = cols[10] || "";

      return {
        iso2_code: iso2,
        iso3_code: iso3,
        name: JSON.stringify({ de, en }),
        is_eu: EU_COUNTRIES.includes(iso2),
        is_active: true,
      };
    })
    .filter((v) => v.iso2_code && v.iso3_code);

  // Batch insert
  const BATCH_SIZE = 100;
  for (let i = 0; i < values.length; i += BATCH_SIZE) {
    const batch = values.slice(i, i + BATCH_SIZE);
    await client`
      INSERT INTO country
      ${client(batch, "iso2_code", "iso3_code", "name", "is_eu", "is_active")}
      ON CONFLICT (iso2_code) DO UPDATE SET
        iso3_code = EXCLUDED.iso3_code,
        name = EXCLUDED.name,
        is_eu = EXCLUDED.is_eu
    `;
    console.log(
      `✅ Inserted batch ${Math.floor(i / BATCH_SIZE) + 1} / ${Math.ceil(values.length / BATCH_SIZE)}`,
    );
  }

  console.log("🎉 Countries seeded.");
}

seed()
  .catch((err) => {
    console.error("❌ Seed failed:", err);
    process.exit(1);
  })
  .finally(async () => {
    await client.end();
  });
