import postgres from "postgres";

const { DATABASE_URL } = process.env;
if (!DATABASE_URL) throw new Error("DATABASE_URL is not set");

const client = postgres(DATABASE_URL, { max: 1 });

async function seed() {
  console.log("🚀 Fetching currencies...");
  const response = await fetch(
    "https://raw.githubusercontent.com/datasets/currency-codes/main/data/codes-all.csv",
  );
  if (!response.ok) {
    throw new Error(`Failed to fetch: ${response.statusText}`);
  }
  const text = await response.text();
  const lines = text.split("\n");

  // Header: Entity,Currency,AlphabeticCode,NumericCode,MinorUnit,WithdrawalDate
  const data = lines.slice(1).filter((line) => line.trim().length > 0);

  console.log(`📦 Processing ${data.length} entries...`);

  const currencyMap = new Map();

  for (const line of data) {
    // Basic CSV split - names might have commas but usually ISO CSVs use quotes if so.
    // This dataset seems simple enough.
    const cols = line.split(",");
    const code = cols[2]?.trim();
    const nameStr = cols[1]?.trim();
    const decimals = parseInt(cols[4]?.trim()) || 2;
    const withdrawn = cols[5]?.trim();

    if (!code || withdrawn || code.length !== 3) continue;

    if (!currencyMap.has(code)) {
      currencyMap.set(code, {
        code,
        name: JSON.stringify({ en: nameStr, de: nameStr }),
        decimals: decimals,
        is_active: true,
      });
    }
  }

  const values = Array.from(currencyMap.values());

  // Batch insert
  const BATCH_SIZE = 100;
  for (let i = 0; i < values.length; i += BATCH_SIZE) {
    const batch = values.slice(i, i + BATCH_SIZE);
    await client`
      INSERT INTO currency
      ${client(batch, "code", "name", "decimals", "is_active")}
      ON CONFLICT (code) DO UPDATE SET
        name = EXCLUDED.name,
        decimals = EXCLUDED.decimals
    `;
    console.log(
      `✅ Inserted batch ${Math.floor(i / BATCH_SIZE) + 1} / ${Math.ceil(values.length / BATCH_SIZE)}`,
    );
  }

  console.log("🎉 Currencies seeded.");
}

seed()
  .catch((err) => {
    console.error("❌ Seed failed:", err);
    process.exit(1);
  })
  .finally(async () => {
    await client.end();
  });
