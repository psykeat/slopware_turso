import postgres from "postgres";

const { DATABASE_URL } = process.env;
if (!DATABASE_URL) throw new Error("DATABASE_URL is not set");

const client = postgres(DATABASE_URL, { max: 1 });

async function seed() {
  console.log("🚀 Fetching German postal codes...");
  const response = await fetch(
    "https://gist.githubusercontent.com/jbspeakr/4565964/raw/German-Zip-Codes.csv",
  );
  if (!response.ok) {
    throw new Error(`Failed to fetch: ${response.statusText}`);
  }
  const text = await response.text();
  const lines = text.split("\n");

  // Skip header
  const data = lines.slice(1).filter((line) => line.trim().length > 0);

  console.log(`📦 Processing ${data.length} entries...`);

  const values = data
    .map((line) => {
      const [ort, zusatz, plz, vorwahl, bundesland] = line.split(";");

      // Fix common typos or encoding issues if any
      let state = bundesland?.trim() || null;
      if (state === "Schlewig-Holstein") state = "Schleswig-Holstein";

      // Combine city and zusatz if zusatz exists
      let city = ort?.trim() || "";
      if (zusatz && zusatz.trim()) {
        city = `${city} (${zusatz.trim()})`;
      }

      return {
        country_code: "DE",
        plz: plz?.trim() || "",
        city: city,
        state: state,
      };
    })
    .filter((v) => v.plz && v.city);

  // Batch insert
  const BATCH_SIZE = 1000;
  for (let i = 0; i < values.length; i += BATCH_SIZE) {
    const batch = values.slice(i, i + BATCH_SIZE);
    try {
      await client`
        INSERT INTO postal_code
        ${client(batch, "country_code", "plz", "city", "state")}
        ON CONFLICT (country_code, plz, city, state) DO NOTHING
      `;
      console.log(
        `✅ Inserted batch ${Math.floor(i / BATCH_SIZE) + 1} / ${Math.ceil(values.length / BATCH_SIZE)}`,
      );
    } catch (err) {
      console.error(`❌ Batch ${Math.floor(i / BATCH_SIZE) + 1} failed:`, err.message);
      // If a batch fails, try smaller batches or just log and continue if appropriate
      // For seeds, we usually want to know what failed.
    }
  }

  console.log("🎉 German postal codes seeded.");
}

seed()
  .catch((err) => {
    console.error("❌ Seed failed:", err);
    process.exit(1);
  })
  .finally(async () => {
    await client.end();
  });
