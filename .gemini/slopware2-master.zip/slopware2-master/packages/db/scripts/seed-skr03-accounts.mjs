import postgres from "postgres";

const BASE_TENANT_ID = "00000000-0000-0000-0000-000000000002";

const { DATABASE_URL } = process.env;
if (!DATABASE_URL) throw new Error("DATABASE_URL is not set");

const client = postgres(DATABASE_URL, { max: 1 });

async function seed() {
  console.log("🚀 Fetching SKR03 template...");
  const response = await fetch(
    "https://raw.githubusercontent.com/KDE/kmymoney/master/kmymoney/templates/de_DE/skr03.kmt",
  );
  if (!response.ok) {
    throw new Error(`Failed to fetch: ${response.statusText}`);
  }
  const xml = await response.text();

  console.log("🔍 Finding base company...");
  const existing = await client`
    SELECT company_id FROM company WHERE tenant_id = ${BASE_TENANT_ID} LIMIT 1
  `;
  const companyId = existing.length ? existing[0].company_id : null;

  if (!companyId) {
    throw new Error("Base company not found. Run postmigrate first.");
  }

  console.log("📦 Parsing accounts...");
  const accountRegex = /<account type="(\d+)" name="([^"]*)"/g;
  let match;
  const accounts = [];

  while ((match = accountRegex.exec(xml)) !== null) {
    const type = match[1];
    const fullName = match[2];

    // Check if starts with 4 digits
    const accountMatch = fullName.match(/^(\d{4})\s+(.*)$/);
    if (accountMatch) {
      accounts.push({
        tenant_id: BASE_TENANT_ID,
        company_id: companyId,
        account_no: accountMatch[1],
        name: accountMatch[2],
        account_type: type,
        is_active: true,
      });
    }
  }

  console.log(`✨ Found ${accounts.length} valid accounts.`);

  // Batch insert
  const BATCH_SIZE = 500;
  for (let i = 0; i < accounts.length; i += BATCH_SIZE) {
    const batch = accounts.slice(i, i + BATCH_SIZE);
    await client`
      INSERT INTO gl_account
      ${client(batch, "tenant_id", "company_id", "account_no", "name", "account_type", "is_active")}
      ON CONFLICT (tenant_id, account_no) DO UPDATE SET
        name = EXCLUDED.name,
        account_type = EXCLUDED.account_type
    `;
    console.log(
      `✅ Inserted batch ${Math.floor(i / BATCH_SIZE) + 1} / ${Math.ceil(accounts.length / BATCH_SIZE)}`,
    );
  }

  console.log("🎉 SKR03 accounts seeded.");
}

seed()
  .catch((err) => {
    console.error("❌ Seed failed:", err);
    process.exit(1);
  })
  .finally(async () => {
    await client.end();
  });
