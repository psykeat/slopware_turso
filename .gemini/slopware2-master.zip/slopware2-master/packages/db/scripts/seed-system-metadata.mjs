import { getTableColumns, getTableName } from "drizzle-orm";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";

import * as schema from "../src/schema/index.js";

const { DATABASE_URL } = process.env;
if (!DATABASE_URL) throw new Error("DATABASE_URL is not set");

const client = postgres(DATABASE_URL, { max: 1 });
const db = drizzle(client);

function toTitleCase(str) {
  return str
    .replace(/([A-Z])/g, " $1")
    .replace(/[_-]/g, " ")
    .replace(/^\s+|\s+$/g, "")
    .split(" ")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(" ");
}

const TYPE_MAP = {
  PgUUID: "uuid",
  PgVarchar: "varchar",
  PgChar: "varchar",
  PgText: "text",
  PgInteger: "integer",
  PgNumeric: "numeric",
  PgBoolean: "boolean",
  PgTimestamp: "timestamp",
  PgDate: "date",
  PgJsonb: "jsonb",
};

const HELPER_TABLE_REGISTRY = [
  { tableName: "organization", pk: "organization_id", display: "name", code: "slug" },
  { tableName: "tenant", pk: "tenant_id", display: "name", code: "slug" },
  { tableName: "company", pk: "company_id", display: "name", code: "company_no" },
  { tableName: "address", pk: "address_id", display: "name", code: "address_no" },
  { tableName: "article", pk: "article_id", display: "name", code: "article_no" },
  { tableName: "currency", pk: "currency_id", display: "name", code: "code" },
  { tableName: "country", pk: "country_id", display: "name", code: "iso2_code" },
  { tableName: "warehouse", pk: "warehouse_id", display: "name", code: "code" },
  { tableName: "unit", pk: "unit_id", display: "name", code: "code" },
  { tableName: "tax_class", pk: "tax_class_id", display: "name", code: "code", isI18n: true },
  { tableName: "tax_code", pk: "tax_code_id", display: "code", code: "tax_rate" },
  { tableName: "gl_account", pk: "gl_account_id", display: "name", code: "account_no" },
  { tableName: "cost_center", pk: "cost_center_id", display: "name", code: "code" },
  { tableName: "payment_term", pk: "payment_term_id", display: "name", code: "code" },
  { tableName: "shipping_method", pk: "shipping_method_id", display: "name", code: "code" },
  { tableName: "article_group", pk: "article_group_id", display: "name", code: "code" },
  { tableName: "document_group", pk: "document_group_id", display: "name", code: "name" },
  { tableName: "address_category", pk: "category_id", display: "name", code: "name" },
  { tableName: "industry", pk: "industry_id", display: "name", code: "name" },
  { tableName: "price_list", pk: "price_list_id", display: "name", code: "name" },
  { tableName: "discount_group", pk: "discount_group_id", display: "name", code: "name" },
  { tableName: "app_user", pk: "user_id", display: "display_name", code: "email" },
  { tableName: "document_type", pk: "document_type_id", display: "name", code: "code" },
];

async function seed() {
  console.log("🚀 Starting Dynamic Metadata Sync...");
  await client`SELECT 1`;
  console.log("🔗 Connected.");

  const tables = Object.values(schema).filter((s) => s && s[Symbol.for("drizzle:IsDrizzleTable")]);
  const stats = { tables: 0, fields: 0, lookups: 0 };

  for (const table of tables) {
    const tableName = getTableName(table);
    if (["account", "session", "verification", "user"].includes(tableName)) continue;

    console.log(`📦 Processing: ${tableName}`);
    stats.tables++;

    const helperEntry = HELPER_TABLE_REGISTRY.find((h) => h.tableName === tableName);
    if (helperEntry) {
      await client`
        INSERT INTO "helper_table_registry" 
          (table_name, label, pk_column, display_column, display_is_i18n, code_column, sort_column, is_tenant_scoped)
        VALUES (
          ${tableName}, 
          ${JSON.stringify({ de: toTitleCase(tableName), en: toTitleCase(tableName) })}, 
          ${helperEntry.pk}, 
          ${helperEntry.display}, 
          ${helperEntry.isI18n ?? false}, 
          ${helperEntry.code}, 
          ${helperEntry.display}, 
          true
        )
        ON CONFLICT (table_name) DO UPDATE SET
          pk_column = EXCLUDED.pk_column,
          display_column = EXCLUDED.display_column,
          code_column = EXCLUDED.code_column
      `;
      stats.lookups++;
    }

    const columns = getTableColumns(table);
    const fks = table[Symbol.for("drizzle:PgInlineForeignKeys")] || [];
    let order = 10;

    for (const [colKey, col] of Object.entries(columns)) {
      const fieldName = col.name;
      if (
        ["tenant_id", "created_at", "updated_at", "deleted_at", "custom_attributes"].includes(
          fieldName,
        )
      )
        continue;
      if (col.primary && fieldName.endsWith("_id")) continue;

      const fieldType = TYPE_MAP[col.columnType] || "varchar";
      const label = toTitleCase(fieldName);

      let lookupTable = null;
      const fk = fks.find((f) => f.reference().columns[0].name === fieldName);
      if (fk) {
        lookupTable = fk.reference().foreignTable[Symbol.for("drizzle:Name")];
        if (["tenant", "organization"].includes(lookupTable)) lookupTable = null;
      }

      await client`
        DELETE FROM "tenant_fields"
        WHERE entity_name = ${tableName} AND field_name = ${fieldName} AND scope = 'global'
      `;

      await client`
        INSERT INTO "tenant_fields"
          (scope, entity_name, field_name, field_type, label, is_visible, display_order, lookup_table)
        VALUES (
          'global', ${tableName}, ${fieldName}, ${fieldType}, 
          ${JSON.stringify({ de: label, en: label })}, 
          true, ${order}, ${lookupTable}
        )
      `;

      order += 10;
      stats.fields++;
    }
  }
  console.log(`✅ Done! ${stats.tables} tables, ${stats.fields} fields, ${stats.lookups} lookups.`);
}

seed()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(() => client.end());
