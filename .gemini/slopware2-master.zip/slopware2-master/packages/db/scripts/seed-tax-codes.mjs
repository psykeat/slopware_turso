import postgres from "postgres";

const BASE_TENANT_ID = "00000000-0000-0000-0000-000000000002";

const { DATABASE_URL } = process.env;
if (!DATABASE_URL) throw new Error("DATABASE_URL is not set");

const client = postgres(DATABASE_URL, { max: 1 });

const TAX_CODES = [
  // Germany (DE)
  { code: "DE_99", description: "Vorsteuer 19% (Standard)", rate: 19 },
  { code: "DE_98", description: "Vorsteuer 7% (Ermäßigt)", rate: 7 },
  { code: "DE_101", description: "USt 19% (Inland steuerbar)", rate: 19 },
  { code: "DE_103", description: "USt 7% (Inland ermäßigt)", rate: 7 },
  { code: "DE_8", description: "IG-Lieferung (Steuerfrei innergem.)", rate: 0 },
  { code: "DE_9", description: "IG-Erwerb (Steuerfrei innergem.)", rate: 0 },
  { code: "DE_94", description: "EU-Dienstleistung (§13b RC)", rate: 19 },
  { code: "DE_7", description: "Export/Drittland (Steuerfrei)", rate: 0 },
  { code: "DE_A9", description: "IG-USt abführen (AT/EU)", rate: 0 },

  // Austria (AT)
  { code: "AT_9", description: "Vorsteuer 20% (Standard)", rate: 20 },
  { code: "AT_6", description: "Vorsteuer 13%", rate: 13 },
  { code: "AT_8", description: "Vorsteuer 10%", rate: 10 },
  { code: "AT_101", description: "USt 20% (Inland steuerbar)", rate: 20 },
  { code: "AT_13", description: "USt 13% (Inland)", rate: 13 },
  { code: "AT_10", description: "USt 10% (Inland)", rate: 10 },
  { code: "AT_11", description: "IG-Lieferung (Steuerfrei innergem.)", rate: 0 },
  { code: "AT_19", description: "IG-Erwerb 20% (Steuerpflichtig)", rate: 20 },
  { code: "AT_16", description: "IG-Erwerb 13% (Steuerpflichtig)", rate: 13 },
  { code: "AT_94", description: "EU-Dienstleistung (RC)", rate: 20 },
  { code: "AT_01", description: "Export/Drittland (Steuerfrei)", rate: 0 },
  { code: "AT_10_EU", description: "Nicht steuerbare EU-Leistung", rate: 0 },
];

async function seed() {
  console.log("🚀 Seeding DE/AT tax codes...");

  for (const tc of TAX_CODES) {
    await client`
      INSERT INTO tax_code (tenant_id, code, description, tax_rate, is_active)
      VALUES (${BASE_TENANT_ID}, ${tc.code}, ${tc.description}, ${tc.rate}, true)
      ON CONFLICT (tenant_id, code) DO UPDATE SET
        description = EXCLUDED.description,
        tax_rate = EXCLUDED.tax_rate
    `;
  }

  console.log(`🎉 Seeded ${TAX_CODES.length} tax codes.`);
}

seed()
  .catch((err) => {
    console.error("❌ Seed failed:", err);
    process.exit(1);
  })
  .finally(async () => {
    await client.end();
  });
