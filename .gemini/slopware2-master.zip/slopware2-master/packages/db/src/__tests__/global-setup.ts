import { pool } from "../index";

const TEST_ORG_ID = "00000000-0000-0000-0000-000000000009";
const TEST_TENANT_ID = "00000000-0000-0000-0000-000000000010";
const TEST_COMPANY_ID = "00000000-0000-0000-0000-000000000020";

export async function setup() {
  try {
    await pool`INSERT INTO organization (organization_id, slug, name, is_active) VALUES (${TEST_ORG_ID}, 'test-org', 'Test Org', true) ON CONFLICT (organization_id) DO UPDATE SET name = EXCLUDED.name`;
    await pool`INSERT INTO tenant (tenant_id, organization_id, slug, name, is_active) VALUES (${TEST_TENANT_ID}, ${TEST_ORG_ID}, 'test-tenant', 'Test Tenant', true) ON CONFLICT (tenant_id) DO UPDATE SET name = EXCLUDED.name`;
    await pool`INSERT INTO company (company_id, tenant_id, company_no, name, country_code, currency_id, is_active) VALUES (${TEST_COMPANY_ID}, ${TEST_TENANT_ID}, 'TC001', 'Test Company', 'DE', 'EUR', true) ON CONFLICT (company_id) DO UPDATE SET name = EXCLUDED.name`;
    console.log("✅ Integration test seed data ready");
  } catch (err) {
    console.error("❌ Integration test setup failed:", (err as Error).message);
    throw err;
  }
}

export async function teardown() {
  try {
    await pool`DELETE FROM company WHERE company_id = ${TEST_COMPANY_ID}`;
    await pool`DELETE FROM tenant WHERE tenant_id = ${TEST_TENANT_ID}`;
    await pool`DELETE FROM organization WHERE organization_id = ${TEST_ORG_ID}`;
    await pool.end();
    console.log("✅ Integration test cleanup done");
  } catch (err) {
    console.error("⚠️  Integration test cleanup failed:", (err as Error).message);
  }
}
