import { describe, expect, it } from "vitest";

import { isValidColumn, getTableColumns } from "../../src/introspection";

describe("introspection", () => {
  it("finds country columns", () => {
    const cols = getTableColumns("country");
    expect(cols).toBeDefined();
    expect(cols?.has("iso2_code")).toBe(true);
    expect(cols?.has("iso3_code")).toBe(true);
    expect(cols?.has("name")).toBe(true);
    expect(cols?.has("is_active")).toBe(true);
    expect(cols?.has("country_id")).toBe(true);
  });

  it("validates columns", () => {
    expect(isValidColumn("country", "iso2_code")).toBe(true);
    expect(isValidColumn("country", "iso3_code")).toBe(true);
    expect(isValidColumn("country", "name")).toBe(true);
    expect(isValidColumn("country", "fake_col")).toBe(false);
  });
});
