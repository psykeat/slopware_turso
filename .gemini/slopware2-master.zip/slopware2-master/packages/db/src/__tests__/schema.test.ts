import { describe, it, expect } from "vitest";

import * as schema from "../schema";

describe("Schema completeness", () => {
  it("exports all system tables", () => {
    expect(schema.organization).toBeDefined();
    expect(schema.tenant).toBeDefined();
    expect(schema.appUser).toBeDefined();
    expect(schema.userTenant).toBeDefined();
    expect(schema.modules).toBeDefined();
    expect(schema.systemSettings).toBeDefined();
    expect(schema.entityCommands).toBeDefined();
    expect(schema.tenantFields).toBeDefined();
    expect(schema.tenantGroups).toBeDefined();
    expect(schema.tenantLayouts).toBeDefined();
    expect(schema.tenantRules).toBeDefined();
    expect(schema.helperTableRegistry).toBeDefined();
    expect(schema.schemaAnnotations).toBeDefined();
  });

  it("exports all master tables", () => {
    expect(schema.country).toBeDefined();
    expect(schema.currency).toBeDefined();
    expect(schema.unit).toBeDefined();
    expect(schema.postalCode).toBeDefined();
    expect(schema.incoterm).toBeDefined();
    expect(schema.industry).toBeDefined();
    expect(schema.company).toBeDefined();
    expect(schema.addressCategory).toBeDefined();
    expect(schema.address).toBeDefined();
    expect(schema.addressContact).toBeDefined();
    expect(schema.addressSeq).toBeDefined();
    expect(schema.articleGroup).toBeDefined();
    expect(schema.warehouse).toBeDefined();
    expect(schema.article).toBeDefined();
    expect(schema.articleBom).toBeDefined();
    expect(schema.bankAccount).toBeDefined();
    expect(schema.paymentTerm).toBeDefined();
    expect(schema.shippingMethod).toBeDefined();
    expect(schema.priceList).toBeDefined();
    expect(schema.priceListItem).toBeDefined();
    expect(schema.discountGroup).toBeDefined();
    expect(schema.taxClass).toBeDefined();
    expect(schema.taxCode).toBeDefined();
    expect(schema.taxRule).toBeDefined();
    expect(schema.costCenter).toBeDefined();
    expect(schema.glAccount).toBeDefined();
    expect(schema.accountDeterminationRule).toBeDefined();
    expect(schema.fiscalPeriod).toBeDefined();
  });

  it("exports all transaction tables", () => {
    expect(schema.documentType).toBeDefined();
    expect(schema.numberSequence).toBeDefined();
    expect(schema.documentGroup).toBeDefined();
    expect(schema.document).toBeDefined();
    expect(schema.documentLine).toBeDefined();
    expect(schema.serialNumber).toBeDefined();
    expect(schema.documentLineTracking).toBeDefined();
    expect(schema.inventoryBalance).toBeDefined();
    expect(schema.inventoryMovement).toBeDefined();
    expect(schema.journalEntry).toBeDefined();
    expect(schema.journalLine).toBeDefined();
    expect(schema.factSalesEvent).toBeDefined();
    expect(schema.factPurchaseEvent).toBeDefined();
    expect(schema.deliveryAddress).toBeDefined();
    expect(schema.productionOrder).toBeDefined();
  });

  it("exports all connector tables", () => {
    expect(schema.connectorDefinition).toBeDefined();
    expect(schema.tenantConnector).toBeDefined();
    expect(schema.tenantConnectorMapping).toBeDefined();
    expect(schema.importBatch).toBeDefined();
    expect(schema.importRow).toBeDefined();
  });

  it("exports all views", () => {
    expect(schema.currentTenantCtx).toBeDefined();
    expect(schema.effectiveFields).toBeDefined();
    expect(schema.effectiveLayout).toBeDefined();
    expect(schema.effectiveRules).toBeDefined();
    expect(schema.effectiveSettings).toBeDefined();
  });

  it("exports all relations parts", () => {
    expect(schema.systemRelations).toBeDefined();
    expect(schema.masterRelations).toBeDefined();
    expect(schema.transactionRelations).toBeDefined();
    expect(schema.connectorRelations).toBeDefined();
    expect(schema.authRelations).toBeDefined();
    expect(schema.relations).not.toBeNull();
  });

  it("tenantFields has all expected columns", () => {
    const cols = Object.keys(schema.tenantFields);
    expect(cols).toContain("fieldId");
    expect(cols).toContain("scope");
    expect(cols).toContain("entityName");
    expect(cols).toContain("fieldName");
    expect(cols).toContain("fieldType");
    expect(cols).toContain("isRequired");
    expect(cols).toContain("isVisible");
    expect(cols).toContain("groupId");
    expect(cols).toContain("lookupTable");
    expect(cols).toContain("importColumn");
    expect(cols).toContain("importType");
  });

  it("systemSettings has scope-based unique indexes via RLS", () => {
    const cols = Object.keys(schema.systemSettings);
    expect(cols).toContain("settingId");
    expect(cols).toContain("scope");
    expect(cols).toContain("organizationId");
    expect(cols).toContain("tenantId");
    expect(cols).toContain("key");
    expect(cols).toContain("value");
  });

  it("effectiveFields view is defined", () => {
    expect(schema.effectiveFields).toBeDefined();
    expect(typeof schema.effectiveFields).toBe("object");
  });

  it("effectiveSettings view is defined", () => {
    expect(schema.effectiveSettings).toBeDefined();
    expect(typeof schema.effectiveSettings).toBe("object");
  });

  it("currentTenantCtx view is defined", () => {
    expect(schema.currentTenantCtx).toBeDefined();
    expect(typeof schema.currentTenantCtx).toBe("object");
  });

  it("appUser has role column", () => {
    const cols = Object.keys(schema.appUser);
    expect(cols).toContain("userId");
    expect(cols).toContain("email");
    expect(cols).toContain("isSystemAdmin");
    expect(cols).toContain("role");
  });

  it("document has dueDate column", () => {
    const cols = Object.keys(schema.document);
    expect(cols).toContain("dueDate");
  });

  it("schema_annotations has moduleId and dataClass columns", () => {
    const cols = Object.keys(schema.schemaAnnotations);
    expect(cols).toContain("moduleId");
    expect(cols).toContain("dataClass");
    expect(cols).toContain("tableName");
    expect(cols).toContain("columnName");
  });

  it("import_batch has sourceBatchId column", () => {
    const cols = Object.keys(schema.importBatch);
    expect(cols).toContain("sourceBatchId");
    expect(cols).toContain("batchId");
  });

  it("modules table has slug and label columns", () => {
    const cols = Object.keys(schema.modules);
    expect(cols).toContain("moduleId");
    expect(cols).toContain("slug");
    expect(cols).toContain("label");
  });

  it("tenant isolation scope function is used on metadata tables", () => {
    const metadataTables = [
      schema.systemSettings,
      schema.entityCommands,
      schema.tenantFields,
      schema.tenantGroups,
      schema.tenantLayouts,
      schema.tenantRules,
    ];
    for (const table of metadataTables) {
      const cols = Object.keys(table);
      expect(cols).toContain("scope");
      expect(cols).toContain("organizationId");
      expect(cols).toContain("tenantId");
    }
  });
});
