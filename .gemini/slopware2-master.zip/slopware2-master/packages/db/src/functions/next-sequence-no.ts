import { sql } from "drizzle-orm";

// Stub for a stored procedure that will be implemented soon
export const nextSequenceNo = (tenantId: string, companyId: string, docType: string) => {
  return sql`next_sequence_no(${tenantId}::uuid, ${companyId}::uuid, ${docType}::char)`;
};
