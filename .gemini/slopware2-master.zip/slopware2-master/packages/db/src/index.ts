import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";

import { authRelations } from "./schema/auth";
export * from "./functions";
export { isValidColumn, getTableColumns } from "./introspection";

const DATABASE_URL =
  process.env.DATABASE_URL || "postgresql://postgres:bvh9j35v@localhost:5432/slopware2";

const pool = postgres(DATABASE_URL, {
  max: 10,
  idle_timeout: 20,
  connect_timeout: 10,
});

export const db = drizzle({ client: pool, relations: authRelations });
export { pool };

// Probe on startup so a missing DB container fails loudly instead of hiding inside the first request.
pool`SELECT 1`
  .then(() => {
    const safeUrl = DATABASE_URL.replace(/:([^:@]+)@/, ":***@");
    console.log(`[DB] Connected: ${safeUrl}`);
  })
  .catch((err: { code?: string; message?: string }) => {
    console.error(`[DB] ⚠️  Cannot reach database (${err.code ?? err.message})`);
    console.error(
      "[DB] Is the DB container running? Check DATABASE_URL and run: docker compose up -d",
    );
  });
