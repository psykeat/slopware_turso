import * as schema from "./schema";

const DRIZZLE_NAME = Object.getOwnPropertySymbols(schema.user ?? {}).find(
  (s) => s.description === "drizzle:Name",
);
const DRIZZLE_COLUMNS = Object.getOwnPropertySymbols(schema.user ?? {}).find(
  (s) => s.description === "drizzle:Columns",
);
const DRIZZLE_IS_TABLE = Object.getOwnPropertySymbols(schema.user ?? {}).find(
  (s) => s.description === "drizzle:IsDrizzleTable",
);

type DrizzleTable = {
  [sym: symbol]: unknown;
  [key: string]: unknown;
};

type DrizzleColumn = {
  name?: string;
};

const TABLE_COLUMNS = new Map<string, Set<string>>();

for (const val of Object.values(schema)) {
  const table = val as DrizzleTable | undefined;
  if (!table || typeof table !== "object") continue;
  if (DRIZZLE_IS_TABLE && table[DRIZZLE_IS_TABLE] !== true) continue;
  if (!DRIZZLE_NAME) continue;

  const tableName = table[DRIZZLE_NAME] as string | undefined;
  if (!tableName) continue;

  const columns = new Set<string>();
  if (DRIZZLE_COLUMNS && table[DRIZZLE_COLUMNS]) {
    const colMap = table[DRIZZLE_COLUMNS] as Record<string, DrizzleColumn>;
    for (const col of Object.values(colMap)) {
      if (col?.name) {
        columns.add(col.name);
      }
    }
  }
  TABLE_COLUMNS.set(tableName, columns);
}

export function getTableColumns(tableName: string): Set<string> | undefined {
  return TABLE_COLUMNS.get(tableName);
}

export function isValidColumn(tableName: string, column: string): boolean {
  return TABLE_COLUMNS.get(tableName)?.has(column) ?? false;
}
