import { sql } from "drizzle-orm";
import {
  pgTable,
  uuid,
  varchar,
  timestamp,
  jsonb,
  text,
  index,
  pgPolicy,
} from "drizzle-orm/pg-core";

const tenantIsolationScope = (t: { tenantId: any }) =>
  sql`${t.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`;

export const auditEvent = pgTable(
  "audit_event",
  {
    auditEventId: uuid("audit_event_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id").notNull(),
    userId: text("user_id"),
    eventType: varchar("event_type", { length: 64 }).notNull(),
    severity: varchar("severity", { length: 16 }).notNull().default("info"),
    message: text("message").notNull(),
    traceId: varchar("trace_id", { length: 64 }),
    data: jsonb("data"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("idx_audit_event_tenant").on(table.tenantId),
    index("idx_audit_event_type").on(table.eventType),
    index("idx_audit_event_trace").on(table.traceId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: tenantIsolationScope(table),
      withCheck: tenantIsolationScope(table),
    }),
  ],
).enableRLS();
