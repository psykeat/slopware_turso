import { defineRelationsPart, sql } from "drizzle-orm";
import {
  pgTable,
  pgPolicy,
  uuid,
  varchar,
  boolean,
  timestamp,
  jsonb,
  integer,
  text,
  unique,
  check,
} from "drizzle-orm/pg-core";

import { tenant } from "./system";

export const connectorDefinition = pgTable(
  "connector_definition",
  {
    connectorId: uuid("connector_id").primaryKey().defaultRandom(),
    slug: varchar("slug").notNull().unique(),
    label: jsonb("label").notNull(),
    scriptPath: text("script_path"),
    defaultMappings: jsonb("default_mappings").notNull().default({}),
    lockedFields: jsonb("locked_fields").notNull().default([]),
    atomicityMode: varchar("atomicity_mode").notNull(),
  },
  (table) => [
    check(
      "connector_definition_atomicity_mode_check",
      sql`${table.atomicityMode} IN ('file', 'entity', 'run')`,
    ),
  ],
);

export const tenantConnector = pgTable(
  "tenant_connector",
  {
    tenantConnectorId: uuid("tenant_connector_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    connectorId: uuid("connector_id")
      .notNull()
      .references(() => connectorDefinition.connectorId),
    credentials: jsonb("credentials").notNull().default({}),
    isActive: boolean("is_active").notNull().default(true),
    cronExpression: text("cron_expression"),
    lastRunAt: timestamp("last_run_at", { withTimezone: true }),
    nextRunAt: timestamp("next_run_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const tenantConnectorMapping = pgTable(
  "tenant_connector_mapping",
  {
    mappingId: uuid("mapping_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    tenantConnectorId: uuid("tenant_connector_id")
      .notNull()
      .references(() => tenantConnector.tenantConnectorId),
    sourceField: varchar("source_field").notNull(),
    targetTable: varchar("target_table").notNull(),
    targetColumn: varchar("target_column").notNull(),
    transform: jsonb("transform").notNull().default({ type: "direct" }),
    defaultValue: jsonb("default_value"),
  },
  (table) => [
    unique().on(table.tenantConnectorId, table.sourceField),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const importBatch = pgTable(
  "import_batch",
  {
    batchId: uuid("batch_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    connectorId: uuid("connector_id").references(() => connectorDefinition.connectorId),
    atomicityMode: varchar("atomicity_mode").notNull(),
    status: varchar("status").notNull().default("pending"),
    isRerun: boolean("is_rerun").notNull().default(false),
    sourceBatchId: uuid("source_batch_id"),
    postedEntityCount: integer("posted_entity_count").notNull().default(0),
    errorSummary: jsonb("error_summary"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    processedAt: timestamp("processed_at", { withTimezone: true }),
    targetEntity: varchar("target_entity"),
    targetCommandKey: varchar("target_command_key"),
  },
  (table) => [
    check(
      "import_batch_atomicity_mode_check",
      sql`${table.atomicityMode} IN ('file', 'entity', 'run')`,
    ),
    check(
      "import_batch_status_check",
      sql`${table.status} IN ('pending', 'validating', 'approved', 'posted', 'failed', 'rejected')`,
    ),
    // Self-referential FK handled in migration (Drizzle circular ref limitation)
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const importRow = pgTable(
  "import_row",
  {
    rowId: uuid("row_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    batchId: uuid("batch_id")
      .notNull()
      .references(() => importBatch.batchId),
    targetEntity: varchar("target_entity").notNull(),
    payload: jsonb("payload").notNull(),
    status: varchar("status").notNull().default("pending"),
    errorDetail: jsonb("error_detail"),
    postedAt: timestamp("posted_at", { withTimezone: true }),
  },
  (table) => [
    check("import_row_status_check", sql`${table.status} IN ('pending', 'posted', 'failed')`),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const connectorRelations = defineRelationsPart(
  {
    tenant,
    connectorDefinition,
    tenantConnector,
    tenantConnectorMapping,
    importBatch,
    importRow,
  },
  (r) => ({
    tenantConnector: {
      tenant: r.one.tenant({ from: r.tenantConnector.tenantId, to: r.tenant.tenantId }),
      definition: r.one.connectorDefinition({
        from: r.tenantConnector.connectorId,
        to: r.connectorDefinition.connectorId,
      }),
    },
  }),
);
