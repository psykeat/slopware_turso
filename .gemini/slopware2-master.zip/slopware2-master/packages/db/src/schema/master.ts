import { defineRelationsPart, sql } from "drizzle-orm";
import {
  pgTable,
  uuid,
  varchar,
  boolean,
  timestamp,
  jsonb,
  integer,
  text,
  index,
  unique,
  char,
  numeric,
  date,
  check,
  pgPolicy,
  foreignKey,
} from "drizzle-orm/pg-core";

import { tenant, organization, appUser } from "./system";

export const country = pgTable("country", {
  countryId: uuid("country_id").primaryKey().defaultRandom(),
  iso2Code: varchar("iso2_code", { length: 2 }).notNull().unique(),
  iso3Code: varchar("iso3_code", { length: 3 }).notNull().unique(),
  name: jsonb("name").notNull(),
  isEu: boolean("is_eu").notNull().default(false),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const currency = pgTable("currency", {
  currencyId: uuid("currency_id").primaryKey().defaultRandom(),
  code: varchar("code", { length: 3 }).notNull().unique(),
  name: jsonb("name").notNull(),
  symbol: varchar("symbol", { length: 5 }),
  decimals: integer("decimals").notNull().default(2),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const unit = pgTable(
  "unit",
  {
    unitId: uuid("unit_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    code: varchar("code", { length: 10 }).notNull(),
    name: jsonb("name").notNull(),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    customAttributes: jsonb("custom_attributes"),
  },
  (table) => [
    unique().on(table.tenantId, table.code),
    index("idx_unit_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const postalCode = pgTable(
  "postal_code",
  {
    postalCodeId: uuid("postal_code_id").primaryKey().defaultRandom(),
    countryCode: varchar("country_code", { length: 2 }).notNull(),
    plz: varchar("plz").notNull(),
    city: varchar("city").notNull(),
    state: varchar("state"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    unique().on(table.countryCode, table.plz, table.city, table.state),
    index("idx_postal_code_lookup").on(table.countryCode, table.plz),
  ],
);

export const incoterm = pgTable("incoterm", {
  incotermId: uuid("incoterm_id").primaryKey().defaultRandom(),
  code: char("code", { length: 3 }).notNull().unique(),
  name: varchar("name").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const industry = pgTable(
  "industry",
  {
    industryId: uuid("industry_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    name: jsonb("name").notNull(),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    customAttributes: jsonb("custom_attributes"),
  },
  (table) => [
    unique().on(table.tenantId, table.name),
    index("idx_industry_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const company = pgTable(
  "company",
  {
    companyId: uuid("company_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyNo: varchar("company_no").notNull(),
    name: varchar("name").notNull(),
    legalName: varchar("legal_name"),
    countryCode: char("country_code", { length: 2 }).notNull(),
    currencyId: char("currency_id", { length: 3 }).notNull(),
    vatId: varchar("vat_id"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    addressLine1: varchar("address_line_1"),
    addressLine2: varchar("address_line_2"),
    city: varchar("city"),
    postalCode: varchar("postal_code"),
    phoneLandline: varchar("phone_landline"),
    phoneMobile: varchar("phone_mobile"),
    email: varchar("email"),
    homepage: varchar("homepage"),
    taxNumber: varchar("tax_number"),
    taxAuthority: varchar("tax_authority"),
    gln: varchar("gln"),
    eoriNo: varchar("eori_no"),
    dunsNo: varchar("duns_no"),
    customAttributes: jsonb("custom_attributes"),
    bankName: varchar("bank_name"),
    bankBic: varchar("bank_bic"),
    bankIban: varchar("bank_iban"),
    fiscalYearStartMonth: integer("fiscal_year_start_month").notNull().default(1),
  },
  (table) => [
    unique().on(table.tenantId, table.companyId),
    unique().on(table.tenantId, table.companyNo),
    index("idx_company_tenant").on(table.tenantId),
    index("idx_company_tenant_active").on(table.tenantId, table.isActive),
    check(
      "company_fiscal_year_start_month_check",
      sql`${table.fiscalYearStartMonth} >= 1 AND ${table.fiscalYearStartMonth} <= 12`,
    ),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const addressCategory = pgTable(
  "address_category",
  {
    categoryId: uuid("category_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    name: jsonb("name").notNull(),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    customAttributes: jsonb("custom_attributes"),
  },
  (table) => [
    unique().on(table.tenantId, table.name),
    index("idx_address_category_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const address = pgTable(
  "address",
  {
    addressId: uuid("address_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    addressNo: varchar("address_no").notNull(),
    addressType: varchar("address_type").notNull(),
    isCustomer: boolean("is_customer").notNull().default(false),
    isSupplier: boolean("is_supplier").notNull().default(false),
    companyName: varchar("company_name"),
    firstName: varchar("first_name"),
    lastName: varchar("last_name"),
    addressLine1: varchar("address_line_1").notNull(),
    addressLine2: varchar("address_line_2"),
    postalCode: varchar("postal_code").notNull(),
    city: varchar("city").notNull(),
    stateProvince: varchar("state_province"),
    countryCode: char("country_code", { length: 2 }).notNull(),
    vatId: varchar("vat_id"),
    taxClassId: uuid("tax_class_id"), // Will link later
    currencyId: char("currency_id", { length: 3 }),
    paymentTermId: uuid("payment_term_id"), // Will link later
    isActive: boolean("is_active").notNull().default(true),
    archivedAt: timestamp("archived_at", { withTimezone: true }),
    customAttributes: jsonb("custom_attributes"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }),
    bankAccountId: uuid("bank_account_id"), // Will link later
    defaultDeliveryAddressId: uuid("default_delivery_address_id"), // Will link later
    searchText: text("search_text"),
    addressCategoryId: uuid("address_category_id").references(() => addressCategory.categoryId),
    priceListId: uuid("price_list_id"),
  },
  (table) => [
    unique().on(table.tenantId, table.addressNo),
    unique().on(table.tenantId, table.addressId),
    index("idx_address_category").on(table.tenantId, table.addressCategoryId),
    index("idx_address_price_list").on(table.tenantId, table.priceListId),
    foreignKey({
      columns: [table.tenantId, table.priceListId],
      foreignColumns: [priceList.tenantId, priceList.priceListId],
    }),
    index("idx_address_customer")
      .on(table.tenantId, table.isCustomer)
      .where(sql`${table.isCustomer} = true`),
    index("idx_address_supplier")
      .on(table.tenantId, table.isSupplier)
      .where(sql`${table.isSupplier} = true`),
    index("idx_address_tenant").on(table.tenantId),
    index("idx_address_type").on(table.tenantId, table.addressType),
    index("idx_address_search_trgm").on(table.searchText), // GIN index usually needs extension,
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const addressContact = pgTable(
  "address_contact",
  {
    contactId: uuid("contact_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    addressId: uuid("address_id")
      .notNull()
      .references(() => address.addressId),
    firstName: varchar("first_name"),
    lastName: varchar("last_name").notNull(),
    email: varchar("email"),
    phoneMobile: varchar("phone_mobile"),
    phoneLandline: varchar("phone_landline"),
    roleFunction: varchar("role_function"),
    isPrimary: boolean("is_primary").notNull().default(false),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("idx_address_contact_address").on(table.addressId),
    index("idx_address_contact_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const addressSeq = pgTable(
  "address_seq",
  {
    tenantId: uuid("tenant_id")
      .primaryKey()
      .references(() => tenant.tenantId),
    nextVal: integer("next_val").notNull().default(1),
  },
  (table) => [
    index("idx_address_seq_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const articleGroup = pgTable(
  "article_group",
  {
    articleGroupId: uuid("article_group_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    code: varchar("code").notNull(),
    name: varchar("name").notNull(),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    unique().on(table.tenantId, table.articleGroupId),
    unique().on(table.tenantId, table.code),
    index("idx_article_group_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const warehouse = pgTable(
  "warehouse",
  {
    warehouseId: uuid("warehouse_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyId: uuid("company_id").references(() => company.companyId),
    code: varchar("code").notNull(),
    name: varchar("name").notNull(),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    unique().on(table.tenantId, table.warehouseId),
    unique().on(table.tenantId, table.code),
    index("idx_warehouse_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const article = pgTable(
  "article",
  {
    articleId: uuid("article_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    articleNo: varchar("article_no").notNull(),
    name: varchar("name").notNull(),
    description: text("description"),
    articleGroupId: uuid("article_group_id"),
    taxClassId: uuid("tax_class_id"), // Will link later
    baseUnit: varchar("base_unit"),
    salesUnit: varchar("sales_unit"),
    purchaseUnit: varchar("purchase_unit"),
    isActive: boolean("is_active").notNull().default(true),
    archivedAt: timestamp("archived_at", { withTimezone: true }),
    customAttributes: jsonb("custom_attributes"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }),
    defaultWarehouseId: uuid("default_warehouse_id"),
    trackingMode: varchar("tracking_mode"),
    bomType: varchar("bom_type").notNull().default("none"),
  },
  (table) => [
    unique().on(table.tenantId, table.articleNo),
    unique().on(table.tenantId, table.articleId),
    index("idx_article_default_wh").on(table.tenantId, table.defaultWarehouseId),
    index("idx_article_group_fk").on(table.articleGroupId),
    index("idx_article_tenant").on(table.tenantId),
    index("idx_article_tenant_active").on(table.tenantId, table.isActive),
    check(
      "article_tracking_mode_check",
      sql`${table.trackingMode} IN ('serial', 'batch') OR ${table.trackingMode} IS NULL`,
    ),
    check("article_bom_type_check", sql`${table.bomType} IN ('none', 'production', 'sales')`),
    foreignKey({
      columns: [table.tenantId, table.articleGroupId],
      foreignColumns: [articleGroup.tenantId, articleGroup.articleGroupId],
    }),
    foreignKey({
      columns: [table.tenantId, table.defaultWarehouseId],
      foreignColumns: [warehouse.tenantId, warehouse.warehouseId],
    }),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const articleBom = pgTable(
  "article_bom",
  {
    bomId: uuid("bom_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    headerArticleId: uuid("header_article_id").notNull(),
    componentArticleId: uuid("component_article_id").notNull(),
    quantity: numeric("quantity").notNull(),
    scrapPercentage: numeric("scrap_percentage").notNull().default("0"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    unique().on(table.tenantId, table.headerArticleId, table.componentArticleId),
    check("article_bom_quantity_check", sql`${table.quantity} > 0`),
    foreignKey({
      columns: [table.tenantId, table.headerArticleId],
      foreignColumns: [article.tenantId, article.articleId],
    }),
    foreignKey({
      columns: [table.tenantId, table.componentArticleId],
      foreignColumns: [article.tenantId, article.articleId],
    }),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const bankAccount = pgTable(
  "bank_account",
  {
    bankAccountId: uuid("bank_account_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyId: uuid("company_id").references(() => company.companyId),
    addressId: uuid("address_id").references(() => address.addressId),
    iban: varchar("iban").notNull(),
    bic: varchar("bic"),
    bankName: varchar("bank_name"),
    currencyId: char("currency_id", { length: 3 }),
    isDefault: boolean("is_default").notNull().default(false),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    customAttributes: jsonb("custom_attributes"),
  },
  (table) => [
    unique().on(table.tenantId, table.iban),
    index("idx_bank_account_address").on(table.addressId),
    index("idx_bank_account_company").on(table.companyId),
    index("idx_bank_account_tenant").on(table.tenantId),
    check(
      "chk_bank_account_target",
      sql`(${table.companyId} IS NOT NULL AND ${table.addressId} IS NULL) OR (${table.companyId} IS NULL AND ${table.addressId} IS NOT NULL)`,
    ),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const paymentTerm = pgTable(
  "payment_term",
  {
    paymentTermId: uuid("payment_term_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    name: jsonb("name").notNull(),
    netDays: integer("net_days").notNull(),
    discountDays: integer("discount_days"),
    discountPercentage: numeric("discount_percentage"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    customAttributes: jsonb("custom_attributes"),
  },
  (table) => [
    unique().on(table.tenantId, table.name),
    index("idx_payment_term_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const shippingMethod = pgTable(
  "shipping_method",
  {
    shippingMethodId: uuid("shipping_method_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    name: jsonb("name").notNull(),
    trackingUrlTemplate: varchar("tracking_url_template"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    customAttributes: jsonb("custom_attributes"),
  },
  (table) => [
    unique().on(table.tenantId, table.name),
    index("idx_shipping_method_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const priceList = pgTable(
  "price_list",
  {
    priceListId: uuid("price_list_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    name: varchar("name").notNull(),
    currencyId: char("currency_id", { length: 3 }).notNull(),
    isNet: boolean("is_net").notNull().default(true),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    unique().on(table.tenantId, table.priceListId),
    unique().on(table.tenantId, table.name),
    index("idx_price_list_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const priceListItem = pgTable(
  "price_list_item",
  {
    priceListItemId: uuid("price_list_item_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    priceListId: uuid("price_list_id").notNull(),
    articleId: uuid("article_id").notNull(),
    price: numeric("price").notNull(),
    validFrom: date("valid_from"),
    validTo: date("valid_to"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    unique().on(table.tenantId, table.priceListId, table.articleId, table.validFrom),
    index("idx_price_list_item_lookup").on(table.priceListId, table.articleId, table.validFrom),
    index("idx_price_list_item_tenant").on(table.tenantId),
    foreignKey({
      columns: [table.tenantId, table.priceListId],
      foreignColumns: [priceList.tenantId, priceList.priceListId],
    }),
    foreignKey({
      columns: [table.tenantId, table.articleId],
      foreignColumns: [article.tenantId, article.articleId],
    }),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const discountGroup = pgTable(
  "discount_group",
  {
    discountGroupId: uuid("discount_group_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    name: varchar("name").notNull(),
    percentage: numeric("percentage").notNull(),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    unique().on(table.tenantId, table.name),
    index("idx_discount_group_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const taxClass = pgTable(
  "tax_class",
  {
    taxClassId: uuid("tax_class_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    code: varchar("code").notNull(),
    name: jsonb("name").notNull(),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    customAttributes: jsonb("custom_attributes"),
  },
  (table) => [
    unique().on(table.tenantId, table.code),
    index("idx_tax_class_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const taxCode = pgTable(
  "tax_code",
  {
    taxCodeId: uuid("tax_code_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    code: varchar("code").notNull(),
    description: varchar("description"),
    taxRate: numeric("tax_rate").notNull(),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    unique().on(table.tenantId, table.taxCodeId),
    unique().on(table.tenantId, table.code),
    index("idx_tax_code_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const taxRule = pgTable(
  "tax_rule",
  {
    taxRuleId: uuid("tax_rule_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    customerTaxClassId: uuid("customer_tax_class_id"),
    articleTaxClassId: uuid("article_tax_class_id"),
    countryCode: char("country_code", { length: 2 }),
    taxCodeId: uuid("tax_code_id")
      .notNull()
      .references(() => taxCode.taxCodeId),
    validFrom: date("valid_from").notNull(),
    validTo: date("valid_to"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("idx_tax_rule_lookup").on(
      table.tenantId,
      table.customerTaxClassId,
      table.articleTaxClassId,
      table.countryCode,
      table.validFrom,
    ),
    index("idx_tax_rule_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const costCenter = pgTable(
  "cost_center",
  {
    costCenterId: uuid("cost_center_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyId: uuid("company_id").references(() => company.companyId),
    code: varchar("code").notNull(),
    name: varchar("name").notNull(),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    unique().on(table.tenantId, table.costCenterId),
    unique().on(table.tenantId, table.code),
    index("idx_cost_center_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const glAccount = pgTable(
  "gl_account",
  {
    glAccountId: uuid("gl_account_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyId: uuid("company_id").references(() => company.companyId),
    accountNo: varchar("account_no").notNull(),
    name: varchar("name").notNull(),
    accountType: varchar("account_type").notNull(),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    unique().on(table.tenantId, table.accountNo),
    index("idx_gl_account_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const accountDeterminationRule = pgTable(
  "account_determination_rule",
  {
    ruleId: uuid("rule_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyId: uuid("company_id").references(() => company.companyId),
    articleGroupId: uuid("article_group_id").references(() => articleGroup.articleGroupId),
    taxCodeId: uuid("tax_code_id").references(() => taxCode.taxCodeId),
    postingContext: varchar("posting_context").notNull(),
    glAccountId: uuid("gl_account_id")
      .notNull()
      .references(() => glAccount.glAccountId),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("idx_acct_det_lookup").on(
      table.tenantId,
      table.postingContext,
      table.articleGroupId,
      table.taxCodeId,
    ),
    index("idx_acct_det_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const fiscalPeriod = pgTable(
  "fiscal_period",
  {
    fiscalPeriodId: uuid("fiscal_period_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyId: uuid("company_id")
      .notNull()
      .references(() => company.companyId),
    fiscalYear: integer("fiscal_year").notNull(),
    periodNo: integer("period_no").notNull(),
    startDate: date("start_date").notNull(),
    endDate: date("end_date").notNull(),
    isClosed: boolean("is_closed").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    unique().on(table.companyId, table.fiscalYear, table.periodNo),
    index("idx_fiscal_period_lookup").on(
      table.tenantId,
      table.companyId,
      table.startDate,
      table.endDate,
    ),
    check("fiscal_period_no_check", sql`${table.periodNo} BETWEEN 1 AND 12`),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const masterRelations = defineRelationsPart(
  {
    tenant,
    organization,
    appUser,
    country,
    currency,
    unit,
    postalCode,
    incoterm,
    industry,
    company,
    addressCategory,
    address,
    addressContact,
    addressSeq,
    articleGroup,
    warehouse,
    article,
    articleBom,
    bankAccount,
    paymentTerm,
    shippingMethod,
    priceList,
    priceListItem,
    discountGroup,
    taxClass,
    taxCode,
    taxRule,
    costCenter,
    glAccount,
    accountDeterminationRule,
    fiscalPeriod,
  },
  (r) => ({
    company: {
      tenant: r.one.tenant({ from: r.company.tenantId, to: r.tenant.tenantId }),
      warehouses: r.many.warehouse({ from: r.company.companyId, to: r.warehouse.companyId }),
    },
    tenant: {
      companies: r.many.company({ from: r.tenant.tenantId, to: r.company.tenantId }),
    },
  }),
);
