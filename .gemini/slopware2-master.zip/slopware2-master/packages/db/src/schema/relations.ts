import { defineRelationsPart } from "drizzle-orm";

import * as authSchema from "./auth";
import * as connectorSchema from "./connector";
import * as masterSchema from "./master";
import * as systemSchema from "./system";
import * as transactionSchema from "./transaction";
import * as viewSchema from "./views";

const allSchemas = {
  ...authSchema,
  ...systemSchema,
  ...masterSchema,
  ...transactionSchema,
  ...connectorSchema,
  ...viewSchema,
} as Record<string, unknown>;

export const relations = defineRelationsPart(
  allSchemas as Parameters<typeof defineRelationsPart>[0],
  () => ({}),
);
