import { defineRelationsPart, sql } from "drizzle-orm";
import {
  pgTable,
  uuid,
  varchar,
  boolean,
  timestamp,
  jsonb,
  integer,
  text,
  index,
  uniqueIndex,
  unique,
  pgPolicy,
  check,
  foreignKey,
} from "drizzle-orm/pg-core";

export const organization = pgTable("organization", {
  organizationId: uuid("organization_id").primaryKey().defaultRandom(),
  slug: varchar("slug", { length: 63 }).notNull().unique(),
  name: varchar("name").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const tenant = pgTable(
  "tenant",
  {
    tenantId: uuid("tenant_id").primaryKey().defaultRandom(),
    organizationId: uuid("organization_id")
      .notNull()
      .references(() => organization.organizationId),
    slug: varchar("slug", { length: 63 }).notNull().unique(),
    name: varchar("name").notNull(),
    isBase: boolean("is_base").notNull().default(false),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("idx_tenant_organization").on(table.organizationId),
    uniqueIndex("uq_single_base_tenant")
      .on(table.isBase)
      .where(sql`${table.isBase} = true`),
  ],
);

export const appUser = pgTable(
  "app_user",
  {
    userId: uuid("user_id").primaryKey().defaultRandom(),
    email: varchar("email").notNull().unique(),
    passwordHash: varchar("password_hash").notNull(),
    displayName: varchar("display_name"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    lastCompanyId: uuid("last_company_id"),
    isSystemAdmin: boolean("is_system_admin").notNull().default(false),
    locale: varchar("locale", { length: 5 }).notNull().default("de"),
    role: varchar("role", { length: 32 }).notNull().default("tenant_user"),
  },
  (table) => [index("idx_app_user_role").on(table.role)],
);

export const userTenant = pgTable(
  "user_tenant",
  {
    userId: uuid("user_id")
      .notNull()
      .references(() => appUser.userId),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    role: varchar("role").notNull(),
  },
  (table) => [
    unique().on(table.userId, table.tenantId),
    index("idx_user_tenant_tenant").on(table.tenantId),
    index("idx_user_tenant_user").on(table.userId),
  ],
);

export const modules = pgTable("modules", {
  moduleId: uuid("module_id").primaryKey().defaultRandom(),
  slug: varchar("slug").notNull().unique(),
  label: jsonb("label").notNull(),
});

const tenantIsolationScope = (t: { scope: any; organizationId: any; tenantId: any }) =>
  sql`${t.scope} = 'global' OR (${t.scope} = 'organization' AND ${t.organizationId} = (SELECT organization_id FROM tenant WHERE tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid LIMIT 1)) OR (${t.scope} = 'tenant' AND ${t.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid)`;

export const systemSettings = pgTable(
  "system_settings",
  {
    settingId: uuid("setting_id").primaryKey().defaultRandom(),
    scope: varchar("scope").notNull(),
    organizationId: uuid("organization_id"),
    tenantId: uuid("tenant_id"),
    key: varchar("key").notNull(),
    value: jsonb("value").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }),
  },
  (table) => [
    uniqueIndex("uq_settings_global")
      .on(table.key)
      .where(sql`${table.scope} = 'global'`),
    uniqueIndex("uq_settings_org")
      .on(table.organizationId, table.key)
      .where(sql`${table.scope} = 'organization'`),
    uniqueIndex("uq_settings_tenant")
      .on(table.tenantId, table.key)
      .where(sql`${table.scope} = 'tenant'`),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: tenantIsolationScope(table),
      withCheck: tenantIsolationScope(table),
    }),
  ],
).enableRLS();

export const entityCommands = pgTable(
  "entity_commands",
  {
    commandId: uuid("command_id").primaryKey().defaultRandom(),
    scope: varchar("scope").notNull().default("global"),
    organizationId: uuid("organization_id"),
    tenantId: uuid("tenant_id"),
    entityName: varchar("entity_name").notNull(),
    commandKey: varchar("command_key").notNull(),
    handlerkey: varchar("handlerkey"),
    label: jsonb("label").notNull(),
    description: jsonb("description"),
    httpMethod: varchar("http_method").notNull().default("POST"),
    routePattern: varchar("route_pattern").notNull(),
    entityIdParam: varchar("entity_id_param"),
    parentEntity: varchar("parent_entity"),
    parentIdSource: varchar("parent_id_source"),
    inputSchema: jsonb("input_schema").notNull().default({}),
    serverManaged: jsonb("server_managed").notNull().default([]),
    uiPlacement: varchar("ui_placement"),
    uiIcon: varchar("ui_icon"),
    uiShortcut: varchar("ui_shortcut"),
    uiConfirm: jsonb("ui_confirm"),
    writesTables: jsonb("writes_tables").notNull().default([]),
    sideEffects: jsonb("side_effects").notNull().default([]),
    minRole: varchar("min_role").notNull().default("tenant_user"),
    visibility: varchar("visibility").notNull().default("tenant"),
    commandState: varchar("command_state").notNull().default("published"),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    unique().on(
      table.scope,
      table.organizationId,
      table.tenantId,
      table.entityName,
      table.commandKey,
    ),
    index("idx_entity_commands_entity").on(table.entityName, table.commandState),
    index("idx_entity_commands_org")
      .on(table.organizationId)
      .where(sql`${table.organizationId} IS NOT NULL`),
    index("idx_entity_commands_tenant")
      .on(table.tenantId)
      .where(sql`${table.tenantId} IS NOT NULL`),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: tenantIsolationScope(table),
      withCheck: tenantIsolationScope(table),
    }),
  ],
).enableRLS();

export const tenantFields = pgTable(
  "tenant_fields",
  {
    fieldId: uuid("field_id").primaryKey().defaultRandom(),
    scope: varchar("scope").notNull().default("tenant"),
    organizationId: uuid("organization_id"),
    tenantId: uuid("tenant_id"),
    entityName: varchar("entity_name").notNull(),
    fieldName: varchar("field_name").notNull(),
    fieldType: varchar("field_type").notNull(),
    isRequired: boolean("is_required").notNull().default(false),
    customAttributes: jsonb("custom_attributes"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    label: jsonb("label"),
    helpText: jsonb("help_text"),
    isVisible: boolean("is_visible").notNull().default(true),
    displayOrder: integer("display_order"),
    importColumn: text("import_column"),
    importType: text("import_type"),
    importRequired: boolean("import_required").notNull().default(false),
    importTransform: text("import_transform"),
    groupId: varchar("group_id"),
    lookupTable: varchar("lookup_table"),
    lookupFilter: jsonb("lookup_filter"),
  },
  (table) => [
    uniqueIndex("uq_fields_global")
      .on(table.entityName, table.fieldName)
      .where(sql`${table.scope} = 'global'`),
    uniqueIndex("uq_fields_org")
      .on(table.organizationId, table.entityName, table.fieldName)
      .where(sql`${table.scope} = 'organization'`),
    uniqueIndex("uq_fields_tenant")
      .on(table.tenantId, table.entityName, table.fieldName)
      .where(sql`${table.scope} = 'tenant'`),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: tenantIsolationScope(table),
      withCheck: tenantIsolationScope(table),
    }),
  ],
).enableRLS();

export const tenantGroups = pgTable(
  "tenant_groups",
  {
    groupId: uuid("group_id").primaryKey().defaultRandom(),
    scope: varchar("scope").notNull().default("tenant"),
    organizationId: uuid("organization_id"),
    tenantId: uuid("tenant_id"),
    entityName: varchar("entity_name").notNull(),
    groupKey: varchar("group_key").notNull(),
    label: jsonb("label").notNull(),
    displayOrder: integer("display_order").notNull().default(0),
    isVisible: boolean("is_visible").notNull().default(true),
    customAttributes: jsonb("custom_attributes"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("uq_groups_global")
      .on(table.entityName, table.groupKey)
      .where(sql`${table.scope} = 'global'`),
    uniqueIndex("uq_groups_org")
      .on(table.organizationId, table.entityName, table.groupKey)
      .where(sql`${table.scope} = 'organization'`),
    uniqueIndex("uq_groups_tenant")
      .on(table.tenantId, table.entityName, table.groupKey)
      .where(sql`${table.scope} = 'tenant'`),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: tenantIsolationScope(table),
      withCheck: tenantIsolationScope(table),
    }),
  ],
).enableRLS();

export const tenantLayouts = pgTable(
  "tenant_layouts",
  {
    layoutId: uuid("layout_id").primaryKey().defaultRandom(),
    scope: varchar("scope").notNull().default("tenant"),
    organizationId: uuid("organization_id"),
    tenantId: uuid("tenant_id"),
    entityName: varchar("entity_name").notNull(),
    layoutKey: varchar("layout_key").notNull(),
    layoutDefinition: jsonb("layout_definition").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    uniqueIndex("uq_layouts_global")
      .on(table.entityName, table.layoutKey)
      .where(sql`${table.scope} = 'global'`),
    uniqueIndex("uq_layouts_org")
      .on(table.organizationId, table.entityName, table.layoutKey)
      .where(sql`${table.scope} = 'organization'`),
    uniqueIndex("uq_layouts_tenant")
      .on(table.tenantId, table.entityName, table.layoutKey)
      .where(sql`${table.scope} = 'tenant'`),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: tenantIsolationScope(table),
      withCheck: tenantIsolationScope(table),
    }),
  ],
).enableRLS();

export const tenantRules = pgTable(
  "tenant_rules",
  {
    ruleId: uuid("rule_id").primaryKey().defaultRandom(),
    scope: varchar("scope").notNull().default("tenant"),
    organizationId: uuid("organization_id"),
    tenantId: uuid("tenant_id"),
    entityName: varchar("entity_name").notNull(),
    hookName: varchar("hook_name").notNull(),
    ruleState: varchar("rule_state").notNull().default("draft"),
    ruleDefinition: jsonb("rule_definition").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    ruleSource: text("rule_source"),
  },
  (table) => [
    uniqueIndex("uq_rules_global")
      .on(table.entityName, table.hookName)
      .where(sql`${table.scope} = 'global' AND ${table.ruleState} = 'published'`),
    uniqueIndex("uq_rules_org")
      .on(table.organizationId, table.entityName, table.hookName)
      .where(sql`${table.scope} = 'organization' AND ${table.ruleState} = 'published'`),
    uniqueIndex("uq_rules_tenant")
      .on(table.tenantId, table.entityName, table.hookName)
      .where(sql`${table.scope} = 'tenant' AND ${table.ruleState} = 'published'`),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: tenantIsolationScope(table),
      withCheck: tenantIsolationScope(table),
    }),
  ],
).enableRLS();

export const helperTableRegistry = pgTable("helper_table_registry", {
  tableName: varchar("table_name").primaryKey(),
  label: jsonb("label").notNull(),
  pkColumn: varchar("pk_column").notNull(),
  displayColumn: varchar("display_column").notNull(),
  displayIsI18n: boolean("display_is_i18n").notNull().default(false),
  codeColumn: varchar("code_column"),
  isTenantScoped: boolean("is_tenant_scoped").notNull().default(false),
  defaultFilter: jsonb("default_filter"),
  sortColumn: varchar("sort_column").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  valueColumn: varchar("value_column"),
});

export const schemaAnnotations = pgTable(
  "schema_annotations",
  {
    tableName: varchar("table_name").notNull(),
    columnName: varchar("column_name").notNull().default(""),
    businessName: varchar("business_name").notNull(),
    description: text("description").notNull(),
    dataClass: varchar("data_class").notNull(),
    moduleId: uuid("module_id"),
    mandatoryFor: jsonb("mandatory_for").notNull().default([]),
    lockedFor: jsonb("locked_for").notNull().default([]),
    aiGeneratedAt: timestamp("ai_generated_at", { withTimezone: true }),
    humanOverride: boolean("human_override").notNull().default(false),
  },
  (table) => [
    unique().on(table.tableName, table.columnName),
    foreignKey({
      columns: [table.moduleId],
      foreignColumns: [modules.moduleId],
    }),
    check(
      "schema_annotations_data_class_check",
      sql`${table.dataClass} IN ('master', 'transaction', 'derived', 'metadata')`,
    ),
  ],
);

export const systemRelations = defineRelationsPart(
  {
    organization,
    tenant,
    appUser,
    userTenant,
    modules,
    systemSettings,
    entityCommands,
    tenantFields,
    tenantGroups,
    tenantLayouts,
    tenantRules,
    helperTableRegistry,
    schemaAnnotations,
  },
  (r) => ({
    organization: {
      tenants: r.many.tenant({
        from: r.organization.organizationId,
        to: r.tenant.organizationId,
      }),
    },
    tenant: {
      organization: r.one.organization({
        from: r.tenant.organizationId,
        to: r.organization.organizationId,
      }),
      users: r.many.userTenant({
        from: r.tenant.tenantId,
        to: r.userTenant.tenantId,
      }),
    },
    appUser: {
      tenants: r.many.userTenant({
        from: r.appUser.userId,
        to: r.userTenant.userId,
      }),
    },
    userTenant: {
      user: r.one.appUser({
        from: r.userTenant.userId,
        to: r.appUser.userId,
      }),
      tenant: r.one.tenant({
        from: r.userTenant.tenantId,
        to: r.tenant.tenantId,
      }),
    },
  }),
);
