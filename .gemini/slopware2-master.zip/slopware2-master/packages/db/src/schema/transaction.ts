import { defineRelationsPart, sql } from "drizzle-orm";
import {
  pgTable,
  uuid,
  varchar,
  boolean,
  timestamp,
  jsonb,
  integer,
  text,
  index,
  unique,
  char,
  numeric,
  date,
  check,
  pgPolicy,
  foreignKey,
} from "drizzle-orm/pg-core";

import {
  company,
  address,
  article,
  warehouse,
  taxCode,
  costCenter,
  glAccount,
  fiscalPeriod,
} from "./master";
import { tenant, appUser } from "./system";

export const documentType = pgTable(
  "document_type",
  {
    documentTypeId: uuid("document_type_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    code: varchar("code", { length: 20 }).notNull(),
    name: varchar("name", { length: 100 }).notNull(),
    movementType: char("movement_type", { length: 1 }).notNull(),
    nextDocumentTypeId: uuid("next_document_type_id"),
    requiresWarehouse: boolean("requires_warehouse").notNull().default(true),
    requiresCostCenter: boolean("requires_cost_center").notNull().default(false),
    isActive: boolean("is_active").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    unique().on(table.tenantId, table.code),
    unique().on(table.tenantId, table.documentTypeId),
    index("idx_document_type_tenant").on(table.tenantId),
    check(
      "document_type_movement_type_check",
      sql`${table.movementType} IN ('N', 'A', 'L', 'R', 'G', 'b', 'l', 'r', 'g', 'Z', 'E', 'V', 'q', 'p', 'U')`,
    ),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const numberSequence = pgTable(
  "number_sequence",
  {
    numberSequenceId: uuid("number_sequence_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyId: uuid("company_id")
      .notNull()
      .references(() => company.companyId),
    prefix: varchar("prefix", { length: 10 }).notNull(),
    documentType: char("document_type", { length: 1 }).notNull(),
    nextValue: integer("next_value").notNull().default(1),
    padding: integer("padding").notNull().default(5),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }),
  },
  (table) => [
    unique("uq_number_sequence_id").on(table.tenantId, table.numberSequenceId),
    unique("uq_number_sequence_config").on(table.tenantId, table.companyId, table.documentType),
    index("idx_number_sequence_tenant").on(table.tenantId),
    index("idx_number_sequence_tenant_company").on(table.tenantId, table.companyId),
    index("idx_number_sequence_lookup").on(table.tenantId, table.companyId, table.documentType),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const documentGroup = pgTable(
  "document_group",
  {
    documentGroupId: uuid("document_group_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyId: uuid("company_id").references(() => company.companyId),
    name: varchar("name").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    numberSequenceId: uuid("number_sequence_id").references(() => numberSequence.numberSequenceId),
    description: text("description"),
    defaultWarehouseId: uuid("default_warehouse_id").references(() => warehouse.warehouseId),
    defaultTaxCodeId: uuid("default_tax_code_id").references(() => taxCode.taxCodeId),
    defaultSalesAccountId: uuid("default_sales_account_id").references(() => glAccount.glAccountId),
    defaultCostAccountId: uuid("default_cost_account_id").references(() => glAccount.glAccountId),
    isActive: boolean("is_active").default(true),
    sortOrder: integer("sort_order").default(0),
    updatedAt: timestamp("updated_at", { withTimezone: true }),
    defaultPaymentTermId: uuid("default_payment_term_id"),
    defaultShippingMethodId: uuid("default_shipping_method_id"),
    requireSerialTracking: boolean("require_serial_tracking").notNull().default(true),
    requireBatchTracking: boolean("require_batch_tracking").notNull().default(true),
    documentType: varchar("document_type", { length: 1 }).notNull(),
    groupNumber: integer("group_number").notNull(),
    direction: varchar("direction", { length: 20 }),
    nextGroupId: uuid("next_group_id"),
  },
  (table) => [
    unique().on(table.tenantId, table.documentGroupId),
    unique().on(table.tenantId, table.documentType, table.groupNumber),
    index("idx_document_group_tenant").on(table.tenantId),
    index("idx_document_group_company").on(table.companyId),
    check(
      "document_group_group_number_check",
      sql`${table.groupNumber} >= 0 AND ${table.groupNumber} <= 99`,
    ),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const document = pgTable(
  "document",
  {
    documentId: uuid("document_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyId: uuid("company_id").notNull(),
    documentType: char("document_type", { length: 1 }).notNull(),
    documentDirection: varchar("document_direction").notNull(),
    documentNo: varchar("document_no").notNull(),
    status: varchar("status").notNull(),
    customerId: uuid("customer_id"),
    currencyId: char("currency_id", { length: 3 }),
    documentDate: date("document_date").notNull(),
    postingDate: date("posting_date"),
    totalNet: numeric("total_net"),
    totalTax: numeric("total_tax"),
    totalGross: numeric("total_gross"),
    versionNo: integer("version_no").notNull().default(1),
    postedAt: timestamp("posted_at", { withTimezone: true }),
    postedBy: uuid("posted_by").references(() => appUser.userId),
    cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
    stornoDocumentId: uuid("storno_document_id"),
    customAttributes: jsonb("custom_attributes"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }),
    transactionId: uuid("transaction_id").notNull(),
    parentDocumentId: uuid("parent_document_id"),
    documentGroupId: uuid("document_group_id").references(() => documentGroup.documentGroupId),
    archivedAt: timestamp("archived_at", { withTimezone: true }),
    billingAddress: jsonb("billing_address"),
    deliveryAddress: jsonb("delivery_address"),
    deliveryAddressId: uuid("delivery_address_id"),
    paymentTermId: uuid("payment_term_id"),
    shippingMethodId: uuid("shipping_method_id"),
    documentTypeId: uuid("document_type_id").references(() => documentType.documentTypeId),
    warehouseId: uuid("warehouse_id"),
    targetWarehouseId: uuid("target_warehouse_id").references(() => warehouse.warehouseId),
    isPaid: boolean("is_paid").notNull().default(false),
    paidAt: timestamp("paid_at", { withTimezone: true }),
    paidAmount: numeric("paid_amount"),
    dueDate: date("due_date"),
  },
  (table) => [
    unique().on(table.tenantId, table.companyId, table.documentNo),
    unique().on(table.tenantId, table.documentId),
    index("idx_document_company").on(table.tenantId, table.companyId),
    index("idx_document_customer").on(table.tenantId, table.customerId),
    index("idx_document_delivery_address").on(table.tenantId, table.deliveryAddressId),
    index("idx_document_group").on(table.documentGroupId),
    index("idx_document_group_type").on(table.documentGroupId, table.documentTypeId),
    index("idx_document_parent").on(table.parentDocumentId),
    index("idx_document_payment_term").on(table.paymentTermId),
    index("idx_document_posted_at")
      .on(table.tenantId, table.postedAt)
      .where(sql`${table.postedAt} IS NOT NULL`),
    index("idx_document_shipping_method").on(table.shippingMethodId),
    index("idx_document_tenant").on(table.tenantId),
    index("idx_document_transaction").on(table.tenantId, table.transactionId),
    index("idx_document_type_status").on(table.tenantId, table.documentType, table.status),
    index("idx_document_warehouse").on(table.warehouseId),
    index("idx_document_status_live")
      .on(table.tenantId, table.status)
      .where(sql`${table.status} != 'posted'`),
    index("idx_document_customer_unpaid")
      .on(table.tenantId, table.customerId, table.isPaid)
      .where(sql`${table.isPaid} = false`),
    check(
      "chk_document_type",
      sql`${table.documentType} IN ('N', 'A', 'L', 'R', 'G', 'b', 'l', 'r', 'g', 'Z', 'E', 'V', 'q', 'p', 'U')`,
    ),
    foreignKey({
      columns: [table.tenantId, table.companyId],
      foreignColumns: [company.tenantId, company.companyId],
    }),
    foreignKey({
      columns: [table.tenantId, table.customerId],
      foreignColumns: [address.tenantId, address.addressId],
    }),
    foreignKey({
      columns: [table.tenantId, table.warehouseId],
      foreignColumns: [warehouse.tenantId, warehouse.warehouseId],
    }),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const documentLine = pgTable(
  "document_line",
  {
    documentLineId: uuid("document_line_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    documentId: uuid("document_id")
      .notNull()
      .references(() => document.documentId),
    lineNo: integer("line_no").notNull(),
    articleId: uuid("article_id"),
    articleTextSnapshot: varchar("article_text_snapshot"),
    quantity: numeric("quantity").notNull(),
    unit: varchar("unit"),
    netPrice: numeric("net_price").notNull(),
    discountPercentage: numeric("discount_percentage"),
    taxCodeId: uuid("tax_code_id"),
    taxAmount: numeric("tax_amount"),
    lineTotalNet: numeric("line_total_net"),
    warehouseId: uuid("warehouse_id"),
    costCenterId: uuid("cost_center_id"),
    targetWarehouseId: uuid("target_warehouse_id").references(() => warehouse.warehouseId),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    transactionId: uuid("transaction_id"),
    movementType: char("movement_type", { length: 1 }),
    lineType: varchar("line_type", { length: 20 }).notNull().default("article"),
  },
  (table) => [
    unique().on(table.tenantId, table.documentId, table.lineNo),
    unique().on(table.tenantId, table.documentLineId),
    index("idx_document_line_article").on(table.articleId),
    index("idx_document_line_document").on(table.documentId),
    index("idx_document_line_tenant").on(table.tenantId),
    index("idx_document_line_tx").on(table.tenantId, table.transactionId),
    foreignKey({
      columns: [table.tenantId, table.targetWarehouseId],
      foreignColumns: [warehouse.tenantId, warehouse.warehouseId],
    }),
    check(
      "chk_article_line_requires_article_id",
      sql`${table.lineType} = 'comment' OR ${table.articleId} IS NOT NULL`,
    ),
    check(
      "document_line_line_type_check",
      sql`${table.lineType} IN ('article', 'comment', 'production_output', 'production_input', 'bom_component')`,
    ),
    check(
      "chk_document_line_movement_type",
      sql`${table.movementType} IN ('N', 'A', 'L', 'R', 'G', 'b', 'l', 'r', 'g', 'Z', 'E', 'V', 'q', 'p', 'U') OR ${table.movementType} IS NULL`,
    ),
    foreignKey({
      columns: [table.tenantId, table.articleId],
      foreignColumns: [article.tenantId, article.articleId],
    }),
    foreignKey({
      columns: [table.tenantId, table.warehouseId],
      foreignColumns: [warehouse.tenantId, warehouse.warehouseId],
    }),
    foreignKey({
      columns: [table.tenantId, table.costCenterId],
      foreignColumns: [costCenter.tenantId, costCenter.costCenterId],
    }),
    foreignKey({
      columns: [table.tenantId, table.taxCodeId],
      foreignColumns: [taxCode.tenantId, taxCode.taxCodeId],
    }),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const serialNumber = pgTable(
  "serial_number",
  {
    serialNumberId: uuid("serial_number_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    articleId: uuid("article_id").notNull(),
    serialNo: varchar("serial_no").notNull(),
    status: varchar("status").notNull().default("in_stock"),
    createdMovementId: uuid("created_movement_id"), // Will link to inventory_movement
    consumedMovementId: uuid("consumed_movement_id"), // Will link to inventory_movement
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    unique().on(table.tenantId, table.serialNumberId),
    unique().on(table.tenantId, table.articleId, table.serialNo),
    check("serial_number_status_check", sql`${table.status} IN ('in_stock', 'reserved', 'sold')`),
    foreignKey({
      columns: [table.tenantId, table.articleId],
      foreignColumns: [article.tenantId, article.articleId],
    }),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const documentLineTracking = pgTable(
  "document_line_tracking",
  {
    trackingId: uuid("tracking_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    documentLineId: uuid("document_line_id").notNull(),
    serialNumberId: uuid("serial_number_id"),
    batchNo: varchar("batch_no"),
    qty: numeric("qty").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    check(
      "document_line_tracking_check",
      sql`(${table.serialNumberId} IS NOT NULL AND ${table.batchNo} IS NULL) OR (${table.serialNumberId} IS NULL AND ${table.batchNo} IS NOT NULL)`,
    ),
    foreignKey({
      columns: [table.tenantId, table.documentLineId],
      foreignColumns: [documentLine.tenantId, documentLine.documentLineId],
    }),
    foreignKey({
      columns: [table.tenantId, table.serialNumberId],
      foreignColumns: [serialNumber.tenantId, serialNumber.serialNumberId],
    }),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const inventoryBalance = pgTable(
  "inventory_balance",
  {
    inventoryBalanceId: uuid("inventory_balance_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyId: uuid("company_id"),
    warehouseId: uuid("warehouse_id").notNull(),
    articleId: uuid("article_id").notNull(),
    onHandQty: numeric("on_hand_qty").notNull().default("0"),
    reservedQty: numeric("reserved_qty").notNull().default("0"),
    asOfAt: timestamp("as_of_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    availableQty: numeric("available_qty"),
    expectedPurchaseQty: numeric("expected_purchase_qty").notNull().default("0"),
    gldPurchase: numeric("gld_purchase"),
    gldCost: numeric("gld_cost"),
  },
  (table) => [
    unique().on(table.tenantId, table.warehouseId, table.articleId),
    index("idx_inv_balance_lookup").on(table.tenantId, table.warehouseId, table.articleId),
    index("idx_inv_balance_tenant").on(table.tenantId),
    foreignKey({
      columns: [table.tenantId, table.companyId],
      foreignColumns: [company.tenantId, company.companyId],
    }),
    foreignKey({
      columns: [table.tenantId, table.warehouseId],
      foreignColumns: [warehouse.tenantId, warehouse.warehouseId],
    }),
    foreignKey({
      columns: [table.tenantId, table.articleId],
      foreignColumns: [article.tenantId, article.articleId],
    }),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const inventoryMovement = pgTable(
  "inventory_movement",
  {
    inventoryMovementId: uuid("inventory_movement_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyId: uuid("company_id"),
    warehouseId: uuid("warehouse_id").notNull(),
    articleId: uuid("article_id").notNull(),
    movementType: char("movement_type", { length: 1 }).notNull(),
    qtyDelta: numeric("qty_delta"),
    movementDate: timestamp("movement_date", { withTimezone: true }).notNull(),
    sourceDocumentId: uuid("source_document_id"),
    sourceDocumentLineId: uuid("source_document_line_id"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    transactionId: uuid("transaction_id"),
    absoluteQty: numeric("absolute_qty"),
    referenceText: varchar("reference_text"),
    serialNumberId: uuid("serial_number_id"),
    batchNo: varchar("batch_no"),
  },
  (table) => [
    index("idx_inv_movement_date").on(table.tenantId, table.movementDate),
    index("idx_inv_movement_inventory_anchor")
      .on(table.tenantId, table.warehouseId, table.articleId, table.movementDate)
      .where(sql`${table.movementType} = 'V'`),
    index("idx_inv_movement_lookup").on(
      table.tenantId,
      table.warehouseId,
      table.articleId,
      table.movementDate,
    ),
    index("idx_inv_movement_tenant").on(table.tenantId),
    index("idx_inv_movement_tx").on(table.tenantId, table.transactionId),
    index("idx_inv_movement_warehouse_article").on(
      table.tenantId,
      table.warehouseId,
      table.articleId,
    ),
    index("idx_inventory_movement_batch_balance").on(
      table.tenantId,
      table.warehouseId,
      table.articleId,
      table.batchNo,
    ),
    check(
      "chk_inventory_movement_qty_logic",
      sql`(${table.movementType} = 'V' AND ${table.absoluteQty} IS NOT NULL) OR (${table.movementType} <> 'V' AND ${table.qtyDelta} IS NOT NULL AND ${table.absoluteQty} IS NULL)`,
    ),
    check(
      "chk_inventory_movement_type",
      sql`${table.movementType} IN ('N', 'A', 'L', 'R', 'G', 'b', 'l', 'r', 'g', 'Z', 'E', 'V', 'q', 'p', 'U')`,
    ),
    foreignKey({
      columns: [table.tenantId, table.companyId],
      foreignColumns: [company.tenantId, company.companyId],
    }),
    foreignKey({
      columns: [table.tenantId, table.warehouseId],
      foreignColumns: [warehouse.tenantId, warehouse.warehouseId],
    }),
    foreignKey({
      columns: [table.tenantId, table.articleId],
      foreignColumns: [article.tenantId, article.articleId],
    }),
    foreignKey({
      columns: [table.tenantId, table.sourceDocumentId],
      foreignColumns: [document.tenantId, document.documentId],
    }),
    foreignKey({
      columns: [table.tenantId, table.sourceDocumentLineId],
      foreignColumns: [documentLine.tenantId, documentLine.documentLineId],
    }),
    foreignKey({
      columns: [table.tenantId, table.serialNumberId],
      foreignColumns: [serialNumber.tenantId, serialNumber.serialNumberId],
    }),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const journalEntry = pgTable(
  "journal_entry",
  {
    journalEntryId: uuid("journal_entry_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyId: uuid("company_id")
      .notNull()
      .references(() => company.companyId),
    postingDate: date("posting_date").notNull(),
    sourceDocumentId: uuid("source_document_id").references(() => document.documentId),
    description: varchar("description"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("idx_journal_entry_company").on(table.tenantId, table.companyId),
    index("idx_journal_entry_date").on(table.tenantId, table.postingDate),
    index("idx_journal_entry_document").on(table.sourceDocumentId),
    index("idx_journal_entry_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const journalLine = pgTable(
  "journal_line",
  {
    journalLineId: uuid("journal_line_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyId: uuid("company_id")
      .notNull()
      .references(() => company.companyId),
    journalEntryId: uuid("journal_entry_id")
      .notNull()
      .references(() => journalEntry.journalEntryId),
    glAccountId: uuid("gl_account_id")
      .notNull()
      .references(() => glAccount.glAccountId),
    debitAmount: numeric("debit_amount").notNull().default("0"),
    creditAmount: numeric("credit_amount").notNull().default("0"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("idx_journal_line_account").on(table.glAccountId),
    index("idx_journal_line_entry").on(table.journalEntryId),
    index("idx_journal_line_tenant").on(table.tenantId),
    check(
      "chk_debit_or_credit",
      sql`(${table.debitAmount} > 0 AND ${table.creditAmount} = 0) OR (${table.creditAmount} > 0 AND ${table.debitAmount} = 0)`,
    ),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const factSalesEvent = pgTable(
  "fact_sales_event",
  {
    factSalesEventId: uuid("fact_sales_event_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyId: uuid("company_id"),
    sourceDocumentId: uuid("source_document_id"),
    sourceDocumentLineId: uuid("source_document_line_id"),
    customerId: uuid("customer_id"),
    articleId: uuid("article_id"),
    eventType: varchar("event_type"),
    quantityDelta: numeric("quantity_delta").notNull(),
    amountNetDelta: numeric("amount_net_delta").notNull(),
    bookingPeriod: date("booking_period").notNull(),
    fiscalPeriodId: uuid("fiscal_period_id").references(() => fiscalPeriod.fiscalPeriodId),
    cogsDelta: numeric("cogs_delta"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    transactionId: uuid("transaction_id"),
  },
  (table) => [
    index("idx_fact_sales_article").on(table.tenantId, table.articleId),
    index("idx_fact_sales_customer").on(table.tenantId, table.customerId),
    index("idx_fact_sales_period").on(table.tenantId, table.bookingPeriod),
    index("idx_fact_sales_fiscal_period").on(table.tenantId, table.fiscalPeriodId),
    index("idx_fact_sales_tenant").on(table.tenantId),
    index("idx_fact_sales_tx").on(table.tenantId, table.transactionId),
    foreignKey({
      columns: [table.tenantId, table.companyId],
      foreignColumns: [company.tenantId, company.companyId],
    }),
    foreignKey({
      columns: [table.tenantId, table.sourceDocumentId],
      foreignColumns: [document.tenantId, document.documentId],
    }),
    foreignKey({
      columns: [table.tenantId, table.sourceDocumentLineId],
      foreignColumns: [documentLine.tenantId, documentLine.documentLineId],
    }),
    foreignKey({
      columns: [table.tenantId, table.customerId],
      foreignColumns: [address.tenantId, address.addressId],
    }),
    foreignKey({
      columns: [table.tenantId, table.articleId],
      foreignColumns: [article.tenantId, article.articleId],
    }),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const factPurchaseEvent = pgTable(
  "fact_purchase_event",
  {
    factPurchaseEventId: uuid("fact_purchase_event_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyId: uuid("company_id"),
    sourceDocumentId: uuid("source_document_id"),
    sourceDocumentLineId: uuid("source_document_line_id"),
    supplierId: uuid("supplier_id"),
    articleId: uuid("article_id"),
    eventType: varchar("event_type"),
    quantityDelta: numeric("quantity_delta").notNull(),
    amountNetDelta: numeric("amount_net_delta").notNull(),
    avgCostBefore: numeric("avg_cost_before"),
    avgCostAfter: numeric("avg_cost_after"),
    bookingPeriod: date("booking_period").notNull(),
    fiscalPeriodId: uuid("fiscal_period_id").references(() => fiscalPeriod.fiscalPeriodId),
    transactionId: uuid("transaction_id"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("idx_fact_purchase_article").on(table.tenantId, table.articleId),
    index("idx_fact_purchase_supplier").on(table.tenantId, table.supplierId),
    index("idx_fact_purchase_fiscal_period").on(table.tenantId, table.fiscalPeriodId),
    index("idx_fact_purchase_tx").on(table.tenantId, table.transactionId),
    foreignKey({
      columns: [table.tenantId, table.companyId],
      foreignColumns: [company.tenantId, company.companyId],
    }),
    foreignKey({
      columns: [table.tenantId, table.sourceDocumentId],
      foreignColumns: [document.tenantId, document.documentId],
    }),
    foreignKey({
      columns: [table.tenantId, table.supplierId],
      foreignColumns: [address.tenantId, address.addressId],
    }),
    foreignKey({
      columns: [table.tenantId, table.articleId],
      foreignColumns: [article.tenantId, article.articleId],
    }),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const deliveryAddress = pgTable(
  "delivery_address",
  {
    deliveryAddressId: uuid("delivery_address_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    addressId: uuid("address_id")
      .notNull()
      .references(() => address.addressId),
    name: varchar("name"),
    addressLine1: varchar("address_line_1").notNull(),
    addressLine2: varchar("address_line_2"),
    postalCode: varchar("postal_code").notNull(),
    city: varchar("city").notNull(),
    countryCode: char("country_code", { length: 2 }).notNull(),
    isActive: boolean("is_active").default(true),
    defaultForShipping: boolean("default_for_shipping").default(false),
    customAttributes: jsonb("custom_attributes"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }),
  },
  (table) => [
    index("idx_delivery_address_partner").on(table.addressId),
    index("idx_delivery_address_tenant").on(table.tenantId),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const productionOrder = pgTable(
  "production_order",
  {
    productionOrderId: uuid("production_order_id").primaryKey().defaultRandom(),
    tenantId: uuid("tenant_id")
      .notNull()
      .references(() => tenant.tenantId),
    companyId: uuid("company_id").references(() => company.companyId),
    orderNo: varchar("order_no", { length: 50 }).notNull(),
    articleId: uuid("article_id").references(() => article.articleId),
    quantity: integer("quantity").notNull().default(0),
    status: varchar("status", { length: 20 }).notNull().default("planned"),
    plannedStartDate: date("planned_start_date"),
    plannedEndDate: date("planned_end_date"),
    actualStartDate: date("actual_start_date"),
    actualEndDate: date("actual_end_date"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }),
  },
  (table) => [
    unique().on(table.tenantId, table.orderNo),
    index("idx_production_order_tenant").on(table.tenantId),
    index("idx_production_order_article").on(table.articleId),
    index("idx_production_order_status").on(table.status),
    pgPolicy("tenant_isolation", {
      as: "permissive",
      for: "all",
      to: "public",
      using: sql`${table.tenantId} = NULLIF(current_setting('app.tenant_id', true), '')::uuid`,
    }),
  ],
).enableRLS();

export const transactionRelations = defineRelationsPart(
  {
    tenant,
    appUser,
    company,
    address,
    article,
    warehouse,
    taxCode,
    costCenter,
    glAccount,
    documentType,
    numberSequence,
    documentGroup,
    document,
    documentLine,
    serialNumber,
    documentLineTracking,
    inventoryBalance,
    inventoryMovement,
    journalEntry,
    journalLine,
    factSalesEvent,
    factPurchaseEvent,
    deliveryAddress,
    productionOrder,
  },
  (r) => ({
    document: {
      lines: r.many.documentLine({ from: r.document.documentId, to: r.documentLine.documentId }),
    },
    documentLine: {
      document: r.one.document({ from: r.documentLine.documentId, to: r.document.documentId }),
      tracking: r.many.documentLineTracking({
        from: r.documentLine.documentLineId,
        to: r.documentLineTracking.documentLineId,
      }),
    },
  }),
);
