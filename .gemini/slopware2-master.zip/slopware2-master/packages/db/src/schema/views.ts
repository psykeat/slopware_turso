import { sql } from "drizzle-orm";
import {
  pgView,
  uuid,
  varchar,
  boolean,
  jsonb,
  timestamp,
  integer,
  text,
} from "drizzle-orm/pg-core";

import { tenantFields, tenantLayouts, tenantRules, systemSettings, tenant } from "./system";

export const currentTenantCtx = pgView("_current_tenant_ctx", {
  tenantId: uuid("tenant_id"),
  organizationId: uuid("organization_id"),
}).as(sql`
  SELECT 
    t.tenant_id,
    t.organization_id
  FROM ${tenant} t
  WHERE t.tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid
`);

export const effectiveFields = pgView("effective_fields", {
  fieldId: uuid("field_id"),
  scope: varchar("scope"),
  organizationId: uuid("organization_id"),
  tenantId: uuid("tenant_id"),
  entityName: varchar("entity_name"),
  fieldName: varchar("field_name"),
  fieldType: varchar("field_type"),
  isRequired: boolean("is_required"),
  customAttributes: jsonb("custom_attributes"),
  createdAt: timestamp("created_at", { withTimezone: true }),
  label: jsonb("label"),
  helpText: jsonb("help_text"),
  isVisible: boolean("is_visible"),
  displayOrder: integer("display_order"),
  importColumn: text("import_column"),
  importType: text("import_type"),
  importRequired: boolean("import_required"),
  importTransform: text("import_transform"),
  groupId: varchar("group_id"),
  lookupTable: varchar("lookup_table"),
  lookupFilter: jsonb("lookup_filter"),
}).as(sql`
  SELECT DISTINCT ON (entity_name, field_name)
    field_id, scope, organization_id, tenant_id, entity_name, field_name, field_type, 
    is_required, custom_attributes, created_at, label, help_text, is_visible, 
    display_order, import_column, import_type, import_required, import_transform, 
    group_id, lookup_table, lookup_filter
  FROM (
    SELECT *, 3 as priority FROM ${tenantFields} WHERE scope = 'tenant' AND tenant_id = (SELECT tenant_id FROM ${currentTenantCtx})
    UNION ALL
    SELECT *, 2 as priority FROM ${tenantFields} WHERE scope = 'organization' AND organization_id = (SELECT organization_id FROM ${currentTenantCtx})
    UNION ALL
    SELECT *, 1 as priority FROM ${tenantFields} WHERE scope = 'global'
  ) combined
  ORDER BY entity_name, field_name, priority DESC
`);

export const effectiveLayout = pgView("effective_layout", {
  layoutId: uuid("layout_id"),
  scope: varchar("scope"),
  organizationId: uuid("organization_id"),
  tenantId: uuid("tenant_id"),
  entityName: varchar("entity_name"),
  layoutKey: varchar("layout_key"),
  layoutDefinition: jsonb("layout_definition"),
  createdAt: timestamp("created_at", { withTimezone: true }),
}).as(sql`
  SELECT DISTINCT ON (entity_name, layout_key)
    layout_id, scope, organization_id, tenant_id, entity_name, layout_key, layout_definition, created_at
  FROM (
    SELECT *, 3 as priority FROM ${tenantLayouts} WHERE scope = 'tenant' AND tenant_id = (SELECT tenant_id FROM ${currentTenantCtx})
    UNION ALL
    SELECT *, 2 as priority FROM ${tenantLayouts} WHERE scope = 'organization' AND organization_id = (SELECT organization_id FROM ${currentTenantCtx})
    UNION ALL
    SELECT *, 1 as priority FROM ${tenantLayouts} WHERE scope = 'global'
  ) combined
  ORDER BY entity_name, layout_key, priority DESC
`);

export const effectiveRules = pgView("effective_rules", {
  ruleId: uuid("rule_id"),
  scope: varchar("scope"),
  organizationId: uuid("organization_id"),
  tenantId: uuid("tenant_id"),
  entityName: varchar("entity_name"),
  hookName: varchar("hook_name"),
  ruleState: varchar("rule_state"),
  ruleDefinition: jsonb("rule_definition"),
  createdAt: timestamp("created_at", { withTimezone: true }),
  ruleSource: text("rule_source"),
}).as(sql`
  SELECT DISTINCT ON (entity_name, hook_name)
    rule_id, scope, organization_id, tenant_id, entity_name, hook_name, rule_state, rule_definition, created_at, rule_source
  FROM (
    SELECT *, 3 as priority FROM ${tenantRules} WHERE scope = 'tenant' AND tenant_id = (SELECT tenant_id FROM ${currentTenantCtx}) AND rule_state = 'published'
    UNION ALL
    SELECT *, 2 as priority FROM ${tenantRules} WHERE scope = 'organization' AND organization_id = (SELECT organization_id FROM ${currentTenantCtx}) AND rule_state = 'published'
    UNION ALL
    SELECT *, 1 as priority FROM ${tenantRules} WHERE scope = 'global' AND rule_state = 'published'
  ) combined
  ORDER BY entity_name, hook_name, priority DESC
`);

export const effectiveSettings = pgView("effective_settings", {
  settingId: uuid("setting_id"),
  scope: varchar("scope"),
  organizationId: uuid("organization_id"),
  tenantId: uuid("tenant_id"),
  key: varchar("key"),
  value: jsonb("value"),
  createdAt: timestamp("created_at", { withTimezone: true }),
  updatedAt: timestamp("updated_at", { withTimezone: true }),
}).as(sql`
  SELECT DISTINCT ON (key)
    setting_id, scope, organization_id, tenant_id, key, value, created_at, updated_at
  FROM (
    SELECT *, 3 as priority FROM ${systemSettings} WHERE scope = 'tenant' AND tenant_id = (SELECT tenant_id FROM ${currentTenantCtx})
    UNION ALL
    SELECT *, 2 as priority FROM ${systemSettings} WHERE scope = 'organization' AND organization_id = (SELECT organization_id FROM ${currentTenantCtx})
    UNION ALL
    SELECT *, 1 as priority FROM ${systemSettings} WHERE scope = 'global'
  ) combined
  ORDER BY key, priority DESC
`);
