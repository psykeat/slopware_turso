import { db } from "../index";
import { connectorDefinition, schemaAnnotations } from "../schema";

const XRECHNUNG_LOCKED_FIELDS = [
  "invoiceNumber",
  "invoiceDate",
  "sellerName",
  "totalNet",
  "totalTax",
  "totalGross",
];

export async function seedXrechnungConnector(): Promise<void> {
  await db
    .insert(connectorDefinition)
    .values({
      slug: "xrechnung",
      label: { en: "XRechnung Inbound", de: "XRechnung Eingang", fr: "XRechnung Entrée" },
      scriptPath: "connectors/xrechnung-script.ts",
      defaultMappings: {
        sourceField: "invoiceNumber",
        targetEntity: "document",
        targetField: "documentNo",
      },
      lockedFields: XRECHNUNG_LOCKED_FIELDS,
      atomicityMode: "file",
    })
    .onConflictDoNothing();

  const lockedColumns = [
    {
      table: "document",
      column: "document_no",
      name: "Document Number",
      desc: "Source invoice number from XRechnung",
    },
    {
      table: "document",
      column: "document_date",
      name: "Invoice Date",
      desc: "Original invoice date from XRechnung",
    },
    {
      table: "document",
      column: "total_net",
      name: "Total Net",
      desc: "Net amount from XRechnung",
    },
    {
      table: "document",
      column: "total_tax",
      name: "Total Tax",
      desc: "Tax amount from XRechnung",
    },
    {
      table: "document",
      column: "total_gross",
      name: "Total Gross",
      desc: "Gross amount from XRechnung",
    },
  ];

  for (const col of lockedColumns) {
    await db
      .insert(schemaAnnotations)
      .values({
        tableName: col.table,
        columnName: col.column,
        businessName: col.name,
        description: col.desc,
        dataClass: "transaction",
        mandatoryFor: ["xrechnung"],
        lockedFor: ["xrechnung"],
      })
      .onConflictDoNothing();
  }
}
