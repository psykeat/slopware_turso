import { describe, it, expect } from "vitest";

import { resolveArticlePricing } from "../queries/article-pricing";

describe("resolveArticlePricing", () => {
  it("returns pricing with price and tax when all matches found", async () => {
    const mockSql = {
      unsafe: () =>
        Promise.resolve([
          {
            net_price: "19.99",
            price_list_id: "pl-1",
            currency_id: "EUR",
            tax_rate: "19",
            tax_code_id: "tc-1",
            tax_code: "MW19",
          },
        ]),
    } as any;

    const result = await resolveArticlePricing(mockSql, {
      articleId: "art-1",
      addressId: "addr-1",
      documentDate: "2026-01-15",
    });

    expect(result.netPrice).toBe("19.99");
    expect(result.taxRate).toBe(19);
    expect(result.taxCodeId).toBe("tc-1");
    expect(result.taxCode).toBe("MW19");
    expect(result.currencyId).toBe("EUR");
    expect(result.priceListId).toBe("pl-1");
  });

  it("returns null price when no price list item matches", async () => {
    const mockSql = {
      unsafe: () =>
        Promise.resolve([
          {
            net_price: null,
            price_list_id: null,
            currency_id: null,
            tax_rate: "19",
            tax_code_id: "tc-1",
            tax_code: "MW19",
          },
        ]),
    } as any;

    const result = await resolveArticlePricing(mockSql, {
      articleId: "art-nomatch",
      addressId: "addr-1",
      documentDate: "2026-01-15",
    });

    expect(result.netPrice).toBeNull();
    expect(result.priceListId).toBeNull();
    expect(result.taxRate).toBe(19);
  });

  it("returns null tax when no tax rule matches", async () => {
    const mockSql = {
      unsafe: () =>
        Promise.resolve([
          {
            net_price: "25.00",
            price_list_id: "pl-2",
            currency_id: "USD",
            tax_rate: null,
            tax_code_id: null,
            tax_code: null,
          },
        ]),
    } as any;

    const result = await resolveArticlePricing(mockSql, {
      articleId: "art-2",
      addressId: "addr-2",
      documentDate: "2026-06-01",
    });

    expect(result.netPrice).toBe("25.00");
    expect(result.taxRate).toBeNull();
    expect(result.taxCodeId).toBeNull();
    expect(result.taxCode).toBeNull();
    expect(result.currencyId).toBe("USD");
  });

  it("returns all null when address not found", async () => {
    const mockSql = {
      unsafe: () => Promise.resolve([]),
    } as any;

    const result = await resolveArticlePricing(mockSql, {
      articleId: "art-1",
      addressId: "addr-nonexistent",
      documentDate: "2026-01-15",
    });

    expect(result.netPrice).toBeNull();
    expect(result.taxRate).toBeNull();
    expect(result.taxCodeId).toBeNull();
    expect(result.taxCode).toBeNull();
    expect(result.currencyId).toBeNull();
    expect(result.priceListId).toBeNull();
  });

  it("builds correct SQL with article_id, document_date, and address_id params", async () => {
    let capturedQuery = "";
    let capturedParams: unknown[] = [];
    const mockSql = {
      unsafe: (q: string, p: unknown[]) => {
        capturedQuery = q;
        capturedParams = p;
        return Promise.resolve([]);
      },
    } as any;

    await resolveArticlePricing(mockSql, {
      articleId: "a-1",
      addressId: "b-2",
      documentDate: "2026-03-01",
    });

    expect(capturedQuery).toContain("pli.article_id = $1");
    expect(capturedQuery).toContain("a.address_id = $3");
    expect(capturedParams).toEqual(["a-1", "2026-03-01", "b-2"]);
  });

  it("tax rule resolution joins article tax_class, address tax_class, and country", async () => {
    let capturedQuery = "";
    const mockSql = {
      unsafe: (q: string) => {
        capturedQuery = q;
        return Promise.resolve([]);
      },
    } as any;

    await resolveArticlePricing(mockSql, {
      articleId: "art-1",
      addressId: "addr-1",
      documentDate: "2026-01-15",
    });

    expect(capturedQuery).toContain("tr.article_tax_class_id = ar.tax_class_id");
    expect(capturedQuery).toContain("tr.customer_tax_class_id = a.tax_class_id");
    expect(capturedQuery).toContain("tr.country_code = a.country_code");
  });
});
