import { describe, it, expect } from "vitest";

import {
  createEntity,
  patchEntity,
  deleteEntity,
  deactivateEntity,
  duplicateEntity,
  validateAgainstEffectiveFields,
  preparePatchPayload,
} from "../commands";

describe("Commands Module", () => {
  describe("exports", () => {
    it("exports all expected functions", () => {
      expect(typeof createEntity).toBe("function");
      expect(typeof patchEntity).toBe("function");
      expect(typeof deleteEntity).toBe("function");
      expect(typeof deactivateEntity).toBe("function");
      expect(typeof duplicateEntity).toBe("function");
      expect(typeof validateAgainstEffectiveFields).toBe("function");
      expect(typeof preparePatchPayload).toBe("function");
    });
  });

  describe("preparePatchPayload", () => {
    it("removes undefined values", () => {
      const result = preparePatchPayload("article", {
        name: "Test",
        description: undefined,
        price: 10,
      });
      expect(result).toEqual({ name: "Test", price: 10 });
    });

    it("keeps null values", () => {
      const result = preparePatchPayload("article", {
        name: "Test",
        description: null,
      });
      expect(result).toEqual({ name: "Test", description: null });
    });
  });

  describe("validateAgainstEffectiveFields", () => {
    it("rejects unregistered entity", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      const result = await validateAgainstEffectiveFields(mockSql, "nonexistent_entity", {});
      expect(result.valid).toBe(false);
      expect(result.errors[0].code).toBe("unknown");
    });

    it("rejects non-patchable entity", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      const result = await validateAgainstEffectiveFields(mockSql, "document", {});
      expect(result.valid).toBe(false);
      expect(result.errors[0].code).toBe("unknown");
    });

    it("returns valid for patchable entity with empty payload and no required fields", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      const result = await validateAgainstEffectiveFields(mockSql, "article", {});
      expect(result.valid).toBe(true);
    });
  });

  describe("createEntity", () => {
    it("returns error for unregistered entity", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      const result = await createEntity(mockSql, "nonexistent_entity", {});
      expect(result.success).toBe(false);
      expect(result.error).toContain("not found");
    });

    it("returns error for non-patchable entity", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      const result = await createEntity(mockSql, "document", {});
      expect(result.success).toBe(false);
      expect(result.error).toContain("not generically creatable");
    });

    it("creates organization successfully", async () => {
      const mockFields = [
        { fieldName: "name", fieldType: "text", isRequired: false },
        { fieldName: "slug", fieldType: "text", isRequired: true },
      ];
      const mockSql = {
        unsafe: (q: string) => {
          if (q.includes("effective_fields")) return Promise.resolve(mockFields);
          return Promise.resolve([{ organization_id: "new-org-id" }]);
        },
      } as any;
      const result = await createEntity(mockSql, "organization", {
        name: "Test Org",
        slug: "test-org",
      });
      expect(result.success).toBe(true);
      expect(result.id).toBe("new-org-id");
    });
  });

  describe("patchEntity", () => {
    it("returns error for unregistered entity", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      const result = await patchEntity(mockSql, "nonexistent_entity", "id", {});
      expect(result.success).toBe(false);
      expect(result.error).toContain("not found");
    });

    it("returns error for non-patchable entity", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      const result = await patchEntity(mockSql, "document", "id", {});
      expect(result.success).toBe(false);
      expect(result.error).toContain("not generically patchable");
    });

    it("patches organization successfully", async () => {
      let lastQuery = "";
      const mockFields = [
        { fieldName: "name", fieldType: "text", isRequired: false },
        { fieldName: "slug", fieldType: "text", isRequired: false },
      ];
      const mockSql = {
        unsafe: (q: string) => {
          lastQuery = q;
          if (q.includes("effective_fields")) return Promise.resolve(mockFields);
          return Promise.resolve([]);
        },
      } as any;
      const result = await patchEntity(mockSql, "organization", "org-id", {
        name: "Updated Org",
      });
      expect(result.success).toBe(true);
      expect(lastQuery).toContain("organization");
    });
  });

  describe("deleteEntity", () => {
    it("returns error for unregistered entity", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      const result = await deleteEntity(mockSql, "nonexistent_entity", "id");
      expect(result.success).toBe(false);
      expect(result.error).toContain("not found");
    });

    it("returns error for non-patchable entity", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      const result = await deleteEntity(mockSql, "document", "id");
      expect(result.success).toBe(false);
      expect(result.error).toContain("not generically deletable");
    });

    it("performs soft delete for master data with is_active", async () => {
      let lastQuery = "";
      const mockSql = {
        unsafe: (q: string) => {
          lastQuery = q;
          return Promise.resolve([]);
        },
      } as any;
      const result = await deleteEntity(mockSql, "article_group", "id");
      expect(result.success).toBe(true);
      expect(result.action).toBe("soft_delete");
      expect(lastQuery).toContain("is_active = false");
    });

    it("performs soft delete for master data with archived_at", async () => {
      let lastQuery = "";
      const mockSql = {
        unsafe: (q: string) => {
          lastQuery = q;
          return Promise.resolve([]);
        },
      } as any;
      const result = await deleteEntity(mockSql, "article", "id");
      expect(result.success).toBe(true);
      expect(result.action).toBe("soft_delete");
      expect(lastQuery).toContain("archived_at");
    });

    it("performs soft delete for organization (non-tenant-scoped)", async () => {
      let lastQuery = "";
      const mockSql = {
        unsafe: (q: string) => {
          lastQuery = q;
          return Promise.resolve([]);
        },
      } as any;
      const result = await deleteEntity(mockSql, "organization", "org-id");
      expect(result.success).toBe(true);
      expect(result.action).toBe("soft_delete");
      expect(lastQuery).toContain("is_active = false");
    });
  });

  describe("deactivateEntity", () => {
    it("returns error for unregistered entity", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      const result = await deactivateEntity(mockSql, "nonexistent_entity", "id");
      expect(result.success).toBe(false);
      expect(result.error).toContain("not found");
    });

    it("returns error for non-master-data entity", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      const result = await deactivateEntity(mockSql, "document", "id");
      expect(result.success).toBe(false);
      expect(result.error).toContain("not master data");
    });

    it("deactivates master data with is_active", async () => {
      let lastQuery = "";
      const mockSql = {
        unsafe: (q: string) => {
          lastQuery = q;
          return Promise.resolve([]);
        },
      } as any;
      const result = await deactivateEntity(mockSql, "company", "id");
      expect(result.success).toBe(true);
      expect(lastQuery).toContain("is_active = false");
    });
  });

  describe("duplicateEntity", () => {
    it("returns error for unregistered entity", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      const result = await duplicateEntity(mockSql, "nonexistent_entity", "id");
      expect(result.success).toBe(false);
      expect(result.error).toContain("not found");
    });

    it("returns error for non-patchable entity", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      const result = await duplicateEntity(mockSql, "document", "id");
      expect(result.success).toBe(false);
      expect(result.error).toContain("not generically duplicable");
    });

    it("returns error when source record not found", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      const result = await duplicateEntity(mockSql, "company", "nonexistent-id");
      expect(result.success).toBe(false);
      expect(result.error).toContain("not found");
    });

    it("duplicates company successfully", async () => {
      let queries: string[] = [];
      const mockSource = {
        company_id: "src-id",
        name: "Source Company",
        tax_id: "DE123",
        is_active: true,
        created_at: new Date(),
        updated_at: new Date(),
      };
      const mockSql = {
        unsafe: (q: string) => {
          queries.push(q);
          if (q.includes("SELECT")) return Promise.resolve([mockSource]);
          return Promise.resolve([{ company_id: "new-copy-id" }]);
        },
        tenantId: "tenant-123",
      } as any;
      const result = await duplicateEntity(mockSql, "company", "src-id");
      expect(result.success).toBe(true);
      expect(result.id).toBe("new-copy-id");
      expect(queries.length).toBe(2);
      expect(queries[0]).toContain("SELECT");
      expect(queries[1]).toContain("INSERT");
    });

    it("strips audit fields from duplicated record", async () => {
      const mockSource = {
        company_id: "src-id",
        name: "Source Company",
        created_at: new Date(),
        updated_at: new Date(),
        is_active: true,
      };
      const mockSql = {
        unsafe: (q: string) => {
          if (q.includes("SELECT")) return Promise.resolve([mockSource]);
          return Promise.resolve([{ company_id: "new-copy-id" }]);
        },
        tenantId: "tenant-123",
      } as any;
      const result = await duplicateEntity(mockSql, "company", "src-id");
      expect(result.success).toBe(true);
    });

    it("sets status to draft when duplicating", async () => {
      let insertQuery = "";
      const mockSource = {
        production_order_id: "src-id",
        order_no: "PO-001",
        status: "posted",
        is_active: true,
      };
      const mockSql = {
        unsafe: (q: string) => {
          if (q.includes("SELECT")) return Promise.resolve([mockSource]);
          insertQuery = q;
          return Promise.resolve([{ production_order_id: "new-copy-id" }]);
        },
        tenantId: "tenant-123",
      } as any;
      const result = await duplicateEntity(mockSql, "prodord", "src-id");
      expect(result.success).toBe(true);
      expect(insertQuery).toContain("INSERT");
    });
  });

  describe("tenant entity commands", () => {
    it("creates tenant successfully", async () => {
      const mockFields = [
        { fieldName: "name", fieldType: "text", isRequired: false },
        { fieldName: "slug", fieldType: "text", isRequired: true },
        { fieldName: "organization_id", fieldType: "uuid", isRequired: true },
      ];
      const mockSql = {
        unsafe: (q: string) => {
          if (q.includes("effective_fields")) return Promise.resolve(mockFields);
          return Promise.resolve([{ tenant_id: "new-tenant-id" }]);
        },
      } as any;
      const result = await createEntity(mockSql, "tenant", {
        name: "Test Tenant",
        slug: "test-tenant",
        organization_id: "org-uuid",
      });
      expect(result.success).toBe(true);
      expect(result.id).toBe("new-tenant-id");
    });

    it("patches tenant successfully", async () => {
      let lastQuery = "";
      const mockFields = [
        { fieldName: "name", fieldType: "text", isRequired: false },
        { fieldName: "is_active", fieldType: "boolean", isRequired: false },
      ];
      const mockSql = {
        unsafe: (q: string) => {
          lastQuery = q;
          if (q.includes("effective_fields")) return Promise.resolve(mockFields);
          return Promise.resolve([]);
        },
      } as any;
      const result = await patchEntity(mockSql, "tenant", "tenant-id", {
        name: "Updated Tenant",
      });
      expect(result.success).toBe(true);
      expect(lastQuery).toContain("tenant");
    });

    it("performs soft delete for tenant", async () => {
      let lastQuery = "";
      const mockSql = {
        unsafe: (q: string) => {
          lastQuery = q;
          return Promise.resolve([]);
        },
      } as any;
      const result = await deleteEntity(mockSql, "tenant", "tenant-id");
      expect(result.success).toBe(true);
      expect(result.action).toBe("soft_delete");
      expect(lastQuery).toContain("is_active = false");
    });
  });
});
