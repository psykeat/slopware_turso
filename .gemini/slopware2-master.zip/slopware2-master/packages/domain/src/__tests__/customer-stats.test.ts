import { describe, it, expect } from "vitest";

import { getCustomerDocuments } from "../queries/customer-stats";

describe("getCustomerDocuments", () => {
  it("returns last 10 documents with correct fields", async () => {
    const mockSql = {
      unsafe: () =>
        Promise.resolve([
          {
            document_id: "doc-1",
            document_no: "RE-2024-001",
            document_type: "R",
            document_date: "2024-03-15",
            status: "posted",
            total_gross: "1190.00",
          },
          {
            document_id: "doc-2",
            document_no: "RE-2024-002",
            document_type: "R",
            document_date: "2024-02-10",
            status: "posted",
            total_gross: "595.00",
          },
        ]),
    } as any;

    const result = await getCustomerDocuments(mockSql, { customerId: "cust-1" });

    expect(result).toHaveLength(2);
    expect(result[0].documentId).toBe("doc-1");
    expect(result[0].documentNo).toBe("RE-2024-001");
    expect(result[0].documentType).toBe("R");
    expect(result[0].documentDate).toBe("2024-03-15");
    expect(result[0].status).toBe("posted");
    expect(result[0].totalGross).toBe(1190);
  });

  it("returns empty array when no documents exist", async () => {
    const mockSql = {
      unsafe: () => Promise.resolve([]),
    } as any;

    const result = await getCustomerDocuments(mockSql, { customerId: "cust-empty" });

    expect(result).toHaveLength(0);
  });

  it("uses custom limit parameter", async () => {
    let capturedParams: unknown[] = [];
    const mockSql = {
      unsafe: (q: string, p: unknown[]) => {
        capturedParams = p;
        return Promise.resolve([]);
      },
    } as any;

    await getCustomerDocuments(mockSql, { customerId: "cust-1", limit: 20 });

    expect(capturedParams).toEqual(["cust-1", 20]);
  });

  it("defaults limit to 10", async () => {
    let capturedParams: unknown[] = [];
    const mockSql = {
      unsafe: (q: string, p: unknown[]) => {
        capturedParams = p;
        return Promise.resolve([]);
      },
    } as any;

    await getCustomerDocuments(mockSql, { customerId: "cust-1" });

    expect(capturedParams).toEqual(["cust-1", 10]);
  });

  it("handles null total_gross gracefully", async () => {
    const mockSql = {
      unsafe: () =>
        Promise.resolve([
          {
            document_id: "doc-1",
            document_no: "RE-2024-001",
            document_type: "R",
            document_date: "2024-03-15",
            status: "draft",
            total_gross: null,
          },
        ]),
    } as any;

    const result = await getCustomerDocuments(mockSql, { customerId: "cust-1" });

    expect(result[0].totalGross).toBe(0);
  });
});
