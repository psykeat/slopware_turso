import { describe, it, expect } from "vitest";

import { getCustomerYearlyRevenue } from "../queries/customer-yearly-revenue";

describe("getCustomerYearlyRevenue", () => {
  it("returns yearly revenue with correct fields", async () => {
    const mockSql = {
      unsafe: () =>
        Promise.resolve([
          {
            year: 2024,
            quantity: "150",
            net_amount: "10000.00",
          },
          {
            year: 2023,
            quantity: "100",
            net_amount: "7500.00",
          },
        ]),
    } as any;

    const result = await getCustomerYearlyRevenue(mockSql, { customerId: "cust-1" });

    expect(result).toHaveLength(2);
    expect(result[0].year).toBe(2024);
    expect(result[0].quantity).toBe(150);
    expect(result[0].netAmount).toBe(10000);
    expect(result[1].year).toBe(2023);
    expect(result[1].quantity).toBe(100);
    expect(result[1].netAmount).toBe(7500);
  });

  it("returns empty array when no posted invoices exist", async () => {
    const mockSql = {
      unsafe: () => Promise.resolve([]),
    } as any;

    const result = await getCustomerYearlyRevenue(mockSql, { customerId: "cust-empty" });

    expect(result).toHaveLength(0);
  });

  it("filters by customerId parameter", async () => {
    let capturedParams: unknown[] = [];
    const mockSql = {
      unsafe: (q: string, p: unknown[]) => {
        capturedParams = p;
        return Promise.resolve([]);
      },
    } as any;

    await getCustomerYearlyRevenue(mockSql, { customerId: "my-customer-id" });

    expect(capturedParams).toEqual(["my-customer-id"]);
  });

  it("handles null values gracefully", async () => {
    const mockSql = {
      unsafe: () =>
        Promise.resolve([
          {
            year: 2024,
            quantity: null,
            net_amount: null,
          },
        ]),
    } as any;

    const result = await getCustomerYearlyRevenue(mockSql, { customerId: "cust-1" });

    expect(result[0].year).toBe(2024);
    expect(result[0].quantity).toBe(0);
    expect(result[0].netAmount).toBe(0);
  });
});
