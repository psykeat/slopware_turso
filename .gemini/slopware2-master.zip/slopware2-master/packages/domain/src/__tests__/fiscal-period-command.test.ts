import { describe, it, expect } from "vitest";

import { closePeriod } from "../commands/fiscal-period-command";

describe("closePeriod", () => {
  it("sets is_closed = true for open period", async () => {
    let updatedId = "";
    const mockSql = {
      unsafe: (q: string, params?: unknown[]) => {
        if (q.includes("SELECT fiscal_period_id"))
          return Promise.resolve([{ fiscal_period_id: "fp-1", is_closed: false }]);
        if (q.includes("UPDATE fiscal_period")) {
          updatedId = String(params?.[0]);
          return Promise.resolve([]);
        }
        return Promise.resolve([]);
      },
    } as any;
    const result = await closePeriod(mockSql, { fiscalPeriodId: "fp-1" });
    expect(result.success).toBe(true);
    expect(updatedId).toBe("fp-1");
  });

  it("returns success for already-closed period (idempotent)", async () => {
    const mockSql = {
      unsafe: (q: string) => {
        if (q.includes("SELECT fiscal_period_id"))
          return Promise.resolve([{ fiscal_period_id: "fp-1", is_closed: true }]);
        return Promise.resolve([]);
      },
    } as any;
    const result = await closePeriod(mockSql, { fiscalPeriodId: "fp-1" });
    expect(result.success).toBe(true);
    expect(result.errorCode).toBe("ALREADY_CLOSED");
  });

  it("returns NOT_FOUND for unknown period", async () => {
    const mockSql = {
      unsafe: () => Promise.resolve([]),
    } as any;
    const result = await closePeriod(mockSql, { fiscalPeriodId: "nx" });
    expect(result.success).toBe(false);
    expect(result.errorCode).toBe("NOT_FOUND");
  });
});
