import { describe, it, expect } from "vitest";

import { getInventoryBalance } from "../queries/inventory-balance";

describe("getInventoryBalance", () => {
  it("returns balance per warehouse with correct fields", async () => {
    const mockSql = {
      unsafe: () =>
        Promise.resolve([
          {
            warehouse_id: "wh-1",
            warehouse_code: "WH1",
            warehouse_name: "Main Warehouse",
            on_hand_qty: "100",
            reserved_qty: "20",
            available_qty: "80",
          },
          {
            warehouse_id: "wh-2",
            warehouse_code: "WH2",
            warehouse_name: "Secondary",
            on_hand_qty: "50",
            reserved_qty: "10",
            available_qty: "40",
          },
        ]),
    } as any;

    const result = await getInventoryBalance(mockSql, { articleId: "art-1" });

    expect(result).toHaveLength(2);
    expect(result[0].warehouseId).toBe("wh-1");
    expect(result[0].warehouseCode).toBe("WH1");
    expect(result[0].warehouseName).toBe("Main Warehouse");
    expect(result[0].onHandQty).toBe(100);
    expect(result[0].reservedQty).toBe(20);
    expect(result[0].availableQty).toBe(80);
  });

  it("returns zero values when no inventory balance exists", async () => {
    const mockSql = {
      unsafe: () =>
        Promise.resolve([
          {
            warehouse_id: "wh-1",
            warehouse_code: "WH1",
            warehouse_name: "Empty Warehouse",
            on_hand_qty: null,
            reserved_qty: null,
            available_qty: null,
          },
        ]),
    } as any;

    const result = await getInventoryBalance(mockSql, { articleId: "art-empty" });

    expect(result).toHaveLength(1);
    expect(result[0].onHandQty).toBe(0);
    expect(result[0].reservedQty).toBe(0);
    expect(result[0].availableQty).toBe(0);
  });

  it("returns empty array when no warehouses exist", async () => {
    const mockSql = {
      unsafe: () => Promise.resolve([]),
    } as any;

    const result = await getInventoryBalance(mockSql, { articleId: "art-1" });

    expect(result).toHaveLength(0);
  });

  it("filters by articleId parameter", async () => {
    let capturedParams: unknown[] = [];
    const mockSql = {
      unsafe: (q: string, p: unknown[]) => {
        capturedParams = p;
        return Promise.resolve([]);
      },
    } as any;

    await getInventoryBalance(mockSql, { articleId: "my-article-id" });

    expect(capturedParams).toEqual(["my-article-id"]);
  });

  it("uses SQL COALESCE for available qty fallback", async () => {
    const mockSql = {
      unsafe: () =>
        Promise.resolve([
          {
            warehouse_id: "wh-1",
            warehouse_code: "WH1",
            warehouse_name: "Test",
            on_hand_qty: "100",
            reserved_qty: "30",
            available_qty: "70",
          },
        ]),
    } as any;

    const result = await getInventoryBalance(mockSql, { articleId: "art-1" });

    expect(result[0].availableQty).toBe(70);
  });
});
