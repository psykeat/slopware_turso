import { describe, it, expect } from "vitest";

import { listHelperTables, getHelperTableItems } from "../lookups";

describe("Lookups Module", () => {
  describe("exports", () => {
    it("exports all expected functions", () => {
      expect(typeof listHelperTables).toBe("function");
      expect(typeof getHelperTableItems).toBe("function");
    });
  });

  describe("listHelperTables", () => {
    it("returns results from helper_table_registry", async () => {
      let lastQuery = "";
      const mockSql = {
        unsafe: (q: string) => {
          lastQuery = q;
          return Promise.resolve([]);
        },
      } as any;

      await listHelperTables(mockSql);
      expect(lastQuery).toContain("helper_table_registry");
      expect(lastQuery).toContain("ORDER BY table_name");
    });
  });

  describe("getHelperTableItems", () => {
    it("throws for unregistered table", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      await expect(getHelperTableItems(mockSql, "nonexistent_table")).rejects.toThrow(
        "not found in registry",
      );
    });

    it("builds query with i18n display column", async () => {
      let lastQuery = "";
      const mockSql = {
        unsafe: (q: string, _params?: unknown[]) => {
          if (q.includes("helper_table_registry")) {
            lastQuery = q;
            return Promise.resolve([
              {
                pk_column: "id",
                display_column: "name",
                display_is_i18n: true,
                code_column: "code",
                sort_column: "name",
                value_column: null,
              },
            ]);
          }
          lastQuery = q;
          return Promise.resolve([]);
        },
      } as any;

      await getHelperTableItems(mockSql, "some_table");
      expect(lastQuery).toContain("->>'en'");
    });

    it("builds query with search option", async () => {
      let lastQuery = "";
      const mockSql = {
        unsafe: (q: string, _params?: unknown[]) => {
          if (q.includes("helper_table_registry")) {
            return Promise.resolve([
              {
                pk_column: "id",
                display_column: "name",
                display_is_i18n: false,
                code_column: null,
                sort_column: "name",
                value_column: null,
              },
            ]);
          }
          lastQuery = q;
          return Promise.resolve([]);
        },
      } as any;

      await getHelperTableItems(mockSql, "some_table", { search: "test" });
      expect(lastQuery).toContain("ILIKE");
    });

    it("builds query with limit and offset", async () => {
      let lastQuery = "";
      const mockSql = {
        unsafe: (q: string, _params?: unknown[]) => {
          if (q.includes("helper_table_registry")) {
            return Promise.resolve([
              {
                pk_column: "id",
                display_column: "name",
                display_is_i18n: false,
                code_column: null,
                sort_column: "name",
                value_column: null,
              },
            ]);
          }
          lastQuery = q;
          return Promise.resolve([]);
        },
      } as any;

      await getHelperTableItems(mockSql, "some_table", {
        limit: 10,
        offset: 20,
      });
      expect(lastQuery).toContain("LIMIT");
      expect(lastQuery).toContain("OFFSET");
    });
  });
});
