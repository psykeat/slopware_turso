import { describe, it, expect } from "vitest";

import {
  getEffectiveFields,
  getEffectiveLayout,
  getEffectiveRules,
  getEffectiveSettings,
} from "../metadata";

describe("Metadata Services", () => {
  describe("exports", () => {
    it("exports all expected functions", () => {
      expect(typeof getEffectiveFields).toBe("function");
      expect(typeof getEffectiveLayout).toBe("function");
      expect(typeof getEffectiveRules).toBe("function");
      expect(typeof getEffectiveSettings).toBe("function");
    });
  });

  describe("getEffectiveFields", () => {
    it("accepts entityName option", () => {
      expect(() => {
        getEffectiveFields({ unsafe: () => Promise.resolve([]) } as any, { entityName: "article" });
      }).not.toThrow();
    });

    it("accepts optional fieldName", () => {
      expect(() => {
        getEffectiveFields({ unsafe: () => Promise.resolve([]) } as any, {
          entityName: "article",
          fieldName: "name",
        });
      }).not.toThrow();
    });
  });

  describe("getEffectiveLayout", () => {
    it("accepts entityName option", () => {
      expect(() => {
        getEffectiveLayout({ unsafe: () => Promise.resolve([]) } as any, { entityName: "article" });
      }).not.toThrow();
    });
  });

  describe("getEffectiveRules", () => {
    it("accepts entityName option", () => {
      expect(() => {
        getEffectiveRules({ unsafe: () => Promise.resolve([]) } as any, { entityName: "article" });
      }).not.toThrow();
    });
  });

  describe("getEffectiveSettings", () => {
    it("accepts optional options", () => {
      expect(() => {
        getEffectiveSettings({ unsafe: () => Promise.resolve([]) } as any);
      }).not.toThrow();
    });

    it("accepts prefix option", () => {
      expect(() => {
        getEffectiveSettings({ unsafe: () => Promise.resolve([]) } as any, { prefix: "currency" });
      }).not.toThrow();
    });

    it("accepts keys option", () => {
      expect(() => {
        getEffectiveSettings({ unsafe: () => Promise.resolve([]) } as any, {
          keys: ["currency.default"],
        });
      }).not.toThrow();
    });
  });
});
