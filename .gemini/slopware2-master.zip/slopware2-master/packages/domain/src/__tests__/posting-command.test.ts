import { describe, it, expect, vi } from "vitest";

import { postDocument } from "../commands/posting-command";

describe("postDocument", () => {
  const baseDoc = {
    document_id: "doc-1",
    document_type: "L",
    status: "draft",
    posted_at: null,
    company_id: "comp-1",
    warehouse_id: "wh-1",
    tenant_id: "tenant-1",
    posting_date: "2026-01-15",
    customer_id: "cust-1",
    total_net: "100.00",
    transaction_id: "tx-1",
    target_warehouse_id: null,
    storno_document_id: null,
    document_group_id: null,
  };

  const baseLine = {
    document_line_id: "line-1",
    article_id: "art-1",
    quantity: "5",
    warehouse_id: "wh-1",
    line_total_net: "100.00",
    net_price: "20.00",
    line_type: "article",
    target_warehouse_id: null,
    tracking_mode: null,
  };

  it("returns NOT_FOUND when document does not exist", async () => {
    const mockSql = { unsafe: () => Promise.resolve([]) } as any;
    const result = await postDocument(mockSql, { documentId: "nx", userId: "u1" });
    expect(result.success).toBe(false);
    expect(result.errorCode).toBe("NOT_FOUND");
  });

  it("returns ALREADY_POSTED when document has posted_at", async () => {
    const mockSql = {
      unsafe: (q: string) => {
        if (q.includes("SELECT document_id"))
          return Promise.resolve([{ ...baseDoc, posted_at: "2026-01-01T00:00:00Z" }]);
        return Promise.resolve([]);
      },
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(false);
    expect(result.errorCode).toBe("ALREADY_POSTED");
  });

  it("posts type L - creates inventory movement with negative delta", async () => {
    const calls: { query: string; params: unknown[] }[] = [];
    const mockDoc = { ...baseDoc };
    const mockLine = { ...baseLine };
    const mockSql = {
      unsafe: vi.fn((q: string, p?: unknown[]) => {
        calls.push({ query: q, params: p ?? [] });
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        return Promise.resolve([]);
      }),
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(true);
    const movementCall = calls.find((c) => c.query.includes("INSERT INTO inventory_movement"));
    expect(movementCall).toBeDefined();
    expect(movementCall!.params[5]).toBe("-5");
    const balanceCall = calls.find((c) => c.query.includes("INSERT INTO inventory_balance"));
    expect(balanceCall).toBeDefined();
    expect(balanceCall!.params[4]).toBe("-5");
  });

  it("posts type b - increases expected_purchase_qty", async () => {
    const calls: { query: string; params: unknown[] }[] = [];
    const mockDoc = { ...baseDoc, document_type: "b" };
    const mockLine = { ...baseLine };
    const mockSql = {
      unsafe: vi.fn((q: string, p?: unknown[]) => {
        calls.push({ query: q, params: p ?? [] });
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        return Promise.resolve([]);
      }),
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(true);
    const balanceCall = calls.find((c) => c.query.includes("INSERT INTO inventory_balance"));
    expect(balanceCall).toBeDefined();
    expect(balanceCall!.query.includes("expected_purchase_qty")).toBe(true);
  });

  it("posts type l - increases on_hand AND decreases expected_purchase", async () => {
    const calls: { query: string; params: unknown[] }[] = [];
    const mockDoc = { ...baseDoc, document_type: "l" };
    const mockLine = { ...baseLine };
    const mockSql = {
      unsafe: vi.fn((q: string, p?: unknown[]) => {
        calls.push({ query: q, params: p ?? [] });
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        return Promise.resolve([]);
      }),
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(true);
    const balanceCall = calls.find((c) => c.query.includes("INSERT INTO inventory_balance"));
    expect(balanceCall).toBeDefined();
    const query = balanceCall!.query;
    expect(query.includes("on_hand_qty = inventory_balance.on_hand_qty")).toBe(true);
    expect(
      query.includes("expected_purchase_qty = inventory_balance.expected_purchase_qty -"),
    ).toBe(true);
  });

  it("posts type V - sets on_hand_qty to exact value", async () => {
    const calls: { query: string; params: unknown[] }[] = [];
    const mockDoc = { ...baseDoc, document_type: "V" };
    const mockLine = { ...baseLine };
    const mockSql = {
      unsafe: vi.fn((q: string, p?: unknown[]) => {
        calls.push({ query: q, params: p ?? [] });
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        return Promise.resolve([]);
      }),
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(true);
    const balanceCall = calls.find((c) => c.query.includes("INSERT INTO inventory_balance"));
    expect(balanceCall).toBeDefined();
    expect(balanceCall!.query.includes("EXCLUDED.on_hand_qty")).toBe(true);
  });

  it("posts type U - creates two balance upserts", async () => {
    const mockDoc = { ...baseDoc, document_type: "U", target_warehouse_id: "wh-2" };
    const mockLine = { ...baseLine, target_warehouse_id: "wh-2" };
    let balanceInsertCount = 0;
    const mockSql = {
      unsafe: vi.fn((q: string, _p?: unknown[]) => {
        if (q.includes("INSERT INTO inventory_balance")) balanceInsertCount++;
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        return Promise.resolve([]);
      }),
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(true);
    expect(balanceInsertCount).toBe(2);
  });

  it("returns SAME_WAREHOUSE when U type has same source and target", async () => {
    const mockDoc = { ...baseDoc, document_type: "U", target_warehouse_id: "wh-1" };
    const mockLine = { ...baseLine, target_warehouse_id: "wh-1" };
    const mockSql = {
      unsafe: vi.fn((q: string) => {
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        return Promise.resolve([]);
      }),
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(false);
    expect(result.errorCode).toBe("SAME_WAREHOUSE");
  });

  it("posts type R - creates fact_sales_event", async () => {
    const calls: { query: string; params: unknown[] }[] = [];
    const mockDoc = { ...baseDoc, document_type: "R" };
    const mockLine = { ...baseLine };
    const mockSql = {
      unsafe: vi.fn((q: string, p?: unknown[]) => {
        calls.push({ query: q, params: p ?? [] });
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        if (q.includes("fiscal_period"))
          return Promise.resolve([{ fiscal_period_id: "fp-1", is_closed: false }]);
        if (q.includes("gld_purchase")) return Promise.resolve([{ gld_purchase: "10.00" }]);
        return Promise.resolve([]);
      }),
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(true);
    const salesCall = calls.find((c) => c.query.includes("INSERT INTO fact_sales_event"));
    expect(salesCall).toBeDefined();
  });

  it("posts type G - creates fact_sales_event with correction type", async () => {
    const calls: { query: string; params: unknown[] }[] = [];
    const mockDoc = { ...baseDoc, document_type: "G", storno_document_id: "doc-original" };
    const mockLine = { ...baseLine };
    const mockSql = {
      unsafe: vi.fn((q: string, p?: unknown[]) => {
        calls.push({ query: q, params: p ?? [] });
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        if (q.includes("fiscal_period"))
          return Promise.resolve([{ fiscal_period_id: "fp-1", is_closed: false }]);
        if (q.includes("gld_purchase")) return Promise.resolve([{ gld_purchase: "10.00" }]);
        return Promise.resolve([]);
      }),
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(true);
    const salesCall = calls.find((c) => c.query.includes("INSERT INTO fact_sales_event"));
    expect(salesCall).toBeDefined();
    expect(salesCall!.params[6]).toBe("correction");
  });

  it("posts type Z - adds positive qty_delta", async () => {
    const calls: { query: string; params: unknown[] }[] = [];
    const mockDoc = { ...baseDoc, document_type: "Z" };
    const mockLine = { ...baseLine };
    const mockSql = {
      unsafe: vi.fn((q: string, p?: unknown[]) => {
        calls.push({ query: q, params: p ?? [] });
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        return Promise.resolve([]);
      }),
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(true);
    const movementCall = calls.find((c) => c.query.includes("INSERT INTO inventory_movement"));
    expect(movementCall).toBeDefined();
    expect(movementCall!.params[4]).toBe("5");
  });

  it("posts type E - adds negative qty_delta", async () => {
    const calls: { query: string; params: unknown[] }[] = [];
    const mockDoc = { ...baseDoc, document_type: "E" };
    const mockLine = { ...baseLine };
    const mockSql = {
      unsafe: vi.fn((q: string, p?: unknown[]) => {
        calls.push({ query: q, params: p ?? [] });
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        return Promise.resolve([]);
      }),
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(true);
    const movementCall = calls.find((c) => c.query.includes("INSERT INTO inventory_movement"));
    expect(movementCall).toBeDefined();
    expect(movementCall!.params[4]).toBe("-5");
  });

  it("posts type N - no inventory or fact records created", async () => {
    const calls: { query: string; params: unknown[] }[] = [];
    const mockDoc = { ...baseDoc, document_type: "N" };
    const mockLine = { ...baseLine };
    const mockSql = {
      unsafe: vi.fn((q: string, p?: unknown[]) => {
        calls.push({ query: q, params: p ?? [] });
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        return Promise.resolve([]);
      }),
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(true);
    const hasMovement = calls.some((c) => c.query.includes("INSERT INTO inventory_movement"));
    const hasBalance = calls.some((c) => c.query.includes("INSERT INTO inventory_balance"));
    const hasSales = calls.some((c) => c.query.includes("INSERT INTO fact_sales_event"));
    expect(hasMovement).toBe(false);
    expect(hasBalance).toBe(false);
    expect(hasSales).toBe(false);
  });

  it("sets document status to posted with posted_at and posted_by", async () => {
    const calls: { query: string; params: unknown[] }[] = [];
    const mockDoc = { ...baseDoc };
    const mockLine = { ...baseLine };
    const mockSql = {
      unsafe: vi.fn((q: string, p?: unknown[]) => {
        calls.push({ query: q, params: p ?? [] });
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        return Promise.resolve([]);
      }),
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(true);
    const updateCall = calls.find((c) => c.query.includes("UPDATE document"));
    expect(updateCall).toBeDefined();
    expect(updateCall!.params[0]).toBe("u1");
    expect(updateCall!.params[1]).toBe("doc-1");
  });

  it("sends pg_notify stats_refresh after posting", async () => {
    const calls: { query: string; params: unknown[] }[] = [];
    const mockDoc = { ...baseDoc };
    const mockLine = { ...baseLine };
    const mockSql = {
      unsafe: vi.fn((q: string, p?: unknown[]) => {
        calls.push({ query: q, params: p ?? [] });
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        return Promise.resolve([]);
      }),
    } as any;
    await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    const notifyCall = calls.find((c) => c.query.includes("pg_notify"));
    expect(notifyCall).toBeDefined();
  });

  it("AVCO computes weighted average for r-type", async () => {
    const calls: { query: string; params: unknown[] }[] = [];
    const mockDoc = { ...baseDoc, document_type: "r" };
    const mockLine = { ...baseLine, net_price: "30.00" };
    const mockSql = {
      unsafe: vi.fn((q: string, p?: unknown[]) => {
        calls.push({ query: q, params: p ?? [] });
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        if (q.includes("fiscal_period"))
          return Promise.resolve([{ fiscal_period_id: "fp-1", is_closed: false }]);
        if (q.includes("SUM(on_hand_qty)"))
          return Promise.resolve([{ total_qty: "10", gld_purchase: "20.00" }]);
        return Promise.resolve([]);
      }),
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(true);
    const updateCall = calls.find((c) => c.query.includes("UPDATE inventory_balance"));
    expect(updateCall).toBeDefined();
    expect(updateCall!.params[0]).toBe("23.333333333333332");
  });

  it("AVCO frozen when qty goes negative for r-type", async () => {
    const calls: { query: string; params: unknown[] }[] = [];
    const mockDoc = { ...baseDoc, document_type: "r" };
    const mockLine = { ...baseLine, quantity: "0" };
    const mockSql = {
      unsafe: vi.fn((q: string, p?: unknown[]) => {
        calls.push({ query: q, params: p ?? [] });
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        if (q.includes("fiscal_period"))
          return Promise.resolve([{ fiscal_period_id: "fp-1", is_closed: false }]);
        if (q.includes("SUM(on_hand_qty)"))
          return Promise.resolve([{ total_qty: "0", gld_purchase: "20.00" }]);
        return Promise.resolve([]);
      }),
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(true);
    const updateCall = calls.find((c) => c.query.includes("UPDATE inventory_balance"));
    expect(updateCall).toBeUndefined();
  });

  it("throws PERIOD_CLOSED for closed fiscal period", async () => {
    const mockDoc = { ...baseDoc, document_type: "R" };
    const mockLine = { ...baseLine };
    const mockSql = {
      unsafe: vi.fn((q: string) => {
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        if (q.includes("fiscal_period"))
          return Promise.resolve([{ fiscal_period_id: "fp-1", is_closed: true }]);
        return Promise.resolve([]);
      }),
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(false);
    expect(result.errorCode).toBe("PERIOD_CLOSED");
  });

  it("calculates due_date for R-type with 30-day payment term", async () => {
    const calls: { query: string; params: unknown[] }[] = [];
    const mockDoc = {
      ...baseDoc,
      document_type: "R",
      payment_term_id: "pt-1",
      document_date: "2026-01-15",
    };
    const mockLine = { ...baseLine };
    const mockSql = {
      unsafe: vi.fn((q: string, p?: unknown[]) => {
        calls.push({ query: q, params: p ?? [] });
        if (q.includes("SELECT document_id")) return Promise.resolve([mockDoc]);
        if (q.includes("SELECT dl.document_line_id")) return Promise.resolve([mockLine]);
        if (q.includes("document_line_tracking")) return Promise.resolve([]);
        if (q.includes("fiscal_period"))
          return Promise.resolve([{ fiscal_period_id: "fp-1", is_closed: false }]);
        if (q.includes("gld_purchase")) return Promise.resolve([{ gld_purchase: "10.00" }]);
        if (q.includes("net_days")) return Promise.resolve([{ net_days: 30 }]);
        return Promise.resolve([]);
      }),
    } as any;
    const result = await postDocument(mockSql, { documentId: "doc-1", userId: "u1" });
    expect(result.success).toBe(true);
    const dueDateCall = calls.find(
      (c) => c.query.includes("UPDATE document") && c.query.includes("due_date"),
    );
    expect(dueDateCall).toBeDefined();
    expect(dueDateCall!.params[0]).toBe("2026-02-14");
  });
});
