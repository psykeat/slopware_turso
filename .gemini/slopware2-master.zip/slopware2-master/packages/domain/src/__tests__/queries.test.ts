import { describe, it, expect } from "vitest";

import { getEntityDescriptor, isEntityPatchable, isMasterData } from "../entities/registry";
import { listEntity, getEntityById, isEntityReadable } from "../queries";

describe("Queries Module", () => {
  describe("exports", () => {
    it("exports all expected functions", () => {
      expect(typeof listEntity).toBe("function");
      expect(typeof getEntityById).toBe("function");
      expect(typeof isEntityReadable).toBe("function");
    });
  });

  describe("organization registry", () => {
    it("organization is registered in ENTITY_REGISTRY", () => {
      const desc = getEntityDescriptor("organization");
      expect(desc).toBeDefined();
      expect(desc?.entityName).toBe("organization");
      expect(desc?.tableName).toBe("organization");
      expect(desc?.tenantScoped).toBe(false);
      expect(desc?.genericRead).toBe(true);
      expect(desc?.genericPatch).toBe(true);
      expect(desc?.genericDelete).toBe(false);
      expect(desc?.idColumn).toBe("organization_id");
      expect(desc?.kind).toBe("master");
      expect(desc?.softDeleteField).toBe("is_active");
    });

    it("organization is readable", () => {
      expect(isEntityReadable("organization")).toBe(true);
    });

    it("organization is patchable", () => {
      expect(isEntityPatchable("organization")).toBe(true);
    });

    it("organization is master data", () => {
      expect(isMasterData("organization")).toBe(true);
    });
  });

  describe("listEntity", () => {
    it("throws for unregistered entity", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      await expect(listEntity(mockSql, "nonexistent_entity")).rejects.toThrow(
        "Entity 'nonexistent_entity' is not registered",
      );
    });

    it("throws for non-readable entity", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      await expect(listEntity(mockSql, "firmenstamm")).rejects.toThrow(
        "Entity 'firmenstamm' is not generically readable",
      );
    });

    it("uses default limit and offset", async () => {
      let lastQuery = "";
      let lastParams: unknown[] = [];
      const mockSql = {
        unsafe: (q: string, p?: unknown[]) => {
          lastQuery = q;
          lastParams = p ?? [];
          return Promise.resolve([{ total: 0 }]);
        },
      } as any;

      await listEntity(mockSql, "article");

      expect(lastQuery).toContain("LIMIT $1");
      expect(lastQuery).toContain("OFFSET $2");
      expect(lastParams).toEqual([100, 0]);
    });

    it("builds WHERE clause for allowed filters", async () => {
      let lastQuery = "";
      const mockSql = {
        unsafe: (q: string) => {
          lastQuery = q;
          return Promise.resolve([{ total: 0 }]);
        },
      } as any;

      await listEntity(mockSql, "article", {
        filters: [{ column: "tenant_id", operator: "=", value: "test-uuid" }],
      });

      expect(lastQuery).toContain("WHERE");
      expect(lastQuery).toContain("tenant_id");
    });

    it("throws for disallowed filter column", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      await expect(
        listEntity(mockSql, "article", {
          filters: [{ column: "invalid_column", operator: "=", value: "x" }],
        }),
      ).rejects.toThrow("is not allowed");
    });

    it("throws for disallowed sort column", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      await expect(
        listEntity(mockSql, "article", {
          sortBy: "invalid_column",
        }),
      ).rejects.toThrow("is not allowed");
    });

    it("allows listing organization (non-tenant-scoped entity)", async () => {
      let lastQuery = "";
      const mockSql = {
        unsafe: (q: string) => {
          lastQuery = q;
          return Promise.resolve([{ total: 0 }]);
        },
      } as any;
      await listEntity(mockSql, "organization");
      expect(lastQuery).toContain("organization");
    });

    it("allows filtering organization by slug", async () => {
      let lastQuery = "";
      const mockSql = {
        unsafe: (q: string) => {
          lastQuery = q;
          return Promise.resolve([{ total: 0 }]);
        },
      } as any;
      await listEntity(mockSql, "organization", {
        filters: [{ column: "slug", operator: "=", value: "acme" }],
      });
      expect(lastQuery).toContain("slug");
    });

    it("throws for disallowed filter on organization", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      await expect(
        listEntity(mockSql, "organization", {
          filters: [{ column: "tenant_id", operator: "=", value: "x" }],
        }),
      ).rejects.toThrow("is not allowed");
    });

    it("allows listing tenant (non-tenant-scoped entity)", async () => {
      let lastQuery = "";
      const mockSql = {
        unsafe: (q: string) => {
          lastQuery = q;
          return Promise.resolve([{ total: 0 }]);
        },
      } as any;
      await listEntity(mockSql, "tenant");
      expect(lastQuery).toContain("tenant");
    });

    it("allows filtering tenant by organization_id", async () => {
      let lastQuery = "";
      const mockSql = {
        unsafe: (q: string) => {
          lastQuery = q;
          return Promise.resolve([{ total: 0 }]);
        },
      } as any;
      await listEntity(mockSql, "tenant", {
        filters: [{ column: "organization_id", operator: "=", value: "org-uuid" }],
      });
      expect(lastQuery).toContain("organization_id");
    });
  });

  describe("tenant registry", () => {
    it("tenant is registered in ENTITY_REGISTRY", () => {
      const desc = getEntityDescriptor("tenant");
      expect(desc).toBeDefined();
      expect(desc?.entityName).toBe("tenant");
      expect(desc?.tableName).toBe("tenant");
      expect(desc?.tenantScoped).toBe(false);
      expect(desc?.genericRead).toBe(true);
      expect(desc?.genericPatch).toBe(true);
      expect(desc?.genericDelete).toBe(false);
      expect(desc?.idColumn).toBe("tenant_id");
      expect(desc?.kind).toBe("master");
      expect(desc?.softDeleteField).toBe("is_active");
    });

    it("tenant is readable", () => {
      expect(isEntityReadable("tenant")).toBe(true);
    });

    it("tenant is patchable", () => {
      expect(isEntityPatchable("tenant")).toBe(true);
    });

    it("tenant is master data", () => {
      expect(isMasterData("tenant")).toBe(true);
    });
  });

  describe("getEntityById", () => {
    it("throws for unregistered entity", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      await expect(getEntityById(mockSql, "nonexistent_entity", "some-id")).rejects.toThrow(
        "Entity 'nonexistent_entity' is not registered",
      );
    });

    it("throws for non-readable entity", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      await expect(getEntityById(mockSql, "firmenstamm", "some-id")).rejects.toThrow(
        "is not generically readable",
      );
    });

    it("returns null for empty result", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([]),
      } as any;
      const result = await getEntityById(mockSql, "article", "some-id");
      expect(result).toBeNull();
    });

    it("returns entity for matching result", async () => {
      const mockSql = {
        unsafe: () => Promise.resolve([{ article_id: "some-id", name: "Test" }]),
      } as any;
      const result = await getEntityById(mockSql, "article", "some-id");
      expect(result).toEqual({ article_id: "some-id", name: "Test" });
    });
  });
});
