import type { SqlClient } from "../runtime";

export interface CreateUserPayload {
  email: string;
  password: string;
  displayName?: string;
  role?: string;
  locale?: string;
}

export interface UpdateUserPayload {
  displayName?: string;
  role?: string;
  is_active?: boolean;
  locale?: string;
}

export interface CreateUserResult {
  success: boolean;
  id?: string;
  error?: string;
}

export interface UpdateUserResult {
  success: boolean;
  error?: string;
}

export interface ResetPasswordResult {
  success: boolean;
  error?: string;
}

export interface AssignTenantResult {
  success: boolean;
  error?: string;
}

export async function createUser(
  sql: SqlClient,
  payload: CreateUserPayload,
): Promise<CreateUserResult> {
  try {
    const passwordHash = await sql.unsafe(`SELECT crypt($1, gen_salt('bf')) as password_hash`, [
      payload.password,
    ]);
    const hashed = String((passwordHash[0] as Record<string, unknown>).password_hash);

    const role = payload.role ?? "tenant_user";
    const locale = payload.locale ?? "de";

    const res = await sql.unsafe<Record<string, unknown>[]>(
      `INSERT INTO app_user (email, password_hash, display_name, is_active, role, locale)
       VALUES ($1, $2, $3, true, $4, $5)
       RETURNING user_id`,
      [payload.email, hashed, payload.displayName ?? null, role, locale],
    );

    return { success: true, id: String((res[0] as unknown as Record<string, unknown>)?.user_id) };
  } catch (e: unknown) {
    const msg = e instanceof Error ? e.message : "Failed to create user";
    if (msg.includes("unique")) {
      return { success: false, error: "Email already exists" };
    }
    return { success: false, error: msg };
  }
}

export async function updateUser(
  sql: SqlClient,
  userId: string,
  payload: UpdateUserPayload,
): Promise<UpdateUserResult> {
  const updates: string[] = [];
  const params: unknown[] = [];

  if (payload.displayName !== undefined) {
    params.push(payload.displayName);
    updates.push(`display_name = $${params.length}`);
  }
  if (payload.role !== undefined) {
    params.push(payload.role);
    updates.push(`role = $${params.length}`);
  }
  if (payload.is_active !== undefined) {
    params.push(payload.is_active);
    updates.push(`is_active = $${params.length}`);
  }
  if (payload.locale !== undefined) {
    params.push(payload.locale);
    updates.push(`locale = $${params.length}`);
  }

  if (updates.length === 0) {
    return { success: false, error: "No fields to update" };
  }

  params.push(userId);
  try {
    await sql.unsafe(
      `UPDATE app_user SET ${updates.join(", ")} WHERE user_id = $${params.length}`,
      params,
    );
    return { success: true };
  } catch (e: unknown) {
    return {
      success: false,
      error: e instanceof Error ? e.message : "Failed to update user",
    };
  }
}

export async function deactivateUser(sql: SqlClient, userId: string): Promise<UpdateUserResult> {
  try {
    await sql.unsafe(`UPDATE app_user SET is_active = false WHERE user_id = $1`, [userId]);
    return { success: true };
  } catch (e: unknown) {
    return {
      success: false,
      error: e instanceof Error ? e.message : "Failed to deactivate user",
    };
  }
}

export async function resetUserPassword(
  sql: SqlClient,
  userId: string,
  newPassword: string,
): Promise<ResetPasswordResult> {
  try {
    const passwordHash = await sql.unsafe(`SELECT crypt($1, gen_salt('bf')) as password_hash`, [
      newPassword,
    ]);
    const hashed = String((passwordHash[0] as Record<string, unknown>).password_hash);

    await sql.unsafe(`UPDATE app_user SET password_hash = $1 WHERE user_id = $2`, [hashed, userId]);
    return { success: true };
  } catch (e: unknown) {
    return {
      success: false,
      error: e instanceof Error ? e.message : "Failed to reset password",
    };
  }
}

export async function assignUserTenant(
  sql: SqlClient,
  userId: string,
  tenantId: string,
  role: string = "tenant_user",
): Promise<AssignTenantResult> {
  try {
    await sql.unsafe(
      `INSERT INTO user_tenant (user_id, tenant_id, role)
       VALUES ($1, $2, $3)
       ON CONFLICT (user_id, tenant_id) DO UPDATE SET role = $3`,
      [userId, tenantId, role],
    );
    return { success: true };
  } catch (e: unknown) {
    return {
      success: false,
      error: e instanceof Error ? e.message : "Failed to assign tenant",
    };
  }
}

export async function removeUserTenant(
  sql: SqlClient,
  userId: string,
  tenantId: string,
): Promise<AssignTenantResult> {
  try {
    await sql.unsafe(`DELETE FROM user_tenant WHERE user_id = $1 AND tenant_id = $2`, [
      userId,
      tenantId,
    ]);
    return { success: true };
  } catch (e: unknown) {
    return {
      success: false,
      error: e instanceof Error ? e.message : "Failed to remove tenant assignment",
    };
  }
}
