import type { SqlClient } from "../runtime";
import { resolveFiscalPeriodId } from "./posting-command";

export interface ApplyDeltaParams {
  documentLineId: string;
  qtyDelta: number; // positive = increase, negative = decrease
}

export interface ApplyDeltaResult {
  success: boolean;
  errorCode?: string;
  error?: string;
}

const INVENTORY_OUT_TYPES = new Set(["L"]);
const INVENTORY_IN_TYPES = new Set(["b", "l"]);
const SALES_EVENT_TYPES = new Set(["R", "G"]);
const PURCHASE_EVENT_TYPES = new Set(["r", "g"]);
const RESERVATION_TYPES = new Set(["A"]);

export async function applyDeltaEffect(
  sql: SqlClient,
  params: ApplyDeltaParams,
): Promise<ApplyDeltaResult> {
  const { documentLineId, qtyDelta } = params;
  if (qtyDelta === 0) return { success: true };

  return sql.begin(async (tx) => {
    // 1. Fetch line + parent document
    const lineRows = await tx.unsafe<Record<string, unknown>>(
      `SELECT dl.*, d.document_type, d.status, d.warehouse_id AS doc_warehouse_id,
              d.tenant_id, d.company_id, d.customer_id, d.transaction_id, d.posting_date,
              d.document_date, tc.tax_rate
       FROM document_line dl
       JOIN document d ON dl.document_id = d.document_id
       LEFT JOIN tax_code tc ON dl.tax_code_id = tc.tax_code_id
       WHERE dl.document_line_id = $1
       FOR UPDATE OF d, dl`,
      [documentLineId],
    );

    if (lineRows.length === 0) {
      return { success: false, error: "Document line not found", errorCode: "NOT_FOUND" };
    }

    const line = lineRows[0];
    const docType = line.document_type as string;
    const status = line.status as string;
    const tenantId = line.tenant_id as string;
    const companyId = line.company_id as string;
    const customerId = line.customer_id as string | null;
    const transactionId = line.transaction_id as string;
    const documentId = line.document_id as string;
    const lineWarehouseId =
      (line.warehouse_id as string | null) || (line.doc_warehouse_id as string | null);
    const articleId = line.article_id as string | null;
    const taxRate = parseFloat((line.tax_rate as string) ?? "0");
    const netPrice = parseFloat((line.net_price as string) ?? "0");
    const discountPercentage = parseFloat((line.discount_percentage as string) ?? "0");
    const postingDate = line.posting_date as string | null;
    const documentDate = line.document_date as string | null;
    const effectiveDate = postingDate || documentDate || new Date().toISOString().split("T")[0];

    // 2. Guard: status === 'posted'
    if (status !== "posted") {
      return {
        success: false,
        error: `Cannot apply delta to document with status '${status}'`,
        errorCode: "INVALID_STATUS",
      };
    }

    // 3. Fiscal period check
    const period = await resolveFiscalPeriodId(tx, tenantId, companyId, effectiveDate);
    if (!period || period.isClosed) {
      return {
        success: false,
        error: period ? "Fiscal period is closed" : "No fiscal period found for date",
        errorCode: "PERIOD_CLOSED",
      };
    }

    // 4. Inventory updates
    if (articleId && lineWarehouseId) {
      if (INVENTORY_OUT_TYPES.has(docType)) {
        await tx.unsafe(
          `INSERT INTO inventory_movement (
            tenant_id, company_id, warehouse_id, article_id,
            movement_type, qty_delta, movement_date,
            source_document_id, source_document_line_id, transaction_id
          ) VALUES ($1, $2, $3, $4, 'CORRECTION', $5, NOW(), $6, $7, $8)`,
          [
            tenantId,
            companyId,
            lineWarehouseId,
            articleId,
            (-qtyDelta).toString(),
            documentId,
            documentLineId,
            transactionId,
          ],
        );

        await tx.unsafe(
          `INSERT INTO inventory_balance (
            tenant_id, company_id, warehouse_id, article_id,
            on_hand_qty, reserved_qty, available_qty
          ) VALUES ($1, $2, $3, $4, $5, 0, $5)
          ON CONFLICT (tenant_id, warehouse_id, article_id)
          DO UPDATE SET
            on_hand_qty = inventory_balance.on_hand_qty + $5,
            available_qty = inventory_balance.on_hand_qty + $5 - inventory_balance.reserved_qty,
            as_of_at = NOW()`,
          [tenantId, companyId, lineWarehouseId, articleId, (-qtyDelta).toString()],
        );
      } else if (INVENTORY_IN_TYPES.has(docType)) {
        const qty_delta = qtyDelta;
        if (docType === "l") {
          await tx.unsafe(
            `INSERT INTO inventory_movement (
              tenant_id, company_id, warehouse_id, article_id,
              movement_type, qty_delta, movement_date,
              source_document_id, source_document_line_id, transaction_id
            ) VALUES ($1, $2, $3, $4, 'CORRECTION', $5, NOW(), $6, $7, $8)`,
            [
              tenantId,
              companyId,
              lineWarehouseId,
              articleId,
              qty_delta.toString(),
              documentId,
              documentLineId,
              transactionId,
            ],
          );

          await tx.unsafe(
            `INSERT INTO inventory_balance (
              tenant_id, company_id, warehouse_id, article_id,
              on_hand_qty, reserved_qty, available_qty, expected_purchase_qty
            ) VALUES ($1, $2, $3, $4, $5, 0, $5, $6)
            ON CONFLICT (tenant_id, warehouse_id, article_id)
            DO UPDATE SET
              on_hand_qty = inventory_balance.on_hand_qty + $5,
              expected_purchase_qty = inventory_balance.expected_purchase_qty - $5,
              available_qty = inventory_balance.on_hand_qty + $5 - inventory_balance.reserved_qty,
              as_of_at = NOW()`,
            [tenantId, companyId, lineWarehouseId, articleId, qty_delta.toString(), "0"],
          );
        } else if (docType === "b") {
          await tx.unsafe(
            `INSERT INTO inventory_balance (
              tenant_id, company_id, warehouse_id, article_id,
              on_hand_qty, reserved_qty, available_qty, expected_purchase_qty
            ) VALUES ($1, $2, $3, $4, 0, 0, 0, $5)
            ON CONFLICT (tenant_id, warehouse_id, article_id)
            DO UPDATE SET
              expected_purchase_qty = inventory_balance.expected_purchase_qty + $5,
              available_qty = inventory_balance.on_hand_qty - inventory_balance.reserved_qty,
              as_of_at = NOW()`,
            [tenantId, companyId, lineWarehouseId, articleId, qtyDelta.toString()],
          );
        }
      } else if (RESERVATION_TYPES.has(docType)) {
        await tx.unsafe(
          `INSERT INTO inventory_balance (
            tenant_id, company_id, warehouse_id, article_id,
            on_hand_qty, reserved_qty, available_qty
          ) VALUES ($1, $2, $3, $4, 0, $5, -$5)
          ON CONFLICT (tenant_id, warehouse_id, article_id)
          DO UPDATE SET
            reserved_qty = inventory_balance.reserved_qty + $5,
            available_qty = inventory_balance.on_hand_qty - (inventory_balance.reserved_qty + $5),
            as_of_at = NOW()`,
          [tenantId, companyId, lineWarehouseId, articleId, qtyDelta.toString()],
        );
      }
    }

    // 5. Fact events
    const discountFactor = 1 - discountPercentage / 100;
    const amountNetDelta = qtyDelta * netPrice * discountFactor;

    if (articleId && SALES_EVENT_TYPES.has(docType)) {
      const sign = docType === "G" ? -1 : 1;
      const salesQtyDelta = qtyDelta * sign;
      const salesAmountNetDelta = amountNetDelta * sign;

      const balanceRows = await tx.unsafe<Record<string, unknown>>(
        `SELECT gld_purchase FROM inventory_balance
         WHERE tenant_id = $1 AND article_id = $2
         LIMIT 1`,
        [tenantId, articleId],
      );
      const gldPurchase =
        balanceRows.length > 0 ? parseFloat((balanceRows[0].gld_purchase as string) ?? "0") : 0;
      const cogsDelta = gldPurchase * Math.abs(salesQtyDelta);

      await tx.unsafe(
        `INSERT INTO fact_sales_event (
          tenant_id, company_id, source_document_id, source_document_line_id,
          customer_id, article_id, event_type,
          quantity_delta, amount_net_delta, booking_period, transaction_id,
          fiscal_period_id, cogs_delta
        ) VALUES ($1, $2, $3, $4, $5, $6, 'correction', $7, $8, $9, $10, $11, $12)`,
        [
          tenantId,
          companyId,
          documentId,
          documentLineId,
          customerId,
          articleId,
          salesQtyDelta.toString(),
          salesAmountNetDelta.toString(),
          effectiveDate,
          transactionId,
          period.fiscalPeriodId,
          cogsDelta.toString(),
        ],
      );
    }

    if (articleId && PURCHASE_EVENT_TYPES.has(docType)) {
      const sign = docType === "g" ? -1 : 1;
      const purchaseQtyDelta = qtyDelta * sign;
      const purchaseAmountNetDelta = amountNetDelta * sign;

      await tx.unsafe(
        `INSERT INTO fact_purchase_event (
          tenant_id, company_id, source_document_id, source_document_line_id,
          supplier_id, article_id, event_type,
          quantity_delta, amount_net_delta, booking_period, transaction_id,
          fiscal_period_id
        ) VALUES ($1, $2, $3, $4, $5, $6, 'correction', $7, $8, $9, $10, $11)`,
        [
          tenantId,
          companyId,
          documentId,
          documentLineId,
          customerId,
          articleId,
          purchaseQtyDelta.toString(),
          purchaseAmountNetDelta.toString(),
          effectiveDate,
          transactionId,
          period.fiscalPeriodId,
        ],
      );
    }

    // 6. Update document line
    const newQty = parseFloat((line.quantity as string) ?? "0") + qtyDelta;
    const newLineTotalNet = newQty * netPrice * discountFactor;
    const newTaxAmount = newLineTotalNet * taxRate;

    await tx.unsafe(
      `UPDATE document_line
       SET quantity = $2, line_total_net = $3, tax_amount = $4, updated_at = NOW()
       WHERE document_line_id = $1`,
      [documentLineId, newQty, newLineTotalNet, newTaxAmount],
    );

    // 7. Recalculate document totals
    const totalsRows = await tx.unsafe<Record<string, unknown>>(
      `SELECT SUM(line_total_net) AS total_net, SUM(tax_amount) AS total_tax
       FROM document_line
       WHERE document_id = $1`,
      [documentId],
    );

    const totalNet = parseFloat((totalsRows[0].total_net as string) ?? "0");
    const totalTax = parseFloat((totalsRows[0].total_tax as string) ?? "0");
    const totalGross = totalNet + totalTax;

    await tx.unsafe(
      `UPDATE document
       SET total_net = $2, total_tax = $3, total_gross = $4, version_no = version_no + 1, updated_at = NOW()
       WHERE document_id = $1`,
      [documentId, totalNet, totalTax, totalGross],
    );

    return { success: true };
  });
}
