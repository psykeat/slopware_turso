import { metrics } from "@opentelemetry/api";
import type { Sql } from "postgres";

const meter = metrics.getMeter("slopware-domain");
const auditEventCounter = meter.createCounter("audit_event_created", {
  description: "Count of audit events created",
});

export interface AuditEventPayload {
  tenantId: string;
  userId?: string;
  eventType: string;
  severity?: "info" | "warn" | "error";
  message: string;
  traceId?: string;
  data?: any;
}

export async function createAuditEvent(sql: Sql, payload: AuditEventPayload) {
  auditEventCounter.add(1, {
    "audit.event_type": payload.eventType,
    "audit.severity": payload.severity ?? "info",
    tenant_id: payload.tenantId,
  });

  return sql.unsafe(
    `INSERT INTO audit_event (tenant_id, user_id, event_type, severity, message, trace_id, data)
      VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb)
      RETURNING audit_event_id`,
    [
      payload.tenantId,
      payload.userId ?? null,
      payload.eventType,
      payload.severity ?? "info",
      payload.message,
      payload.traceId ?? null,
      payload.data ? JSON.stringify(payload.data) : null,
    ],
  );
}
