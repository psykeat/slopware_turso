import type { SqlClient } from "../runtime";

export interface DocumentLinePayload {
  lineNo: number;
  articleId?: string;
  quantity: number;
  netPrice: number;
  taxCodeId?: string;
  warehouseId?: string;
  costCenterId?: string;
  targetWarehouseId?: string;
  lineType?: string;
  movementType?: string;
  unit?: string;
  discountPercentage?: number;
  articleTextSnapshot?: string;
}

export interface CreateDocumentPayload {
  companyId: string;
  documentType: string;
  documentDirection: string;
  documentDate: string;
  customerId?: string;
  currencyId?: string;
  documentGroupId?: string;
  documentTypeId?: string;
  warehouseId?: string;
  targetWarehouseId?: string;
  paymentTermId?: string;
  shippingMethodId?: string;
  deliveryAddressId?: string;
  parentDocumentId?: string;
  postingDate?: string;
  billingAddress?: Record<string, unknown>;
  deliveryAddress?: Record<string, unknown>;
  customAttributes?: Record<string, unknown>;
  lines?: DocumentLinePayload[];
}

export interface CreateDocumentResult {
  success: boolean;
  documentId?: string;
  documentNo?: string;
  error?: string;
}

export async function createDocument(
  sql: SqlClient,
  payload: CreateDocumentPayload,
): Promise<CreateDocumentResult> {
  const execute = async (tx: SqlClient) => {
    const tenantId = (tx as any).tenantId;
    if (!tenantId) {
      return { success: false, error: "Missing tenant context in SQL client" };
    }

    const { companyId, documentType, documentDirection, documentDate, lines = [] } = payload;

    const seqRows = await tx.unsafe(
      `SELECT prefix, next_value, padding FROM number_sequence
       WHERE tenant_id = $1 AND company_id = $2 AND document_type = $3
       FOR UPDATE`,
      [tenantId, companyId, documentType],
    );

    if (seqRows.length === 0) {
      return { success: false, error: `No number sequence found for type '${documentType}'` };
    }

    const seq = seqRows[0] as Record<string, unknown>;
    const prefix = seq.prefix as string;
    const nextValue = seq.next_value as number;
    const padding = seq.padding as number;
    const documentNo = `${prefix}-${String(nextValue).padStart(padding, "0")}`;

    await tx.unsafe(
      `UPDATE number_sequence SET next_value = next_value + 1, updated_at = NOW()
       WHERE tenant_id = $1 AND company_id = $2 AND document_type = $3`,
      [tenantId, companyId, documentType],
    );

    const headerRows = await tx.unsafe(
      `INSERT INTO document (
        tenant_id, company_id, document_type, document_direction, document_no, status,
        document_date, customer_id, currency_id, document_group_id, document_type_id,
        warehouse_id, target_warehouse_id, payment_term_id, shipping_method_id,
        delivery_address_id, parent_document_id, posting_date, billing_address,
        delivery_address, custom_attributes, transaction_id
      ) VALUES (
        $1, $2, $3, $4, $5, 'draft', $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, gen_random_uuid()
      ) RETURNING document_id`,
      [
        tenantId,
        companyId,
        documentType,
        documentDirection,
        documentNo,
        documentDate,
        payload.customerId ?? null,
        payload.currencyId ?? null,
        payload.documentGroupId ?? null,
        payload.documentTypeId ?? null,
        payload.warehouseId ?? null,
        payload.targetWarehouseId ?? null,
        payload.paymentTermId ?? null,
        payload.shippingMethodId ?? null,
        payload.deliveryAddressId ?? null,
        payload.parentDocumentId ?? null,
        payload.postingDate ?? null,
        payload.billingAddress ? JSON.stringify(payload.billingAddress) : null,
        payload.deliveryAddress ? JSON.stringify(payload.deliveryAddress) : null,
        payload.customAttributes ? JSON.stringify(payload.customAttributes) : null,
      ],
    );

    const documentId = (headerRows[0] as Record<string, unknown>).document_id as string;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      await tx.unsafe(
        `INSERT INTO document_line (
          tenant_id, document_id, line_no, article_id, quantity, net_price, tax_code_id,
          warehouse_id, cost_center_id, target_warehouse_id, movement_type,
          line_type, unit, discount_percentage, article_text_snapshot, transaction_id
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, gen_random_uuid())`,
        [
          tenantId,
          documentId,
          line.lineNo || i + 1,
          line.articleId ?? null,
          line.quantity,
          line.netPrice,
          line.taxCodeId ?? null,
          line.warehouseId ?? null,
          line.costCenterId ?? null,
          line.targetWarehouseId ?? null,
          line.movementType ?? null,
          line.lineType ?? "article",
          line.unit ?? null,
          line.discountPercentage ?? null,
          line.articleTextSnapshot ?? null,
        ],
      );
    }

    return { success: true, documentId, documentNo };
  };

  if (typeof sql.begin === "function") {
    return sql.begin(execute);
  } else {
    return execute(sql);
  }
}

export interface UpdateDocumentPayload {
  companyId: string;
  documentDate?: string;
  customerId?: string | null;
  currencyId?: string | null;
  documentGroupId?: string | null;
  documentTypeId?: string | null;
  warehouseId?: string | null;
  targetWarehouseId?: string | null;
  paymentTermId?: string | null;
  shippingMethodId?: string | null;
  deliveryAddressId?: string | null;
  postingDate?: string | null;
  billingAddress?: Record<string, unknown> | null;
  deliveryAddress?: Record<string, unknown> | null;
  customAttributes?: Record<string, unknown> | null;
  lines?: DocumentLinePayload[];
}

export interface UpdateDocumentResult {
  success: boolean;
  totalNet?: number;
  totalTax?: number;
  totalGross?: number;
  error?: string;
}

export async function updateDocument(
  sql: SqlClient,
  id: string,
  payload: UpdateDocumentPayload,
): Promise<UpdateDocumentResult> {
  const execute = async (tx: SqlClient) => {
    const tenantId = (tx as any).tenantId;
    if (!tenantId) {
      return { success: false, error: "Missing tenant context in SQL client" };
    }

    const rows = await tx.unsafe(
      `SELECT document_type, status FROM document WHERE tenant_id = $1 AND document_id = $2 FOR UPDATE`,
      [tenantId, id],
    );

    if (rows.length === 0) {
      return { success: false, error: "Document not found" };
    }

    const status = (rows[0] as Record<string, unknown>).status as string;
    if (status !== "draft") {
      return {
        success: false,
        error: `Cannot update document with status '${status}' (only draft documents can be updated)`,
      };
    }

    const {
      documentDate,
      customerId,
      currencyId,
      documentGroupId,
      documentTypeId,
      warehouseId,
      targetWarehouseId,
      paymentTermId,
      shippingMethodId,
      deliveryAddressId,
      postingDate,
      billingAddress,
      deliveryAddress,
      customAttributes,
      lines,
    } = payload;

    const setParts: string[] = [];
    const values: unknown[] = [tenantId];
    let paramIdx = 2; // Start from 2 because $1 is tenantId

    if (documentDate !== undefined) {
      setParts.push(`document_date = $${paramIdx++}`);
      values.push(documentDate);
    }
    if (customerId !== undefined) {
      setParts.push(`customer_id = $${paramIdx++}`);
      values.push(customerId ?? null);
    }
    if (currencyId !== undefined) {
      setParts.push(`currency_id = $${paramIdx++}`);
      values.push(currencyId ?? null);
    }
    if (documentGroupId !== undefined) {
      setParts.push(`document_group_id = $${paramIdx++}`);
      values.push(documentGroupId ?? null);
    }
    if (documentTypeId !== undefined) {
      setParts.push(`document_type_id = $${paramIdx++}`);
      values.push(documentTypeId ?? null);
    }
    if (warehouseId !== undefined) {
      setParts.push(`warehouse_id = $${paramIdx++}`);
      values.push(warehouseId ?? null);
    }
    if (targetWarehouseId !== undefined) {
      setParts.push(`target_warehouse_id = $${paramIdx++}`);
      values.push(targetWarehouseId ?? null);
    }
    if (paymentTermId !== undefined) {
      setParts.push(`payment_term_id = $${paramIdx++}`);
      values.push(paymentTermId ?? null);
    }
    if (shippingMethodId !== undefined) {
      setParts.push(`shipping_method_id = $${paramIdx++}`);
      values.push(shippingMethodId ?? null);
    }
    if (deliveryAddressId !== undefined) {
      setParts.push(`delivery_address_id = $${paramIdx++}`);
      values.push(deliveryAddressId ?? null);
    }
    if (postingDate !== undefined) {
      setParts.push(`posting_date = $${paramIdx++}`);
      values.push(postingDate ?? null);
    }
    if (billingAddress !== undefined) {
      setParts.push(`billing_address = $${paramIdx++}`);
      values.push(billingAddress ? JSON.stringify(billingAddress) : null);
    }
    if (deliveryAddress !== undefined) {
      setParts.push(`delivery_address = $${paramIdx++}`);
      values.push(deliveryAddress ? JSON.stringify(deliveryAddress) : null);
    }
    if (customAttributes !== undefined) {
      setParts.push(`custom_attributes = $${paramIdx++}`);
      values.push(customAttributes ? JSON.stringify(customAttributes) : null);
    }

    setParts.push(`version_no = version_no + 1`);
    setParts.push(`updated_at = NOW()`);

    let computedTotalNet: number | undefined;
    let computedTotalTax: number | undefined;
    let computedTotalGross: number | undefined;

    if (lines !== undefined) {
      await tx.unsafe(`DELETE FROM document_line WHERE tenant_id = $1 AND document_id = $2`, [
        tenantId,
        id,
      ]);

      computedTotalNet = 0;
      computedTotalTax = 0;

      for (const line of lines) {
        const discountFactor = line.discountPercentage ? 1 - line.discountPercentage / 100 : 1;
        const lineNet = line.quantity * line.netPrice * discountFactor;
        const taxRate = line.taxCodeId ? 0.19 : 0; // Default tax fallback
        const lineTax = lineNet * taxRate;
        computedTotalNet += lineNet;
        computedTotalTax += lineTax;

        await tx.unsafe(
          `INSERT INTO document_line (
            tenant_id, document_id, line_no, article_id, quantity, net_price, tax_code_id,
            warehouse_id, cost_center_id, target_warehouse_id, movement_type,
            line_type, unit, discount_percentage, article_text_snapshot, transaction_id,
            line_total_net, tax_amount
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, gen_random_uuid(), $16, $17)`,
          [
            tenantId,
            id,
            line.lineNo,
            line.articleId ?? null,
            line.quantity,
            line.netPrice,
            line.taxCodeId ?? null,
            line.warehouseId ?? null,
            line.costCenterId ?? null,
            line.targetWarehouseId ?? null,
            line.movementType ?? null,
            line.lineType ?? "article",
            line.unit ?? null,
            line.discountPercentage ?? null,
            line.articleTextSnapshot ?? null,
            lineNet,
            lineTax,
          ],
        );
      }

      computedTotalGross = computedTotalNet + computedTotalTax;
      setParts.push(`total_net = $${paramIdx++}`);
      values.push(computedTotalNet);
      setParts.push(`total_tax = $${paramIdx++}`);
      values.push(computedTotalTax);
      setParts.push(`total_gross = $${paramIdx++}`);
      values.push(computedTotalGross);
    }

    values.push(id);
    const qs = `UPDATE document SET ${setParts.join(", ")} WHERE tenant_id = $1 AND document_id = $${paramIdx}`;
    await tx.unsafe(qs, values);

    if (computedTotalNet !== undefined) {
      return {
        success: true,
        totalNet: computedTotalNet,
        totalTax: computedTotalTax,
        totalGross: computedTotalGross,
      };
    }

    return { success: true };
  };

  if (typeof sql.begin === "function") {
    return sql.begin(execute);
  } else {
    return execute(sql);
  }
}

export interface DeleteDocumentResult {
  success: boolean;
  error?: string;
}

export async function deleteDocument(sql: SqlClient, id: string): Promise<DeleteDocumentResult> {
  const execute = async (tx: SqlClient) => {
    const tenantId = (tx as any).tenantId;
    if (!tenantId) {
      return { success: false, error: "Missing tenant context in SQL client" };
    }

    const rows = await tx.unsafe(
      `SELECT document_type FROM document WHERE tenant_id = $1 AND document_id = $2`,
      [tenantId, id],
    );

    if (rows.length === 0) {
      return { success: false, error: "Document not found" };
    }

    const docType = (rows[0] as Record<string, unknown>).document_type as string;

    if (["R", "r", "G", "g"].includes(docType)) {
      return {
        success: false,
        error: `Cannot delete document of type '${docType}' (credit memo protected)`,
      };
    }

    await tx.unsafe(`DELETE FROM document WHERE tenant_id = $1 AND document_id = $2`, [
      tenantId,
      id,
    ]);
    return { success: true };
  };

  if (typeof sql.begin === "function") {
    return sql.begin(execute);
  } else {
    return execute(sql);
  }
}
