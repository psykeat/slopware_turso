import type { SqlClient } from "../runtime";

// Hardcoded conversion map: source type → target type
const CONVERSION_MAP: Record<string, string> = {
  N: "A",
  A: "L",
  L: "R",
  b: "l",
  l: "r",
};

export interface ConvertDocumentParams {
  documentId: string;
  targetGroupId?: string;
}

export interface ConvertDocumentResult {
  success: boolean;
  newDocumentId?: string;
  newDocumentNo?: string;
  error?: string;
}

export async function convertDocument(
  sql: SqlClient,
  params: ConvertDocumentParams,
): Promise<ConvertDocumentResult> {
  const { documentId, targetGroupId } = params;

  return sql.begin(async (tx) => {
    const docRows = await tx.unsafe<Record<string, unknown>>(
      `SELECT d.*, dg.next_group_id
       FROM document d
       LEFT JOIN document_group dg ON d.document_group_id = dg.document_group_id
       WHERE d.document_id = $1
       FOR UPDATE`,
      [documentId],
    );

    if (docRows.length === 0) {
      return { success: false, error: "Document not found" };
    }

    const doc = docRows[0];
    const docType = doc.document_type as string;
    const targetDocType = CONVERSION_MAP[docType];

    if (!targetDocType) {
      return {
        success: false,
        error: `No conversion defined for document type '${docType}'`,
      };
    }

    const fallbackNextGroupId = doc.next_group_id as string | null;
    const effectiveTargetGroupId = targetGroupId ?? fallbackNextGroupId;

    const companyId = doc.company_id as string;
    const transactionId = doc.transaction_id as string;
    const documentDirection = doc.document_direction as string;
    const documentDate = doc.document_date as string;
    const customerId = doc.customer_id as string | null;
    const currencyId = doc.currency_id as string | null;
    const documentTypeId = doc.document_type_id as string | null;
    const warehouseId = doc.warehouse_id as string | null;
    const targetWarehouseId = doc.target_warehouse_id as string | null;
    const paymentTermId = doc.payment_term_id as string | null;
    const shippingMethodId = doc.shipping_method_id as string | null;
    const deliveryAddressId = doc.delivery_address_id as string | null;
    const postingDate = doc.posting_date as string | null;
    const billingAddress = doc.billing_address as string | null;
    const deliveryAddress = doc.delivery_address as string | null;
    const customAttributes = doc.custom_attributes as string | null;

    // Fetch source lines
    const lineRows = await tx.unsafe<Record<string, unknown>>(
      `SELECT line_no, article_id, quantity, net_price, tax_code_id, warehouse_id,
              cost_center_id, target_warehouse_id, movement_type, line_type, unit,
              discount_percentage, article_text_snapshot
       FROM document_line
       WHERE document_id = $1
       ORDER BY line_no`,
      [documentId],
    );

    // Archive source document
    await tx.unsafe(
      `UPDATE document
       SET status = 'archived', archived_at = NOW(), version_no = version_no + 1, updated_at = NOW()
       WHERE document_id = $1`,
      [documentId],
    );

    // Allocate new number from sequence
    const seqRows = await tx.unsafe<Record<string, unknown>>(
      `SELECT prefix, next_value, padding FROM number_sequence
       WHERE company_id = $1 AND document_type = $2
       FOR UPDATE`,
      [companyId, targetDocType],
    );

    if (seqRows.length === 0) {
      return {
        success: false,
        error: `No number sequence found for target type '${targetDocType}'`,
      };
    }

    const seq = seqRows[0];
    const prefix = seq.prefix as string;
    const nextValue = seq.next_value as number;
    const padding = seq.padding as number;
    const newDocumentNo = `${prefix}-${String(nextValue).padStart(padding, "0")}`;

    await tx.unsafe(
      `UPDATE number_sequence SET next_value = next_value + 1, updated_at = NOW()
       WHERE company_id = $1 AND document_type = $2`,
      [companyId, targetDocType],
    );

    // Create new document
    const newDocRows = await tx.unsafe<Record<string, unknown>>(
      `INSERT INTO document (
        company_id, document_type, document_direction, document_no, status,
        document_date, customer_id, currency_id, document_group_id, document_type_id,
        warehouse_id, target_warehouse_id, payment_term_id, shipping_method_id,
        delivery_address_id, parent_document_id, posting_date, billing_address,
        delivery_address, custom_attributes, transaction_id
      ) VALUES (
        $1, $2, $3, $4, 'draft', $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21
      ) RETURNING document_id`,
      [
        companyId,
        targetDocType,
        documentDirection,
        newDocumentNo,
        documentDate,
        customerId,
        currencyId,
        effectiveTargetGroupId ?? null,
        documentTypeId,
        warehouseId,
        targetWarehouseId,
        paymentTermId,
        shippingMethodId,
        deliveryAddressId,
        documentId,
        postingDate,
        billingAddress,
        deliveryAddress,
        customAttributes,
        transactionId,
      ],
    );

    const newDocumentId = newDocRows[0].document_id as string;

    // Copy lines
    for (const line of lineRows) {
      await tx.unsafe(
        `INSERT INTO document_line (
          document_id, line_no, article_id, quantity, net_price, tax_code_id,
          warehouse_id, cost_center_id, target_warehouse_id, movement_type,
          line_type, unit, discount_percentage, article_text_snapshot, transaction_id
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, gen_random_uuid())`,
        [
          newDocumentId,
          line.line_no,
          line.article_id,
          line.quantity,
          line.net_price,
          line.tax_code_id,
          line.warehouse_id,
          line.cost_center_id,
          line.target_warehouse_id,
          line.movement_type,
          line.line_type ?? "article",
          line.unit,
          line.discount_percentage,
          line.article_text_snapshot,
        ],
      );
    }

    return {
      success: true,
      newDocumentId,
      newDocumentNo,
    };
  });
}

export interface StornoDocumentParams {
  documentId: string;
  userId: string;
}

export interface StornoDocumentResult {
  success: boolean;
  stornoDocumentId?: string;
  stornoDocumentNo?: string;
  error?: string;
}

// Hardcoded storno map: source type → target type (null means no new document, just reverse)
const STORNO_REVERSAL_MAP: Record<string, string | null> = {
  A: null,
  L: null,
  R: "G",
  r: "g",
};

export async function stornoDocument(
  sql: SqlClient,
  params: StornoDocumentParams,
): Promise<StornoDocumentResult> {
  const { documentId } = params;

  return sql.begin(async (tx) => {
    const docRows = await tx.unsafe<Record<string, unknown>>(
      `SELECT d.*, dg.next_group_id
       FROM document d
       LEFT JOIN document_group dg ON d.document_group_id = dg.document_group_id
       WHERE d.document_id = $1
       FOR UPDATE`,
      [documentId],
    );

    if (docRows.length === 0) {
      return { success: false, error: "Document not found" };
    }

    const doc = docRows[0];
    const docType = doc.document_type as string;
    const status = doc.status as string;
    const tenantId = doc.tenant_id as string;
    const companyId = doc.company_id as string;
    const docWarehouseId = doc.warehouse_id as string | null;

    const stornoType = STORNO_REVERSAL_MAP[docType];
    if (stornoType === undefined) {
      return {
        success: false,
        error: `Storno not supported for document type '${docType}'`,
      };
    }

    if (status !== "posted") {
      return {
        success: false,
        error: `Storno only allowed for posted documents, current status is '${status}'`,
      };
    }

    const transactionId = doc.transaction_id as string;
    const documentDirection = doc.document_direction as string;
    const documentDate = doc.document_date as string;
    const customerId = doc.customer_id as string | null;
    const currencyId = doc.currency_id as string | null;
    const documentGroupId = doc.document_group_id as string | null;
    const documentTypeId = doc.document_type_id as string | null;
    const warehouseId = doc.warehouse_id as string | null;
    const targetWarehouseId = doc.target_warehouse_id as string | null;
    const paymentTermId = doc.payment_term_id as string | null;
    const shippingMethodId = doc.shipping_method_id as string | null;
    const deliveryAddressId = doc.delivery_address_id as string | null;
    const postingDate = doc.posting_date as string | null;
    const billingAddress = doc.billing_address as string | null;
    const deliveryAddress = doc.delivery_address as string | null;
    const customAttributes = doc.custom_attributes as string | null;

    // Fetch source lines with tracking info
    const lineRows = await tx.unsafe<Record<string, unknown>>(
      `SELECT dl.*, a.tracking_mode
       FROM document_line dl
       LEFT JOIN article a ON dl.article_id = a.article_id
       WHERE dl.document_id = $1
       ORDER BY dl.line_no`,
      [documentId],
    );

    // Reversal side-effects
    if (docType === "A") {
      for (const line of lineRows) {
        const articleId = line.article_id as string | null;
        const qty = parseFloat((line.quantity as string) ?? "0");
        const lineWhId = (line.warehouse_id as string | null) || docWarehouseId;

        if (articleId && lineWhId && qty !== 0) {
          await tx.unsafe(
            `UPDATE inventory_balance
             SET reserved_qty = inventory_balance.reserved_qty - $4,
                 available_qty = inventory_balance.on_hand_qty - (inventory_balance.reserved_qty - $4),
                 as_of_at = NOW()
             WHERE tenant_id = $1 AND warehouse_id = $2 AND article_id = $3`,
            [tenantId, lineWhId, articleId, qty.toString()],
          );
        }
      }
    } else if (docType === "L") {
      for (const line of lineRows) {
        const articleId = line.article_id as string | null;
        const qty = parseFloat((line.quantity as string) ?? "0");
        const lineWhId = (line.warehouse_id as string | null) || docWarehouseId;
        const trackingMode = line.tracking_mode as string | null;

        if (articleId && lineWhId && qty !== 0) {
          // Return items to stock
          await tx.unsafe(
            `INSERT INTO inventory_movement (
              tenant_id, company_id, warehouse_id, article_id,
              movement_type, qty_delta, movement_date,
              source_document_id, source_document_line_id, transaction_id
            ) VALUES ($1, $2, $3, $4, 'L-STORNO', $5, NOW(), $6, $7, $8)`,
            [
              tenantId,
              companyId,
              lineWhId,
              articleId,
              qty.toString(),
              documentId,
              line.document_line_id,
              transactionId,
            ],
          );

          await tx.unsafe(
            `INSERT INTO inventory_balance (
              tenant_id, company_id, warehouse_id, article_id,
              on_hand_qty, reserved_qty, available_qty
            ) VALUES ($1, $2, $3, $4, $5, 0, $5)
            ON CONFLICT (tenant_id, warehouse_id, article_id)
            DO UPDATE SET
              on_hand_qty = inventory_balance.on_hand_qty + $5,
              available_qty = inventory_balance.on_hand_qty + $5 - inventory_balance.reserved_qty,
              as_of_at = NOW()`,
            [tenantId, companyId, lineWhId, articleId, qty.toString()],
          );

          // Revert serial number status
          if (trackingMode === "serial") {
            const trackingRows = await tx.unsafe<Record<string, unknown>>(
              `SELECT serial_number_id FROM document_line_tracking WHERE document_line_id = $1`,
              [line.document_line_id],
            );
            for (const tr of trackingRows) {
              await tx.unsafe(
                `UPDATE serial_number SET status = 'in_stock', consumed_movement_id = NULL, updated_at = NOW()
                 WHERE serial_number_id = $1`,
                [tr.serial_number_id],
              );
            }
          }
        }
      }
    }

    // Cancel original document
    await tx.unsafe(
      `UPDATE document
       SET status = 'cancelled', cancelled_at = NOW(), version_no = version_no + 1, updated_at = NOW()
       WHERE document_id = $1`,
      [documentId],
    );

    if (stornoType === null) {
      return { success: true };
    }

    // Allocate new number for storno document
    const seqRows = await tx.unsafe<Record<string, unknown>>(
      `SELECT prefix, next_value, padding FROM number_sequence
       WHERE company_id = $1 AND document_type = $2
       FOR UPDATE`,
      [companyId, stornoType],
    );

    if (seqRows.length === 0) {
      return {
        success: false,
        error: `No number sequence found for storno type '${stornoType}'`,
      };
    }

    const seq = seqRows[0];
    const prefix = seq.prefix as string;
    const nextValue = seq.next_value as number;
    const padding = seq.padding as number;
    const stornoDocumentNo = `${prefix}-${String(nextValue).padStart(padding, "0")}`;

    await tx.unsafe(
      `UPDATE number_sequence SET next_value = next_value + 1, updated_at = NOW()
       WHERE company_id = $1 AND document_type = $2`,
      [companyId, stornoType],
    );

    // Create storno document (G or g) with same positive quantities
    const stornoDocRows = await tx.unsafe<Record<string, unknown>>(
      `INSERT INTO document (
        company_id, document_type, document_direction, document_no, status,
        document_date, customer_id, currency_id, document_group_id, document_type_id,
        warehouse_id, target_warehouse_id, payment_term_id, shipping_method_id,
        delivery_address_id, parent_document_id, posting_date, billing_address,
        delivery_address, custom_attributes, transaction_id, storno_document_id
      ) VALUES (
        $1, $2, $3, $4, 'draft', $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22
      ) RETURNING document_id`,
      [
        companyId,
        stornoType,
        documentDirection,
        stornoDocumentNo,
        documentDate,
        customerId,
        currencyId,
        documentGroupId,
        documentTypeId,
        warehouseId,
        targetWarehouseId,
        paymentTermId,
        shippingMethodId,
        deliveryAddressId,
        documentId,
        postingDate,
        billingAddress,
        deliveryAddress,
        customAttributes,
        transactionId,
        documentId,
      ],
    );

    const stornoDocumentId = stornoDocRows[0].document_id as string;

    // Copy lines with same positive quantities
    for (const line of lineRows) {
      await tx.unsafe(
        `INSERT INTO document_line (
          document_id, line_no, article_id, quantity, net_price, tax_code_id,
          warehouse_id, cost_center_id, target_warehouse_id, movement_type,
          line_type, unit, discount_percentage, article_text_snapshot, transaction_id
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, gen_random_uuid())`,
        [
          stornoDocumentId,
          line.line_no,
          line.article_id,
          line.quantity,
          line.net_price,
          line.tax_code_id,
          line.warehouse_id,
          line.cost_center_id,
          line.target_warehouse_id,
          line.movement_type,
          line.line_type ?? "article",
          line.unit,
          line.discount_percentage,
          line.article_text_snapshot,
        ],
      );
    }

    return {
      success: true,
      stornoDocumentId,
      stornoDocumentNo,
    };
  });
}
