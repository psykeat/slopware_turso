import {
  isEntityReadable,
  isEntityPatchable,
  getEntityDescriptor,
  isMasterData,
  getSoftDeleteField,
} from "../entities/registry";
import type { EffectiveField } from "../metadata";
import { getEffectiveFields } from "../metadata";
import type { SqlClient } from "../runtime";

export interface ValidationError {
  field: string;
  message: string;
  code: "required" | "type" | "unknown";
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
}

export interface PatchPayload {
  [key: string]: unknown;
}

export async function validateAgainstEffectiveFields(
  sql: SqlClient,
  entityName: string,
  payload: PatchPayload,
): Promise<ValidationResult> {
  if (!isEntityReadable(entityName)) {
    return {
      valid: false,
      errors: [
        {
          field: "_entity",
          message: `Entity '${entityName}' is not registered or not readable`,
          code: "unknown",
        },
      ],
    };
  }

  if (!isEntityPatchable(entityName)) {
    return {
      valid: false,
      errors: [
        {
          field: "_entity",
          message: `Entity '${entityName}' is not generically patchable`,
          code: "unknown",
        },
      ],
    };
  }

  const fields = await getEffectiveFields(sql, { entityName });
  const errors: ValidationError[] = [];

  const fieldMap = new Map<string, EffectiveField>();
  for (const f of fields) {
    fieldMap.set(f.fieldName, f);
  }

  for (const [key, value] of Object.entries(payload)) {
    const field = fieldMap.get(key);
    if (!field) {
      errors.push({
        field: key,
        message: `Unknown field '${key}' for entity '${entityName}'`,
        code: "unknown",
      });
      continue;
    }

    if (field.isVisible === false) {
      errors.push({ field: key, message: `Field '${key}' is not visible`, code: "unknown" });
      continue;
    }

    if (value === null || value === undefined) {
      if (field.isRequired) {
        errors.push({ field: key, message: `Field '${key}' is required`, code: "required" });
      }
      continue;
    }

    if (field.fieldType && typeof value !== "object") {
      const type = field.fieldType.toLowerCase();
      const actual = typeof value;
      const isNumeric = [
        "integer",
        "number",
        "decimal",
        "numeric",
        "real",
        "double",
        "float",
        "int",
        "smallint",
        "bigint",
      ].includes(type);

      if ((type === "boolean" || type === "bool") && actual !== "boolean") {
        errors.push({ field: key, message: `Expected boolean for '${key}'`, code: "type" });
      } else if (isNumeric && actual !== "number") {
        errors.push({ field: key, message: `Expected number for '${key}'`, code: "type" });
      }
    }
  }

  for (const field of fields) {
    if (field.isRequired && !(field.fieldName in payload)) {
      errors.push({
        field: field.fieldName,
        message: `Field '${field.fieldName}' is required`,
        code: "required",
      });
    }
  }

  return { valid: errors.length === 0, errors };
}

export function preparePatchPayload(entityName: string, payload: PatchPayload): PatchPayload {
  const sanitized: PatchPayload = {};
  for (const [key, value] of Object.entries(payload)) {
    if (value === undefined) {
      continue;
    }
    sanitized[key] = value;
  }
  return sanitized;
}

export interface CreateEntityResult {
  success: boolean;
  id?: string;
  error?: string;
}

export async function createEntity(
  sql: SqlClient,
  entityName: string,
  payload: PatchPayload,
): Promise<CreateEntityResult> {
  const desc = getEntityDescriptor(entityName);
  if (!desc) {
    return { success: false, error: `Entity '${entityName}' not found` };
  }

  if (!isEntityPatchable(entityName)) {
    return { success: false, error: `Entity '${entityName}' is not generically creatable` };
  }

  const validation = await validateAgainstEffectiveFields(sql, entityName, payload);
  if (!validation.valid) {
    return {
      success: false,
      error: `Validation failed: ${validation.errors.map((e) => e.message).join("; ")}`,
    };
  }

  // Ensure tenant_id is set for tenant-scoped entities
  const finalPayload = { ...payload };
  if (desc.tenantScoped) {
    const currentTenantId = (sql as any).tenantId;
    if (currentTenantId && !finalPayload.tenant_id) {
      finalPayload.tenant_id = currentTenantId;
    }
  }

  const tableName = desc.tableName;
  const columns = Object.keys(finalPayload).join(", ");
  const placeholders = Object.keys(finalPayload)
    .map((_, i) => `$${i + 1}`)
    .join(", ");
  // Ensure objects are stringified for JSONB columns to avoid driver issues
  const values = Object.values(finalPayload).map((v) =>
    typeof v === "object" && v !== null ? JSON.stringify(v) : v,
  );

  try {
    const result = await sql.unsafe<Record<string, unknown>>(
      `INSERT INTO ${tableName} (${columns}) VALUES (${placeholders}) RETURNING ${desc.idColumn}`,
      values,
    );
    return { success: true, id: String(result[0]?.[desc.idColumn]) };
  } catch (e: unknown) {
    return {
      success: false,
      error: e instanceof Error ? e.message : "Failed to create entity",
    };
  }
}

export interface PatchEntityResult {
  success: boolean;
  error?: string;
  errorCode?: string;
}

export async function patchEntity(
  sql: SqlClient,
  entityName: string,
  id: string,
  payload: PatchPayload,
): Promise<PatchEntityResult> {
  const desc = getEntityDescriptor(entityName);
  if (!desc) {
    return { success: false, error: `Entity '${entityName}' not found` };
  }

  if (!isEntityPatchable(entityName)) {
    return { success: false, error: `Entity '${entityName}' is not generically patchable` };
  }

  if (entityName === "document_group") {
    const rows = await sql.unsafe<Record<string, unknown>>(
      `SELECT group_number FROM document_group WHERE document_group_id = $1`,
      [id],
    );
    if (rows.length > 0 && rows[0].group_number === 0) {
      return {
        success: false,
        error: "System document group (X00) is protected",
        errorCode: "GROUP_PROTECTED",
      };
    }
  }

  const sanitized = preparePatchPayload(entityName, payload);
  const validation = await validateAgainstEffectiveFields(sql, entityName, sanitized);
  if (!validation.valid) {
    return {
      success: false,
      error: `Validation failed: ${validation.errors.map((e) => e.message).join("; ")}`,
    };
  }

  const tableName = desc.tableName;
  const setClauses = Object.keys(sanitized)
    .map((key, i) => `${key} = $${i + 1}`)
    .join(", ");
  // Ensure objects are stringified for JSONB columns
  const values = [
    ...Object.values(sanitized).map((v) =>
      typeof v === "object" && v !== null ? JSON.stringify(v) : v,
    ),
    id,
  ];

  try {
    await sql.unsafe(
      `UPDATE ${tableName} SET ${setClauses}, updated_at = NOW() WHERE ${desc.idColumn} = $${values.length}`,
      values,
    );
    return { success: true };
  } catch (e: unknown) {
    return {
      success: false,
      error: e instanceof Error ? e.message : "Failed to patch entity",
    };
  }
}

export interface DeleteEntityResult {
  success: boolean;
  error?: string;
  errorCode?: string;
  action?: "hard_delete" | "soft_delete";
}

export interface DeactivateEntityResult {
  success: boolean;
  error?: string;
}

export async function deactivateEntity(
  sql: SqlClient,
  entityName: string,
  id: string,
): Promise<DeactivateEntityResult> {
  const desc = getEntityDescriptor(entityName);
  if (!desc) {
    return { success: false, error: `Entity '${entityName}' not found` };
  }

  if (entityName === "document_group") {
    const rows = await sql.unsafe<Record<string, unknown>>(
      `SELECT group_number FROM document_group WHERE document_group_id = $1`,
      [id],
    );
    if (rows.length > 0 && rows[0].group_number === 0) {
      return {
        success: false,
        error: "System document group (X00) is protected",
      };
    }
  }

  if (!isMasterData(entityName)) {
    return { success: false, error: `Entity '${entityName}' is not master data` };
  }

  const softField = getSoftDeleteField(entityName);
  if (!softField) {
    return {
      success: false,
      error: `Entity '${entityName}' is master data with no soft-delete field configured`,
    };
  }

  const tableName = desc.tableName;
  try {
    if (softField === "is_active") {
      await sql.unsafe(`UPDATE ${tableName} SET is_active = false WHERE ${desc.idColumn} = $1`, [
        id,
      ]);
    } else if (softField === "archived_at") {
      await sql.unsafe(
        `UPDATE ${tableName} SET is_active = false, archived_at = NOW() WHERE ${desc.idColumn} = $1`,
        [id],
      );
    }
    return { success: true };
  } catch (e: unknown) {
    return {
      success: false,
      error: e instanceof Error ? e.message : "Failed to deactivate entity",
    };
  }
}

export interface DuplicateEntityResult {
  success: boolean;
  id?: string;
  error?: string;
}

const AUDIT_FIELDS = new Set([
  "id",
  "created_at",
  "updated_at",
  "created_by",
  "updated_by",
  "row_version",
  "inserted_on",
  "modified_on",
]);

export async function duplicateEntity(
  sql: SqlClient,
  entityName: string,
  sourceId: string,
): Promise<DuplicateEntityResult> {
  const desc = getEntityDescriptor(entityName);
  if (!desc) {
    return { success: false, error: `Entity '${entityName}' not found` };
  }

  if (!isEntityPatchable(entityName)) {
    return { success: false, error: `Entity '${entityName}' is not generically duplicable` };
  }

  const tableName = desc.tableName;
  const idColumn = desc.idColumn;

  try {
    const result = await sql.unsafe<Record<string, unknown>>(
      `SELECT * FROM ${tableName} WHERE ${idColumn} = $1 LIMIT 1`,
      [sourceId],
    );

    if (!result.length) {
      return { success: false, error: `Record with ID '${sourceId}' not found` };
    }

    const source = result[0];
    const payload: PatchPayload = {};
    for (const [key, value] of Object.entries(source)) {
      if (AUDIT_FIELDS.has(key) || key === idColumn || key.endsWith("_id")) {
        if (key === "tenant_id" || key === idColumn) {
          continue;
        }
        if (key !== idColumn && !AUDIT_FIELDS.has(key)) {
          payload[key] = value;
        }
        continue;
      }
      payload[key] = value;
    }

    if (desc.tenantScoped) {
      const currentTenantId = (sql as any).tenantId;
      if (currentTenantId) {
        payload.tenant_id = currentTenantId;
      }
    }

    if ("status" in payload) {
      payload.status = "draft";
    }
    if ("is_active" in payload) {
      payload.is_active = true;
    }

    const columns = Object.keys(payload).join(", ");
    const placeholders = Object.keys(payload)
      .map((_, i) => `$${i + 1}`)
      .join(", ");
    const values = Object.values(payload).map((v) =>
      typeof v === "object" && v !== null ? JSON.stringify(v) : v,
    );

    const insertResult = await sql.unsafe<Record<string, unknown>>(
      `INSERT INTO ${tableName} (${columns}) VALUES (${placeholders}) RETURNING ${idColumn}`,
      values,
    );

    return { success: true, id: String(insertResult[0]?.[idColumn]) };
  } catch (e: unknown) {
    return {
      success: false,
      error: e instanceof Error ? e.message : "Failed to duplicate entity",
    };
  }
}

export async function deleteEntity(
  sql: SqlClient,
  entityName: string,
  id: string,
): Promise<DeleteEntityResult> {
  const desc = getEntityDescriptor(entityName);
  if (!desc) {
    return { success: false, error: `Entity '${entityName}' not found` };
  }

  if (!isEntityPatchable(entityName)) {
    return { success: false, error: `Entity '${entityName}' is not generically deletable` };
  }

  if (entityName === "document_group") {
    const rows = await sql.unsafe<Record<string, unknown>>(
      `SELECT group_number FROM document_group WHERE document_group_id = $1`,
      [id],
    );
    if (rows.length > 0 && rows[0].group_number === 0) {
      return {
        success: false,
        error: "System document group (X00) is protected",
        errorCode: "GROUP_PROTECTED",
      };
    }
  }

  const tableName = desc.tableName;

  if (isMasterData(entityName)) {
    const softField = getSoftDeleteField(entityName);
    if (softField) {
      try {
        if (softField === "is_active") {
          await sql.unsafe(
            `UPDATE ${tableName} SET is_active = false WHERE ${desc.idColumn} = $1`,
            [id],
          );
        } else if (softField === "archived_at") {
          await sql.unsafe(
            `UPDATE ${tableName} SET is_active = false, archived_at = NOW() WHERE ${desc.idColumn} = $1`,
            [id],
          );
        }
        return { success: true, action: "soft_delete" };
      } catch (e: unknown) {
        return {
          success: false,
          error: e instanceof Error ? e.message : "Failed to deactivate entity",
        };
      }
    }
    return {
      success: false,
      error: `Entity '${entityName}' is master data with no soft-delete field configured`,
    };
  }

  try {
    await sql.unsafe(`DELETE FROM ${tableName} WHERE ${desc.idColumn} = $1`, [id]);
    return { success: true, action: "hard_delete" };
  } catch (e: unknown) {
    return {
      success: false,
      error: e instanceof Error ? e.message : "Failed to delete entity",
    };
  }
}
