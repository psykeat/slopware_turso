import type { SqlClient } from "../runtime";

export interface ExplodeBomResult {
  success: boolean;
  linesAdded: number;
  error?: string;
}

export async function explodeDocumentBom(
  sql: SqlClient,
  params: { documentId: string; tenantId: string },
): Promise<ExplodeBomResult> {
  const { documentId, tenantId } = params;

  return sql.begin(async (tx) => {
    // 1. Fetch document status
    const docRows = await tx.unsafe<Record<string, unknown>>(
      `SELECT status FROM document WHERE document_id = $1`,
      [documentId],
    );

    if (docRows.length === 0) {
      return { success: false, linesAdded: 0, error: "Document not found" };
    }

    const status = docRows[0].status as string;
    if (status !== "draft") {
      return {
        success: false,
        linesAdded: 0,
        error: "Only draft documents can be exploded",
      };
    }

    // 2. Fetch lines and their articles' BOM type
    const lines = await tx.unsafe<Record<string, unknown>>(
      `SELECT dl.*, a.bom_type
       FROM document_line dl
       LEFT JOIN article a ON dl.article_id = a.article_id
       WHERE dl.document_id = $1
       ORDER BY dl.line_no`,
      [documentId],
    );

    let totalLinesAdded = 0;
    const newLines: any[] = [];

    for (const line of lines) {
      newLines.push(line);
      // Only explode production BOMs that aren't already components
      if (line.bom_type === "production" && line.line_type !== "bom_component") {
        const articleId = line.article_id as string;
        const quantity = parseFloat((line.quantity as string) ?? "0");

        // Fetch components
        const components = await tx.unsafe<Record<string, unknown>>(
          `SELECT ab.*, a.name AS article_name, a.sales_unit
           FROM article_bom ab
           JOIN article a ON ab.component_article_id = a.article_id
           WHERE ab.header_article_id = $1 AND ab.tenant_id = $2 AND ab.is_active = true`,
          [articleId, tenantId],
        );

        for (const comp of components) {
          totalLinesAdded++;
          const compQty = parseFloat((comp.quantity as string) ?? "0");
          newLines.push({
            article_id: comp.component_article_id,
            quantity: quantity * compQty,
            line_type: "bom_component",
            article_text_snapshot: comp.article_name,
            warehouse_id: line.warehouse_id,
            net_price: 0,
            tax_code_id: null,
            unit: comp.sales_unit,
            discount_percentage: 0,
            cost_center_id: line.cost_center_id,
            target_warehouse_id: line.target_warehouse_id,
            movement_type: line.movement_type,
          });
        }
      }
    }

    if (totalLinesAdded > 0) {
      // Delete old lines and insert all renumbered
      await tx.unsafe(`DELETE FROM document_line WHERE document_id = $1`, [documentId]);

      for (let i = 0; i < newLines.length; i++) {
        const ln = newLines[i];
        const qty = typeof ln.quantity === "string" ? parseFloat(ln.quantity) : ln.quantity;
        const price =
          typeof ln.net_price === "string" ? parseFloat(ln.net_price) : ln.net_price || 0;
        const discount =
          typeof ln.discount_percentage === "string"
            ? parseFloat(ln.discount_percentage)
            : ln.discount_percentage || 0;

        const lineNet = qty * price * (1 - discount / 100);

        await tx.unsafe(
          `INSERT INTO document_line (
            document_id, line_no, article_id, quantity, net_price, tax_code_id,
            warehouse_id, cost_center_id, target_warehouse_id, movement_type,
            line_type, unit, discount_percentage, article_text_snapshot, transaction_id,
            line_total_net, tax_amount
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, gen_random_uuid(), $15, 0)`,
          [
            documentId,
            i + 1,
            ln.article_id ?? null,
            qty,
            price,
            ln.tax_code_id ?? null,
            ln.warehouse_id ?? null,
            ln.cost_center_id ?? null,
            ln.target_warehouse_id ?? null,
            ln.movement_type ?? null,
            ln.line_type ?? "article",
            ln.unit ?? null,
            discount,
            ln.article_text_snapshot ?? "",
            lineNet,
          ],
        );
      }
    }

    return { success: true, linesAdded: totalLinesAdded };
  });
}
