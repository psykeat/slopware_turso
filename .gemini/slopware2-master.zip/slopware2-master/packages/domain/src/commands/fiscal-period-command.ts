import type { SqlClient } from "../runtime";

export interface ClosePeriodParams {
  fiscalPeriodId: string;
}

export interface ClosePeriodResult {
  success: boolean;
  error?: string;
  errorCode?: "NOT_FOUND" | "ALREADY_CLOSED" | "INTERNAL";
}

export async function closePeriod(
  sql: SqlClient,
  params: ClosePeriodParams,
): Promise<ClosePeriodResult> {
  const { fiscalPeriodId } = params;

  const rows = await sql.unsafe<Record<string, unknown>>(
    `SELECT fiscal_period_id, is_closed FROM fiscal_period WHERE fiscal_period_id = $1 LIMIT 1`,
    [fiscalPeriodId],
  );

  if (rows.length === 0) {
    return { success: false, error: "Fiscal period not found", errorCode: "NOT_FOUND" };
  }

  const period = rows[0];
  if (period.is_closed === true) {
    return { success: true, errorCode: "ALREADY_CLOSED" };
  }

  try {
    await sql.unsafe(`UPDATE fiscal_period SET is_closed = true WHERE fiscal_period_id = $1`, [
      fiscalPeriodId,
    ]);
    return { success: true };
  } catch (e: unknown) {
    return {
      success: false,
      error: e instanceof Error ? e.message : "Failed to close fiscal period",
      errorCode: "INTERNAL",
    };
  }
}
