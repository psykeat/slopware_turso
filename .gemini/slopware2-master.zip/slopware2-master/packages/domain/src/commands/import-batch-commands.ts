import type { SqlClient } from "../runtime";
import { createEntity, patchEntity } from "./entity-command-service";

export async function rerunImportBatch(sql: SqlClient, batchId: string) {
  const rows = await sql.unsafe<any>(
    `SELECT connector_id, atomicity_mode, target_entity, target_command_key
     FROM import_batch WHERE batch_id = $1`,
    [batchId],
  );

  if (rows.length === 0) {
    throw new Error(`Batch ${batchId} not found`);
  }

  const original = rows[0];

  return createEntity(sql, "import_batch", {
    connector_id: original.connector_id,
    atomicity_mode: original.atomicity_mode,
    target_entity: original.target_entity,
    target_command_key: original.target_command_key,
    status: "pending",
    is_rerun: true,
    source_batch_id: batchId,
  });
}

export async function rejectImportBatch(sql: SqlClient, batchId: string) {
  return patchEntity(sql, "import_batch", batchId, {
    status: "rejected",
  });
}
