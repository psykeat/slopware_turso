import type { SqlClient } from "../runtime";

export interface PostDocumentParams {
  documentId: string;
  userId: string;
}

export interface PostDocumentResult {
  success: boolean;
  error?: string;
  errorCode?:
    | "NOT_FOUND"
    | "ALREADY_POSTED"
    | "INVALID_TYPE"
    | "INTERNAL"
    | "SAME_WAREHOUSE"
    | "TRACKING_INCOMPLETE"
    | "STORNO_DOCUMENT_REQUIRED"
    | "PERIOD_CLOSED";
}

const INVENTORY_OUT_TYPES = new Set(["L"]);
const INVENTORY_IN_TYPES = new Set(["b", "l"]);
const SALES_EVENT_TYPES = new Set(["R", "G"]);
const PURCHASE_EVENT_TYPES = new Set(["r", "g"]);
const INVENTORY_ADJUSTMENT_TYPES = new Set(["V", "Z", "E", "U"]);
const SERIAL_CONSUME_TYPES = new Set(["L", "R", "G"]);
const SERIAL_CREATE_TYPES = new Set(["b", "l", "g", "r"]);
const STORNO_TYPES = new Set(["G"]);
const RESERVATION_TYPES = new Set(["A"]);
const PRODUCTION_TYPES = new Set(["q", "p"]);

export async function resolveFiscalPeriodId(
  sql: SqlClient,
  tenantId: string,
  companyId: string,
  bookingPeriod: string,
): Promise<{ fiscalPeriodId: string; isClosed: boolean } | null> {
  const rows = await sql.unsafe<Record<string, unknown>>(
    `SELECT fiscal_period_id, is_closed FROM fiscal_period
     WHERE tenant_id = $1 AND company_id = $2 AND start_date <= $3 AND end_date >= $3
     LIMIT 1`,
    [tenantId, companyId, bookingPeriod],
  );
  if (rows.length === 0) return null;
  return {
    fiscalPeriodId: rows[0].fiscal_period_id as string,
    isClosed: !!rows[0].is_closed,
  };
}

async function generateFiscalPeriods(
  sql: SqlClient,
  companyId: string,
  tenantId: string,
  fiscalYear: number,
): Promise<void> {
  const companyRows = await sql.unsafe<Record<string, unknown>>(
    `SELECT fiscal_year_start_month FROM company WHERE company_id = $1 LIMIT 1`,
    [companyId],
  );
  const startMonth = (companyRows[0]?.fiscal_year_start_month as number) ?? 1;

  for (let i = 0; i < 12; i++) {
    const monthNo = ((startMonth - 1 + i) % 12) + 1;
    const year = fiscalYear + (startMonth - 1 + i >= 13 ? 1 : 0);
    const startDate = `${year}-${String(monthNo).padStart(2, "0")}-01`;
    const nextMonth = monthNo === 12 ? 1 : monthNo + 1;
    const nextYear = monthNo === 12 ? year + 1 : year;
    const daysInMonth = new Date(nextYear, nextMonth, 0).getDate();
    const endDate = `${nextYear}-${String(nextMonth).padStart(2, "0")}-${String(daysInMonth).padStart(2, "0")}`;

    await sql.unsafe(
      `INSERT INTO fiscal_period (tenant_id, company_id, fiscal_year, period_no, start_date, end_date, is_closed)
       VALUES ($1, $2, $3, $4, $5, $6, false)
       ON CONFLICT (company_id, fiscal_year, period_no) DO NOTHING`,
      [tenantId, companyId, fiscalYear, i + 1, startDate, endDate],
    );
  }
}

export async function postDocument(
  sql: SqlClient,
  params: PostDocumentParams,
): Promise<PostDocumentResult> {
  const { documentId, userId } = params;

  const docRows = await sql.unsafe<Record<string, unknown>>(
    `SELECT document_id, document_type, status, posted_at, company_id, warehouse_id, tenant_id,
             posting_date, customer_id, total_net, transaction_id, target_warehouse_id,
             storno_document_id, document_group_id, payment_term_id, document_date
      FROM document
     WHERE document_id = $1
     LIMIT 1`,
    [documentId],
  );

  if (docRows.length === 0) {
    return { success: false, error: "Document not found", errorCode: "NOT_FOUND" };
  }

  const doc = docRows[0];
  const postedAt = doc.posted_at as string | null;

  if (postedAt !== null) {
    return { success: false, error: "Document is already posted", errorCode: "ALREADY_POSTED" };
  }

  const docType = doc.document_type as string;
  const companyId = doc.company_id as string;
  const tenantId = doc.tenant_id as string;
  const postingDate = doc.posting_date as string | null;
  const customerId = doc.customer_id as string | null;
  const _totalNet = doc.total_net as string | null;
  void _totalNet;
  const transactionId = doc.transaction_id as string;
  const docWarehouseId = doc.warehouse_id as string | null;
  const docGroupId = doc.document_group_id as string | null;
  const paymentTermId = doc.payment_term_id as string | null;
  const documentDate = doc.document_date as string | null;

  const effectiveDate = postingDate || new Date().toISOString().split("T")[0];
  const needsFiscalPeriod = SALES_EVENT_TYPES.has(docType) || PURCHASE_EVENT_TYPES.has(docType);
  let fiscalPeriodId: string | null = null;
  if (needsFiscalPeriod) {
    let fpResult = await resolveFiscalPeriodId(sql, tenantId, companyId, effectiveDate);
    if (!fpResult) {
      const year = parseInt(effectiveDate.slice(0, 4), 10);
      await generateFiscalPeriods(sql, companyId, tenantId, year);
      fpResult = await resolveFiscalPeriodId(sql, tenantId, companyId, effectiveDate);
    }
    if (fpResult) {
      if (fpResult.isClosed) {
        return { success: false, error: "Fiscal period is closed", errorCode: "PERIOD_CLOSED" };
      }
      fiscalPeriodId = fpResult.fiscalPeriodId;
    }
  }

  const lineRows = await sql.unsafe<Record<string, unknown>>(
    `SELECT dl.document_line_id, dl.article_id, dl.quantity, dl.warehouse_id,
            dl.line_total_net, dl.net_price, dl.line_type, dl.target_warehouse_id, a.tracking_mode
     FROM document_line dl
     LEFT JOIN article a ON a.article_id = dl.article_id AND a.tenant_id = dl.tenant_id
     WHERE dl.document_id = $1 AND dl.line_type = 'article'
     ORDER BY dl.line_no`,
    [documentId],
  );

  let requireSerialTracking = true;
  let requireBatchTracking = true;
  if (docGroupId) {
    const groupRows = await sql.unsafe<Record<string, unknown>>(
      `SELECT require_serial_tracking, require_batch_tracking
       FROM document_group
       WHERE document_group_id = $1
       LIMIT 1`,
      [docGroupId],
    );
    if (groupRows.length > 0) {
      requireSerialTracking = !!groupRows[0].require_serial_tracking;
      requireBatchTracking = !!groupRows[0].require_batch_tracking;
    }
  }

  const trackedLines = lineRows.filter(
    (l) => (l.article_id as string | null) && (l.tracking_mode as string | null),
  );

  if (trackedLines.length > 0) {
    const lineIds = trackedLines.map((l) => l.document_line_id as string);
    const trackingRows = await sql.unsafe<Record<string, unknown>>(
      `SELECT dlt.document_line_id, dlt.serial_number_id, dlt.batch_no, dlt.qty::float AS qty
       FROM document_line_tracking dlt
       WHERE dlt.document_line_id = ANY($1::uuid[])`,
      [lineIds],
    );

    const trackingByLine = new Map<string, typeof trackingRows>();
    for (const tr of trackingRows) {
      const lid = tr.document_line_id as string;
      if (!trackingByLine.has(lid)) trackingByLine.set(lid, []);
      trackingByLine.get(lid)!.push(tr);
    }

    for (const line of trackedLines) {
      const lineId = line.document_line_id as string;
      const trackingMode = line.tracking_mode as string;
      const qty = parseFloat((line.quantity as string) ?? "0");
      const lineTracking = trackingByLine.get(lineId) ?? [];

      if (trackingMode === "serial" && requireSerialTracking) {
        const trackedQty = lineTracking.length;
        if (trackedQty !== qty) {
          return {
            success: false,
            error: `Serial tracking incomplete for line ${lineId}: expected ${qty}, got ${trackedQty}`,
            errorCode: "TRACKING_INCOMPLETE",
          };
        }
      } else if (trackingMode === "batch" && requireBatchTracking) {
        const trackedQty = lineTracking.reduce((sum, t) => sum + (t.qty as number), 0);
        if (Math.abs(trackedQty - qty) > 0.001) {
          return {
            success: false,
            error: `Batch tracking incomplete for line ${lineId}: expected ${qty}, got ${trackedQty}`,
            errorCode: "TRACKING_INCOMPLETE",
          };
        }
      }
    }
  }

  if (STORNO_TYPES.has(docType)) {
    const serialTrackedLines = trackedLines.filter((l) => (l.tracking_mode as string) === "serial");
    if (serialTrackedLines.length > 0) {
      const stornoDocId = doc.storno_document_id as string | null;
      if (!stornoDocId) {
        return {
          success: false,
          error: "Credit memo with serial-tracked articles requires storno_document_id",
          errorCode: "STORNO_DOCUMENT_REQUIRED",
        };
      }
    }
  }

  if (INVENTORY_OUT_TYPES.has(docType) || INVENTORY_IN_TYPES.has(docType)) {
    const allLineIds = lineRows.map((l) => l.document_line_id as string);
    const allTracking = allLineIds.length
      ? ((await sql.unsafe<Record<string, unknown>>(
          `SELECT dlt.document_line_id, dlt.serial_number_id, dlt.batch_no, dlt.qty::float AS qty
           FROM document_line_tracking dlt
           WHERE dlt.document_line_id = ANY($1::uuid[])
           ORDER BY dlt.created_at`,
          [allLineIds],
        )) as Record<string, unknown>[])
      : [];

    const trackingByLine = new Map<string, Record<string, unknown>[]>();
    for (const tr of allTracking) {
      const lid = tr.document_line_id as string;
      if (!trackingByLine.has(lid)) trackingByLine.set(lid, []);
      trackingByLine.get(lid)!.push(tr);
    }

    for (const line of lineRows) {
      const articleId = line.article_id as string | null;
      const qty = parseFloat((line.quantity as string) ?? "0");
      const lineWarehouseId = (line.warehouse_id as string | null) || docWarehouseId;
      const _trackingMode = line.tracking_mode as string | null;

      if (!articleId || !lineWarehouseId || qty === 0) {
        continue;
      }

      const qtyDelta = INVENTORY_OUT_TYPES.has(docType) ? -qty : qty;
      const movementType = docType as string;
      const lineTracking = trackingByLine.get(line.document_line_id as string) ?? [];

      if (lineTracking.length > 0) {
        for (const tr of lineTracking) {
          const serialNumberId = tr.serial_number_id as string | null;
          const batchNo = tr.batch_no as string | null;
          const trQty = tr.qty as number;
          const trQtyDelta = INVENTORY_OUT_TYPES.has(docType) ? -trQty : trQty;

          await sql.unsafe(
            `INSERT INTO inventory_movement (
              tenant_id, company_id, warehouse_id, article_id,
              movement_type, qty_delta, movement_date,
              source_document_id, source_document_line_id, transaction_id,
              serial_number_id, batch_no
            ) VALUES ($1, $2, $3, $4, $5, $6, NOW(), $7, $8, $9, $10, $11)
            RETURNING inventory_movement_id`,
            [
              tenantId,
              companyId,
              lineWarehouseId,
              articleId,
              movementType,
              trQtyDelta.toString(),
              documentId,
              line.document_line_id,
              transactionId,
              serialNumberId,
              batchNo,
            ],
          );
        }
      } else {
        await sql.unsafe(
          `INSERT INTO inventory_movement (
            tenant_id, company_id, warehouse_id, article_id,
            movement_type, qty_delta, movement_date,
            source_document_id, source_document_line_id, transaction_id
          ) VALUES ($1, $2, $3, $4, $5, $6, NOW(), $7, $8, $9)`,
          [
            tenantId,
            companyId,
            lineWarehouseId,
            articleId,
            movementType,
            qtyDelta.toString(),
            documentId,
            line.document_line_id,
            transactionId,
          ],
        );
      }

      if (docType === "b") {
        await sql.unsafe(
          `INSERT INTO inventory_balance (
            tenant_id, company_id, warehouse_id, article_id,
            on_hand_qty, reserved_qty, available_qty, expected_purchase_qty
          ) VALUES ($1, $2, $3, $4, $5, $6, $5, $7)
          ON CONFLICT (tenant_id, warehouse_id, article_id)
          DO UPDATE SET
            expected_purchase_qty = inventory_balance.expected_purchase_qty + $7,
            available_qty = inventory_balance.on_hand_qty - inventory_balance.reserved_qty,
            as_of_at = NOW()`,
          [tenantId, companyId, lineWarehouseId, articleId, "0", "0", qtyDelta.toString()],
        );
      } else if (docType === "l") {
        await sql.unsafe(
          `INSERT INTO inventory_balance (
            tenant_id, company_id, warehouse_id, article_id,
            on_hand_qty, reserved_qty, available_qty, expected_purchase_qty
          ) VALUES ($1, $2, $3, $4, $5, $6, $5, $7)
          ON CONFLICT (tenant_id, warehouse_id, article_id)
          DO UPDATE SET
            on_hand_qty = inventory_balance.on_hand_qty + $5,
            expected_purchase_qty = inventory_balance.expected_purchase_qty - $5,
            available_qty = inventory_balance.on_hand_qty + $5 - inventory_balance.reserved_qty,
            as_of_at = NOW()`,
          [
            tenantId,
            companyId,
            lineWarehouseId,
            articleId,
            qtyDelta.toString(),
            "0",
            qtyDelta.toString(),
          ],
        );
      } else {
        await sql.unsafe(
          `INSERT INTO inventory_balance (
            tenant_id, company_id, warehouse_id, article_id,
            on_hand_qty, reserved_qty, available_qty
          ) VALUES ($1, $2, $3, $4, $5, $6, $5)
          ON CONFLICT (tenant_id, warehouse_id, article_id)
          DO UPDATE SET
            on_hand_qty = inventory_balance.on_hand_qty + $5,
            available_qty = inventory_balance.on_hand_qty + $5 - inventory_balance.reserved_qty,
            as_of_at = NOW()`,
          [tenantId, companyId, lineWarehouseId, articleId, qtyDelta.toString(), "0"],
        );
      }
    }
  }

  if (INVENTORY_ADJUSTMENT_TYPES.has(docType)) {
    for (const line of lineRows) {
      const articleId = line.article_id as string | null;
      const qty = parseFloat((line.quantity as string) ?? "0");
      const lineWarehouseId = (line.warehouse_id as string | null) || docWarehouseId;
      const lineTargetWarehouseId = line.target_warehouse_id as string | null;

      if (!articleId || !lineWarehouseId || qty === 0) {
        continue;
      }

      if (docType === "V") {
        await sql.unsafe(
          `INSERT INTO inventory_movement (
            tenant_id, company_id, warehouse_id, article_id,
            movement_type, absolute_qty, movement_date,
            source_document_id, source_document_line_id, transaction_id
          ) VALUES ($1, $2, $3, $4, 'V', $5, NOW(), $6, $7, $8)`,
          [
            tenantId,
            companyId,
            lineWarehouseId,
            articleId,
            qty.toString(),
            documentId,
            line.document_line_id,
            transactionId,
          ],
        );

        await sql.unsafe(
          `INSERT INTO inventory_balance (
            tenant_id, company_id, warehouse_id, article_id,
            on_hand_qty, reserved_qty, available_qty
          ) VALUES ($1, $2, $3, $4, $5, $6, $5)
          ON CONFLICT (tenant_id, warehouse_id, article_id)
          DO UPDATE SET
            on_hand_qty = EXCLUDED.on_hand_qty,
            available_qty = EXCLUDED.on_hand_qty - inventory_balance.reserved_qty,
            as_of_at = NOW()`,
          [tenantId, companyId, lineWarehouseId, articleId, qty.toString(), "0"],
        );
      } else if (docType === "Z") {
        await sql.unsafe(
          `INSERT INTO inventory_movement (
            tenant_id, company_id, warehouse_id, article_id,
            movement_type, qty_delta, movement_date,
            source_document_id, source_document_line_id, transaction_id
          ) VALUES ($1, $2, $3, $4, 'Z', $5, NOW(), $6, $7, $8)`,
          [
            tenantId,
            companyId,
            lineWarehouseId,
            articleId,
            qty.toString(),
            documentId,
            line.document_line_id,
            transactionId,
          ],
        );

        await sql.unsafe(
          `INSERT INTO inventory_balance (
            tenant_id, company_id, warehouse_id, article_id,
            on_hand_qty, reserved_qty, available_qty
          ) VALUES ($1, $2, $3, $4, $5, $6, $5)
          ON CONFLICT (tenant_id, warehouse_id, article_id)
          DO UPDATE SET
            on_hand_qty = inventory_balance.on_hand_qty + $5,
            available_qty = inventory_balance.on_hand_qty + $5 - inventory_balance.reserved_qty,
            as_of_at = NOW()`,
          [tenantId, companyId, lineWarehouseId, articleId, qty.toString(), "0"],
        );
      } else if (docType === "E") {
        await sql.unsafe(
          `INSERT INTO inventory_movement (
            tenant_id, company_id, warehouse_id, article_id,
            movement_type, qty_delta, movement_date,
            source_document_id, source_document_line_id, transaction_id
          ) VALUES ($1, $2, $3, $4, 'E', $5, NOW(), $6, $7, $8)`,
          [
            tenantId,
            companyId,
            lineWarehouseId,
            articleId,
            (-qty).toString(),
            documentId,
            line.document_line_id,
            transactionId,
          ],
        );

        await sql.unsafe(
          `INSERT INTO inventory_balance (
            tenant_id, company_id, warehouse_id, article_id,
            on_hand_qty, reserved_qty, available_qty
          ) VALUES ($1, $2, $3, $4, $5, $6, $5)
          ON CONFLICT (tenant_id, warehouse_id, article_id)
          DO UPDATE SET
            on_hand_qty = inventory_balance.on_hand_qty + $5,
            available_qty = inventory_balance.on_hand_qty + $5 - inventory_balance.reserved_qty,
            as_of_at = NOW()`,
          [tenantId, companyId, lineWarehouseId, articleId, (-qty).toString(), "0"],
        );
      } else if (docType === "U") {
        const targetWhId = lineTargetWarehouseId || docWarehouseId;
        if (!targetWhId) {
          continue;
        }
        if (lineWarehouseId === targetWhId) {
          return {
            success: false,
            error: "Source and target warehouse are the same",
            errorCode: "SAME_WAREHOUSE",
          };
        }

        await sql.unsafe(
          `INSERT INTO inventory_movement (
            tenant_id, company_id, warehouse_id, article_id,
            movement_type, qty_delta, movement_date,
            source_document_id, source_document_line_id, transaction_id
          ) VALUES ($1, $2, $3, $4, 'U', $5, NOW(), $6, $7, $8)`,
          [
            tenantId,
            companyId,
            lineWarehouseId,
            articleId,
            (-qty).toString(),
            documentId,
            line.document_line_id,
            transactionId,
          ],
        );

        await sql.unsafe(
          `INSERT INTO inventory_balance (
            tenant_id, company_id, warehouse_id, article_id,
            on_hand_qty, reserved_qty, available_qty
          ) VALUES ($1, $2, $3, $4, $5, $6, $5)
          ON CONFLICT (tenant_id, warehouse_id, article_id)
          DO UPDATE SET
            on_hand_qty = inventory_balance.on_hand_qty + $5,
            available_qty = inventory_balance.on_hand_qty + $5 - inventory_balance.reserved_qty,
            as_of_at = NOW()`,
          [tenantId, companyId, lineWarehouseId, articleId, (-qty).toString(), "0"],
        );

        await sql.unsafe(
          `INSERT INTO inventory_movement (
            tenant_id, company_id, warehouse_id, article_id,
            movement_type, qty_delta, movement_date,
            source_document_id, source_document_line_id, transaction_id
          ) VALUES ($1, $2, $3, $4, 'U', $5, NOW(), $6, $7, $8)`,
          [
            tenantId,
            companyId,
            targetWhId,
            articleId,
            qty.toString(),
            documentId,
            line.document_line_id,
            transactionId,
          ],
        );

        await sql.unsafe(
          `INSERT INTO inventory_balance (
            tenant_id, company_id, warehouse_id, article_id,
            on_hand_qty, reserved_qty, available_qty
          ) VALUES ($1, $2, $3, $4, $5, $6, $5)
          ON CONFLICT (tenant_id, warehouse_id, article_id)
          DO UPDATE SET
            on_hand_qty = inventory_balance.on_hand_qty + $5,
            available_qty = inventory_balance.on_hand_qty + $5 - inventory_balance.reserved_qty,
            as_of_at = NOW()`,
          [tenantId, companyId, targetWhId, articleId, qty.toString(), "0"],
        );
      }
    }
  }

  if (PRODUCTION_TYPES.has(docType)) {
    for (const line of lineRows) {
      const articleId = line.article_id as string | null;
      const qty = parseFloat((line.quantity as string) ?? "0");
      const lineWarehouseId = (line.warehouse_id as string | null) || docWarehouseId;
      const lineType = line.line_type as string | null;

      if (!articleId || !lineWarehouseId || qty === 0) continue;

      let sign = 0;
      if (lineType === "production_output") sign = 1;
      else if (lineType === "bom_component" || lineType === "production_input") sign = -1;

      if (sign !== 0) {
        const qtyDelta = qty * sign;
        await sql.unsafe(
          `INSERT INTO inventory_movement (
            tenant_id, company_id, warehouse_id, article_id,
            movement_type, qty_delta, movement_date,
            source_document_id, source_document_line_id, transaction_id
          ) VALUES ($1, $2, $3, $4, $5, $6, NOW(), $7, $8, $9)`,
          [
            tenantId,
            companyId,
            lineWarehouseId,
            articleId,
            docType,
            qtyDelta.toString(),
            documentId,
            line.document_line_id,
            transactionId,
          ],
        );

        await sql.unsafe(
          `INSERT INTO inventory_balance (
            tenant_id, company_id, warehouse_id, article_id,
            on_hand_qty, reserved_qty, available_qty
          ) VALUES ($1, $2, $3, $4, $5, 0, $5)
          ON CONFLICT (tenant_id, warehouse_id, article_id)
          DO UPDATE SET
            on_hand_qty = inventory_balance.on_hand_qty + $5,
            available_qty = inventory_balance.on_hand_qty + $5 - inventory_balance.reserved_qty,
            as_of_at = NOW()`,
          [tenantId, companyId, lineWarehouseId, articleId, qtyDelta.toString()],
        );
      }
    }
  }

  if (RESERVATION_TYPES.has(docType)) {
    for (const line of lineRows) {
      const articleId = line.article_id as string | null;
      const qty = parseFloat((line.quantity as string) ?? "0");
      const lineWarehouseId = (line.warehouse_id as string | null) || docWarehouseId;

      if (!articleId || !lineWarehouseId || qty === 0) continue;

      await sql.unsafe(
        `INSERT INTO inventory_balance (
          tenant_id, company_id, warehouse_id, article_id,
          on_hand_qty, reserved_qty, available_qty
        ) VALUES ($1, $2, $3, $4, 0, $5, -$5)
        ON CONFLICT (tenant_id, warehouse_id, article_id)
        DO UPDATE SET
          reserved_qty = inventory_balance.reserved_qty + $5,
          available_qty = inventory_balance.on_hand_qty - (inventory_balance.reserved_qty + $5),
          as_of_at = NOW()`,
        [tenantId, companyId, lineWarehouseId, articleId, qty.toString()],
      );
    }
  }

  if (SALES_EVENT_TYPES.has(docType)) {
    for (const line of lineRows) {
      const articleId = line.article_id as string | null;
      const qty = parseFloat((line.quantity as string) ?? "0");
      const lineTotalNet = parseFloat((line.line_total_net as string) ?? "0");

      if (!articleId) {
        continue;
      }

      const sign = docType === "G" ? -1 : 1;
      const qtyDelta = qty * sign;
      const amountNetDelta = lineTotalNet * sign;

      const balanceRows = await sql.unsafe<Record<string, unknown>>(
        `SELECT gld_purchase FROM inventory_balance
         WHERE tenant_id = $1 AND article_id = $2
         LIMIT 1`,
        [tenantId, articleId],
      );
      const gldPurchase =
        balanceRows.length > 0 ? parseFloat((balanceRows[0].gld_purchase as string) ?? "0") : 0;
      const cogsDelta = gldPurchase * Math.abs(qtyDelta);

      await sql.unsafe(
        `INSERT INTO fact_sales_event (
          tenant_id, company_id, source_document_id, source_document_line_id,
          customer_id, article_id, event_type,
          quantity_delta, amount_net_delta, booking_period, transaction_id,
          fiscal_period_id, cogs_delta
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
        [
          tenantId,
          companyId,
          documentId,
          line.document_line_id,
          customerId,
          articleId,
          docType === "G" ? "correction" : "original",
          qtyDelta.toString(),
          amountNetDelta.toString(),
          effectiveDate,
          transactionId,
          fiscalPeriodId,
          cogsDelta.toString(),
        ],
      );
    }
  }

  if (PURCHASE_EVENT_TYPES.has(docType)) {
    for (const line of lineRows) {
      const articleId = line.article_id as string | null;
      const qty = parseFloat((line.quantity as string) ?? "0");
      const lineTotalNet = parseFloat((line.line_total_net as string) ?? "0");
      const netPrice = parseFloat((line.net_price as string) ?? "0");

      if (!articleId) {
        continue;
      }

      const sign = docType === "g" ? -1 : 1;
      const qtyDelta = qty * sign;
      const amountNetDelta = lineTotalNet * sign;

      let avgCostBefore: number | null = null;
      let avgCostAfter: number | null = null;

      if (docType === "r") {
        const balanceRows = await sql.unsafe<Record<string, unknown>>(
          `SELECT SUM(on_hand_qty)::numeric AS total_qty, MAX(gld_purchase)::numeric AS gld_purchase
           FROM inventory_balance
           WHERE tenant_id = $1 AND article_id = $2
           FOR UPDATE`,
          [tenantId, articleId],
        );

        if (balanceRows.length > 0 && balanceRows[0].total_qty !== null) {
          const currentQty = parseFloat((balanceRows[0].total_qty as string) ?? "0");
          const currentAvg = parseFloat(
            (balanceRows[0].gld_purchase as string) ?? String(netPrice),
          );
          avgCostBefore = currentAvg;

          const newQty = currentQty + qty;
          if (newQty <= 0) {
            avgCostAfter = currentAvg;
          } else {
            const newAvg = (currentQty * currentAvg + qty * netPrice) / newQty;
            avgCostAfter = newAvg;
          }

          if (newQty > 0) {
            await sql.unsafe(
              `UPDATE inventory_balance
               SET gld_purchase = $1, gld_cost = $1, as_of_at = NOW()
               WHERE tenant_id = $2 AND article_id = $3`,
              [avgCostAfter!.toString(), tenantId, articleId],
            );
          }
        }
      }

      await sql.unsafe(
        `INSERT INTO fact_purchase_event (
          tenant_id, company_id, source_document_id, source_document_line_id,
          supplier_id, article_id, event_type,
          quantity_delta, amount_net_delta, booking_period, transaction_id,
          fiscal_period_id, avg_cost_before, avg_cost_after
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)`,
        [
          tenantId,
          companyId,
          documentId,
          line.document_line_id,
          customerId,
          articleId,
          docType === "g" ? "correction" : "original",
          qtyDelta.toString(),
          amountNetDelta.toString(),
          effectiveDate,
          transactionId,
          fiscalPeriodId,
          avgCostBefore !== null ? avgCostBefore.toString() : null,
          avgCostAfter !== null ? avgCostAfter.toString() : null,
        ],
      );
    }
  }

  if (SERIAL_CONSUME_TYPES.has(docType) || SERIAL_CREATE_TYPES.has(docType)) {
    const allLineIds = lineRows.map((l) => l.document_line_id as string);
    const postTracking = allLineIds.length
      ? ((await sql.unsafe<Record<string, unknown>>(
          `SELECT dlt.document_line_id, dlt.serial_number_id, dlt.batch_no
           FROM document_line_tracking dlt
           WHERE dlt.document_line_id = ANY($1::uuid[])
           ORDER BY dlt.created_at`,
          [allLineIds],
        )) as Record<string, unknown>[])
      : [];

    const serialTrackingEntries = postTracking.filter(
      (t) => (t.serial_number_id as string | null) !== null,
    );

    if (SERIAL_CONSUME_TYPES.has(docType)) {
      if (docType === "L") {
        const movementRows = await sql.unsafe<Record<string, unknown>>(
          `SELECT inventory_movement_id, serial_number_id
           FROM inventory_movement
           WHERE source_document_id = $1 AND serial_number_id IS NOT NULL`,
          [documentId],
        );
        const movementById = new Map<string, string>();
        for (const mr of movementRows) {
          movementById.set(mr.serial_number_id as string, mr.inventory_movement_id as string);
        }
        for (const entry of serialTrackingEntries) {
          const snId = entry.serial_number_id as string;
          const movId = movementById.get(snId) || null;
          await sql.unsafe(
            `UPDATE serial_number
             SET status = 'sold', consumed_movement_id = $2
             WHERE serial_number_id = $1`,
            [snId, movId],
          );
        }
      } else {
        for (const entry of serialTrackingEntries) {
          const snId = entry.serial_number_id as string;
          await sql.unsafe(
            `UPDATE serial_number
             SET status = 'sold'
             WHERE serial_number_id = $1`,
            [snId],
          );
        }
      }
    }

    if (SERIAL_CREATE_TYPES.has(docType)) {
      for (const entry of serialTrackingEntries) {
        const snId = entry.serial_number_id as string;
        const lineEntry = lineRows.find((l) => l.document_line_id === entry.document_line_id);
        const articleId = lineEntry?.article_id as string | null;
        if (!articleId) continue;

        const snRows = await sql.unsafe<Record<string, unknown>>(
          `SELECT serial_no FROM serial_number WHERE serial_number_id = $1 LIMIT 1`,
          [snId],
        );
        const serialNo =
          snRows.length > 0 ? (snRows[0].serial_no as string) : `SN-${snId.slice(0, 8)}`;

        const existingRows = await sql.unsafe<Record<string, unknown>>(
          `SELECT serial_number_id FROM serial_number
           WHERE article_id = $1 AND serial_no = $2 LIMIT 1`,
          [articleId, serialNo],
        );

        if (existingRows.length === 0) {
          await sql.unsafe(
            `INSERT INTO serial_number (tenant_id, article_id, serial_no, status)
             VALUES ($1, $2, $3, 'in_stock')
             RETURNING serial_number_id`,
            [tenantId, articleId, serialNo],
          );
        } else {
          await sql.unsafe(
            `UPDATE serial_number
             SET status = 'in_stock', consumed_movement_id = NULL
             WHERE serial_number_id = $1`,
            [existingRows[0].serial_number_id as string],
          );
        }
      }

      if (INVENTORY_IN_TYPES.has(docType)) {
        const movementRows = await sql.unsafe<Record<string, unknown>>(
          `SELECT im.inventory_movement_id, im.serial_number_id, a.article_id
           FROM inventory_movement im
           JOIN document_line dl ON dl.document_line_id = im.source_document_line_id
           JOIN article a ON a.article_id = dl.article_id AND a.tenant_id = dl.tenant_id
           WHERE im.source_document_id = $1 AND im.serial_number_id IS NOT NULL`,
          [documentId],
        );
        for (const mr of movementRows) {
          const snId = mr.serial_number_id as string;
          await sql.unsafe(
            `UPDATE serial_number
             SET created_movement_id = $2
             WHERE serial_number_id = $1`,
            [snId, mr.inventory_movement_id as string],
          );
        }
      }
    }
  }

  if (docType === "G") {
    const stornoDocId = doc.storno_document_id as string | null;
    if (stornoDocId) {
      const originalTrackingRows = await sql.unsafe<Record<string, unknown>>(
        `SELECT dlt.serial_number_id
         FROM document_line_tracking dlt
         JOIN document_line dl ON dl.document_line_id = dlt.document_line_id
         WHERE dl.document_id = $1 AND dlt.serial_number_id IS NOT NULL`,
        [stornoDocId],
      );
      for (const tr of originalTrackingRows) {
        const snId = tr.serial_number_id as string;
        await sql.unsafe(
          `UPDATE serial_number
           SET status = 'in_stock', consumed_movement_id = NULL
           WHERE serial_number_id = $1`,
          [snId],
        );
      }
    }
  }

  if (docType === "R" || docType === "r") {
    let dueDate: string | null = null;
    if (paymentTermId && documentDate) {
      const ptRows = await sql.unsafe<Record<string, unknown>>(
        `SELECT net_days FROM payment_term WHERE payment_term_id = $1 LIMIT 1`,
        [paymentTermId],
      );
      if (ptRows.length > 0) {
        const netDays = (ptRows[0].net_days as number) ?? 0;
        const dueDateObj = new Date(documentDate);
        dueDateObj.setDate(dueDateObj.getDate() + netDays);
        dueDate = dueDateObj.toISOString().split("T")[0];
      }
    }

    await sql.unsafe(
      `UPDATE document
       SET due_date = $1
       WHERE document_id = $2`,
      [dueDate, documentId],
    );
  }

  await sql.unsafe(
    `UPDATE document
     SET status = 'posted',
         posted_at = NOW(),
         posted_by = $1,
         posting_date = COALESCE(posting_date, CURRENT_DATE),
         version_no = version_no + 1,
         updated_at = NOW()
     WHERE document_id = $2`,
    [userId, documentId],
  );

  await sql.unsafe(`SELECT pg_notify('stats_refresh', $1)`, [tenantId]);

  return { success: true };
}

const ADJUSTMENT_PREFIXES: Record<string, string> = {
  V: "INV-",
  Z: "ZUB-",
  E: "ENT-",
  U: "UMB-",
};

export function getAdjustmentPrefix(docType: string): string {
  return ADJUSTMENT_PREFIXES[docType] ?? "DOC-";
}

export interface GetNextNumberParams {
  prefix: string;
  companyId: string;
  tenantId: string;
}

export interface GetNextNumberResult {
  success: boolean;
  documentNo?: string;
  error?: string;
}

export async function getNextNumber(
  sql: SqlClient,
  params: GetNextNumberParams,
): Promise<GetNextNumberResult> {
  const { prefix, companyId, tenantId } = params;

  const rows = await sql.unsafe<Record<string, unknown>>(
    `INSERT INTO number_sequence (tenant_id, company_id, prefix, next_value, padding)
     VALUES ($1, $2, $3, 1, 5)
     ON CONFLICT (tenant_id, company_id, prefix)
     DO UPDATE SET next_value = number_sequence.next_value
     RETURNING next_value, padding`,
    [tenantId, companyId, prefix],
  );

  if (rows.length === 0) {
    return { success: false, error: "Failed to get next number" };
  }

  const currentValue = parseInt((rows[0].next_value as string) ?? "1", 10);
  const padding = parseInt((rows[0].padding as string) ?? "5", 10);

  const updatedRows = await sql.unsafe<Record<string, unknown>>(
    `UPDATE number_sequence
     SET next_value = next_value + 1, updated_at = NOW()
     WHERE tenant_id = $1 AND company_id = $2 AND prefix = $3
     RETURNING next_value`,
    [tenantId, companyId, prefix],
  );

  if (updatedRows.length === 0) {
    return { success: false, error: "Failed to increment number sequence" };
  }

  const documentNo = `${prefix}${String(currentValue).padStart(padding, "0")}`;
  return { success: true, documentNo };
}
