import type { SqlClient } from "../runtime";

export interface DocumentTypeDef {
  code: string;
  name: string;
  movementType: string;
  nextCode?: string;
  requiresWarehouse: boolean;
  requiresCostCenter: boolean;
  sortOrder: number;
}

export interface DocumentGroupDef {
  name: string;
  documentType: string;
  groupNumber: number;
  direction?: string;
  nextGroupCode?: string;
}

export interface NumberSequenceDef {
  prefix: string;
  documentType: string;
  padding: number;
}

export interface SeedResult {
  success: boolean;
  documentTypesCreated: number;
  documentGroupsCreated: number;
  numberSequencesCreated: number;
  error?: string;
}

const DOCUMENT_TYPES: DocumentTypeDef[] = [
  {
    code: "N",
    name: "Angebot",
    movementType: "N",
    nextCode: "A",
    requiresWarehouse: false,
    requiresCostCenter: false,
    sortOrder: 1,
  },
  {
    code: "A",
    name: "Auftrag",
    movementType: "A",
    nextCode: "L",
    requiresWarehouse: true,
    requiresCostCenter: false,
    sortOrder: 2,
  },
  {
    code: "L",
    name: "Lieferschein",
    movementType: "L",
    nextCode: "R",
    requiresWarehouse: true,
    requiresCostCenter: false,
    sortOrder: 3,
  },
  {
    code: "R",
    name: "Rechnung",
    movementType: "R",
    requiresWarehouse: false,
    requiresCostCenter: false,
    sortOrder: 4,
  },
  {
    code: "b",
    name: "Bestellung",
    movementType: "b",
    nextCode: "l",
    requiresWarehouse: false,
    requiresCostCenter: false,
    sortOrder: 11,
  },
  {
    code: "l",
    name: "WE-Lieferschein",
    movementType: "l",
    nextCode: "r",
    requiresWarehouse: true,
    requiresCostCenter: false,
    sortOrder: 12,
  },
  {
    code: "r",
    name: "WE-Rechnung",
    movementType: "r",
    requiresWarehouse: false,
    requiresCostCenter: false,
    sortOrder: 13,
  },
  {
    code: "G",
    name: "Gutschrift",
    movementType: "G",
    requiresWarehouse: false,
    requiresCostCenter: false,
    sortOrder: 21,
  },
  {
    code: "g",
    name: "WE-Gutschrift",
    movementType: "g",
    requiresWarehouse: false,
    requiresCostCenter: false,
    sortOrder: 22,
  },
  {
    code: "V",
    name: "Inventurbuchung",
    movementType: "V",
    requiresWarehouse: true,
    requiresCostCenter: false,
    sortOrder: 31,
  },
  {
    code: "Z",
    name: "Zubuchung",
    movementType: "Z",
    requiresWarehouse: true,
    requiresCostCenter: false,
    sortOrder: 32,
  },
  {
    code: "E",
    name: "Entnahme",
    movementType: "E",
    requiresWarehouse: true,
    requiresCostCenter: false,
    sortOrder: 41,
  },
  {
    code: "U",
    name: "Umlagerung",
    movementType: "U",
    requiresWarehouse: true,
    requiresCostCenter: false,
    sortOrder: 51,
  },
  {
    code: "q",
    name: "Produktionsauftrag",
    movementType: "q",
    requiresWarehouse: true,
    requiresCostCenter: false,
    sortOrder: 61,
  },
  {
    code: "p",
    name: "Produktionsbuchung",
    movementType: "p",
    requiresWarehouse: true,
    requiresCostCenter: false,
    sortOrder: 62,
  },
];

const DOCUMENT_GROUPS: DocumentGroupDef[] = [
  {
    name: "Angebote",
    documentType: "N",
    groupNumber: 1,
    direction: undefined,
    nextGroupCode: "A01",
  },
  {
    name: "Aufträge",
    documentType: "A",
    groupNumber: 1,
    direction: "outbound",
    nextGroupCode: "L01",
  },
  {
    name: "Lieferscheine",
    documentType: "L",
    groupNumber: 1,
    direction: "outbound",
    nextGroupCode: "R01",
  },
  { name: "Rechnungen", documentType: "R", groupNumber: 1, direction: "outbound" },
  {
    name: "Bestellungen",
    documentType: "b",
    groupNumber: 1,
    direction: "inbound",
    nextGroupCode: "l01",
  },
  {
    name: "WE-Lieferscheine",
    documentType: "l",
    groupNumber: 1,
    direction: "inbound",
    nextGroupCode: "r01",
  },
  { name: "WE-Rechnungen", documentType: "r", groupNumber: 1, direction: "inbound" },
  { name: "Gutschriften", documentType: "G", groupNumber: 1, direction: "outbound" },
  { name: "WE-Gutschriften", documentType: "g", groupNumber: 1, direction: "inbound" },
  { name: "Inventuren", documentType: "V", groupNumber: 1 },
  { name: "Zubuchungen", documentType: "Z", groupNumber: 1 },
  { name: "Entnahmen", documentType: "E", groupNumber: 1 },
  { name: "Umlagerungen", documentType: "U", groupNumber: 1 },
  { name: "Produktionsaufträge", documentType: "q", groupNumber: 1, direction: "inbound" },
  { name: "Produktionsbuchungen", documentType: "p", groupNumber: 1, direction: "outbound" },
];

const NUMBER_SEQUENCES: NumberSequenceDef[] = [
  { prefix: "ANG-", documentType: "N", padding: 5 },
  { prefix: "AUF-", documentType: "A", padding: 5 },
  { prefix: "LIS-", documentType: "L", padding: 5 },
  { prefix: "RE-", documentType: "R", padding: 5 },
  { prefix: "BES-", documentType: "b", padding: 5 },
  { prefix: "WEL-", documentType: "l", padding: 5 },
  { prefix: "WER-", documentType: "r", padding: 5 },
  { prefix: "GU-", documentType: "G", padding: 5 },
  { prefix: "WEG-", documentType: "g", padding: 5 },
  { prefix: "INV-", documentType: "V", padding: 5 },
  { prefix: "ZUB-", documentType: "Z", padding: 5 },
  { prefix: "ENT-", documentType: "E", padding: 5 },
  { prefix: "UMB-", documentType: "U", padding: 5 },
  { prefix: "PRO-", documentType: "q", padding: 5 },
  { prefix: "PRB-", documentType: "p", padding: 5 },
];

export async function seedDocumentDefaults(
  sql: SqlClient,
  tenantId: string,
  companyId: string,
): Promise<SeedResult> {
  return sql.begin(async (tx) => {
    await tx.unsafe(`SET LOCAL app.tenant_id = '${tenantId}'`);

    const docTypeIds: Record<string, string> = {};

    for (const dt of DOCUMENT_TYPES) {
      const rows = await tx.unsafe(
        `INSERT INTO document_type (tenant_id, code, name, movement_type, requires_warehouse, requires_cost_center, sort_order, is_active)
         VALUES ($1, $2, $3, $4, $5, $6, $7, true)
         ON CONFLICT (tenant_id, code) DO UPDATE SET name = EXCLUDED.name
         RETURNING document_type_id`,
        [
          tenantId,
          dt.code,
          dt.name,
          dt.movementType,
          dt.requiresWarehouse,
          dt.requiresCostCenter,
          dt.sortOrder,
        ],
      );
      docTypeIds[dt.code] = (rows[0] as Record<string, unknown>).document_type_id as string;
    }

    await updateDocumentTypeLinks(tx, tenantId, docTypeIds);

    const docGroupIds: Record<string, string> = {};

    for (const dg of DOCUMENT_GROUPS) {
      const rows = await tx.unsafe(
        `INSERT INTO document_group (tenant_id, company_id, name, document_type, group_number, direction, is_active, sort_order)
         VALUES ($1, $2, $3, $4, $5, $6, true, 0)
         ON CONFLICT (tenant_id, document_type, group_number) DO UPDATE SET name = EXCLUDED.name
         RETURNING document_group_id`,
        [tenantId, companyId, dg.name, dg.documentType, dg.groupNumber, dg.direction ?? null],
      );
      docGroupIds[`${dg.documentType}_${dg.groupNumber}`] = (rows[0] as Record<string, unknown>)
        .document_group_id as string;
    }

    await updateDocumentGroupLinks(tx, tenantId, docGroupIds);

    for (const ns of NUMBER_SEQUENCES) {
      await tx.unsafe(
        `INSERT INTO number_sequence (tenant_id, company_id, prefix, document_type, next_value, padding)
         VALUES ($1, $2, $3, $4, 1, $5)
         ON CONFLICT (tenant_id, company_id, document_type) DO UPDATE SET prefix = EXCLUDED.prefix`,
        [tenantId, companyId, ns.prefix, ns.documentType, ns.padding],
      );
    }

    return {
      success: true,
      documentTypesCreated: DOCUMENT_TYPES.length,
      documentGroupsCreated: DOCUMENT_GROUPS.length,
      numberSequencesCreated: NUMBER_SEQUENCES.length,
    };
  });
}

async function updateDocumentTypeLinks(
  tx: SqlClient,
  tenantId: string,
  ids: Record<string, string>,
): Promise<void> {
  const types = await tx.unsafe(
    `SELECT code, next_document_type_id FROM document_type WHERE tenant_id = $1`,
    [tenantId],
  );

  for (const t of types as Record<string, unknown>[]) {
    const code = t.code as string;
    const nextCode = DOCUMENT_TYPES.find((dt) => dt.code === code)?.nextCode;
    if (nextCode && ids[nextCode]) {
      await tx.unsafe(
        `UPDATE document_type SET next_document_type_id = $1 WHERE tenant_id = $2 AND code = $3`,
        [ids[nextCode], tenantId, code],
      );
    }
  }
}

async function updateDocumentGroupLinks(
  tx: SqlClient,
  tenantId: string,
  ids: Record<string, string>,
): Promise<void> {
  const groups = await tx.unsafe(
    `SELECT document_type, group_number, next_group_id FROM document_group WHERE tenant_id = $1`,
    [tenantId],
  );

  for (const g of groups as Record<string, unknown>[]) {
    const docType = g.document_type as string;
    const groupNum = g.group_number as number;
    const def = DOCUMENT_GROUPS.find(
      (dg) => dg.documentType === docType && dg.groupNumber === groupNum,
    );
    const nextCode = def?.nextGroupCode;
    if (nextCode) {
      const [nt, gn] = nextCode.split(/(\d+)/).filter(Boolean) as [string, string];
      const key = `${nt}_${parseInt(gn, 10)}`;
      if (ids[key]) {
        await tx.unsafe(
          `UPDATE document_group SET next_group_id = $1 WHERE tenant_id = $2 AND document_type = $3 AND group_number = $4`,
          [ids[key], tenantId, docType, groupNum],
        );
      }
    }
  }
}
