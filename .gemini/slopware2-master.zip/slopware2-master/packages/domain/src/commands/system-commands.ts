import type { LiteLLMConfig } from "../queries/system-queries";
import { LlmConfig } from "../queries/system-queries";
import type { SqlClient } from "../runtime";

export async function saveLlmConfig(
  sql: SqlClient,
  config: LlmConfig,
): Promise<{ success: boolean }> {
  try {
    await sql.unsafe(
      `INSERT INTO system_settings (scope, key, value, updated_at)
       VALUES ('global', 'llm_config', $1, NOW())
       ON CONFLICT (key) WHERE scope = 'global' DO UPDATE SET value = $1, updated_at = NOW()`,
      [JSON.stringify(config)],
    );
    return { success: true };
  } catch (e) {
    console.error("Failed to save LLM config", e);
    return { success: false };
  }
}

export async function saveLiteLLMConfig(
  sql: SqlClient,
  config: LiteLLMConfig,
): Promise<{ success: boolean }> {
  try {
    const keys = [
      { key: "litellm.base_url", value: config.base_url },
      { key: "litellm.api_key", value: config.api_key },
      { key: "litellm.default_model", value: config.default_model },
    ];
    for (const { key, value } of keys) {
      await sql.unsafe(
        `INSERT INTO system_settings (scope, key, value, updated_at)
         VALUES ('global', $1, $2, NOW())
         ON CONFLICT (key) WHERE scope = 'global' DO UPDATE SET value = $2, updated_at = NOW()`,
        [key, JSON.stringify(value)],
      );
    }
    return { success: true };
  } catch (e) {
    console.error("Failed to save LiteLLM config", e);
    return { success: false };
  }
}
