import type { SqlClient } from "../runtime";

export interface XrechnungValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

const REQUIRED_FIELDS = [
  "invoiceNumber",
  "invoiceDate",
  "sellerName",
  "buyerName",
  "currency",
  "totalNet",
  "totalGross",
];

const LOCKED_SOURCE_FIELDS = [
  "invoiceNumber",
  "invoiceDate",
  "sellerName",
  "totalNet",
  "totalTax",
  "totalGross",
];

export function validateXrechnungInvoice(data: Record<string, unknown>): XrechnungValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  for (const field of REQUIRED_FIELDS) {
    if (data[field] == null || data[field] === "") {
      errors.push(`Missing required field: ${field}`);
    }
  }

  const totalNet = Number(data.totalNet) || 0;
  const totalGross = Number(data.totalGross) || 0;
  const totalTax = Number(data.totalTax) || 0;

  if (totalNet < 0) {
    errors.push("totalNet must not be negative");
  }

  if (Math.abs(totalNet + totalTax - totalGross) > 0.02) {
    warnings.push(
      `Tax calculation mismatch: net(${totalNet}) + tax(${totalTax}) != gross(${totalGross})`,
    );
  }

  const lines = (data.customAttributes as any)?.sourceLines as
    | Array<Record<string, unknown>>
    | undefined;
  if (!lines || lines.length === 0) {
    warnings.push("No line items found in source invoice");
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

export async function validateXrechnungBatch(
  sql: SqlClient,
  batchId: string,
): Promise<XrechnungValidationResult> {
  const rows = await sql.unsafe<any>(
    `SELECT ir.payload, ir.status, ir.error_detail
     FROM import_row ir
     WHERE ir.batch_id = $1 AND ir.target_entity = 'document'`,
    [batchId],
  );

  const allErrors: string[] = [];
  const allWarnings: string[] = [];

  for (const row of rows) {
    const result = validateXrechnungInvoice(row.payload);
    allErrors.push(...result.errors);
    allWarnings.push(...result.warnings);
  }

  if (allErrors.length > 0) {
    await sql.unsafe(
      `UPDATE import_batch SET status = 'failed', error_summary = $1, processed_at = NOW()
       WHERE batch_id = $2`,
      [{ errors: allErrors, warnings: allWarnings }, batchId],
    );
  } else {
    await sql.unsafe(
      `UPDATE import_batch SET status = 'approved', processed_at = NOW()
       WHERE batch_id = $1`,
      [batchId],
    );
  }

  return {
    valid: allErrors.length === 0,
    errors: allErrors,
    warnings: allWarnings,
  };
}

export { LOCKED_SOURCE_FIELDS };
