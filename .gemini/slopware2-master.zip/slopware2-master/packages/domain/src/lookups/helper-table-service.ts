import type { SqlClient } from "../runtime";

export interface HelperTableInfo {
  tableName: string;
  label: Record<string, string>;
  pkColumn: string;
  displayColumn: string;
  displayIsI18n: boolean;
  codeColumn: string | null;
  isTenantScoped: boolean;
  sortColumn: string;
  valueColumn: string | null;
}

export interface HelperTableItem {
  value: string;
  label: string;
  code?: string;
  meta?: Record<string, unknown>;
}

export interface GetHelperTableItemsOptions {
  limit?: number;
  offset?: number;
  search?: string;
}

export async function listHelperTables(sql: SqlClient): Promise<HelperTableInfo[]> {
  return sql.unsafe(
    "SELECT table_name, label, pk_column, display_column, display_is_i18n, code_column, is_tenant_scoped, sort_column, value_column FROM helper_table_registry ORDER BY table_name",
  ) as Promise<HelperTableInfo[]>;
}

export async function getHelperTableItems(
  sql: SqlClient,
  tableName: string,
  options?: GetHelperTableItemsOptions,
): Promise<HelperTableItem[]> {
  const registry = await sql.unsafe(
    "SELECT pk_column, display_column, display_is_i18n, code_column, sort_column, value_column, is_tenant_scoped FROM helper_table_registry WHERE table_name = $1",
    [tableName],
  );

  if (registry.length === 0) {
    throw new Error(`Helper table '${tableName}' not found in registry`);
  }

  const reg = registry[0] as Record<string, unknown>;
  const pkColumn = String(reg.pk_column);
  const displayColumn = String(reg.display_column);
  const displayIsI18n = Boolean(reg.display_is_i18n);
  const codeColumn = typeof reg.code_column === "string" ? reg.code_column : null;
  const sortColumn = String(reg.sort_column);
  const valueColumn = typeof reg.value_column === "string" ? reg.value_column : null;

  let displayExpr = displayColumn;
  if (displayIsI18n) {
    displayExpr = `(${displayColumn})->>'en'`;
  }

  let selectParts = [`${displayExpr} as label`];
  if (valueColumn) {
    selectParts.push(`${valueColumn} as value`);
  } else {
    selectParts.push(`${pkColumn} as value`);
  }
  if (codeColumn) {
    selectParts.push(`${codeColumn} as code`);
  }

  let query = `SELECT ${selectParts.join(", ")} FROM ${tableName}`;
  const params: unknown[] = [];

  if (options?.search) {
    params.push(`%${options.search}%`);
    query += ` WHERE ${displayColumn} ILIKE $${params.length}`;
  }

  query += ` ORDER BY ${sortColumn}`;

  if (options?.limit) {
    params.push(options.limit);
    query += ` LIMIT $${params.length}`;
  }

  if (options?.offset) {
    params.push(options.offset);
    query += ` OFFSET $${params.length}`;
  }

  return sql.unsafe(query, params) as Promise<HelperTableItem[]>;
}
