import type { SqlClient } from "../runtime";

export interface EffectiveField {
  fieldId: string;
  scope: string;
  organizationId: string | null;
  tenantId: string | null;
  entityName: string;
  fieldName: string;
  fieldType: string;
  isRequired: boolean | null;
  customAttributes: Record<string, unknown> | null;
  label: Record<string, string> | null;
  helpText: Record<string, string> | null;
  isVisible: boolean | null;
  displayOrder: number | null;
  groupId: string | null;
  lookupTable: string | null;
  lookupFilter: Record<string, unknown> | null;
}

export interface EffectiveLayout {
  layoutId: string;
  scope: string;
  organizationId: string | null;
  tenantId: string | null;
  entityName: string;
  layoutKey: string;
  layoutDefinition: Record<string, unknown> | null;
}

export interface EffectiveRule {
  ruleId: string;
  scope: string;
  organizationId: string | null;
  tenantId: string | null;
  entityName: string;
  hookName: string;
  ruleState: string;
  ruleDefinition: Record<string, unknown> | null;
}

export interface EffectiveSetting {
  settingId: string;
  scope: string;
  organizationId: string | null;
  tenantId: string | null;
  key: string;
  value: Record<string, unknown> | string | number | boolean | null;
}

export interface GetEffectiveFieldsOptions {
  entityName: string;
  fieldName?: string;
}

export interface GetEffectiveLayoutOptions {
  entityName: string;
  layoutKey?: string;
}

export interface GetEffectiveRulesOptions {
  entityName: string;
  hookName?: string;
}

export interface GetEffectiveSettingsOptions {
  prefix?: string;
  keys?: string[];
}

export async function getEffectiveFields(
  sql: SqlClient,
  options: GetEffectiveFieldsOptions,
): Promise<EffectiveField[]> {
  const { entityName, fieldName } = options;
  let query =
    'SELECT field_id as "fieldId", scope, organization_id as "organizationId", ' +
    'tenant_id as "tenantId", entity_name as "entityName", field_name as "fieldName", ' +
    'field_type as "fieldType", is_required as "isRequired", custom_attributes as "customAttributes", ' +
    'label, help_text as "helpText", is_visible as "isVisible", display_order as "displayOrder", ' +
    'group_id as "groupId", lookup_table as "lookupTable", lookup_filter as "lookupFilter" ' +
    "FROM effective_fields WHERE entity_name = $1";
  const params: unknown[] = [entityName];

  if (fieldName) {
    params.push(fieldName);
    query += " AND field_name = $2";
  }

  query += " ORDER BY display_order NULLS LAST, field_name";
  return sql.unsafe(query, params) as Promise<EffectiveField[]>;
}

export async function getEffectiveLayout(
  sql: SqlClient,
  options: GetEffectiveLayoutOptions,
): Promise<EffectiveLayout[]> {
  const { entityName, layoutKey } = options;
  let query =
    'SELECT layout_id as "layoutId", scope, organization_id as "organizationId", ' +
    'tenant_id as "tenantId", entity_name as "entityName", layout_key as "layoutKey", ' +
    'layout_definition as "layoutDefinition" FROM effective_layout WHERE entity_name = $1';
  const params: unknown[] = [entityName];

  if (layoutKey) {
    params.push(layoutKey);
    query += " AND layout_key = $2";
  }

  return sql.unsafe(query, params) as Promise<EffectiveLayout[]>;
}

export async function getEffectiveRules(
  sql: SqlClient,
  options: GetEffectiveRulesOptions,
): Promise<EffectiveRule[]> {
  const { entityName, hookName } = options;
  let query =
    'SELECT rule_id as "ruleId", scope, organization_id as "organizationId", ' +
    'tenant_id as "tenantId", entity_name as "entityName", hook_name as "hookName", ' +
    'rule_state as "ruleState", rule_definition as "ruleDefinition" FROM effective_rules WHERE entity_name = $1';
  const params: unknown[] = [entityName];

  if (hookName) {
    params.push(hookName);
    query += " AND hook_name = $2";
  }

  return sql.unsafe(query, params) as Promise<EffectiveRule[]>;
}

export async function getEffectiveSettings(
  sql: SqlClient,
  options?: GetEffectiveSettingsOptions,
): Promise<EffectiveSetting[]> {
  let query =
    'SELECT setting_id as "settingId", scope, organization_id as "organizationId", ' +
    'tenant_id as "tenantId", key, value FROM effective_settings WHERE true';
  const params: unknown[] = [];

  if (options?.prefix) {
    params.push(`${options.prefix}%%`);
    query += ` AND key LIKE $${params.length}`;
  }

  if (options?.keys && options.keys.length > 0) {
    const placeholders = options.keys.map((_, i) => `$${params.length + i + 1}`).join(", ");
    params.push(...options.keys);
    query += ` AND key IN (${placeholders})`;
  }

  query += " ORDER BY key";
  return sql.unsafe(query, params) as Promise<EffectiveSetting[]>;
}
