export * from "./effective-service";
