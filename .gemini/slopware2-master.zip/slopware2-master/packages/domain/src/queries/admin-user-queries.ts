import type { SqlClient } from "../runtime";

export interface AdminUser {
  user_id: string;
  email: string;
  display_name: string | null;
  is_active: boolean;
  role: string;
  created_at: unknown;
  locale: string;
  tenant_count?: number;
}

export interface ListAdminUsersOptions {
  limit?: number;
  offset?: number;
  search?: string;
  role?: string;
  tenantId?: string;
}

export async function listAdminUsers(
  sql: SqlClient,
  options?: ListAdminUsersOptions,
): Promise<{ items: AdminUser[]; total: number; limit: number; offset: number }> {
  const limit = options?.limit ?? 100;
  const offset = options?.offset ?? 0;
  const conditions: string[] = [];
  const params: unknown[] = [];

  if (options?.search) {
    params.push(`%${options.search}%`);
    conditions.push(`(u.email ILIKE $${params.length} OR u.display_name ILIKE $${params.length})`);
  }

  if (options?.role) {
    params.push(options.role);
    conditions.push(`u.role = $${params.length}`);
  }

  if (options?.tenantId) {
    conditions.push(
      `u.user_id = ANY(SELECT user_id FROM user_tenant WHERE tenant_id = $${params.length + 1})`,
    );
    params.push(options.tenantId);
  }

  const whereClause = conditions.length > 0 ? ` WHERE ${conditions.join(" AND ")}` : "";

  const countQuery = `SELECT COUNT(*) as total FROM app_user u${whereClause}`;
  const countRows = await sql.unsafe(countQuery, params);
  const total = Number((countRows[0] as Record<string, unknown>).total);

  const dataParams = [...params];
  const dataQuery = `
    SELECT u.user_id, u.email, u.display_name, u.is_active, u.role, u.created_at, u.locale,
      (SELECT COUNT(*) FROM user_tenant ut WHERE ut.user_id = u.user_id) as tenant_count
    FROM app_user u${whereClause}
    ORDER BY u.user_id ASC
    LIMIT $${dataParams.length + 1} OFFSET $${dataParams.length + 2}
  `;
  dataParams.push(limit, offset);
  const items = (await sql.unsafe(dataQuery, dataParams)) as AdminUser[];

  return { items, total, limit, offset };
}

export async function getAdminUser(sql: SqlClient, userId: string): Promise<AdminUser | null> {
  const rows = (await sql.unsafe(
    `SELECT u.user_id, u.email, u.display_name, u.is_active, u.role, u.created_at, u.locale,
      (SELECT COUNT(*) FROM user_tenant ut WHERE ut.user_id = u.user_id) as tenant_count
    FROM app_user u WHERE u.user_id = $1`,
    [userId],
  )) as AdminUser[];
  return rows[0] ?? null;
}

export async function getUserTenants(
  sql: SqlClient,
  userId: string,
): Promise<Record<string, unknown>[]> {
  return sql.unsafe(
    `SELECT ut.*, t.name as tenant_name, t.slug as tenant_slug, o.name as organization_name
     FROM user_tenant ut
     JOIN tenant t ON ut.tenant_id = t.tenant_id
     JOIN organization o ON t.organization_id = o.organization_id
     WHERE ut.user_id = $1`,
    [userId],
  ) as unknown as Record<string, unknown>[];
}
