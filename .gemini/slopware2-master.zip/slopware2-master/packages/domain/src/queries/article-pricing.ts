import type { SqlClient } from "../runtime";

export interface ArticlePricingParams {
  articleId: string;
  addressId: string;
  documentDate: string;
}

export interface ArticlePricingResult {
  netPrice: string | null;
  taxRate: number | null;
  taxCodeId: string | null;
  taxCode: string | null;
  currencyId: string | null;
  priceListId: string | null;
}

export async function resolveArticlePricing(
  sql: SqlClient,
  params: ArticlePricingParams,
): Promise<ArticlePricingResult> {
  const { articleId, addressId, documentDate } = params;

  const rows = await sql.unsafe<Record<string, unknown>>(
    `SELECT
      pli.price as net_price,
      pli.price_list_id,
      pl.currency_id,
      tc.tax_rate,
      tc.tax_code_id,
      tc.code as tax_code
    FROM address a
    LEFT JOIN price_list_item pli
      ON a.price_list_id = pli.price_list_id
      AND pli.article_id = $1
      AND (pli.valid_from IS NULL OR pli.valid_from <= $2)
      AND (pli.valid_to IS NULL OR pli.valid_to >= $2)
    LEFT JOIN price_list pl ON pli.price_list_id = pl.price_list_id
    LEFT JOIN article ar ON ar.article_id = $1
    LEFT JOIN tax_rule tr
      ON tr.article_tax_class_id = ar.tax_class_id
      AND tr.customer_tax_class_id = a.tax_class_id
      AND tr.country_code = a.country_code
      AND (tr.valid_from IS NULL OR tr.valid_from <= $2)
      AND (tr.valid_to IS NULL OR tr.valid_to >= $2)
    LEFT JOIN tax_code tc ON tr.tax_code_id = tc.tax_code_id
    WHERE a.address_id = $3`,
    [articleId, documentDate, addressId],
  );

  const row = rows[0];
  if (!row) {
    return {
      netPrice: null,
      taxRate: null,
      taxCodeId: null,
      taxCode: null,
      currencyId: null,
      priceListId: null,
    };
  }

  return {
    netPrice: row["net_price"] ? String(row["net_price"]) : null,
    taxRate: row["tax_rate"] ? Number(row["tax_rate"]) : null,
    taxCodeId: (row["tax_code_id"] as string) ?? null,
    taxCode: (row["tax_code"] as string) ?? null,
    currencyId: (row["currency_id"] as string) ?? null,
    priceListId: (row["price_list_id"] as string) ?? null,
  };
}
