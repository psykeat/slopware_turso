import type { SqlClient } from "../runtime";

export interface CustomerDocumentsParams {
  customerId: string;
  limit?: number;
}

export interface CustomerDocumentRow {
  documentId: string;
  documentNo: string;
  documentType: string;
  documentDate: string;
  status: string;
  totalGross: number;
}

export async function getCustomerDocuments(
  sql: SqlClient,
  params: CustomerDocumentsParams,
): Promise<CustomerDocumentRow[]> {
  const { customerId, limit = 10 } = params;

  const rows = await sql.unsafe<Record<string, unknown>>(
    `SELECT
      d.document_id,
      d.document_no,
      d.document_type,
      d.document_date::text as document_date,
      d.status,
      COALESCE(d.total_gross::float, 0) as total_gross
    FROM document d
    WHERE d.customer_id = $1
    ORDER BY d.document_date DESC, d.document_no DESC
    LIMIT $2`,
    [customerId, limit],
  );

  return rows.map((r) => ({
    documentId: (r["document_id"] as string) ?? "",
    documentNo: (r["document_no"] as string) ?? "",
    documentType: (r["document_type"] as string) ?? "",
    documentDate: (r["document_date"] as string) ?? "",
    status: (r["status"] as string) ?? "",
    totalGross: Number(r["total_gross"]) || 0,
  }));
}
