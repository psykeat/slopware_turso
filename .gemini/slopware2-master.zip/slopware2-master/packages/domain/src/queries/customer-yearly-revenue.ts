import type { SqlClient } from "../runtime";

export interface CustomerYearlyRevenueParams {
  customerId: string;
}

export interface CustomerYearlyRevenueRow {
  year: number;
  quantity: number;
  netAmount: number;
}

export async function getCustomerYearlyRevenue(
  sql: SqlClient,
  params: CustomerYearlyRevenueParams,
): Promise<CustomerYearlyRevenueRow[]> {
  const { customerId } = params;

  const rows = await sql.unsafe<Record<string, unknown>>(
    `SELECT
      EXTRACT(YEAR FROM d.document_date)::int as year,
      COALESCE(SUM(dil.quantity::float), 0) as quantity,
      COALESCE(SUM(dil.line_total_net::float), 0) as net_amount
    FROM document d
    JOIN document_line dil ON dil.document_id = d.document_id
    WHERE d.customer_id = $1
      AND d.posted_at IS NOT NULL
      AND d.document_type IN ('R', 'r', 'G', 'g', 'N', 'A')
    GROUP BY EXTRACT(YEAR FROM d.document_date)
    ORDER BY year DESC`,
    [customerId],
  );

  return rows.map((r) => ({
    year: Number(r["year"]) || 0,
    quantity: Number(r["quantity"]) || 0,
    netAmount: Number(r["net_amount"]) || 0,
  }));
}
