import {
  getEntityDescriptor,
  isEntityReadable,
  isFilterAllowed,
  isSortable,
} from "../entities/registry";
import type { SqlClient } from "../runtime";

export interface EntityFilter {
  column: string;
  operator:
    | "="
    | "!="
    | "LIKE"
    | "ILIKE"
    | "NOT_ILIKE"
    | ">"
    | "<"
    | ">="
    | "<="
    | "IN"
    | "NOT_IN"
    | "IS_NULL"
    | "IS_NOT_NULL";
  value?: unknown;
}

export interface ListEntityOptions {
  filters?: EntityFilter[];
  searchQuery?: string;
  searchColumns?: string[];
  limit?: number;
  offset?: number;
  sortBy?: string;
  sortOrder?: "ASC" | "DESC";
}

export interface EntityListResult<T = Record<string, unknown>> {
  items: T[];
  total: number;
  limit: number;
  offset: number;
}

export { isEntityReadable } from "../entities/registry";

export async function listEntity<T = Record<string, unknown>>(
  sql: SqlClient,
  entityName: string,
  options?: ListEntityOptions,
): Promise<EntityListResult<T>> {
  const descriptor = getEntityDescriptor(entityName);

  if (!descriptor) {
    throw new Error(`Entity '${entityName}' is not registered`);
  }

  if (!descriptor.genericRead) {
    throw new Error(`Entity '${entityName}' is not generically readable`);
  }

  const limit = options?.limit ?? 100;
  const offset = options?.offset ?? 0;

  let whereClause = "";
  const params: unknown[] = [];
  const conditions: string[] = [];

  if (options?.filters && options.filters.length > 0) {
    for (const f of options.filters) {
      if (!isFilterAllowed(entityName, f.column)) {
        throw new Error(`Filter on '${f.column}' is not allowed for entity '${entityName}'`);
      }
    }

    for (const f of options.filters) {
      if (f.operator === "IS_NULL") {
        conditions.push(`(${f.column} IS NULL)`);
      } else if (f.operator === "IS_NOT_NULL") {
        conditions.push(`(${f.column} IS NOT NULL)`);
      } else if (f.operator === "IN") {
        params.push(f.value);
        conditions.push(`(${f.column}::text = ANY($${params.length}::text[]))`);
      } else if (f.operator === "NOT_IN") {
        params.push(f.value);
        conditions.push(`(${f.column}::text != ALL($${params.length}::text[]))`);
      } else if (f.operator === "NOT_ILIKE") {
        params.push(f.value);
        const col =
          f.column === "custom_attributes" || f.column.includes("->")
            ? `${f.column}::text`
            : f.column;
        conditions.push(`(${col} NOT ILIKE $${params.length})`);
      } else if (f.operator === "LIKE" || f.operator === "ILIKE") {
        params.push(f.value);
        const col =
          f.column === "custom_attributes" || f.column.includes("->")
            ? `${f.column}::text`
            : f.column;
        conditions.push(`(${col} ${f.operator} $${params.length})`);
      } else {
        params.push(f.value);
        conditions.push(`(${f.column} ${f.operator} $${params.length})`);
      }
    }
  }

  if (options?.searchQuery && options.searchColumns && options.searchColumns.length > 0) {
    for (const col of options.searchColumns) {
      if (!isFilterAllowed(entityName, col)) {
        throw new Error(`Search on '${col}' is not allowed for entity '${entityName}'`);
      }
    }
    params.push(`%${options.searchQuery}%`);
    const n = params.length;
    const orParts = options.searchColumns.map((col) => `${col}::text ILIKE $${n}`);
    conditions.push(`(${orParts.join(" OR ")})`);
  }

  if (conditions.length > 0) {
    whereClause = ` WHERE ${conditions.join(" AND ")}`;
  }

  const sortBy = options?.sortBy ?? descriptor.defaultSort;
  const sortOrder = options?.sortOrder ?? "ASC";

  if (options?.sortBy && !isSortable(entityName, options.sortBy)) {
    throw new Error(`Sort on '${options.sortBy}' is not allowed for entity '${entityName}'`);
  }

  const countQuery = `SELECT COUNT(*) as total FROM ${descriptor.tableName}${whereClause}`;
  const countRows = await sql.unsafe(countQuery, params);
  const total = Number((countRows[0] as Record<string, unknown>).total);

  const dataParams = [...params];
  const dataQuery = `SELECT * FROM ${descriptor.tableName}${whereClause} ORDER BY ${sortBy} ${sortOrder} LIMIT $${dataParams.length + 1} OFFSET $${dataParams.length + 2}`;
  dataParams.push(limit, offset);

  const items = (await sql.unsafe(dataQuery, dataParams)) as T[];

  return { items, total, limit, offset };
}

export async function getEntityById<T = Record<string, unknown>>(
  sql: SqlClient,
  entityName: string,
  id: string,
): Promise<T | null> {
  const descriptor = getEntityDescriptor(entityName);

  if (!descriptor) {
    throw new Error(`Entity '${entityName}' is not registered`);
  }

  if (!descriptor.genericRead) {
    throw new Error(`Entity '${entityName}' is not generically readable`);
  }

  const rows = await sql.unsafe(
    `SELECT * FROM ${descriptor.tableName} WHERE ${descriptor.idColumn} = $1`,
    [id],
  );
  return (rows[0] as T) ?? null;
}
