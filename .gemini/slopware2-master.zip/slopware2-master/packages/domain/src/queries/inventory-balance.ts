import type { SqlClient } from "../runtime";

export interface InventoryBalanceParams {
  articleId: string;
}

export interface InventoryBalanceRow {
  warehouseId: string;
  warehouseCode: string;
  warehouseName: string;
  onHandQty: number;
  reservedQty: number;
  availableQty: number;
}

export async function getInventoryBalance(
  sql: SqlClient,
  params: InventoryBalanceParams,
): Promise<InventoryBalanceRow[]> {
  const { articleId } = params;

  const rows = await sql.unsafe<Record<string, unknown>>(
    `SELECT
      w.warehouse_id,
      w.code as warehouse_code,
      w.name as warehouse_name,
      COALESCE(ib.on_hand_qty::float, 0) as on_hand_qty,
      COALESCE(ib.reserved_qty::float, 0) as reserved_qty,
      COALESCE(ib.available_qty::float, COALESCE(ib.on_hand_qty::float, 0) - COALESCE(ib.reserved_qty::float, 0)) as available_qty
    FROM warehouse w
    LEFT JOIN inventory_balance ib
      ON ib.warehouse_id = w.warehouse_id
      AND ib.article_id = $1
    WHERE w.is_active = true
    ORDER BY w.code`,
    [articleId],
  );

  return rows.map((r) => ({
    warehouseId: (r["warehouse_id"] as string) ?? "",
    warehouseCode: (r["warehouse_code"] as string) ?? "",
    warehouseName: (r["warehouse_name"] as string) ?? "",
    onHandQty: Number(r["on_hand_qty"]) || 0,
    reservedQty: Number(r["reserved_qty"]) || 0,
    availableQty: Number(r["available_qty"]) || 0,
  }));
}
