import type { SqlClient } from "../runtime";

export interface LlmConfig {
  endpoint_url: string;
  model: string;
  provider: string;
  api_key: string;
  github_token: string;
  github_repo: string;
  feedback_llm_enabled: boolean;
}

export async function getLlmConfig(sql: SqlClient): Promise<LlmConfig> {
  const rows = await sql.unsafe(
    `SELECT value FROM system_settings WHERE scope = 'global' AND key = 'llm_config' LIMIT 1`,
  );
  if (rows.length === 0) {
    return {
      endpoint_url: "",
      model: "",
      provider: "",
      api_key: "",
      github_token: "",
      github_repo: "",
      feedback_llm_enabled: true,
    };
  }
  const config = (rows[0] as any).value as LlmConfig;
  return {
    ...config,
    feedback_llm_enabled: config.feedback_llm_enabled ?? true,
  };
}

export interface LiteLLMConfig {
  base_url: string;
  api_key: string;
  default_model: string;
}

const LITELLM_KEYS = ["litellm.base_url", "litellm.api_key", "litellm.default_model"] as const;

export async function getLiteLLMConfig(sql: SqlClient): Promise<LiteLLMConfig> {
  const rows = await sql.unsafe(
    `SELECT key, value FROM system_settings WHERE scope = 'global' AND key IN ('litellm.base_url', 'litellm.api_key', 'litellm.default_model')`,
  );
  const config: Partial<LiteLLMConfig> = {};
  for (const row of rows as Array<{ key: string; value: string }>) {
    switch (row.key) {
      case "litellm.base_url":
        config.base_url = String(row.value ?? "");
        break;
      case "litellm.api_key":
        config.api_key = String(row.value ?? "");
        break;
      case "litellm.default_model":
        config.default_model = String(row.value ?? "");
        break;
    }
  }
  return {
    base_url: config.base_url ?? "",
    api_key: config.api_key ?? "",
    default_model: config.default_model ?? "",
  };
}
