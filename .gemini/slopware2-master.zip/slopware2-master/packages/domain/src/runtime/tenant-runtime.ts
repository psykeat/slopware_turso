import postgres from "postgres";

const SYSTEM_ORG_ID = "00000000-0000-0000-0000-000000000001";
const BASE_TENANT_ID = "00000000-0000-0000-0000-000000000002";

export { SYSTEM_ORG_ID, BASE_TENANT_ID };

export interface SqlClient {
  <T = unknown>(query: TemplateStringsArray, ...params: unknown[]): Promise<T[]>;
  unsafe<T = unknown>(query: string, params?: unknown[]): Promise<T[]>;
  begin<T>(cb: (tx: SqlClient) => Promise<T>): Promise<T>;
  end(): Promise<void>;
}

export function createSqlClient(config?: {
  host?: string;
  port?: number;
  user?: string;
  password?: string;
  database?: string;
  max?: number;
}): SqlClient {
  const host = config?.host ?? process.env.TEST_DB_HOST ?? process.env.DB_HOST ?? "localhost";
  const port = config?.port ?? Number(process.env.TEST_DB_PORT ?? process.env.DB_PORT ?? 5432);
  const user = config?.user ?? process.env.TEST_DB_USER ?? process.env.DB_USER ?? "app_user";
  const password = config?.password ?? process.env.TEST_DB_PASS ?? process.env.DB_PASS ?? "apppass";
  const database =
    config?.database ?? process.env.TEST_DB_NAME ?? process.env.DB_NAME ?? "slopware_test";
  const max = config?.max ?? 10;

  return postgres({
    host,
    port,
    user,
    password,
    database,
    max,
  }) as unknown as SqlClient;
}

export interface TenantContext {
  tenantId: string;
  organizationId?: string;
}

export async function withTenant<T>(
  sql: SqlClient,
  tenantId: string,
  fn: (ctx: TenantContext, tx: SqlClient) => Promise<T>,
): Promise<T> {
  return sql.begin(async (tx) => {
    await tx.unsafe(`SET LOCAL app.tenant_id = '${tenantId}'`);
    // Attach tenantId to the tx client for entity services
    (tx as any).tenantId = tenantId;

    const orgRows = await tx.unsafe(
      "SELECT organization_id FROM tenant WHERE tenant_id = $1 LIMIT 1",
      [tenantId],
    );
    const organizationId =
      orgRows.length > 0 ? (orgRows[0] as Record<string, unknown>).organization_id : undefined;
    const ctx: TenantContext = { tenantId, organizationId: organizationId as string | undefined };
    return fn(ctx, tx);
  });
}

export async function withSystemContext<T>(
  sql: SqlClient,
  fn: (ctx: TenantContext, tx: SqlClient) => Promise<T>,
): Promise<T> {
  return withTenant(sql, BASE_TENANT_ID, fn);
}

export function validateTenantId(tenantId: unknown): tenantId is string {
  if (typeof tenantId !== "string" || tenantId.length === 0) {
    return false;
  }
  const uuidRe = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return uuidRe.test(tenantId);
}
