import { describe, it, expect, beforeEach } from "vitest";

import { encryptConnectorCredentials, decryptConnectorCredentials } from "../connector-credentials";

const creds = { api_key: "sk-test123", endpoint: "https://api.example.com" };

beforeEach(() => {
  process.env.CREDENTIALS_ENCRYPTION_KEY =
    "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2";
});

describe("connector credentials encryption", () => {
  it("round-trip: encrypt then decrypt returns identical object", async () => {
    const encrypted = await encryptConnectorCredentials(creds);
    expect(encrypted).not.toBe(JSON.stringify(creds));
    const decrypted = await decryptConnectorCredentials(encrypted);
    expect(decrypted).toEqual(creds);
  });
});
