import type { Mock } from "vitest";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

// --- Hoisted mocks: ALL data inline, no external references ---

vi.mock("@repo/db", () => {
  const mockData = [
    { scriptPath: "test-connector.ts", tenantId: "tenant-123", atomicityMode: "run" },
  ];
  const insertData = [{ batchId: "new-batch-id" }];
  // chainFn: returns this (for chaining), is thenable (for await)
  const chainFn = vi.fn().mockReturnThis();
  (chainFn as any).then = (onfulfilled: (v: unknown) => unknown) =>
    Promise.resolve(mockData).then(onfulfilled);
  (chainFn as any).from = chainFn;
  (chainFn as any).innerJoin = chainFn;
  (chainFn as any).where = chainFn;
  (chainFn as any).limit = chainFn;
  (chainFn as any).columns = chainFn;
  (chainFn as any).select = chainFn;
  (chainFn as any).values = chainFn;
  (chainFn as any).set = chainFn;
  const returningMock = vi.fn().mockResolvedValue(insertData);
  (chainFn as any).returning = returningMock;
  // Expose for test override
  (globalThis as any).__slopware_chain = chainFn;
  (globalThis as any).__slopware_mock_data = mockData;
  const selectFn = vi.fn().mockReturnValue(chainFn);
  return {
    db: {
      select: selectFn,
      insert: vi.fn().mockReturnValue({
        values: vi.fn().mockReturnValue({ returning: returningMock }),
      }),
      update: vi.fn().mockReturnValue({
        set: vi.fn().mockReturnValue({
          where: vi.fn().mockImplementation(() => ({
            then: (onfulfilled: (v: unknown) => unknown) => Promise.resolve().then(onfulfilled),
          })),
        }),
      }),
    },
  };
});

vi.mock("@repo/db/schema", () => ({
  importBatch: { batchId: "batch_id", status: "status" },
  tenantConnector: {
    tenantConnectorId: "tenant_connector_id",
    tenantId: "tenant_id",
    connectorId: "connector_id",
  },
  connectorDefinition: {
    connectorId: "connector_id",
    scriptPath: "script_path",
    atomicityMode: "atomicity_mode",
  },
}));

const mockProc = {
  stdout: (async function* () {
    yield "stdout-data\n";
  })(),
  stderr: (async function* () {
    yield "stderr-data\n";
  })(),
  exited: Promise.resolve(0),
  kill: vi.fn(),
};

const mockBunSpawn = vi.fn().mockReturnValue(mockProc);
(globalThis as any).Bun = { spawn: mockBunSpawn };

import { runConnector } from "../connector-runner";

const mockData = (globalThis as any).__slopware_mock_data as unknown[];

beforeEach(() => {
  vi.clearAllMocks();
  mockProc.exited = Promise.resolve(0);
  process.env.INTEGRATION_JWT_SECRET = "test-secret-key-for-jwt";
  process.env.CONNECTOR_SCRIPTS_PATH = "./test-scripts";
});

afterEach(() => {
  delete process.env.INTEGRATION_JWT_SECRET;
  delete process.env.CONNECTOR_SCRIPTS_PATH;
});

describe("runConnector", () => {
  it("generates tenant-scoped JWT with correct claims", async () => {
    await runConnector("tc-001");
    const callArgs = (mockBunSpawn as Mock).mock.calls[0];
    const jwt = callArgs[1].env.TENANT_JWT as string;
    // Decode JWT payload (middle segment) to verify claims
    const payload = JSON.parse(Buffer.from(jwt.split(".")[1], "base64").toString());
    expect(payload.tid).toBe("tenant-123");
    expect(payload.aud).toBe("integration-service");
    expect(payload.scopes).toEqual(["staging:write", "staging:read"]);
  });

  it("spawns Bun subprocess with TENANT_JWT env", async () => {
    await runConnector("tc-001");
    const callArgs = (mockBunSpawn as Mock).mock.calls[0];
    expect(callArgs[0]).toEqual(["bun", "run", "./test-scripts/test-connector.ts"]);
    expect(callArgs[1].env.TENANT_JWT).toBeDefined();
    expect(callArgs[1].env.TENANT_JWT).toMatch(/^eyJ/);
  });

  it("sets batch status to validating on success", async () => {
    const result = await runConnector("tc-001");
    expect((result as any).status).toBe("validating");
  });

  it("sets batch status to failed on non-zero exit", async () => {
    mockProc.exited = Promise.resolve(1);
    const result = await runConnector("tc-001");
    expect((result as any).status).toBe("failed");
    expect((result as any).errorSummary).toMatchObject({ reason: "process_error", exitCode: 1 });
  });

  it("hard-kills process after timeout", async () => {
    const delayedExit = new Promise<number>((resolve) => {
      setTimeout(() => resolve(0), 10);
    });
    mockProc.exited = delayedExit;
    const result = await runConnector("tc-001", { timeoutMs: 1 });
    expect(mockProc.kill).toHaveBeenCalledWith("SIGKILL");
    expect((result as any).status).toBe("failed");
    expect((result as any).errorSummary).toMatchObject({ reason: "timeout" });
  });

  it("passes atomicity modes through env to subprocess", async () => {
    await runConnector("tc-001");
    const callArgs = (mockBunSpawn as Mock).mock.calls[0];
    expect(callArgs[1].env.ATOMICITY_MODE).toBe("run");
  });

  it("uses default 5min timeout when not configured", async () => {
    await runConnector("tc-001");
    const callArgs = (mockBunSpawn as Mock).mock.calls[0];
    expect(callArgs[1].env.CONNECTOR_TIMEOUT_MS).toBe("300000");
  });

  it("throws when connector has no script path", async () => {
    mockData.length = 0;
    await expect(runConnector("tc-missing")).rejects.toThrow("Connector script not configured");
    mockData.length = 1;
    mockData[0] = { scriptPath: "test-connector.ts", tenantId: "tenant-123", atomicityMode: "run" };
  });
});
