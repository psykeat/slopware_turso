import { describe, it, expect } from "vitest";

import { encryptCredentials, decryptCredentials } from "../crypto";

const TEST_KEY = "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2";

describe("encryptCredentials / decryptCredentials", () => {
  it("round-trip: encrypt then decrypt returns identical string", async () => {
    const original = '{"username":"test","password":"secret123"}';
    const encrypted = await encryptCredentials(original, TEST_KEY);
    expect(encrypted).not.toBe(original);
    expect(encrypted.length).toBeGreaterThan(0);
    const decrypted = await decryptCredentials(encrypted, TEST_KEY);
    expect(decrypted).toBe(original);
  });

  it("wrong key throws during decrypt", async () => {
    const original = "secret-data";
    const encrypted = await encryptCredentials(original, TEST_KEY);
    const wrongKey = "0000000000000000000000000000000000000000000000000000000000000000";
    await expect(decryptCredentials(encrypted, wrongKey)).rejects.toThrow();
  });

  it("empty key throws during encrypt", async () => {
    await expect(encryptCredentials("data", "")).rejects.toThrow();
  });

  it("short key throws during encrypt", async () => {
    await expect(encryptCredentials("data", "abc123")).rejects.toThrow();
  });

  it("empty ciphertext throws during decrypt", async () => {
    await expect(decryptCredentials("", TEST_KEY)).rejects.toThrow();
  });
});
