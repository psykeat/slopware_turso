import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

const mockConnections: any[] = [];

vi.mock("postgres", () => {
  const createMock = () => {
    const queries: string[] = [];
    const mockFn = vi.fn(async (...args: any[]) => {
      if (typeof args[0] === "string") {
        queries.push(args[0]);
      }
      return [];
    }) as any;

    mockFn.unsafe = vi.fn(async (q: string) => {
      queries.push(q);
      return [];
    });
    mockFn.end = vi.fn(async () => {});
    mockFn.listen = vi.fn((_channel: string, _cb: () => void) => ({
      state: "listening",
      unlisten: async () => {},
    }));
    mockFn.queries = queries;

    mockConnections.push(mockFn);
    return mockFn;
  };

  const postgresFn = createMock as any;
  postgresFn.reset = () => {
    mockConnections.length = 0;
  };
  postgresFn.getConnections = () => mockConnections;

  return { default: postgresFn };
});

import postgres from "postgres";

import { MV_NAMES } from "../mv-names";
import { createMVRefreshListener } from "../mv-refresh-listener";

describe("MVRefreshListener", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    (postgres as any).reset();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe("startup refresh", () => {
    it("refreshes all 8 MVs on start", async () => {
      const listener = createMVRefreshListener();
      await listener.start();

      const connections = (postgres as any).getConnections();
      expect(connections.length).toBe(2);

      const refreshConn = connections[0];
      const refreshCalls = refreshConn.unsafe.mock.calls.map((c: any[]) => c[0]);

      for (const mv of MV_NAMES) {
        expect(refreshCalls).toContain(`REFRESH MATERIALIZED VIEW CONCURRENTLY ${mv}`);
      }

      await listener.stop();
    });
  });

  describe("debounce", () => {
    it("collapses rapid notifications into single refresh", async () => {
      const refreshCalls: number[] = [];
      const listener = createMVRefreshListener({
        onRefreshComplete: (count) => refreshCalls.push(count),
      });

      await listener.start();

      const startupCount = refreshCalls.length;

      const connections = (postgres as any).getConnections();
      const listenConn = connections[1];

      const listenCb = listenConn.listen.mock.calls[0][1];

      listenCb();
      listenCb();
      listenCb();

      expect(refreshCalls.length).toBe(startupCount);

      await vi.advanceTimersByTimeAsync(5000);
      expect(refreshCalls.length).toBe(startupCount + 1);
      expect(refreshCalls[refreshCalls.length - 1]).toBe(8);

      await listener.stop();
    });
  });
});
