import { describe, it, expect } from "vitest";

import { parseXrechnung } from "../connectors/xrechnung-parser";

const SAMPLE_UBL_XML = `<?xml version="1.0" encoding="UTF-8"?>
<rsm:CrossIndustryInvoice xmlns:rsm="urn:uno:unece:uncefact:data:standard:CrossIndustryInvoice:100"
  xmlns:ram="urn:uno:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100"
  xmlns:udt="urn:uno:unece:uncefact:data:standard:UnqualifiedDataType:100">
  <rsm:ExchangedDocumentContext>
    <ram:GuidelineSpecifiedDocumentContextParameter>
      <ram:ID>urn:cen.eu:en16931:2017#compliant:urn:xoev-de:xrechnung:1.0</ram:ID>
    </ram:GuidelineSpecifiedDocumentContextParameter>
  </rsm:ExchangedDocumentContext>
  <rsm:ExchangedDocument>
    <ram:ID>RE-2024-001</ram:ID>
    <ram:TypeCode>380</ram:TypeCode>
    <ram:IssueDate>
      <udt:DayDateTimeDate>2024-01-15</udt:DayDateTimeDate>
    </ram:IssueDate>
  </rsm:ExchangedDocument>
  <rsm:SupplyChainTradeTransaction>
    <ram:IncludedSupplyChainTradeLineItem>
      <ram:AssociatedDocumentLineDocument>
        <ram:LineID>1</ram:LineID>
      </ram:AssociatedDocumentLineDocument>
      <ram:SpecifiedTradeProduct>
        <ram:Name>Test Article A</ram:Name>
      </ram:SpecifiedTradeProduct>
      <ram:SpecifiedLineTradeAgreement>
        <ram:NetPriceProductTradePrice>
          <ram:ChargeAmount>100.00</ram:ChargeAmount>
        </ram:NetPriceProductTradePrice>
      </ram:SpecifiedLineTradeAgreement>
      <ram:SpecifiedLineTradeDelivery>
        <ram:BilledQuantity unitCode="C62">2</ram:BilledQuantity>
      </ram:SpecifiedLineTradeDelivery>
      <ram:SpecifiedLineTradeSettlement>
        <ram:ApplicableTradeTax>
          <ram:RateApplicablePercent>19</ram:RateApplicablePercent>
        </ram:ApplicableTradeTax>
        <ram:SpecifiedTradeSettlementLineMonetarySummation>
          <ram:LineExtensionAmount>200.00</ram:LineExtensionAmount>
        </ram:SpecifiedTradeSettlementLineMonetarySummation>
      </ram:SpecifiedLineTradeSettlement>
    </ram:IncludedSupplyChainTradeLineItem>
  </rsm:SupplyChainTradeTransaction>
</rsm:CrossIndustryInvoice>`;

const SAMPLE_UBL_INVOICE_XML = `<?xml version="1.0" encoding="UTF-8"?>
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
  xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
  xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2">
  <cbc:ID>INV-2024-001</cbc:ID>
  <cbc:IssueDate>2024-03-01</cbc:IssueDate>
  <cbc:DocumentCurrencyId>EUR</cbc:DocumentCurrencyId>
  <cac:AccountingSupplierParty>
    <cac:Party>
      <cac:PartyName>
        <cbc:PartyName>Muster Lieferant GmbH</cbc:PartyName>
      </cac:PartyName>
      <cac:PostalAddress>
        <cbc:StreetName>Lieferantenstr. 1</cbc:StreetName>
        <cbc:CityName>Berlin</cbc:CityName>
        <cbc:PostalZone>
          <cbc:Identification>10115</cbc:Identification>
        </cbc:PostalZone>
        <cac:Country>
          <cbc:IdentificationCode>DE</cbc:IdentificationCode>
        </cac:Country>
      </cac:PostalAddress>
    </cac:Party>
  </cac:AccountingSupplierParty>
  <cac:AccountingCustomerParty>
    <cac:Party>
      <cac:PartyName>
        <cbc:PartyName>Kunde AG</cbc:PartyName>
      </cac:PartyName>
      <cac:PostalAddress>
        <cbc:StreetName>Kundenweg 2</cbc:StreetName>
        <cbc:CityName>München</cbc:CityName>
        <cbc:PostalZone>
          <cbc:Identification>80331</cbc:Identification>
        </cbc:PostalZone>
        <cac:Country>
          <cbc:IdentificationCode>DE</cbc:IdentificationCode>
        </cac:Country>
      </cac:PostalAddress>
    </cac:Party>
  </cac:AccountingCustomerParty>
  <cac:TaxTotal>
    <cbc:TaxAmount currencyID="EUR">38.00</cbc:TaxAmount>
    <cac:TaxSubtotal>
      <cbc:TaxableAmount currencyID="EUR">200.00</cbc:TaxableAmount>
      <cbc:TaxAmount currencyID="EUR">38.00</cbc:TaxAmount>
      <cac:TaxCategory>
        <cbc:PercentRate>19</cbc:PercentRate>
      </cac:TaxCategory>
    </cac:TaxSubtotal>
  </cac:TaxTotal>
  <cac:LegalMonetaryTotal>
    <cbc:LineExtensionAmount currencyID="EUR">200.00</cbc:LineExtensionAmount>
    <cbc:TaxInclusiveAmount currencyID="EUR">238.00</cbc:TaxInclusiveAmount>
  </cac:LegalMonetaryTotal>
  <cac:InvoiceLine>
    <cbc:ID>1</cbc:ID>
    <cbc:InvoicedQuantity unitCode="C62">2</cbc:InvoicedQuantity>
    <cbc:LineExtensionAmount currencyID="EUR">200.00</cbc:LineExtensionAmount>
    <cac:OrderLineReference>
      <cbc:LineID>1</cbc:LineID>
    </cac:OrderLineReference>
    <cac:Item>
      <cbc:Name>Widget Pro</cbc:Name>
    </cac:Item>
    <cac:Price>
      <cbc:PriceAmount currencyID="EUR">100.00</cbc:PriceAmount>
    </cac:Price>
  </cac:InvoiceLine>
</Invoice>`;

describe("parseXrechnung", () => {
  it("detects CII format from CrossIndustryDocument", () => {
    const inv = parseXrechnung(SAMPLE_UBL_XML);
    expect(inv.invoiceNumber).toBe("RE-2024-001");
  });

  it("parses UBL Invoice format correctly", () => {
    const inv = parseXrechnung(SAMPLE_UBL_INVOICE_XML);
    expect(inv.invoiceNumber).toBe("INV-2024-001");
    expect(inv.invoiceDate).toBe("2024-03-01");
    expect(inv.sellerName).toBe("Muster Lieferant GmbH");
    expect(inv.buyerName).toBe("Kunde AG");
    expect(inv.currency).toBe("EUR");
    expect(inv.totalNet).toBe(200);
    expect(inv.totalTax).toBe(38);
    expect(inv.totalGross).toBe(238);
  });

  it("parses invoice lines from UBL", () => {
    const inv = parseXrechnung(SAMPLE_UBL_INVOICE_XML);
    expect(inv.lines).toHaveLength(1);
    expect(inv.lines[0].productName).toBe("Widget Pro");
    expect(inv.lines[0].quantity).toBe(2);
    expect(inv.lines[0].netPrice).toBe(100);
    expect(inv.lines[0].lineTotalNet).toBe(200);
  });

  it("parses tax breakdown from UBL", () => {
    const inv = parseXrechnung(SAMPLE_UBL_INVOICE_XML);
    expect(inv.taxBreakdown).toHaveLength(1);
    expect(inv.taxBreakdown[0].percentage).toBe(19);
    expect(inv.taxBreakdown[0].taxAmount).toBe(38);
    expect(inv.taxBreakdown[0].taxableAmount).toBe(200);
  });

  it("parses seller address from UBL", () => {
    const inv = parseXrechnung(SAMPLE_UBL_INVOICE_XML);
    expect(inv.sellerAddress?.street).toBe("Lieferantenstr. 1");
    expect(inv.sellerAddress?.city).toBe("Berlin");
    expect(inv.sellerAddress?.postalCode).toBe("10115");
    expect(inv.sellerAddress?.country).toBe("DE");
  });

  it("parses buyer address from UBL", () => {
    const inv = parseXrechnung(SAMPLE_UBL_INVOICE_XML);
    expect(inv.buyerAddress?.street).toBe("Kundenweg 2");
    expect(inv.buyerAddress?.city).toBe("München");
    expect(inv.buyerAddress?.postalCode).toBe("80331");
    expect(inv.buyerAddress?.country).toBe("DE");
  });
});
