import { encryptCredentials, decryptCredentials } from "./crypto";

export async function encryptConnectorCredentials(
  credentials: Record<string, unknown>,
): Promise<string> {
  const key = process.env.CREDENTIALS_ENCRYPTION_KEY || "";
  return encryptCredentials(JSON.stringify(credentials), key);
}

export async function decryptConnectorCredentials(
  ciphertext: string,
): Promise<Record<string, unknown>> {
  const key = process.env.CREDENTIALS_ENCRYPTION_KEY || "";
  const plaintext = await decryptCredentials(ciphertext, key);
  return JSON.parse(plaintext);
}
