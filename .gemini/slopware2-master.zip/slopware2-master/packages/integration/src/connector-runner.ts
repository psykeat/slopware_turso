import { db } from "@repo/db";
import { importBatch, tenantConnector, connectorDefinition } from "@repo/db/schema";
import { eq } from "drizzle-orm";

import { createJWT } from "./crypto";

export type ConnectorRunnerConfig = {
  timeoutMs?: number;
  jwtSecret?: string;
  scriptBasePath?: string;
};

export type ConnectorRunResult = {
  batchId: string;
  status: "validating" | "failed";
  stdout: string;
  stderr: string;
  errorSummary?: Record<string, unknown>;
};

const DEFAULT_TIMEOUT_MS = 5 * 60 * 1000;

async function getConnectorScript(
  tenantConnectorId: string,
): Promise<{ scriptPath: string; tenantId: string; atomicityMode: string } | null> {
  const rows = await db
    .select({
      scriptPath: connectorDefinition.scriptPath,
      tenantId: tenantConnector.tenantId,
      atomicityMode: connectorDefinition.atomicityMode,
    })
    .from(tenantConnector)
    .innerJoin(
      connectorDefinition,
      eq(tenantConnector.connectorId, connectorDefinition.connectorId),
    )
    .where(eq(tenantConnector.tenantConnectorId, tenantConnectorId));

  if (!rows.length || !rows[0].scriptPath) {
    return null;
  }
  return {
    scriptPath: rows[0].scriptPath,
    tenantId: rows[0].tenantId,
    atomicityMode: rows[0].atomicityMode,
  };
}

async function createBatchRow(
  tenantConnectorId: string,
  atomicityMode: string,
): Promise<{ batchId: string; tenantId: string }> {
  const connectorRow = await db
    .select({ tenantId: tenantConnector.tenantId })
    .from(tenantConnector)
    .where(eq(tenantConnector.tenantConnectorId, tenantConnectorId))
    .limit(1);

  if (!connectorRow.length) {
    throw new Error(`Tenant connector not found: ${tenantConnectorId}`);
  }

  const [row] = await db
    .insert(importBatch)
    .values({
      tenantId: connectorRow[0].tenantId,
      atomicityMode,
      status: "pending",
    })
    .returning();

  return { batchId: row.batchId, tenantId: connectorRow[0].tenantId };
}

async function generateTenantJWT(tenantId: string, secret: string): Promise<string> {
  return createJWT(
    {
      tid: tenantId,
      aud: "integration-service",
      scopes: ["staging:write", "staging:read"],
    },
    secret,
    "5m",
  );
}

async function updateBatchStatus(
  batchId: string,
  status: string,
  errorSummary?: Record<string, unknown>,
): Promise<void> {
  const updateData: Record<string, unknown> = { status, processedAt: new Date() };
  if (errorSummary) {
    updateData.errorSummary = errorSummary;
  }
  await db.update(importBatch).set(updateData).where(eq(importBatch.batchId, batchId));
}

/**
 * Atomicity modes:
 * - file: each uploaded file is an independent unit; failure rolls back only that file
 * - entity: each target entity record is independent; partial entity creation is allowed
 * - run: all-or-nothing; any single row failure fails the entire batch
 */
export async function runConnector(
  tenantConnectorId: string,
  config: ConnectorRunnerConfig = {},
): Promise<ConnectorRunResult> {
  const timeoutMs = config.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  const jwtSecret = config.jwtSecret ?? process.env.INTEGRATION_JWT_SECRET ?? "";
  const scriptBasePath = config.scriptBasePath ?? process.env.CONNECTOR_SCRIPTS_PATH ?? "./scripts";

  // 1. Resolve connector script
  const connectorInfo = await getConnectorScript(tenantConnectorId);
  if (!connectorInfo) {
    throw new Error(`Connector script not configured for tenant_connector: ${tenantConnectorId}`);
  }

  const { tenantId, atomicityMode } = connectorInfo;
  const scriptPath = `${scriptBasePath}/${connectorInfo.scriptPath}`;

  // 2. Create import_batch row with status 'pending'
  const { batchId } = await createBatchRow(tenantConnectorId, atomicityMode);

  // 3. Generate tenant-scoped JWT
  const signedJwt = await generateTenantJWT(tenantId, jwtSecret);

  // 4. Spawn subprocess
  let stdout = "";
  let stderr = "";

  const proc = Bun.spawn(["bun", "run", scriptPath], {
    env: {
      TENANT_JWT: signedJwt,
      BATCH_ID: batchId,
      TENANT_ID: tenantId,
      ATOMICITY_MODE: atomicityMode,
      CONNECTOR_TIMEOUT_MS: String(timeoutMs),
      ...(process.env.NODE_ENV ? { NODE_ENV: process.env.NODE_ENV } : {}),
    },
    stdout: "pipe",
    stderr: "pipe",
  });

  // Capture stdout
  if (proc.stdout) {
    for await (const chunk of proc.stdout) {
      stdout += chunk;
    }
  }

  // Capture stderr
  if (proc.stderr) {
    for await (const chunk of proc.stderr) {
      stderr += chunk;
    }
  }

  // 5. Enforce timeout with hard-kill
  let timedOut = false;
  const timeoutTimer = setTimeout(() => {
    timedOut = true;
    proc.kill("SIGKILL");
  }, timeoutMs);

  const exitCode = await proc.exited;
  clearTimeout(timeoutTimer);

  // 6. Update batch status
  let resultStatus: "validating" | "failed" = "failed";
  let errorSummary: Record<string, unknown> | undefined;

  if (timedOut) {
    errorSummary = { reason: "timeout", exitCode, timeoutMs };
  } else if (exitCode === 0) {
    resultStatus = "validating";
  } else {
    errorSummary = { reason: "process_error", exitCode, stderr: stderr.slice(0, 2000) };
  }

  await updateBatchStatus(batchId, resultStatus, errorSummary);

  return { batchId, status: resultStatus, stdout, stderr, errorSummary };
}
