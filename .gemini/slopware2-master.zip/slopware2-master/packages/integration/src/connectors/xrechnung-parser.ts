import { XMLParser } from "fast-xml-parser";

export interface XrechnungInvoiceLine {
  lineNo: number;
  productId?: string;
  productName?: string;
  quantity: number;
  unit: string;
  netPrice: number;
  taxPercentage: number;
  taxAmount: number;
  lineTotalNet: number;
  lineTotalGross: number;
}

export interface XrechnungInvoice {
  invoiceNumber: string;
  invoiceDate: string;
  sellerName: string;
  sellerAddress?: Record<string, string>;
  buyerName: string;
  buyerAddress?: Record<string, string>;
  currency: string;
  totalNet: number;
  totalTax: number;
  totalGross: number;
  taxBreakdown: Array<{ percentage: number; taxAmount: number; taxableAmount: number }>;
  lines: XrechnungInvoiceLine[];
  dueDate?: string;
  paymentTerms?: string;
}

const UBL_PARSER = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "@_",
  removeNSPrefix: true,
  trimValues: true,
  isArray: (name) =>
    [
      "InvoiceLine",
      "TaxSubtotal",
      "AllowanceCharge",
      "PaymentMeans",
      "LegalMonetaryTotal",
    ].includes(name),
});

const CII_PARSER = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "@_",
  removeNSPrefix: true,
  trimValues: true,
  isArray: (name) =>
    [
      "Mtsg",
      "Ubd",
      "Gyld",
      "Concpar",
      "Custpar",
      "Sellpar",
      "Expecpar",
      "Lin",
      "Taxcat",
      "Rct",
    ].includes(name),
});

function detectFormat(xml: string): "UBL" | "CII" | "unknown" {
  if (xml.includes("CrossIndustryDocument") || xml.includes("CrossIndustryInvoice")) {
    return "CII";
  }
  if (xml.includes("<Invoice") || xml.includes("rsm:Invoice")) {
    return "UBL";
  }
  return "unknown";
}

function safeNum(v: unknown): number {
  if (v == null || v === "") return 0;
  if (typeof v === "object" && "#text" in v) {
    return safeNum((v as Record<string, unknown>)["#text"]);
  }
  const n = Number(v);
  return isNaN(n) ? 0 : n;
}

function safeStr(v: unknown): string {
  if (v == null || v === "") return "";
  if (typeof v === "object" && "#text" in v) {
    return safeStr((v as Record<string, unknown>)["#text"]);
  }
  return String(v);
}

function getAttr(obj: unknown, key: string): unknown {
  if (obj == null || typeof obj !== "object") return undefined;
  return (obj as Record<string, unknown>)[key];
}

function asArray<T>(v: T | T[] | undefined | null): T[] {
  if (v == null) return [];
  return Array.isArray(v) ? v : [v];
}

export function parseXrechnung(xml: string): XrechnungInvoice {
  const format = detectFormat(xml);
  if (format === "CII") {
    return parseCII(xml);
  }
  return parseUBL(xml);
}

function parseUBL(xml: string): XrechnungInvoice {
  const parsed = UBL_PARSER.parse(xml);
  const header = parsed.Invoice || {};

  const sellerParty = header.AccountingSupplierParty?.Party || {};
  const sellerName = safeStr(sellerParty.PartyName?.PartyName);

  const buyerParty = header.AccountingCustomerParty?.Party || {};
  const buyerName = safeStr(buyerParty.PartyName?.PartyName);

  const payment = header.PaymentMeans || [];
  const payMeans = Array.isArray(payment) ? payment[0] : payment;
  const dueDate = safeStr(payMeans?.PaidAmountDueDate) || safeStr(header.PaymentDueDate);

  const legalTotals = header.LegalMonetaryTotal || [];
  const legalTotal = Array.isArray(legalTotals) ? legalTotals[0] : legalTotals;

  const taxSubtotals = header.TaxTotal || [];
  const taxTotal = Array.isArray(taxSubtotals) ? taxSubtotals[0] : taxSubtotals;

  const taxBreakdown: XrechnungInvoice["taxBreakdown"] = [];
  for (const tc of asArray(taxTotal?.TaxSubtotal)) {
    for (const cat of asArray((tc as any)?.TaxCategory)) {
      taxBreakdown.push({
        percentage: safeNum((cat as any)?.PercentRate),
        taxAmount: safeNum((tc as any)?.TaxAmount),
        taxableAmount: safeNum((tc as any)?.TaxableAmount),
      });
    }
  }

  const lines: XrechnungInvoiceLine[] = asArray(header.InvoiceLine).map(
    (line: any, idx: number) => {
      const id = line.InvoicePeriod?.InvoiceLineNo || idx + 1;
      const item = line.Item?.Name || "";
      const qty = safeNum(line.InvoicedQuantity);
      const unit = safeStr(getAttr(line.InvoicedQuantity, "@_unitCode")) || "C62";
      const price = safeNum(line.Price?.PriceAmount);
      const lineTax = safeNum(line.LineExtensionAmount);
      const taxPct = safeNum(asArray(line.TaxTotal)[0]?.TaxSubtotal?.TaxCategory?.PercentRate);
      return {
        lineNo: typeof id === "number" ? id : safeNum(id),
        productName: safeStr(item),
        quantity: qty,
        unit,
        netPrice: price,
        taxPercentage: taxPct,
        taxAmount: lineTax * (taxPct / 100),
        lineTotalNet: lineTax,
        lineTotalGross: lineTax * (1 + taxPct / 100),
      };
    },
  );

  return {
    invoiceNumber: safeStr(header.ID),
    invoiceDate: safeStr(header.IssueDate),
    sellerName,
    sellerAddress: parseUBLAddress(sellerParty.PostalAddress || {}),
    buyerName,
    buyerAddress: parseUBLAddress(buyerParty.PostalAddress || {}),
    currency:
      safeStr(getAttr(header.DocumentCurrency, "@_ID")) ||
      safeStr(header.DocumentCurrency) ||
      "EUR",
    totalNet: safeNum(legalTotal?.LineExtensionAmount),
    totalTax: safeNum(taxTotal?.TaxAmount),
    totalGross: safeNum(legalTotal?.TaxInclusiveAmount),
    taxBreakdown,
    lines,
    dueDate: dueDate || undefined,
  };
}

function parseUBLAddress(addr: any): Record<string, string> {
  if (!addr) return {};
  return {
    street: safeStr(addr.StreetName),
    city: safeStr(addr.CityName),
    postalCode: safeStr(addr.PostalZone?.Identification) || safeStr(addr.PostalZone),
    country:
      safeStr(addr.Country?.IdentificationCode) || safeStr(addr.Country?.Identification) || "",
  };
}

function parseCII(xml: string): XrechnungInvoice {
  const parsed = CII_PARSER.parse(xml);
  const root =
    parsed.CrossIndustryInvoice ||
    parsed.CrossIndustryDocument ||
    parsed["rsm:CrossIndustryInvoice"] ||
    {};
  const header = root.ExchangedDocument || {};
  const parties = root.ExchangedDocumentContext || {};
  const seller = (parties.Sellpar || [{}])[0] || {};
  const buyer = (parties.Buypar || [{}])[0] || {};

  const linesRaw = root.LogicalMonetaryRecord?.Lin || root.Lin || [];
  const lines: XrechnungInvoiceLine[] = (Array.isArray(linesRaw) ? linesRaw : [linesRaw]).map(
    (line: any, idx: number) => {
      const specLine = line.SpecifiedTradeProduct || {};
      const qty = safeNum(line.QuantifiedDutyCharge?.Value);
      const price = safeNum(line.AppliedAmount?.AmountMeasure);
      return {
        lineNo: idx + 1,
        productName: safeStr(specLine?.Name),
        quantity: qty || safeNum(line.BilledQuantity?.QuantityMeasure),
        unit: safeStr(getAttr(line.BilledQuantity, "@_unitCode")) || "C62",
        netPrice: price,
        taxPercentage: 0,
        taxAmount: 0,
        lineTotalNet: price * (qty || 1),
        lineTotalGross: price * (qty || 1),
      };
    },
  );

  const sellerAddr = (seller.Name || [{}])[0] || {};
  const buyerAddr = (buyer.Name || [{}])[0] || {};

  return {
    invoiceNumber: safeStr(header.ID),
    invoiceDate:
      safeStr(header.IssueDate?.DayDateTimeDate) ||
      safeStr(header.IssueDate) ||
      safeStr(header.EffectiveDate),
    sellerName: safeStr(sellerAddr?.Name),
    sellerAddress: {},
    buyerName: safeStr(buyerAddr?.Name),
    buyerAddress: {},
    currency: "EUR",
    totalNet: 0,
    totalTax: 0,
    totalGross: 0,
    taxBreakdown: [],
    lines,
  };
}
