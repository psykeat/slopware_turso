import path from "path";

import { parseXrechnung } from "./xrechnung-parser";

type ImportRowPayload = {
  target_entity: string;
  payload: Record<string, unknown>;
};

type ConnectorEnv = {
  TENANT_JWT: string;
  BATCH_ID: string;
  TENANT_ID: string;
  ATOMICITY_MODE: string;
  CONNECTOR_TIMEOUT_MS: string;
  XRECHNUNG_INPUT_DIR?: string;
};

function getEnv(key: string): string {
  const val = process.env[key];
  if (!val) throw new Error(`Required env ${key} not set`);
  return val;
}

async function readInputFiles(): Promise<Array<{ filename: string; xml: string }>> {
  const inputDir = process.env.XRECHNUNG_INPUT_DIR || "./input";
  const glob = new Bun.Glob(`${inputDir}/**/*.xml`);
  const filePaths: string[] = [];
  for await (const f of glob.scan()) {
    filePaths.push(f);
  }
  const results: Array<{ filename: string; xml: string }> = [];
  for (const f of filePaths) {
    const xml = await Bun.file(f).text();
    results.push({ filename: path.basename(f), xml });
  }
  return results;
}

function mapToImportPayload(
  inv: ReturnType<typeof parseXrechnung>,
  filename: string,
): ImportRowPayload {
  return {
    target_entity: "document",
    payload: {
      companyId: "",
      documentType: "r",
      documentDirection: "inbound",
      documentDate: inv.invoiceDate,
      currencyId: inv.currency,
      totalNet: inv.totalNet,
      totalTax: inv.totalTax,
      totalGross: inv.totalGross,
      customAttributes: {
        sourceInvoiceNumber: inv.invoiceNumber,
        sourceFilename: filename,
        sellerName: inv.sellerName,
        buyerName: inv.buyerName,
        sourceDueDate: inv.dueDate,
        taxBreakdown: inv.taxBreakdown,
        sourceLines: inv.lines,
      },
      billingAddress: inv.sellerAddress,
      deliveryAddress: inv.buyerAddress,
    },
  };
}

async function postImportRow(payload: ImportRowPayload, env: ConnectorEnv): Promise<void> {
  const baseUrl = process.env.API_BASE_URL || "http://localhost:3000";
  const res = await fetch(`${baseUrl}/api/import-row`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${env.TENANT_JWT}`,
    },
    body: JSON.stringify({
      batchId: env.BATCH_ID,
      targetEntity: payload.target_entity,
      payload: payload.payload,
    }),
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Import row POST failed: ${res.status} ${err}`);
  }
}

async function main(): Promise<void> {
  const env: ConnectorEnv = {
    TENANT_JWT: getEnv("TENANT_JWT"),
    BATCH_ID: getEnv("BATCH_ID"),
    TENANT_ID: getEnv("TENANT_ID"),
    ATOMICITY_MODE: getEnv("ATOMICITY_MODE"),
    CONNECTOR_TIMEOUT_MS: getEnv("CONNECTOR_TIMEOUT_MS"),
    XRECHNUNG_INPUT_DIR: process.env.XRECHNUNG_INPUT_DIR,
  };

  console.log(`[xrechnung] Starting batch ${env.BATCH_ID}`);

  const files = await readInputFiles();
  if (files.length === 0) {
    console.log("[xrechnung] No input files found");
    return;
  }

  let errorCount = 0;
  for (const { filename, xml } of files) {
    try {
      const invoice = parseXrechnung(xml);
      const payload = mapToImportPayload(invoice, filename);
      await postImportRow(payload, env);
      console.log(`[xrechnung] Parsed: ${filename} -> ${invoice.invoiceNumber}`);
    } catch (err) {
      errorCount++;
      console.error(`[xrechnung] Error parsing ${filename}: ${String(err)}`);
    }
  }

  if (errorCount > 0 && env.ATOMICITY_MODE === "run") {
    console.error(`[xrechnung] ${errorCount} errors in run-mode — aborting`);
    process.exit(1);
  }

  console.log(`[xrechnung] Done. ${files.length - errorCount}/${files.length} files processed.`);
}

main().catch((err) => {
  console.error("[xrechnung] Fatal:", err);
  process.exit(1);
});
