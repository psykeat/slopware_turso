import { SignJWT } from "jose";

export async function createJWT(
  payload: Record<string, unknown>,
  secret: string,
  expiresIn = "1h",
) {
  const jwt = new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setExpirationTime(expiresIn);
  return jwt.sign(new TextEncoder().encode(secret));
}

function hexToBuffer(hex: string): ArrayBuffer {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) {
    bytes[i / 2] = parseInt(hex.substring(i, i + 2), 16);
  }
  return bytes.buffer;
}

function bufferToHex(buffer: ArrayBuffer): string {
  return Array.from(new Uint8Array(buffer))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export function encryptCredentials(data: string, key: string): Promise<string> {
  if (!key || key.length < 64) {
    return Promise.reject(new Error("Encryption key must be at least 32 bytes (64 hex chars)"));
  }
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const keyBuffer = hexToBuffer(key);

  return crypto.subtle
    .importKey("raw", keyBuffer, { name: "AES-GCM" }, false, ["encrypt"])
    .then((cryptoKey) =>
      crypto.subtle
        .encrypt({ name: "AES-GCM", iv }, cryptoKey, new TextEncoder().encode(data))
        .then((encrypted) => {
          const result = new Uint8Array(iv.length + encrypted.byteLength);
          result.set(iv, 0);
          result.set(new Uint8Array(encrypted), iv.length);
          return bufferToHex(result.buffer);
        }),
    );
}

export function decryptCredentials(ciphertext: string, key: string): Promise<string> {
  if (!key || key.length < 64) {
    return Promise.reject(new Error("Encryption key must be at least 32 bytes (64 hex chars)"));
  }
  if (!ciphertext || ciphertext.length < 60) {
    return Promise.reject(new Error("Invalid ciphertext"));
  }

  const keyBuffer = hexToBuffer(key);
  const data = hexToBuffer(ciphertext);
  const iv = data.slice(0, 12);
  const encrypted = data.slice(12);

  return crypto.subtle
    .importKey("raw", keyBuffer, { name: "AES-GCM" }, false, ["decrypt"])
    .then((cryptoKey) =>
      crypto.subtle
        .decrypt({ name: "AES-GCM", iv }, cryptoKey, encrypted)
        .then((decrypted) => new TextDecoder().decode(decrypted)),
    );
}
