export const integrationService = {
  name: "slopware-integration",
  version: "0.0.0",
};

export { createMVRefreshListener, MVRefreshListener } from "./mv-refresh-listener";
export type { MVListenerEvents } from "./mv-refresh-listener";
export { MV_NAMES } from "./mv-names";
export type { MVNames } from "./mv-names";
export { encryptCredentials, decryptCredentials } from "./crypto";
export { encryptConnectorCredentials, decryptConnectorCredentials } from "./connector-credentials";
export { runConnector } from "./connector-runner";
export type { ConnectorRunnerConfig, ConnectorRunResult } from "./connector-runner";
export { parseXrechnung } from "./connectors/xrechnung-parser";
export type { XrechnungInvoice, XrechnungInvoiceLine } from "./connectors/xrechnung-parser";
