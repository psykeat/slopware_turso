const MV_NAMES = [
  "mv_sales_period",
  "mv_sales_period_customer",
  "mv_sales_period_article",
  "mv_sales_period_article_group",
  "mv_sales_period_address_category",
  "mv_purchase_period",
  "mv_purchase_period_supplier",
  "mv_purchase_period_article",
] as const;

export type MVNames = (typeof MV_NAMES)[number];

export { MV_NAMES };
