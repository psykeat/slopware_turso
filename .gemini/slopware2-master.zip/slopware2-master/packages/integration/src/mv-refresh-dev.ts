import { createMVRefreshListener } from "./mv-refresh-listener";

const listener = createMVRefreshListener({
  onRefreshStart: () => console.log("[MV-Listener] Refreshing MVs..."),
  onRefreshComplete: (count) => console.log(`[MV-Listener] Refreshed ${count} MVs`),
  onError: (err) => console.error("[MV-Listener] Refresh error:", err.message),
});

process.on("SIGINT", async () => {
  await listener.stop();
  process.exit(0);
});

process.on("SIGTERM", async () => {
  await listener.stop();
  process.exit(0);
});

listener.start().catch((err) => {
  console.error("[MV-Listener] Failed to start:", err);
  process.exit(1);
});
