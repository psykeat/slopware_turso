import postgres from "postgres";

import { MV_NAMES } from "./mv-names";

const DEBOUNCE_MS = Number(process.env.MV_DEBOUNCE_MS ?? 5000);
const DATABASE_URL =
  process.env.DATABASE_URL || "postgresql://postgres:bvh9j35v@localhost:5432/slopware2";

export interface MVListenerEvents {
  onRefreshStart?: () => void;
  onRefreshComplete?: (count: number) => void;
  onError?: (error: Error) => void;
}

export class MVRefreshListener {
  private listenConn: ReturnType<typeof postgres> | null = null;
  private refreshConn: ReturnType<typeof postgres> | null = null;
  private debounceTimer: ReturnType<typeof setTimeout> | null = null;
  private isRefreshing = false;
  private isRunning = false;
  private events?: MVListenerEvents;

  constructor(events?: MVListenerEvents) {
    this.events = events;
  }

  private async connectWithRetry(
    label: string,
    opts?: Parameters<typeof postgres>[1],
  ): Promise<ReturnType<typeof postgres>> {
    let delay = 1000;
    while (true) {
      try {
        const conn = postgres(DATABASE_URL, { max: 1, ...opts });
        await conn`SELECT 1`;
        console.log(`[MV-Listener] ${label} connected`);
        return conn;
      } catch {
        if (delay > 30000) throw new Error("DB unavailable after retries");
        console.warn(`[MV-Listener] ${label} retry in ${delay}ms...`);
        await new Promise((r) => setTimeout(r, delay));
        delay *= 2;
      }
    }
  }

  private async refreshAllMVs(): Promise<void> {
    if (this.isRefreshing) return;
    this.isRefreshing = true;
    this.events?.onRefreshStart?.();

    const conn = this.refreshConn;
    if (!conn) {
      this.isRefreshing = false;
      return;
    }

    let count = 0;
    try {
      for (const mv of MV_NAMES) {
        await conn.unsafe(`REFRESH MATERIALIZED VIEW CONCURRENTLY ${mv}`);
        count++;
      }
      this.events?.onRefreshComplete?.(count);
    } catch (error) {
      this.events?.onError?.(error instanceof Error ? error : new Error(String(error)));
    } finally {
      this.isRefreshing = false;
    }
  }

  async start(): Promise<void> {
    if (this.isRunning) return;
    this.isRunning = true;

    this.refreshConn = await this.connectWithRetry("Refresh");
    this.listenConn = await this.connectWithRetry("Listen");

    console.log("[MV-Listener] Startup refresh...");
    await this.refreshAllMVs();
    console.log("[MV-Listener] Startup refresh complete");

    this.listenConn!.listen("stats_refresh", () => {
      this.handleNotification();
    });
    console.log("[MV-Listener] Listening on stats_refresh");
  }

  private handleNotification(): void {
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
    }
    this.debounceTimer = setTimeout(() => {
      this.debounceTimer = null;
      this.refreshAllMVs();
    }, DEBOUNCE_MS);
  }

  async stop(): Promise<void> {
    this.isRunning = false;
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
      this.debounceTimer = null;
    }
    await this.listenConn?.end({ timeout: 2 });
    await this.refreshConn?.end({ timeout: 2 });
    this.listenConn = null;
    this.refreshConn = null;
    console.log("[MV-Listener] Stopped");
  }
}

export function createMVRefreshListener(events?: MVListenerEvents): MVRefreshListener {
  return new MVRefreshListener(events);
}
