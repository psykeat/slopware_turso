import { z } from "zod";

export const WorkspaceSchema = z.object({
  id: z.string(),
  name: z.string(),
  views: z.array(z.string()),
});

export type Workspace = z.infer<typeof WorkspaceSchema>;

export const PaneStateSchema = z.object({
  panes: z.record(z.string(), z.array(z.string())),
});

export type PaneLayoutState = z.infer<typeof PaneStateSchema>;

export const LanguageSchema = z.enum(["en", "de"]);
export type Language = z.infer<typeof LanguageSchema>;

export type SlotName = "s1" | "s2" | "s3";

export type PanelFilter = {
  column: string;
  operator: "=" | "!=" | "LIKE" | "ILIKE" | ">" | "<" | ">=" | "<=" | "IN";
  value: unknown;
};

export type PanelType =
  | "list"
  | "detail"
  | "lines"
  | "tree"
  | "lookup"
  | "kpi"
  | "period-comparison"
  | "document-list";

export type PanelState =
  | {
      type: "list";
      entity: string;
      viewKey?: string;
      params?: {
        filter?: string;
        sort?: string;
        page?: number;
        filters?: PanelFilter[];
      };
    }
  | {
      type: "detail";
      entity: string;
      id: string;
      viewKey?: string;
      params?: {
        mode?: "view" | "edit";
      };
    }
  | {
      type: "lines";
      entity: string;
      parentId: string;
      viewKey?: string;
    }
  | {
      type: "tree";
      entity: string;
      viewKey?: string;
    }
  | {
      type: "lookup";
      entity: string;
      viewKey?: string;
    }
  | {
      type: "kpi";
      entity: string;
    }
  | {
      type: "period-comparison";
      entity: string;
    }
  | {
      type: "document-list";
      entity: string;
      viewKey?: string;
      params?: {
        filter?: string;
        documentType?: string;
        documentGroupId?: string;
      };
    };

export type PaneMode = "single" | "split-2" | "split-3";

export interface WorkspaceLayout {
  mode: PaneMode;
  slots: Partial<Record<SlotName, PanelState>>;
}

export interface OpenIntent {
  action: "openRecord" | "openLookup" | "openLines";
  entity: string;
  id?: string;
  targetSlot?: SlotName;
  mode?: "replace" | "push";
  initialData?: Record<string, unknown>;
}

export interface SelectionSyncOptions {
  targetSlot?: SlotName;
  mode?: "replace" | "push";
  skipEmpty?: boolean;
}

/**
 * Serialize a PanelState to a compact URL-safe string for search params.
 * Format: type:entity[:id][:parentId]
 */
export function serializePanelState(panel: PanelState): string {
  const parts = [panel.type, panel.entity];
  if (panel.type === "detail" && panel.id) parts.push(panel.id);
  if (panel.type === "lines" && panel.parentId) parts.push(panel.parentId);
  return parts.join(":");
}

/**
 * Deserialize a compact string back to a PanelState.
 * Format: type:entity[:id][:parentId]
 */
export function deserializePanelState(serialized: string): PanelState | null {
  const parts = serialized.split(":");
  if (parts.length < 2) return null;
  const [type, entity] = parts;
  const panelType = type as PanelType;

  if (panelType === "list") {
    return { type: "list", entity };
  }
  if (panelType === "detail") {
    return { type: "detail", entity, id: parts[2] ?? "" };
  }
  if (panelType === "lines") {
    return { type: "lines", entity, parentId: parts[2] ?? "" };
  }
  if (panelType === "tree") {
    return { type: "tree", entity };
  }
  if (panelType === "lookup") {
    return { type: "lookup", entity };
  }
  if (panelType === "kpi") {
    return { type: "kpi", entity };
  }
  if (panelType === "period-comparison") {
    return { type: "period-comparison", entity };
  }
  if (panelType === "document-list") {
    return { type: "document-list", entity };
  }
  return null;
}

/**
 * Check if an intent is navigation-only (no mutation data).
 */
export function isNavigationIntent(intent: Record<string, unknown>): boolean {
  const validActions = new Set(["openRecord", "openLookup", "openLines"]);
  return (
    typeof intent.action === "string" &&
    validActions.has(intent.action) &&
    typeof intent.entity === "string"
  );
}

export function encodeWorkspaceState(
  ws: string,
  panes: Record<string, string[]>,
  lang: string,
): string {
  const p = Object.entries(panes)
    .map(([k, v]) => `${k}${v.join(",")}`)
    .join("&");
  return `?ws=${ws}&p=${p}&lang=${lang}`;
}

export function decodeWorkspaceState(search: string): {
  ws: string;
  panes: Record<string, string[]>;
  lang: string;
} {
  const params = new URLSearchParams(search);
  const p = params.get("p") || "";
  const panes: Record<string, string[]> = {};
  const parts = p.split("|");
  for (const part of parts) {
    if (!part) continue;
    const [key, ...views] = part.split(",");
    panes[key] = views;
  }
  return {
    ws: params.get("ws") || "dashboard",
    panes,
    lang: params.get("lang") || "en",
  };
}
