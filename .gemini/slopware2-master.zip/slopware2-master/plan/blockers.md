# Blockers

Subagenten schreiben Blocker hier wenn sie auf ein Problem stoßen das sie nicht selbst lösen können.

## Format

- `[BLOCKER] <kurze beschreibung>` — max 3 Zeilen pro Blocker
  -Dispatcher liest diese Datei vor jedem neuen Cycle und fixt die Blocker

## Current Blockers

(keine)

## Resolved

- [x] `.ignored_node_modules/` lint errors → added to vite.config.ts ignorePatterns (2026-05-07)
- [x] External directory access → opencode.json config (2026-05-07)
- [x] GitHub repo empty → initial push successful, master → origin/master (2026-05-09)
- [x] Integration tests: global-setup.ts stub → implemented with seed data (2026-05-09)
