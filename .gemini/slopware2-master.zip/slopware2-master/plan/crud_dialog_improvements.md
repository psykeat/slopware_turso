# PRD: CRUD Dialog UX & Validation Improvements

## 1. Background & Motivation

Write operations within the `CrudDialog` currently fail silently ("gar nichts passiert"). The underlying server errors trigger a workspace `toast` notification, but because the toast is rendered in the bottom status bar, it is completely hidden behind the `CrudDialog`'s modal backdrop (`z-50`). Furthermore, there is no client-side pre-validation, meaning required fields or type mismatches require a full server roundtrip only to fail silently in the UI. Lastly, form labels often fall back to raw English database column names (e.g., `company_id`) when German is selected but database-driven metadata is missing.

## 2. Scope & Impact

This enhancement targets the `CrudDialog` component and its field rendering mechanism to provide robust, immediate, and visible feedback without compromising the server's role as the authoritative validation source.

**Affected Callers of `CrudDialog`:**
These improvements will automatically benefit all existing callers of the dialog:

- `apps/web/src/features/workspace/components/data-table/entity-data-table.tsx`
- `apps/web/src/features/workspace/components/panels/detail-panel-adapter.tsx`
- `apps/web/src/features/workspace/views/settings/settings-main-view.tsx`

## 3. Proposed Solution

### A. Client-Side Validation (Local Validation)

- **Trigger:** Executed within `handleSubmit` before sending the mutation payload.
- **Scope:** Validates `visibleFields` strictly based on metadata rules (`isRequired`, `fieldType`).
- **Behavior:** If validation fails, the save request is aborted, and the affected inputs are highlighted visually.

### B. Unified Error Presentation (In-Dialog Banner)

- **Location:** A prominent error banner rendered directly inside the `CrudDialog` body (e.g., above the action buttons).
- **Replacement:** Replaces the use of the hidden workspace `toast` for dialog-specific errors.
- **Content:** Displays a stable localized title (e.g., "Speichern fehlgeschlagen") along with the normalized error message.

### C. Server Error Normalization (`parseServerError`)

- **Concept:** Server errors (Zod issues, Domain strings, technical errors) are normalized and mapped into the same UI state (`fieldErrors`, `globalError`) used by local validation.
- **Helper Function:** Introduce `parseServerError(rawError: string, visibleFields: any[])` returning `{ fieldErrors, globalError, source, code }`.
- **Parsing Rules:**
  1. _JSON/Zod:_ Parse structured issues. Extract paths mapped to known fields.
  2. _Domain Errors:_ Parse strings (e.g., "Validation failed: ...") by splitting on semicolons to extract field-specific constraints.
  3. _Fallback:_ Any unknown error becomes a `globalError`.
- **Mapping Constraint:** An error is ONLY mapped to `fieldErrors` if its field name exists in the current `visibleFields` (or effective metadata). Unmappable field errors are routed to the `globalError` banner.

### D. I18n Fallback Chain for Field Labels

- Database-driven metadata remains the primary Source of Truth.
- Implement a strict fallback chain in `FieldRenderer` to prevent raw column names from leaking:
  1. `field.label?.[lang]` (Specific metadata translation)
  2. `field.label?.de` (Base language fallback from metadata)
  3. `t(\`field.${field.fieldName}\`, lang)`(Static`i18n.ts` dictionary fallback for generic fields like 'name', 'status')
  4. `field.fieldName` (Raw technical column name, as a last resort)

## 4. Implementation Steps

1. Create the `parseServerError` utility inside or alongside `crud-dialog.tsx`.
2. Update `FieldRenderer` in `form-fields.tsx` to implement the new i18n fallback chain.
3. Update `CrudDialog` state to hold structured `errors` (`fieldErrors`, `globalError`).
4. Implement `validateLocally` in `CrudDialog`.
5. Update mutation `onError`/`onSuccess` handlers to use `parseServerError`.
6. Add the in-dialog error banner UI above the action buttons.
7. Verify all callers (`entity-data-table.tsx`, `detail-panel-adapter.tsx`, `settings-main-view.tsx`) render the updated dialog correctly.

## 5. Verification & Testing

- Open any CRUD dialog (e.g., via the Entity Data Table).
- Attempt to save an empty form; verify local validation triggers the in-dialog banner and highlights missing required fields.
- Input invalid types (e.g., letters in a numeric field) and verify local validation catches it.
- Force a server-side domain error (e.g., unique constraint violation) and verify the unified banner displays the error.
- Check a generic field (e.g., "name" or "status") with no database label to ensure the static `i18n.ts` German translation is applied successfully.
