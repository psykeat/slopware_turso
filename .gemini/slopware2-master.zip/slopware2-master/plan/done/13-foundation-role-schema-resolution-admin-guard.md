# Cycle 13 — foundation-role-schema-resolution-admin-guard

**Status**: done
**Commit**: 0db87d4
**Files**: packages/db/src/schema/system.ts, packages/db/migrations/20260507200000_add_user_role/migration.sql, packages/auth/src/$resolveUserRole.ts, packages/auth/src/adminGuard.ts, apps/web/src/routes/\_auth+/admin/route.tsx, apps/web/src/routes/\_auth+/admin/index.tsx, packages/auth/src/**tests**/role-resolution.test.ts, apps/web/src/**tests**/routes/routes.test.ts, packages/db/src/**tests**/schema.test.ts
**Tests**: 12 tests added (8 role logic, 4 migration SQL)
**vp check**: 0 errors in new files, 28 pre-existing errors
**Acceptance Criteria**:

- [x] Migration adds `role` column, CHECK, index, backfills `is_system_admin`
- [x] `$resolveUserRole` resolves from `user_tenant` + fallback
- [x] `requireAdminRole` returns 403 for `tenant_user`
- [x] Admin layout blocks non-admins, renders nav
- [x] Tests for role resolution + guard
- [x] `vp test` green (329 passed), `vp check` clean (no new errors)

**Notes**: Role hierarchy: tenant_user(0) < tenant_admin(1) < org_admin(2) < system_admin(3). Admin = any role >= tenant_admin.
