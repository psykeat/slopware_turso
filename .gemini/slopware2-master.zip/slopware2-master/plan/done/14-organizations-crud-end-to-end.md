# Cycle 14 — organizations-crud-end-to-end

**Status**: done
**Commit**: 5b3f352
**Files**: registry.ts, server-functions.ts, organizations.tsx, columns.tsx, crud-dialog.tsx, commands.test.ts, queries.test.ts, server-functions.test.ts
**Tests**: 6 tests added/modified
**vp check**: 0 errors, N pre-existing warnings
**Acceptance Criteria**:

- [x] Registry entry, domain queries/commands, server functions with requireAdminRole
- [x] UI: inline CRUD dialog, real data, slug validation
- [x] Tests, vp test green (340/340)

**Notes**: Organizations are non-tenant-scoped → used withSystemContext. Custom inline CRUD dialog instead of EntityDataTable due to non-generic pattern.
