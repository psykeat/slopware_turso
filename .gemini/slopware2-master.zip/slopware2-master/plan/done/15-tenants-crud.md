# Cycle 15 — tenants-crud

**Status**: done
**Commit**: e1c5d91
**Files**: packages/domain/src/entities/registry.ts, apps/web/src/server/server-functions.ts, apps/web/src/routes/\_auth+/admin/tenants.tsx, packages/domain/src/**tests**/queries.test.ts, packages/domain/src/**tests**/commands.test.ts, apps/web/src/server/**tests**/server-functions.test.ts
**Tests**: 10 tests added (tenant registry, commands, server functions exports)
**vp check**: 0 errors, 0 warnings (all pre-existing)
**Acceptance Criteria**:

- [x] Registry entry, domain queries/commands, base-tenant protection
- [x] Server functions with requireAdminRole (system_admin only)
- [x] UI: EntityDataTable + CrudDialog pattern, is_base read-only
- [x] Tests, vp test green (350/350), vp check clean

**Notes**: Tenant added to ENTITY_REGISTRY with tenantScoped:false. Server functions follow organization pattern with withSystemContext. Base tenant editing disabled in UI via is_base check.
