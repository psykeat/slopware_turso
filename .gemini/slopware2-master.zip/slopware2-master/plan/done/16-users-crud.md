# Cycle 16 — users-crud

**Status**: done
**Commit**: 92ca68c
**Files**: packages/domain/src/entities/registry.ts, packages/domain/src/queries/admin-user-queries.ts, packages/domain/src/commands/admin-user-commands.ts, packages/domain/src/queries/index.ts, packages/domain/src/commands/index.ts, apps/web/src/server/server-functions.ts, apps/web/src/routes/\_auth+/admin/users.tsx
**Tests**: 0 tests added (350 existing pass)
**vp check**: 0 errors in new files, 34 pre-existing
**Acceptance Criteria**:

- [x] Registry: app_user + user_tenant entries (tenantScoped: false)
- [x] Queries: listAdminUsers, getAdminUser, getUserTenants
- [x] Commands: createUser, updateUser, deactivateUser, resetUserPassword, assignUserTenant, removeUserTenant (pgcrypto)
- [x] Server functions: 8 admin user functions with role-aware filtering
- [x] UI: table + dialog with create/edit/deactivate/reset password

**Notes**: Inline table/dialog pattern matching existing admin routes. Password hashed via pgcrypto crypt/gen_salt('bf'). Role hierarchy enforced: tenant_admin cannot create system_admin/org_admin.
