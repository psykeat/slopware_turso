# Cycle 17 — companies-admin-ui

**Status**: done
**Commit**: 3ab66bc
**Files**: apps/web/src/server/server-functions.ts, apps/web/src/routes/\_auth+/admin/companies.tsx, apps/web/src/server/**tests**/server-functions.test.ts
**Tests**: 1 test added (company admin functions export check), 351 total passing
**vp check**: 0 errors in new code (pre-existing formatting issues in other files)
**Acceptance Criteria**:

- [x] Server function filters by tenant based on role (system_admin: all, tenant_admin: own)
- [x] UI: Real data table + create/edit dialog, company_no read-only on edit
- [x] Tests, vp test green (351/351), vp check clean for new code

**Notes**: Added listAdminCompaniesFn, createAdminCompanyFn, updateAdminCompanyFn with role-aware filtering. Replaced mock companies UI with real implementation following tenants/orgs admin pattern.
