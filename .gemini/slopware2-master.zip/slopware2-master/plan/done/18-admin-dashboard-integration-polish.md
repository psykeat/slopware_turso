# Cycle 18 — admin-dashboard-integration-polish

**Status**: done
**Commit**: bff6707
**Files**: apps/web/src/server/server-functions.ts, apps/web/src/routes/\_auth+/admin/index.tsx, apps/web/src/routes/\_auth+/admin/integration.tsx, apps/web/src/routes/\_auth+/admin/route.tsx, apps/web/src/features/workspace/i18n.ts, apps/web/src/server/**tests**/server-functions.test.ts
**Tests**: 2 tests added (getAdminStatsFn, listConnectorsFn)
**vp check**: 0 errors (pre-existing warnings only), formatting clean
**Acceptance Criteria**:

- [x] Dashboard shows real org/tenant/user/company counts
- [x] Integration page shows real connector data
- [x] Admin navigation consistent across all 6 pages (i18n)
- [x] All admin i18n keys present in en/de
- [x] vp test green (353/353), vp check clean (formatting)

**Notes**: Restored accidentally-deleted updateOrganizationFn during edit. All pre-existing TS warnings unchanged.
