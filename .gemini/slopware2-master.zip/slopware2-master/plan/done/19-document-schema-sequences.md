# Cycle #19 — document-schema-sequences

**Status**: done
**Commit**: 3507985
**Files**: packages/db/src/schema/transaction.ts, packages/db/src/schema/master.ts, packages/db/src/functions/next-sequence-no.ts, packages/db/src/functions/index.ts, packages/db/src/index.ts, packages/domain/src/commands/seed-document-defaults.ts, packages/domain/src/commands/index.ts, packages/domain/src/**tests**/seed-document-defaults.test.ts, packages/db/drizzle/20260508000000_document_sequences/migration.sql
**Tests**: 7 tests added
**vp check**: formatting OK (pre-existing errors unrelated)
**Acceptance Criteria**:

- [x] `number_sequence` gets `document_type char(1)` column + UNIQUE(tenant_id, company_id, document_type)
- [x] `address` gets `price_list_id uuid` nullable FK
- [x] `next_sequence_no` helper function for PL/pgSQL sequence calls
- [x] `seedDocumentDefaults(tenantId, companyId)` creates 13 document_type/group/number_sequence rows
- [x] Conversion chain links: N→A→L→R, b→l→r; G/g/V/Z/E/U standalone
- [x] Tests: 7 tests — exports, 13-row counts, conversion chains, standalone types, movement_type, ON CONFLICT

**Notes**: Migration applied manually (drizzle-kit RC TTY bug). pgFunction replaced with sql template literal helper.
