# Cycle 20 — createDocument-deleteDocument

**Status**: done
**Commit**: c0ef9e0
**Files**: packages/domain/src/commands/document-commands.ts, packages/domain/src/commands/index.ts, packages/domain/src/**tests**/document-commands.test.ts, apps/web/src/server/server-functions.ts
**Tests**: 11 tests added
**vp check**: 0 errors in new code (pre-existing errors only)
**Acceptance Criteria**:

- [x] createDocument(sql, payload) calls next_sequence_no, sets status=draft, saves header + lines sequentially in transaction
- [x] deleteDocument(sql, id) blocks R, r, G, g; allows all other types regardless of status
- [x] Server functions wired to domain commands with authMiddleware
- [x] Document gets number immediately on creation (e.g., AUF-00042)

**Notes**: Number allocation uses FOR UPDATE on number_sequence row. Lines inserted sequentially after header. Delete protection covers all credit memo types.
