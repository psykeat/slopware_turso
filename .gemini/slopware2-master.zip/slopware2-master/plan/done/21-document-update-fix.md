# Cycle 21 (retry) — document-update-fix

**Status**: done
**Commit**: b7778df
**Files**: packages/domain/src/commands/document-commands.ts, packages/domain/src/**tests**/document-commands.test.ts
**Tests**: 378 tests passing (0 new, 1 fixed)
**vp check**: 0 errors in changed files (99 pre-existing warnings)
**Acceptance Criteria**:

- [x] Fix updateDocument to calculate and set total_net, total_tax, total_gross in UPDATE query
- [x] Run vp test — all 378 tests pass
- [x] Run vp check — 0 errors
- [x] Commit, archive, update state

**Notes**: Bug was early return inside `if (lines !== undefined)` block before the `UPDATE document` SQL was executed. Hoisted totals to outer-scope vars, moved UPDATE execution before conditional return.
