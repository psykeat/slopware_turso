# Cycle 22 — document-list-adapter

**Status**: done
**Commit**: 2b63637
**Files**: document-list-adapter.tsx, panel-resolver.tsx, panels/index.ts, i18n.ts, server-functions.ts, workspace/index.ts, document-list.test.ts, workspace-panel.test.ts, server-functions.test.ts
**Tests**: 31 tests added (24 document-list, 7 workspace-panel)
**vp check**: 0 errors in changed files, 114 warnings (pre-existing)
**Acceptance Criteria**:

- [x] DocumentListAdapter: parses panel params, filters server-side by type and group
- [x] Document list: search, sort, server-side pagination, filter by direction/type/group
- [x] Sidebar tree: 3-level (Warenausgang, Wareneingang, Lagerbuchungen collapsed by default)
- [x] Dynamic from document_type metadata and document_group rows
- [x] Click opens document in detail pane via dispatchIntent

**Notes**: Panel type `document-list` added to shared/workspace PanelState union and deserializer. Server functions `listDocumentsFn` and `listDocumentTreeFn` already existed from previous cycle.
