# Cycle 23 — postDocument

**Status**: done
**Commit**: bf9a406
**Files**: packages/domain/src/commands/posting-command.ts, packages/domain/src/**tests**/posting-command.test.ts, packages/domain/src/commands/index.ts, apps/web/src/server/server-functions.ts, apps/web/src/features/workspace/components/panels/detail-panel-adapter.tsx, apps/web/src/features/workspace/workspace.tsx
**Tests**: 17 tests added (all 13 movement types + edge cases)
**vp check**: 0 new errors (50 pre-existing)
**Acceptance Criteria**:

- [x] postDocument(sql, docId, userId) entry point with guards (404, 409 idempotency, 409 storno)
- [x] Full posting matrix: N, A, L, R, G, b, l, r, g, V, Z, E, U
- [x] inventory_balance upserts with available_qty = on_hand_qty − reserved_qty
- [x] inventory_movement and fact_sales_event records created where applicable
- [x] V: sets on_hand to target (not delta add)
- [x] U: two upserts (source −qty, target +qty)
- [x] b: expected_purchase_qty +qty (not reserved_qty)
- [x] l: on_hand +qty AND expected_purchase −qty
- [x] Status set to posted, posted_at, posted_by set
- [x] "Buchen" button in detail pane wired to postDocumentFn mutation

**Notes**: Fixed test assertions for Z/E type (params[4] not params[5]). Pre-existing: updateOrganizationFn test failure, 50 TS errors in server-functions.ts.
