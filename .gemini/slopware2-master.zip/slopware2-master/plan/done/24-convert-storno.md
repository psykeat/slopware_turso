# Cycle 24 — convert-storno

**Status**: done
**Commit**: 87b494f
**Files**: packages/domain/src/commands/document-convert-storno.ts, packages/domain/src/**tests**/document-convert-storno.test.ts, packages/domain/src/commands/index.ts, apps/web/src/server/server-functions.ts
**Tests**: 15 tests added
**vp check**: 0 errors
**Acceptance Criteria**:

- [x] convertDocument with hardcoded fallback map (N→A, A→L, L→R, b→l, l→r)
- [x] stornoDocument for posted R/r → creates G/g
- [x] Server functions: convertDocumentFn, stornoDocumentFn
- [x] 15 tests covering all conversion chains and storno logic

**Notes**: Worker wrote code but failed to commit due to JSON parse errors. Dispatcher fixed test mocks and committed manually.
