# Cycle 25 — article-autocomplete

**Status**: done
**Commit**: 23ab774
**Files**: packages/domain/src/queries/article-pricing.ts, packages/domain/src/queries/index.ts, packages/domain/src/**tests**/article-pricing.test.ts, apps/web/src/server/server-functions.ts, apps/web/src/server/**tests**/server-functions.test.ts
**Tests**: 7 tests added
**vp check**: 0 errors in new files
**Acceptance Criteria**:

- [x] Server function takes article_id + address_id + document_date context
- [x] Price resolution: address.price_list_id → price_list_item lookup by article + date
- [x] Tax resolution: article.tax_class × address.tax_class × address.country → tax_rule → tax_code
- [x] Returns net_price, tax_rate, tax_code_id in single response
- [x] Currency pre-filled from price_list
