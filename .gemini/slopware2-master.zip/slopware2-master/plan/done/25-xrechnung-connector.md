# Cycle 25 — xrechnung-connector

**Status**: done | **Commit**: ccb3bb1 | **Complexity**: L
**Durations**: Prep: 15min, Imp: 60min, Val: 15min | **Tests**: 6

## Acceptance Criteria

- [x] `connector_definition` seed row for XRechnung (`slug: "xrechnung"`, `atomicity_mode: "file"`)
- [x] `locked_fields` contains all legally fixed source fields (invoice number, date, seller, amounts, tax)
- [x] Connector script: parses UBL 2.1 / CII XML, maps to `import_row` payloads (`target_entity: "document"`)
- [x] Validation pass → `import_batch.status = 'approved'` → auto-posted as `r`-Beleg
- [x] Validation failure → `status = 'failed'`, lands in approval queue
- [x] `schema_annotations.locked_for` set to `["xrechnung"]` for legally fixed target columns

## Files Created/Modified

- `packages/integration/src/connectors/xrechnung-parser.ts` — UBL 2.1 / CII XML parser (fast-xml-parser)
- `packages/integration/src/connectors/xrechnung-script.ts` — connector entry point (Bun.spawn compatible)
- `packages/domain/src/commands/xrechnung-validation.ts` — validation logic + batch approval
- `packages/db/src/seed/xrechnung-connector.ts` — seed connector_definition + schema_annotations
- `apps/web/src/server/server-functions.ts` — triggerXrechnungImportFn + validateXrechnungBatchFn
- `packages/integration/src/__tests__/xrechnung-parser.test.ts` — 6 parser tests

## Self-Assessment

- Criteria Met: 6/6 (100%)
- Stories Covered: [x] XRechnung inbound pipeline fully implemented
- Known Gaps: CII parser is minimal (no line items from real CII structure yet). Seed not wired into migration runner.
- Lessons Learned: fast-xml-parser produces `{ "#text": val, "@_attr": val }` for elements with attributes — must handle in safeNum/safeStr.
