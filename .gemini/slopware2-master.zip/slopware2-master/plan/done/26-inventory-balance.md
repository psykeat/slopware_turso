# Cycle 26 — inventory-balance

**Status**: done
**Commit**: f8b480b
**Files**: packages/domain/src/queries/inventory-balance.ts, packages/domain/src/queries/index.ts, packages/domain/src/**tests**/inventory-balance.test.ts, apps/web/src/server/server-functions.ts, apps/web/src/features/workspace/components/inventory-balance-table.tsx, apps/web/src/features/workspace/components/crud-dialog.tsx, apps/web/src/features/workspace/components/data-table/entity-data-table.tsx
**Tests**: 5 tests added
**vp check**: 0 errors (pre-existing TS issues unrelated)
**Acceptance Criteria**:

- [x] Query: inventory balance per warehouse (on_hand, reserved, available)
- [x] InventoryBalanceTable component: columns for warehouse, on_hand, reserved, available
- [x] Reserved qty shown in amber, available qty in green
- [x] Total row when > 1 warehouse
- [x] childSection prop added to crud-dialog.tsx (optional render prop)
- [x] Wired into article dialog

**Notes**: SQL COALESCE handles available_qty fallback at DB level.
