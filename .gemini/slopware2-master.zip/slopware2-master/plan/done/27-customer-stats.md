# Cycle 27 — customer-stats

**Status**: done
**Commit**: 6e6dc06
**Files**: packages/domain/src/queries/customer-stats.ts, packages/domain/src/queries/customer-yearly-revenue.ts, packages/domain/src/queries/index.ts, packages/domain/src/**tests**/customer-stats.test.ts, packages/domain/src/**tests**/customer-yearly-revenue.test.ts, apps/web/src/server/server-functions.ts, apps/web/src/features/workspace/components/customer-stats-section.tsx, apps/web/src/features/workspace/components/data-table/entity-data-table.tsx
**Tests**: 9 tests added (5 customer-stats, 4 customer-yearly-revenue)
**vp check**: 0 errors (pre-existing TS warnings only)
**Acceptance Criteria**:

- [x] Query: last 10 documents for customer (date, number, type, status, gross)
- [x] Query: yearly revenue (qty + net amount per year)
- [x] CustomerStatsSection component with two subsections
- [x] Only visible when is_customer = true
- [x] Revenue section only shown when posted invoices exist
- [x] Wired into address dialog via childSection prop

**Notes**: Follows inventory-balance pattern — domain query + server function + UI component + childSection wiring.
