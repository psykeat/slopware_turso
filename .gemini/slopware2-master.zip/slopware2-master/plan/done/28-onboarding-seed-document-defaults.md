# Cycle 28 — onboarding-seed-document-defaults

**Status**: done
**Commit**: d7e429a
**Files**: apps/web/src/server/server-functions.ts, packages/domain/src/**tests**/company-onboarding-seed.test.ts, apps/web/src/server/**tests**/server-functions.test.ts
**Tests**: 6 tests added (5 domain + 1 server)
**vp check**: pre-existing warnings only
**Acceptance Criteria**:

- [x] `seedDocumentDefaults` called after company creation
- [x] New company has 13 document_type rows with correct chain links
- [x] New company has 13 document_group rows (Standard, group number 1)
- [x] New company has 13 number_sequence rows with correct prefixes
- [x] Error handling: if seed fails, company creation rolls back via transaction

**Notes**: seed runs inside same `withSystemContext` transaction as company INSERT. Seed failure throws, causing tx rollback.
