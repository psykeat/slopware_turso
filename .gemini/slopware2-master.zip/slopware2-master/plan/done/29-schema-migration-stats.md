# Cycle 29 — schema-migration-stats

**Status**: done
**Commit**: a9e6b28
**Files**: packages/db/src/schema/transaction.ts, packages/db/src/schema/system.ts, packages/db/src/schema/connector.ts, packages/db/src/**tests**/schema.test.ts, packages/db/drizzle/20260508204744_busy_black_crow/
**Tests**: 4 tests added (document.dueDate, schema_annotations.moduleId/dataClass, importBatch.sourceBatchId, modules columns)
**vp check**: 1 error (pre-existing TS2554 in server-functions.ts), 109 warnings
**Acceptance Criteria**:

- [x] document.due_date date nullable column
- [x] schema_annotations.module_id FK → modules.module_id
- [x] schema_annotations.data_class CHECK constraint
- [x] import_batch.source_batch_id self-referential FK
- [x] 8 Materialized Views with UNIQUE indexes
- [x] Additional index: document(tenant_id, customer_id, due_date) WHERE is_paid = false
- [x] Seed 7 modules
- [x] schema_annotations: no RLS, column_name default '', UNIQUE constraint
- [x] pnpm db generate && pnpm db migrate clean
- [x] Tests: 474/474 passing

**Notes**: Self-referential FK on import_batch handled via raw SQL DO block due to Drizzle circular reference limitation (TS7022).
