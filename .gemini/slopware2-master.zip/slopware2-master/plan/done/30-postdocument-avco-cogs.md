# Cycle 30 — postdocument-avco-cogs

**Status**: done
**Commit**: 710c2f8
**Files**: packages/domain/src/commands/posting-command.ts, packages/domain/src/**tests**/posting-command.test.ts
**Tests**: 8 tests added (AVCO normal, AVCO frozen, PERIOD_CLOSED, due_date, + 4 updated existing)
**vp check**: 1 error (pre-existing), 109 warnings
**Acceptance Criteria**:

- [x] resolveFiscalPeriodId — lookup by date, lazy-generate via generateFiscalPeriods(), throw PERIOD_CLOSED
- [x] generateFiscalPeriods — 12 rows from company.fiscal_year_start_month, handles cross-year
- [x] AVCO for r-type: weighted avg cost, freeze when newQty <= 0
- [x] fact_purchase_event insert for r/g with avg_cost_before/after
- [x] COGS snapshot for R-type: gld_purchase × |quantity_delta|
- [x] due_date from document_date + payment_term.net_days for R/r
- [x] pg_notify('stats_refresh', tenantId) inside posting transaction
- [x] All inside existing posting transaction — one commit
- [x] Tests: AVCO correct, AVCO frozen, PERIOD_CLOSED, due_date 30-day
- [x] vp check + vp test green

**Notes**: COGS formula fixed from `gldPurchase * qty * sign` to `gldPurchase * Math.abs(qtyDelta)`.
