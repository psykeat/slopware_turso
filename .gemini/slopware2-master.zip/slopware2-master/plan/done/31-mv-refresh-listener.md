# Cycle 31 — mv-refresh-listener

**Status**: done
**Commit**: 1204cda
**Files**: packages/integration/src/mv-refresh-listener.ts, packages/integration/src/mv-names.ts, packages/integration/src/mv-refresh-dev.ts, packages/integration/src/**tests**/mv-refresh-listener.test.ts, packages/integration/src/index.ts, packages/integration/package.json, dev.sh
**Tests**: 2 tests added (startup refresh, debounce collapse)
**vp check**: 0 errors (1 pre-existing), 109 warnings
**Acceptance Criteria**:

- [x] On startup: REFRESH MATERIALIZED VIEW CONCURRENTLY for all 8 MVs sequentially
- [x] LISTEN stats_refresh channel active after startup refresh
- [x] Debounce to 5 seconds (timer reset on each event)
- [x] On debounce fire: refresh all 8 MVs on separate DB connection
- [x] Integration service starts as part of dev.sh
- [x] Exponential backoff retry if DB unavailable on startup
- [x] Tests: startup refresh runs all 8 statements
- [x] Tests: debounce collapses rapid notifications

**Notes**: postgres library uses `sql.listen(channel, cb)` API. Two connections: one for LISTEN, one for REFRESH.
