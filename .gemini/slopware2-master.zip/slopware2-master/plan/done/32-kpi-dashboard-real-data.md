# Cycle 32 — kpi-dashboard-real-data

**Status**: done
**Commit**: d2ffc0a
**Files**: apps/web/src/server/server-functions.ts, apps/web/src/server/**tests**/server-functions.test.ts
**Tests**: 1 test added (DashboardKpis shape validation)
**vp check**: 0 errors (1 pre-existing TS2554 unrelated), 111 warnings
**Acceptance Criteria**:

- [x] getDashboardKpisFn queries mv_sales_period for current/prior year
- [x] Queries document for open orders + invoices
- [x] Queries inventory_balance for total inventory value
- [x] Queries mv_sales_period_article_group for top 5 groups
- [x] kpi-view.tsx uses server function via useQuery, no mock data
- [x] stats:kpi registered in VIEW_REGISTRY as kind: custom
- [x] DashboardKpisShapeCheck validates interface shape

**Notes**: Server function and view were already implemented in prior cycle. Added shape validation test + helper.
