# Cycle 33 — period-comparison-view

**Status**: done
**Commit**: 3aa8849
**Files**: server-functions.ts, stats-period-comparison-view.tsx, view-registry.ts, i18n.ts, server-functions.test.ts
**Tests**: 2 tests added (484 total)
**vp check**: 0 errors, 111 warnings (pre-existing)
**Acceptance Criteria**:

- [x] getPeriodComparisonStatsFn server function queries mv_sales_period for 12 period rows
- [x] getFiscalYearsFn server function queries fiscal_period for year dropdown
- [x] stats-period-comparison-view.tsx with fiscal year selector, bar chart, YoY toggle
- [x] Registered as stats:period-comparison in VIEW_REGISTRY (kind: custom)
- [x] i18n keys for en/de
- [x] Tests for exported functions + shape check

**Notes**: Bar chart uses CSS height-based bars. YoY toggle overlays prior year with reduced opacity.
