# Cycle 34 — address-detail-view

**Status**: done
**Commit**: 3dce433
**Files**: apps/web/src/features/workspace/views/address/address-detail-view.tsx, apps/web/src/server/server-functions.ts, apps/web/src/features/workspace/i18n.ts, apps/web/src/server/**tests**/address-stats-fn.test.ts
**Tests**: 2 tests added
**vp check**: 0 errors, 111 warnings
**Acceptance Criteria**:

- [x] `getAddressStatsFn` server function with 4 sub-queries
- [x] Tab Statistik: mv_sales_period_customer chart
- [x] Tab Offene Posten: live query document where is_paid = false
- [x] Tab Bewegungen: document_line JOIN document
- [x] Tab Belege: document filtered by customer_id
- [x] Tabs nur sichtbar wenn is_customer = true
- [x] Offene Posten shows hint when empty

**Notes**: AddressStatsShapeCheck added for type validation test.
