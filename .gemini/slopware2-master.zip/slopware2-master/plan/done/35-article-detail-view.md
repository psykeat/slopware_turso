# Cycle 35 — article-detail-view

**Status**: done
**Commit**: c1a1ed6
**Files**: apps/web/src/server/server-functions.ts, apps/web/src/features/workspace/views/article/article-detail-view.tsx, apps/web/src/features/workspace/view-registry.ts, apps/web/src/features/workspace/i18n.ts, apps/web/src/server/**tests**/article-stats-fn.test.ts
**Tests**: 5 tests added
**vp check**: 0 errors, 112 warnings
**Acceptance Criteria**:

- [x] getArticleStatsFn with 4 sub-queries (sales/purchase MVs, inventory_movement running balance, document_line movements, document via lines join)
- [x] article:detail view with 4 tabs (stats, journal, movements, documents)
- [x] Stock journal: running balance via window function, warehouse toggle, pinned footer with reserved_qty + expected_purchase_qty
- [x] Registered in VIEW_REGISTRY as article:detail (kind: custom)
- [x] i18n keys for all labels (en/de)
- [x] Tests pass, vp check clean

**Notes**: Follows same pattern as address-detail-view. Stock journal uses SUM(qty_delta) OVER (ORDER BY movement_date, created_at) for running balance.
