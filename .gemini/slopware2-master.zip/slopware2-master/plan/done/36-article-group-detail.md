# Cycle 36 — article-group-detail

**Status**: done
**Commit**: 5b2265b
**Files**: server-functions.ts, article-group-detail-view.tsx, view-registry.ts, workspace-context.tsx, workspace.tsx, feedback-modal.tsx, i18n.ts, article-group-stats-fn.test.ts
**Tests**: 5 tests added
**vp check**: 0 errors, 112 warnings
**Acceptance Criteria**:

- [x] getArticleGroupStatsFn server function with mv_sales_period_article_group query
- [x] document_line JOIN article filtered by article_group_id for movements
- [x] document via lines→article join for documents
- [x] views/article/article-group-detail-view.tsx with 3 tabs (stats, movements, documents)
- [x] article:group-detail registered in VIEW_REGISTRY (kind: custom)
- [x] selectedArticleGroup in workspace context
- [x] i18n keys ag.\* (en/de)
- [x] Tests pass, vp check clean

**Notes**: Pattern follows article-detail-view closely for consistency.
