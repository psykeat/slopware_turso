# Cycle 37 — fiscal-period-settings

**Status**: done
**Commit**: 8effe77
**Files**: packages/domain/src/entities/registry.ts, packages/domain/src/commands/fiscal-period-command.ts, packages/domain/src/commands/index.ts, packages/domain/src/**tests**/fiscal-period-command.test.ts, apps/web/src/server/server-functions.ts, apps/web/src/features/workspace/registry.tsx, apps/web/src/features/workspace/view-registry.ts, apps/web/src/features/workspace/views/settings/settings-fiscal-period-view.tsx
**Tests**: 3 tests added (close period, idempotent, not-found)
**vp check**: 0 errors, 111 warnings
**Acceptance Criteria**:

- [x] fiscal_period in ENTITY_REGISTRY under category: "settings", group: "organisation"
- [x] UI registry entry with category, group, icon, labels
- [x] closePeriod domain command (idempotent)
- [x] closePeriodFn server function with authMiddleware
- [x] Custom view with close action + status badges (Offen/Geschlossen)
- [x] Close action hidden for already-closed periods
- [x] Tests: close sets flag, already-closed idempotent, not-found error
- [x] vp check + vp test pass

**Notes**: PERIOD_CLOSED enforcement already exists in postDocument (Cycle 30).
