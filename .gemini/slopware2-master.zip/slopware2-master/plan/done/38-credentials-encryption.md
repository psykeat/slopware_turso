# Cycle 38 — credentials-encryption

**Status**: done
**Commit**: dd961cd
**Files**: packages/integration/src/crypto.ts, connector-credentials.ts, index.ts, **tests**/crypto.test.ts, **tests**/connector-credentials.test.ts, packages/domain/src/queries/system-queries.ts, packages/domain/src/commands/system-commands.ts, apps/web/src/server/server-functions.ts, apps/web/src/routes/\_auth+/admin/litellm.tsx, apps/web/src/routes/\_auth+/admin/route.tsx, .env
**Tests**: 8 tests added (5 crypto + 1 connector-creds + 2 pre-existing)
**vp check**: 0 errors, 117 warnings
**Acceptance Criteria**:

- [x] `encryptCredentials(data, key)` and `decryptCredentials(ciphertext, key)` using AES-GCM via SubtleCrypto
- [x] `CREDENTIALS_ENCRYPTION_KEY` (32-byte hex) added to `.env`
- [x] `encryptConnectorCredentials` / `decryptConnectorCredentials` wrapper for tenant_connector.credentials
- [x] Admin route for LiteLLM config (base_url, api_key, default_model) with Test Connection
- [x] Config stored in `system_settings` under scope `global`
- [x] Tests: round-trip identical, wrong key throws, empty/short key throws, empty ciphertext throws

**Notes**: Fixed SubtleCrypto API arg order (algorithm, key, data). Crypto returns Promises for test compatibility.
