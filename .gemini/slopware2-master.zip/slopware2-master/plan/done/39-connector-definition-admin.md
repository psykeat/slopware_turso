# Cycle 39 — connector-definition-admin

**Status**: done
**Commit**: 72032c0
**Files**:

- packages/domain/src/entities/registry.ts
- apps/web/src/features/workspace/registry.tsx
- apps/web/src/features/workspace/view-registry.ts
- apps/web/src/features/workspace/views/settings/settings-connector-definitions-view.tsx
- apps/web/src/features/workspace/views/integration/integration-tenant-connectors-view.tsx
- apps/web/src/server/server-functions.ts
- apps/web/src/server/**tests**/connector-fns.test.ts
- apps/web/src/server/**tests**/connector-activation.test.ts
  **Tests**: 2 test files added (7 new tests)
  **vp check**: 0 errors, 117 warnings (pre-existing)
  **Acceptance Criteria**:

- [x] connector_definition in domain ENTITY_REGISTRY
- [x] connector_definition in UI registry (category: settings)
- [x] settings-connector-definitions-view.tsx created and registered
- [x] integration-tenant-connectors-view.tsx created and registered
- [x] Server functions: activate, deactivate, save credentials, list tenant connectors
- [x] Credentials encrypted with AES-GCM before storage
- [x] Tests: connector functions exported + credentials encryption round-trip

**Notes**: Credentials encrypted via encryptConnectorCredentials before DB storage.
