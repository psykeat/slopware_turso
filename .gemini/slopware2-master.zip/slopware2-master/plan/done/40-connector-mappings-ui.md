# Cycle 40 — connector-mappings-ui

**Status**: done
**Commit**: aeca91e
**Files**: packages/api/src/connector-handlers.ts, packages/api/src/**tests**/connector-handlers.test.ts, packages/api/src/index.ts, apps/web/src/server/server-functions.ts, apps/web/src/features/workspace/views/integration/integration-connector-mappings-view.tsx, apps/web/src/features/workspace/view-registry.ts
**Tests**: 5 tests added (connector-handlers.test.ts)
**vp check**: 0 errors, 117 warnings
**Acceptance Criteria**:

- [x] Server functions: listConnectorMappingsFn, patchConnectorMappingsFn, getConnectorDefinitionFn, getSchemaAnnotationsFn
- [x] API handler: handlePatchConnectorMappings with two-level lock enforcement (source_locked, target_locked)
- [x] UI view: integration-connector-mappings-view.tsx with connector selector, mapping editor, lock icons, mandatory badges
- [x] VIEW_REGISTRY entry: integration:connector-mappings
- [x] Tests: 5 tests for lock enforcement (2 source_locked, 2 target_locked, 1 success)
- [x] vp check + vp test passing

**Notes**: Lock enforcement uses SQL checks: source_field IN connector_definition.locked_fields → 409 source_locked, connector_definition.slug IN schema_annotations.locked_for → 409 target_locked. Mappings upserted via INSERT ... ON CONFLICT (tenant_connector_id, source_field) DO UPDATE.
