# Cycle 41 — hotkey-core

**Status**: done | **Commit**: 51b794c | **Complexity**: M
**Durations**: Prep: 5min, Imp: 15min, Val: 5min | **Tests**: 15

**Acceptance Criteria**:

- [x] `@tanstack/react-hotkeys` installed in `apps/web` and workspace
- [x] `hotkey-store.ts`: Zustand store with scope stack (push/pop), registry, and input suppression logic
- [x] `use-hotkey-layer.ts`: Hook that pushes layer on mount, pops on unmount. Hotkey only fires when layer is topmost.
- [x] `use-scoped-hotkey.ts`: Hook for registering keys with scope checks
- [x] Input suppression: F-keys/modifier combos pass through inputs. Bare letters/digits/Enter/Space only fire when no input focused.

**Self-Assessment**:

- Criteria Met: 5/5 (100%)
- Stories Covered: [x] Keyboard Navigation PRD — Foundation fully
- Known Gaps: none
- Lessons Learned: React compiler rejects ref writes during render — must use useEffect for handlerRef update
