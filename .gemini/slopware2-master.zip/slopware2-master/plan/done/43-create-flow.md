# Cycle 43 — create-flow

**Status**: done
**Commit**: 9bd2835
**Files**: document-list-adapter.tsx, view-resolver.tsx, document-header-form.tsx, document-detail-view.tsx, i18n.ts, **tests**/create-flow.test.ts
**Tests**: 8 added
**vp check**: 0 new errors, 0 new warnings (pre-existing only)
**Acceptance Criteria**:

- [x] "Neuer Beleg" button in document list view → opens detail pane with DocumentHeaderForm
- [x] After createDocumentFn success: show allocated document number
- [x] Document status is `draft`, detail pane switches to edit mode
- [x] Create mutation invalidates document list query
- [x] Error handling: if create fails, show error, keep form data
- [x] `vp check` + `vp test` passing
- [x] Atomic commit, archive
- [x] Self-Assessment in archive

**Self-Assessment**:

- Criteria Met: 8/8 (100%)
- Stories Covered: [x] #5 fully, [x] #7 fully
- Known Gaps: none
- Lessons Learned: Test path resolution for import.meta.dirname needs careful counting of ../ levels
