# Cycle 43 — grid-actions

**Status**: done | **Commit**: f970b6a | **Complexity**: M
**Durations**: Prep: 5min, Imp: 20min, Val: 5min | **Tests**: 8

**Acceptance Criteria**:

- [x] F3: Triggers openCreateDialog in ListPanelAdapter (via useGridFocus.onNew → DataTable.onAdd → EntityDataTable.setCrudMode("create"))
- [x] F4: Calls deleteEntityFn via deactivateEntity for master data (via useGridFocus.onDeleteRow → DataTable.onDelete → EntityDataTable.setCrudMode("delete") → CrudDialog confirm)
- [x] F8: Calls duplicateEntityFn — copies record with all fields, clears ID, sets status to draft
- [x] duplicateEntity domain command: reads source record, strips ID/audit fields, returns payload for new record
- [x] duplicateEntityFn server function: authMiddleware, calls domain command, returns new record
- [x] All actions scoped to Grid (only fire when grid has focus via useGridFocus hook)

**Self-Assessment**:

- Criteria Met: 6/6 (100%)
- Stories Covered: [x] Grid keyboard actions fully
- Known Gaps: none
- Lessons Learned: F3/F4 already wired through existing onAdd/onDelete chain — only F8 needed new server function + domain command
