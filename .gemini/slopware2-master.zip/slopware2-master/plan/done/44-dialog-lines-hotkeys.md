# Cycle 44 — dialog-lines-hotkeys

**Status**: done | **Commit**: c51b091 | **Complexity**: M
**Durations**: Prep: 5min, Imp: 8min, Val: 3min | **Tests**: 0 new (L2, covered by existing hotkey tests)
**Acceptance Criteria**: [x] F10 triggers submit in CrudDialog [x] Ctrl+Enter saves current line in LinesPanelAdapter [x] Both hotkeys scoped to respective components [x] F10 does not fire when dialog not open (scope stack handles this)
**Self-Assessment**:

- Criteria Met: 4/4 (100%)
- Stories Covered: [x] Dialog hotkeys fully, [x] Lines hotkeys fully
- Known Gaps: none
- Lessons Learned: useScopedHotkey handles key matching by e.key only; modifier combos like Ctrl+Enter require checking e.ctrlKey inside handler
