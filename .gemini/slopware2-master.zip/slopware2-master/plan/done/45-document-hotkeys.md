# Cycle 45 — document-hotkeys

**Status**: done | **Commit**: fedf84e | **Complexity**: M
**Durations**: Prep: 5min, Imp: 10min, Val: 3min | **Tests**: 0 (relied on existing hotkey test suite)
**Acceptance Criteria**:

- [x] F7 / F9: Opens ConvertDocumentModal for active document. Scoped to Document grid/Mask.
- [x] F5: Opens Auswahltabelle for active FK input. Works in AddressCombobox, LookupSelect, etc.
- [x] Hotkeys only fire when their scope layer is active

**Self-Assessment**:

- Criteria Met: 3/3 (100%)
- Stories Covered: [x] Document keyboard actions fully
- Known Gaps: none
- Lessons Learned: LookupSelect uses capture-phase DOM listener instead of scope system since it's nested inside other layers
