# Cycle 45 — lines-editor-ui

**Status**: done
**Commit**: bdec620
**Files**:

- apps/web/src/features/workspace/views/document/document-lines-view.tsx (new, 502 lines)
- apps/web/src/features/workspace/views/document/**tests**/document-lines-view.test.ts (new, 17 tests)
- apps/web/src/features/workspace/i18n.ts (added doc.lines.title, doc.lines.empty en/de)

**Tests**: 17 tests added, all passing
**vp check**: 0 errors in our file (9 pre-existing in other files)
**vp test**: 559/559 passing

**Acceptance Criteria**:

- [x] Lines editor table with columns: Artikel, Menge, Einheitspreis, Steuersatz, Zeilensumme
- [x] Article autocomplete field: search by number + name, returns article UUID on selection
- [x] Quantity field inline editable (numeric input)
- [x] Net price field inline editable (numeric input)
- [x] Lines stored in component state (not persisted until save)
- [x] Keyboard shortcuts: Enter confirm, Escape cancel
- [x] Totals footer: netto, tax, gross
- [x] `vp check` + `vp test` passing
- [x] Atomic commit, archive

**Self-Assessment**:

- Criteria Met: 9/9 (100%)
- Stories Covered: [x] #11 fully, [x] #15 fully
- Known Gaps: none
- Lessons Learned: Bash append for large JSX files works well. i18n edits need dedup check.
