# Cycle 46 — overlays

**Status**: done | **Commit**: 79bbdc0 | **Complexity**: M
**Durations**: Prep: 8min, Imp: 25min, Val: 7min | **Tests**: 10

**Acceptance Criteria**:

- [x] `?` (Shift+/): Opens HotkeyCheatsheet modal. Shows all shortcuts grouped by scope. Closes on `?` again or Esc.
- [x] Alt+I: Opens StatisticsDrawer. Context-aware: shows ArticleStatistics, CustomerStats, etc. based on active entity.
- [x] Both overlays use scope stack (close when their layer is popped)
- [x] Cheatsheet content derived from hotkey registry (not hardcoded)

**Self-Assessment**:

- Criteria Met: 4/4 (100%)
- Stories Covered: [x] Cheatsheet fully, [x] StatisticsDrawer fully
- Known Gaps: None
- Lessons Learned: Global hotkeys need registration in store for cheatsheet derivation; a11y rules require role attributes on overlay divs
