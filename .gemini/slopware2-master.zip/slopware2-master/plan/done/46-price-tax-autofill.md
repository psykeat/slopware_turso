# Cycle 46 — price-tax-autofill

**Status**: done | **Commit**: f959b93 | **Complexity**: S
**Durations**: Prep: 2min, Imp: 8min, Val: 3min | **Tests**: 7 added
**Acceptance Criteria**: [x] Auto-fill net_price from price list on article selection [x] Auto-fill tax_rate and tax_code_id from tax matrix [x] Leave price empty if no match [x] Display actual tax rate % in table
**Self-Assessment**:

- Criteria Met: 4/4 (100%)
- Stories Covered: [x] #12 fully, [x] #13 fully
- Known Gaps: none
- Lessons Learned: Source-code presence tests work well for behavioral verification of existing wiring. Bug was in lines-panel-adapter missing tax_rate field, not in document-lines-view.
