# Cycle 47 — Live-Kalkulation + Save

**Status**: done | **Commit**: d8ac434 | **Complexity**: M
**Durations**: Prep: 5min, Imp: 25min, Val: 10min | **Tests**: 30

**Acceptance Criteria**:

- [x] [Story #14] Line total calculated in real-time per row
- [x] [Story #14] Net total, Tax amount, Gross total in footer
- [x] [Story #19] "Speichern" button persists header + lines
- [x] [Story #19] No auto-save — only explicit button click
- [x] [Story #19] Save button disabled during save operation

**Self-Assessment**:

- Criteria Met: 5/5 (100%)
- Stories Covered: [x] #14 fully, [x] #19 fully
- Known Gaps: none
- Lessons Learned: Duplicate mutation declaration from prior cycle caused parse error — always grep for existing declarations before adding new ones
