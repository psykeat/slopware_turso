# Cycle 48 — lager-pro-zeile-tastaturnavigation

**Status**: done | **Commit**: 4f0435b | **Complexity**: L
**Durations**: Prep: 5min, Imp: 45min, Val: 20min | **Tests**: 15
**Stories**: #16 (per-line warehouse), #18 (keyboard navigation)

**Acceptance Criteria**:

- [x] Warehouse column in lines table with search dropdown
- [x] Default warehouse from document header
- [x] Tab/Shift+Tab field navigation (qty→price→tax→warehouse→next line)
- [x] Enter on article autocomplete selects first, focuses quantity
- [x] Delete key: empty line removed, filled line requires confirmation
- [x] Warehouse persisted in save payload (warehouseId)
- [x] 15 unit tests (warehouse + keyboard nav)
- [x] vp check = 0 errors
- [x] vp test = 603/603 passed
- [x] Cyclomatic complexity reduced (LineRow CM: 26→16 via component extraction)

**Self-Assessment**:

- Criteria Met: 10/10 (100%)
- Stories Covered: [x] #16 fully, [x] #18 fully
- Known Gaps: none
- Lessons Learned: Component extraction (NumericCell, SearchCell) effective for reducing cyclomatic complexity. Fallow complexity threshold (CM=20) met after extraction.
