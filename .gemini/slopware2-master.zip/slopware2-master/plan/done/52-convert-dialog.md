# Cycle 52 — convert-dialog

**Status**: done | **Commit**: c15c2d8 | **Complexity**: S
**Durations**: Prep: 5min, Imp: 12min, Val: 3min | **Tests**: 0 (L1)
**Acceptance Criteria**:

- [x] [Story #21] "Wandeln" button opens confirmation modal (not direct conversion)
- [x] [Story #22] Target group pre-selected from source group's `next_group_id`
- [x] [Story #22] User can pick another group of same target type from list
- [x] Target group list sorted by `group_number`, filtered by target type
- [x] Single target → preselected, still requires confirmation click
- [x] Modal shows: source doc number/type, target type, target group selector, confirm button

**Self-Assessment**:

- Criteria Met: 6/6 (100%)
- Stories Covered: [x] #21 fully, [x] #22 fully
- Known Gaps: none
- Lessons Learned: kept dialog simple — no internal mutation, parent handles conversion call
