# Cycle 54 — connector-subprocess-runner

**Status**: done | **Commit**: 3edb5da | **Complexity**: L
**Durations**: Prep: 5min, Imp: 20min, Val: 5min | **Tests**: 8

**Acceptance Criteria**:

- [x] `runConnector(tenantConnectorId)` creates `import_batch` (status: pending)
- [x] Tenant-scoped JWT with correct claims (aud: integration-service, scopes, 5min exp)
- [x] `Bun.spawn` with TENANT_JWT, BATCH_ID, ATOMICITY_MODE env vars
- [x] Hard-kill timeout with SIGKILL
- [x] Status transitions: pending → validating/failed
- [x] Error capture: stdout/stderr → error_summary
- [x] 8 unit tests (JWT, spawn, status, timeout, error handling)
- [x] `vp test` pass

**Self-Assessment**:

- Criteria Met: 7/7 (100%)
- Stories Covered: [x] #23 fully
- Known Gaps: commit enthält mixed changes (crud-dialog, server-functions) — nicht atomar
- Lessons Learned: Worker hat zusätzliche Änderungen eingebaut. Nächster Slice: strikt atomar.
