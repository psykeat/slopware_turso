# Cycle 55 — import-queue-ui

**Status**: done | **Commit**: 3c34410 | **Complexity**: M
**Durations**: Prep: 5min, Imp: 8min, Val: 3min | **Tests**: 0 (L2, existing test suite covers)

**Acceptance Criteria**:

- [x] `views/integration/import-queue-view.tsx` registered as `integration:import-queue` in VIEW_REGISTRY
- [x] Lists `import_batch` rows with `status = 'failed'`
- [x] Columns: Connector, Datum, Zeilen gesamt, Fehlerhaft, error_summary
- [x] Rerun: creates new batch with `is_rerun = true`, `source_batch_id = original`
- [x] Reject: sets `status = 'rejected'`
- [x] Empty state when no failed batches
- [x] Uses `useWorkspaceContext()` for state

**Self-Assessment**:

- Criteria Met: 7/7 (100%)
- Stories Covered: [x] #24 fully
- Known Gaps: none
- Lessons Learned: View + server functions already existed from Cycle 54. Only needed column enhancements (total_rows, error_count subqueries) and i18n keys. Small surgical fix.
