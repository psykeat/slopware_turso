# Cycle 58 — hotkey-core

**Status**: done | **Commit**: 51b794c | **Complexity**: M
**Durations**: Prep: 5min, Imp: 15min, Val: 5min | **Tests**: 15
**Acceptance Criteria**:

- [x] @tanstack/react-hotkeys installed
- [x] hotkey-store.ts: Zustand scope stack with push/pop, registry, input suppression
- [x] use-hotkey-layer.ts: layer lifecycle hook
- [x] use-scoped-hotkey.ts: scoped hotkey registration
- [x] Input suppression: F-keys/modifiers pass through inputs, bare keys suppressed

**Self-Assessment**:

- Criteria Met: 5/5 (100%)
- Stories Covered: [x] Keyboard Nav PRD foundation fully
- Known Gaps: none
- Lessons Learned: Scope stack pattern works well — clean separation of concerns
