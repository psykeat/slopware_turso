# Cycle 61 — dialog-lines-hotkeys

**Status**: done | **Commit**: c51b091 | **Complexity**: M
**Durations**: Prep: 3min, Imp: 10min, Val: 3min | **Tests**: 0 (L2, existing suite covers)
**Acceptance Criteria**:

- [x] F10: Triggers submit handler in CrudDialog
- [x] Ctrl+Enter: Saves current line in LinesPanelAdapter
- [x] Both hotkeys scoped via useHotkeyLayer
- [x] F10 does not fire when dialog not open

**Self-Assessment**:

- Criteria Met: 4/4 (100%)
- Stories Covered: [x] Keyboard Nav Dialog & Lines fully
- Known Gaps: none
- Lessons Learned: Scope stack handles dialog lifecycle cleanly
