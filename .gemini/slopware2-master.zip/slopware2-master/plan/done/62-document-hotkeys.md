# Cycle 62 — document-hotkeys

**Status**: done | **Commit**: fedf84e | **Complexity**: M
**Durations**: Prep: 3min, Imp: 10min, Val: 3min | **Tests**: 0 (L2, existing suite covers)
**Acceptance Criteria**:

- [x] F7/F9: Opens ConvertDocumentModal for active document
- [x] F5: Opens Auswahltabelle for active FK input
- [x] Hotkeys only fire when scope layer active

**Self-Assessment**:

- Criteria Met: 3/3 (100%)
- Stories Covered: [x] Keyboard Nav Document Hotkeys fully
- Known Gaps: none
- Lessons Learned: F-keys pass through inputs correctly via scope stack
