# Cycle 64 — cleanup-esc

**Status**: done | **Commit**: 27bd27f | **Complexity**: S
**Durations**: Prep: 5, Imp: 10, Val: 3 | **Tests**: 0
**Acceptance Criteria**: [x] All window.addEventListener("keydown") removed from workspace.tsx and crud-dialog.tsx [x] Esc: Pops topmost layer [x] Esc behavior is contextual [x] No regressions
**Self-Assessment**:

- Criteria Met: 4/4 (100%)
- Stories Covered: [x] Keyboard Navigation PRD cleanup fully
- Known Gaps: none
- Lessons Learned: compound key parsing needed in useScopedHotkey for Shift/Ctrl+ combinations
