# Cycle 66 — error-parser-banner

**Status**: done | **Commit**: 8e23904 | **Complexity**: M
**Durations**: Prep: 5min, Imp: 15min, Val: 5min | **Tests**: 9

**Affected Files**:

- `apps/web/src/features/workspace/components/error-parser.ts` — new: parseServerError utility
- `apps/web/src/features/workspace/components/__tests__/error-parser.test.ts` — new: 9 unit tests
- `apps/web/src/features/workspace/components/crud-dialog.tsx` — modified: deduplicated error handling, added error banner
- `apps/web/src/features/workspace/i18n.ts` — modified: added error banner i18n keys (en/de)

**Acceptance Criteria**:

- [x] `parseServerError` returns `{ fieldErrors, globalError, source, code }`
- [x] JSON/Zod parsing: structured issues mapped to visible fields
- [x] Domain error parsing: semicolon-separated strings
- [x] Fallback: unmappable errors → globalError
- [x] In-dialog error banner rendered above action buttons
- [x] Both createMutation and patchMutation use parseServerError
- [x] toast() replaced for save errors with banner state
- [x] Banner clears on success or dialog close
- [x] `vp check` = 0 errors
- [x] `vp test` passes (665/665)

**Self-Assessment**:

- Criteria Met: 10/10 (100%)
- Stories Covered: [x] #48 fully
- Known Gaps: none
- Lessons Learned: domain error detection requires semicolon separator — single key:value is ambiguous, correctly falls through to fallback
