# Cycle 67 — field-i18n-translations

**Status**: done | **Commit**: fb4880d | **Complexity**: S
**Durations**: Prep: 3min, Imp: 5min, Val: 2min | **Tests**: 0

**Affected Files**:

- `apps/web/src/features/workspace/i18n.ts` — modified (added field.\* translations + validation.failed key)

**Acceptance Criteria**:

- [x] `field.*` translations: name, status, description, email, phone, active, created_at, updated_at, company_id, type, group, date, customer, currency, warehouse, article, price, qty, tax_rate
- [x] `list.crud.validation.failed` key in both languages
- [x] FieldRenderer fallback: metadata label > base lang > static i18n > raw column name
- [x] All 3 callers verified
- [x] `vp check` = 0 errors

**Self-Assessment**:

- Criteria Met: 5/5 (100%)
- Stories Covered: [x] #49 fully
- Known Gaps: none
- Lessons Learned: Simple i18n addition — no code changes needed, only dictionary entries. FieldRenderer fallback chain was already correct.
