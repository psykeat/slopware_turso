# Feature Matrix - Slopware v2 Migration

## Legend

- `[ ]` TODO | `[x]` DONE | `[~]` WIP

## Database Schema (packages/db)

| Feature                                                                  | Status | Notes              |
| ------------------------------------------------------------------------ | ------ | ------------------ |
| Auth tables (user, session, account, verification)                       | [x]    | Better Auth        |
| System tables (org, tenant, user_tenant)                                 | [x]    | Done               |
| Master tables (entity_definition, field_definition, entity_field)        | [x]    | Done               |
| Transaction tables (entity_record, entity_record_line)                   | [x]    | Done               |
| Connector tables (connector, connector_run)                              | [x]    | Done               |
| organization table (slug, isActive)                                      | [x]    | Done               |
| app_user table (email, passwordHash, displayName, isSystemAdmin, locale) | [x]    | Done               |
| modules table                                                            | [x]    | Done               |
| systemSettings table (RLS)                                               | [x]    | Done               |
| entityCommands table (RLS)                                               | [x]    | Done               |
| tenantFields table (RLS)                                                 | [x]    | Done               |
| tenantGroups table (RLS)                                                 | [x]    | Done               |
| tenantLayouts table (RLS)                                                | [x]    | Done               |
| tenantRules table (RLS)                                                  | [x]    | Done               |
| helperTableRegistry                                                      | [x]    | Done               |
| schemaAnnotations                                                        | [x]    | Done               |
| RLS policies on all tenant tables                                        | [x]    | Done               |
| effectiveFields view                                                     | [x]    | Done               |
| effectiveLayout view                                                     | [x]    | Done               |
| effectiveRules view                                                      | [x]    | Done               |
| effectiveSettings view                                                   | [x]    | Done               |
| currentTenantCtx view                                                    | [x]    | Done               |
| relations.ts                                                             | [x]    | Done               |
| Migration SQL                                                            | [x]    | Done               |
| postmigrate seed                                                         | [x]    | Seeds org + tenant |

## Auth Layer (packages/auth)

| Feature                                           | Status | Notes                               |
| ------------------------------------------------- | ------ | ----------------------------------- |
| Better Auth config                                | [x]    | Done                                |
| Auth client (signIn, signOut, signUp, useSession) | [x]    | Done                                |
| $getUser                                          | [x]    | Done                                |
| authQueryOptions                                  | [x]    | Done                                |
| authMiddleware (full)                             | [x]    | authMiddleware, freshAuthMiddleware |
| Social providers                                  | [x]    | GitHub, Google                      |

## Domain Layer (packages/domain)

| Feature                                        | Status | Notes |
| ---------------------------------------------- | ------ | ----- |
| Constants (SYSTEM_ORG_ID, BASE_TENANT_ID)      | [x]    | Done  |
| listEntity (paginated, filtered, sorted)       | [x]    | Done  |
| getEntityById                                  | [x]    | Done  |
| createEntity (with validation)                 | [x]    | Done  |
| patchEntity (with validation)                  | [x]    | Done  |
| deleteEntity (soft/hard delete)                | [x]    | Done  |
| deactivateEntity                               | [x]    | Done  |
| validateAgainstEffectiveFields                 | [x]    | Done  |
| listHelperTables                               | [x]    | Done  |
| getHelperTableItems (i18n, search, pagination) | [x]    | Done  |
| entity descriptors (16)                        | [x]    | Done  |
| runtime (SqlClient, withTenant)                | [x]    | Done  |

## API Layer (packages/api)

| Feature                     | Status | Notes |
| --------------------------- | ------ | ----- |
| Entity handlers (full CRUD) | [x]    | Done  |
| Command handlers            | [x]    | Done  |
| Lookup handlers             | [x]    | Done  |
| Metadata handlers           | [x]    | Done  |
| Auth handlers               | [x]    | Done  |

## Web App - Routes

| Feature        | Status | Notes             |
| -------------- | ------ | ----------------- |
| \_\_root.tsx   | [x]    | HTML shell        |
| index.tsx      | [x]    | Auth guard        |
| \_auth routes  | [x]    | Protected layout  |
| \_guest routes | [x]    | Guest layout      |
| api/auth/$.ts  | [x]    | Better Auth proxy |
| router.ts      | [x]    | getRouter pattern |

## Web App - Server Functions

| Feature                            | Status | Notes                 |
| ---------------------------------- | ------ | --------------------- |
| getDb adapter                      | [x]    | Done                  |
| listEntityFn (actual DB query)     | [x]    | Generic + tenant ctx  |
| createEntityFn (actual DB write)   | [x]    | Generic + tenant ctx  |
| updateEntityFn (actual DB write)   | [x]    | Generic + tenant ctx  |
| deleteEntityFn (actual DB write)   | [x]    | Generic + tenant ctx  |
| $getTenantId (from request)        | [x]    | Header + search param |
| $getRequestContext (full)          | [x]    | Full context builder  |
| authMiddleware on server functions | [x]    | requireAuth on all    |

## Web App - Workspace UI

| Feature               | Status | Notes            |
| --------------------- | ------ | ---------------- |
| workspace.tsx         | [x]    | Basic shell      |
| pane.tsx              | [x]    | Basic pane       |
| registry.ts           | [x]    | Basic registry   |
| workspace.css         | [x]    | Design system    |
| i18n.ts               | [x]    | DE/EN            |
| metadata-renderers.ts | [x]    | Basic converters |
| GridRoot              | [x]    | Grid container   |
| GridTable             | [x]    | Table component  |
| GridToolbar           | [x]    | Toolbar          |
| GridSearch            | [x]    | Search           |
| GridFooter            | [x]    | Footer           |
| GridPagination        | [x]    | Pagination       |
| list-panel-adapter    | [x]    | List panel       |
| detail-panel-adapter  | [x]    | Detail panel     |
| lines-panel-adapter   | [x]    | Lines panel      |
| crud-dialog           | [x]    | CRUD dialog      |
| list-view             | [x]    | List view        |
| detail-view           | [x]    | Detail view      |
| kpi-view              | [x]    | KPI view         |
| tree-view             | [x]    | Tree view        |

## Admin Routes

| Feature                 | Status | Notes              |
| ----------------------- | ------ | ------------------ |
| admin/index.tsx         | [x]    | Admin dashboard    |
| admin/users.tsx         | [x]    | User management    |
| admin/organizations.tsx | [x]    | Org management     |
| admin/tenants.tsx       | [x]    | Tenant management  |
| admin/companies.tsx     | [x]    | Company management |
| admin/integration.tsx   | [x]    | Integration config |

## Tests & Quality

| Feature                            | Status | Notes          |
| ---------------------------------- | ------ | -------------- |
| Domain tests                       | [x]    | 42/42 passing  |
| Server function tests              | [x]    | 12 tests       |
| Route tests                        | [x]    | 13 tests       |
| Fallow audit config                | [x]    | .fallowrc.json |
| Document schema + sequences + seed | [x]    | Cycle 19       |
| createDocument + deleteDocument    | [x]    | Cycle 20       |
| updateDocument + detail pane       | [x]    | Cycle 21       |
| Document list + sidebar tree       | [x]    | Cycle 22       |
| postDocument + 13-type matrix      | [x]    | Cycle 23       |
| convertDocument + stornoDocument   | [x]    | Cycle 24       |
| Article autocomplete + pricing     | [x]    | Cycle 25       |
| Inventory balance table            | [x]    | Cycle 26       |
| Customer stats                     | [x]    | Cycle 27       |
| Onboarding seedDocumentDefaults    | [x]    | Cycle 28       |

## Summary

- Total features: ~90
- Done: 90 (100%)
- STATUS: MISSION COMPLETE

## Critical Path

1. Server functions: Wire domain layer to TanStack Start ✅
2. DB schema: Missing tables + RLS policies + views ✅
3. Grid components ✅
4. Panel adapters ✅
5. Admin routes ✅
6. API layer ✅
7. Tests (routes) ✅
8. Social providers ✅
9. Fallow audit config ✅
