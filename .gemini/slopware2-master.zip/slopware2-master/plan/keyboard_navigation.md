# Plan — Keyboard Navigation (Universal Tastatur-Templates)

Forced keyboard-first navigation across the entire app. Universal hotkeys, focus model in the grid, scope stack, discoverability via cheatsheet.

## Foundations

1. **Library:** `@tanstack/react-hotkeys` (alpha v0.7.x).
2. **Focus model in EntityDataTable:** `aria-activedescendant`. Real focus on `<div role="grid" tabIndex={0}>`; the active row is referenced by id + CSS class. Survives virtualization.
3. **Scope architecture:** Stack model. `useHotkeyLayer(id)` pushes on mount, pops on unmount. A registered hotkey only fires when its layer is topmost.
4. **Input suppression:** F-keys and modifier combos always pass through inputs. Bare letters, digits, Enter, Space only fire when no input has focus.

## Shortcut matrix

| Key            | Action                      | Scope                | Component / Implementation                                     |
| -------------- | --------------------------- | -------------------- | -------------------------------------------------------------- |
| **F3**         | Neuer Datensatz             | Grid                 | `ListPanelAdapter` -> `openCreateDialog`                       |
| **F4**         | Datensatz löschen           | Grid                 | `deleteEntityFn` (triggers `deactivateEntity` for master data) |
| **F5**         | Auswahltabelle laden        | Input with FK        | `AddressCombobox`, `LookupSelect`, etc.                        |
| **F7 / F9**    | Beleg wandeln               | Document grid / Mask | `ConvertDocumentModal`                                         |
| **F8**         | Datensatz duplizieren       | Grid                 | `duplicateEntityFn` server function                            |
| **F10**        | Speichern + Maske schließen | CrudDialog           | Submit handler in `CrudDialog`                                 |
| **Ctrl+Enter** | Positionszeile speichern    | LinesPanelAdapter    | Row submit in lines editor                                     |
| **Alt+I**      | Statistikmodul              | Grid / Mask          | `StatisticsDrawer` (dispatches to `ArticleStatistics` etc.)    |
| **↑ / ↓**      | Row up / down               | Grid only            | `EntityDataTable` focus state                                  |
| **Home / End** | First / last                | Grid                 | `EntityDataTable` focus state                                  |
| **Enter**      | Open Record                 | Grid                 | `onRowDoubleClick` equivalent                                  |
| **Space**      | Toggle selection            | Grid                 | `EntityDataTable` selection state                              |
| **?**          | Shortcut cheatsheet         | Global               | New `HotkeyCheatsheet` component                               |
| **Esc**        | Contextual back/close       | Topmost layer        | Pop layer, close modal, or discard prompt                      |

## Refactoring Scope

### 1. Hotkey Core (`apps/web/src/features/hotkeys/`)

- `hotkey-store.ts`: Zustand store for scope stack and registry.
- `use-hotkey-layer.ts`: Hook for managing scope lifecycle.
- `use-scoped-hotkey.ts`: Hook for registering keys with scope checks.

### 2. Grid Focus (`apps/web/src/features/workspace/components/data-table/entity-data-table.tsx`)

- Implement `aria-activedescendant`.
- Add navigation key handlers.
- Change click behavior: Single-click = select, Double-click = open.

### 3. Server Integration (`apps/web/src/server/server-functions.ts`)

- `duplicateEntityFn`: New server function.
- Domain Command: `duplicateEntity` in `packages/domain/src/commands/entity-command-service.ts`.

### 4. UI Components

- `StatisticsDrawer`: `apps/web/src/features/workspace/components/statistics-drawer.tsx`.
- `HotkeyCheatsheet`: `apps/web/src/features/workspace/components/hotkey-cheatsheet.tsx`.

## Implementation Steps

1. **Setup:** Add `@tanstack/react-hotkeys` to workspace and catalog.
2. **Core:** Implement Hotkey Store and Hooks.
3. **Grid:** Update `EntityDataTable` with focus model and basic navigation.
4. **Actions:** Implement `duplicateEntityFn` and domain logic.
5. **Wiring:** Add hotkey listeners to `ListPanelAdapter`, `CrudDialog`, and `LinesPanelAdapter`.
6. **Overlay:** Implement Cheatsheet and Statistics Drawer.
7. **Cleanup:** Remove ad-hoc `window.addEventListener("keydown")` from `workspace.tsx` and `crud-dialog.tsx`.
