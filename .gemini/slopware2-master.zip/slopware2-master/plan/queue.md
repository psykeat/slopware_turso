# Task Queue

Generated from PRD: Belegerfassung & Verbuchung

## Format

Each slice: `[ ] #<N> <title> | <Complexity: S|M|L|XL> | <Test: L1|L2|L3> | <HITL|AFK> | Blocked by: <#N or none>`

- **Complexity**: S (Minor), M (Normal), L (Large), XL (Epic)
- **Test Level**: L1 (Check only), L2 (Focused tests), L3 (Full suite)

## Slices

[x] #1 Schema + next_sequence_no + seedDocumentDefaults | L | L3 | AFK | Blocked by: none
[x] #2 createDocument + deleteDocument + tests | M | L3 | AFK | Blocked by: #1
[x] #3 Document detail pane + lines editor + updateDocument + save | XL | L2 | AFK | Blocked by: #2
[x] #4 Document list + sidebar tree + adapter | M | L2 | AFK | Blocked by: #3 [DONE Cycle 22]
[x] #5 postDocument + full posting matrix + tests | XL | L3 | AFK | Blocked by: #2
[x] #6 convertDocument + stornoDocument + UI actions + tests | L | L3 | AFK | Blocked by: #5
[x] #7 Article autocomplete with price + tax resolution | M | L2 | AFK | Blocked by: #3
[x] #8 Inventory balance table in article dialog | M | L2 | AFK | Blocked by: #5
[x] #9 Customer stats in address dialog | M | L2 | AFK | Blocked by: #5
[x] #10 Onboarding: wire seedDocumentDefaults into company creation | S | L2 | AFK | Blocked by: #1
[x] #11 Schema Migration — Statistics + Info Center gaps | L | L1 | AFK | Blocked by: none
[x] #12 postDocument() — AVCO + COGS + fiscal period + due_date + pg_notify | L | L3 | AFK | Blocked by: #11
[x] #13 Integration Service — MV Refresh Listener | M | L2 | AFK | Blocked by: #11
[x] #14 KPI Dashboard — echte Daten | M | L2 | AFK | Blocked by: #12, #13
[x] #15 Period Comparison View | M | L2 | AFK | Blocked by: #12, #13
[x] #16 Address Detail — Statistik + Offene Posten + Bewegungen + Belege | L | L2 | AFK | Blocked by: #12, #13 [DONE Cycle 34]
[x] #17 Article Detail — Statistik + Lagerstandsjournal + Bewegungen + Belege | L | L2 | AFK | Blocked by: #12, #13
[x] #18 Article Group Detail Stats | M | L2 | AFK | Blocked by: #12, #13
[x] #19 Fiscal Period Settings Entity + close_period Command | M | L2 | AFK | Blocked by: #11
[x] #20 Credentials Encryption + LiteLLM Admin Config | M | L3 | AFK | Blocked by: none [DONE Cycle 38]
[x] #21 Connector Definition Admin + Tenant Connector Config UI | L | L2 | AFK | Blocked by: #20
[x] #22 Tenant Connector Mappings UI + Two-Level Lock Enforcement | L | L3 | AFK | Blocked by: #21
[x] #23 Connector Subprocess Runner | L | L3 | AFK | Blocked by: #22
[x] #24 Import Approval Queue UI | M | L2 | AFK | Blocked by: #23 [DONE Cycle 56]
[x] #25 XRechnung Inbound Connector | L | L3 | AFK | Blocked by: #23 [IN PROGRESS Cycle 57]
[x] #26 XRechnung Outbound Generator [IN PROGRESS Cycle 68] | M | L3 | AFK | Blocked by: #12
[ ] #27 Schema Annotations Admin + LiteLLM Annotation Trigger | M | L2 | AFK | Blocked by: #20
[ ] #28 applyDeltaEffect + changeQuantity posted path + tests | M | L3 | AFK | Blocked by: #12
[ ] #29 Beleggruppen-Redesign — X00/X01 seed, TYPE_SEQUENCE, direction, X00 protection | L | L3 | AFK | Blocked by: #1
[ ] #30 Serien/Chargen-Tracking — article.tracking_mode, validation API, completeness check | XL | L3 | AFK | Blocked by: #5
[ ] #31 Stücklisten/BOM — article.bom_type, BOM explosion, createProductionOrder | XL | L3 | AFK | Blocked by: #5
[ ] #32 bookProductionDocument + POSTABLE_TYPES update | L | L3 | AFK | Blocked by: #31
[x] #33 Wandlungs-Dialog — confirmation modal + next_group_id preselection | S | L1 | AFK | Blocked by: #6 [IN PROGRESS Cycle 52]
[x] #34 DocumentHeaderForm — Typ, Gruppe, Datum, Kunde, Währung, Lager | M | L2 | AFK | Blocked by: #25 [DONE Cycle 42]
[x] #35 Create-Flow — Neuer Beleg Button + createDocumentFn wire-up | S | L2 | AFK | Blocked by: #34 [DONE Cycle 43]
[retry] #36 DocumentLinesEditor — zu dick, aufgeteilt in #36a + #36b
[x] #36a LinesEditor UI — Artikel-Autocomplete + inline Menge/Preis Edit | M | L2 | AFK | Blocked by: #35 [DONE Cycle 45]
[x] #36b Preis/Steuer Auto-Fill — resolveArticlePricing auf Artikel-Auswahl | S | L2 | AFK | Blocked by: #36a [DONE Cycle 46]
[x] #37 Live-Kalkulation + Save — Zeilensummen, Gesamt, expliziter Save | M | L2 | AFK | Blocked by: #36 [DONE Cycle 47]
[x] #38a Lager pro Zeile + Tastaturnavigation | M | L2 | AFK | Blocked by: #37 [DONE Cycle 48]
[x] #38b Kommentarzeilen + Delete-Key-Handling | S | L2 | AFK | Blocked by: #38a [DONE Cycle 49 - already implemented in C48]
[x] #39 Löschregeln UI — delete button visibility + confirmation | S | L2 | AFK | Blocked by: #35 [DONE Cycle 50]
[x] #40 Sidebar Tree Real Data — replace MOCK_DOC_TREE with listDocumentTreeFn | S | L2 | AFK | Blocked by: none [DONE Cycle 51]

---

## Keyboard Navigation PRD

[x] #41 Hotkey Core — @tanstack/react-hotkeys setup, scope stack store, hooks | M | L3 | AFK | Blocked by: none [IN PROGRESS Cycle 58]
[x] #42 Grid Focus Model — aria-activedescendant, ↑↓/Home/End/Enter/Space navigation | L | L2 | AFK | Blocked by: #41 [IN PROGRESS Cycle 59]
[x] #43 Grid Actions — F3/F4/F8 + duplicateEntityFn + domain command | M | L3 | AFK | Blocked by: #41, #42 [IN PROGRESS Cycle 60]
[x] #44 Dialog & Lines Hotkeys — F10 (save) in CrudDialog, Ctrl+Enter in LinesPanelAdapter | M | L2 | AFK | Blocked by: #41 [DONE Cycle 61]
[x] #45 Document Hotkeys — F7/F9 (convert) + F5 (lookup table) | M | L2 | AFK | Blocked by: #41 [IN PROGRESS Cycle 62]
[x] #46 Overlays — ? Cheatsheet + Alt+I StatisticsDrawer | M | L2 | AFK | Blocked by: #41 [IN PROGRESS Cycle 63]
[x] #47 Cleanup & Esc — Remove ad-hoc keydown listeners, Esc contextual back/close | S | L1 | AFK | Blocked by: #41-#46 [IN PROGRESS Cycle 64]

## Slice Details

### #1 Schema + next_sequence_no + seedDocumentDefaults

**What to build**: DB schema changes for document management, the PL/pgSQL sequence function, and the seed command that initializes 13 document types, groups, and number sequences per company.

**Acceptance criteria**

- [ ] `number_sequence` gets `document_type char(1)` column + UNIQUE(tenant_id, company_id, document_type)
- [ ] `address` gets `price_list_id uuid` nullable FK
- [ ] `next_sequence_no(p_tenant_id, p_company_id, p_doc_type)` PL/pgSQL function — atomic UPDATE...RETURNING, returns formatted number (prefix + zero-padded counter)
- [ ] `seedDocumentDefaults(tenantId, companyId)` domain command creates 13 document_type rows, 13 document_group rows, 13 number_sequence rows
- [ ] Conversion chain links: N→A→L→R, b→l→r; G/g/V/Z/E/U standalone

**Tests**: `next_sequence_no` concurrency (no duplicates), counter increment, format correctness. `seedDocumentDefaults` creates exactly 13 rows per table, correct links.

---

### #2 createDocument + deleteDocument + tests

**What to build**: Domain commands for creating and deleting documents with number allocation, plus delete protection rules.

**Acceptance criteria**

- [ ] `createDocument(sql, payload)` calls `next_sequence_no`, sets status=draft, saves header + lines sequentially in transaction
- [ ] `deleteDocument(sql, id)` blocks R, r, G, g; allows all other types regardless of status
- [ ] Server functions wired to domain commands with authMiddleware
- [ ] Document gets number immediately on creation (e.g., AUF-00042)

**Tests**: createDocument allocates number, sets draft, saves lines. deleteDocument rejects R/r/G/g, accepts others. Prior art: `packages/domain/src/__tests__/commands.test.ts`.

---

### #3 Document detail pane + lines editor + updateDocument + save

**What to build**: End-to-end document editing experience — detail pane, lines editor with inline editing, comment lines, keyboard navigation, explicit save.

**Acceptance criteria**

- [ ] Document detail pane: split layout with header fields + lines table + calculation footer
- [ ] DocumentLinesEditor: tabular editor, one row per line, inline editable qty/price
- [ ] Comment lines (no article, text only) via "+ Kommentar" button
- [ ] Live calculation: line_total_net, tax_amount, grand totals
- [ ] `updateDocument(sql, id, payload)` — only for draft documents
- [ ] Explicit save button (no auto-save)
- [ ] Tab-key navigation through fields

**Tests**: updateDocument only works for draft. Lines editor renders correctly. No tests for UI components per PRD.

---

### #4 Document list + sidebar tree + adapter

**What to build**: Document list view with search/filter, sidebar navigation tree, and workspace adapter.

**Acceptance criteria**

- [ ] DocumentListAdapter: parses `?p=document-list:N:0` suffix, filters server-side by type and group
- [ ] Document list: search, sort, server-side pagination, filter by direction/type/group
- [ ] Sidebar tree: 3-level (Warenausgang → doc type → group), Wareneingang, Lagerbuchungen (collapsed by default)
- [ ] Dynamic from `document_type` metadata and `document_group` rows
- [ ] Click opens document in detail pane

**Tests**: adapter parses view identifier correctly, server-side filtering works. No UI component tests per PRD.

---

### #5 postDocument + full posting matrix + tests

**What to build**: Complete document posting logic with the full 13-type inventory/statistics matrix, idempotency guards, and UI button.

**Acceptance criteria**

- [ ] `postDocument(sql, docId, userId)` entry point with guards (404, 409 idempotency, 409 storno)
- [ ] Full posting matrix implemented: N(no-op), A(reserve), L(issue), R(sales fact), G(return+correction), b(expected), l(receipt), r(no-op), g(return), V(set target), Z(receipt), E(issue), U(dual warehouse)
- [ ] `inventory_balance` upserts with `available_qty = on_hand_qty − reserved_qty`
- [ ] `inventory_movement` and `fact_sales_event` records created where applicable
- [ ] V: sets on_hand to target (not delta add)
- [ ] U: two upserts (source −qty, target +qty)
- [ ] b: expected_purchase_qty +qty (not reserved_qty)
- [ ] l: on_hand +qty AND expected_purchase −qty
- [ ] Status set to posted, posted_at, posted_by set
- [ ] "Buchen" button in detail pane

**Tests**: Idempotency (posted → 409), storno → 409, all matrix entries correct deltas, V special case, U dual upsert, b/l correctness. Prior art: `packages/domain/src/__tests__/commands.test.ts`.

---

### #6 convertDocument + stornoDocument + UI actions + tests

**What to build**: Document conversion (Wandlung) and storno logic with status-aware action buttons.

**Acceptance criteria**

- [ ] `convertDocument(sql, id, targetGroupId?)` — hardcoded fallback map (N→A, A→L, L→R, b→l, l→r), `next_group_id` override
- [ ] Source document set to archived, target gets same lines, transaction_id inherited
- [ ] `stornoDocument(sql, id, userId)` — only for posted R/r; creates G/g with same positive qty, storno_document_id set
- [ ] Original R/r gets cancelled status, cancelled_at
- [ ] G/g cannot be deleted, cannot be restorned
- [ ] Action buttons (Buchen, Wandeln, Stornieren) visible only when status allows
- [ ] Wandlung target group pre-selected from source group's next_group_id

**Tests**: convert archives source, copies lines, inherits transaction_id, next_group_id override. storno only for posted R/r, creates G with storno_document_id, sets cancelled. Non-R types rejected.

---

### #7 Article autocomplete with price + tax resolution

**What to build**: Server function that resolves article price and tax in a single call, wired into the lines editor autocomplete.

**Acceptance criteria**

- [ ] Server function takes article_id + customer_id + document_date context
- [ ] Price resolution: `address.price_list_id → price_list_item` lookup by article + date; empty if no match
- [ ] Tax resolution: `article.tax_class × address.tax_class × address.country → tax_rule(valid_from/to) → tax_code.tax_rate`
- [ ] Returns net_price, tax_rate, tax_code_id in single response
- [ ] Wired into DocumentLinesEditor article autocomplete
- [ ] Currency pre-filled from address or company

**Tests**: Price resolution returns correct price from list, empty if no match. Tax resolution traverses matrix correctly. No UI tests per PRD.

---

### #8 Inventory balance table in article dialog

**What to build**: Inventory balance table shown as child section in the article dialog.

**Acceptance criteria**

- [ ] Query: inventory balance per warehouse (on_hand, reserved, available)
- [ ] `InventoryBalanceTable` component: columns for warehouse, on_hand, reserved, available
- [ ] Reserved qty shown in amber, available qty in green
- [ ] Total row when > 1 warehouse
- [ ] `childSection` prop added to `crud-dialog.tsx` (optional render prop)
- [ ] Wired into article dialog

**Tests**: Query returns correct balance data. No component tests per PRD.

---

### #9 Customer stats in address dialog

**What to build**: Customer document history and yearly revenue shown as child section in the address dialog.

**Acceptance criteria**

- [ ] Query: last 10 documents for customer (date, number, type, status, gross)
- [ ] Query: yearly revenue (qty + net amount per year)
- [ ] `CustomerStatsSection` component with two subsections
- [ ] Only visible when `is_customer = true`
- [ ] Revenue section only shown when posted invoices exist
- [ ] Wired into address dialog via `childSection` prop

**Tests**: Queries return correct data. No component tests per PRD.

---

### #10 Onboarding: wire seedDocumentDefaults into company creation

**What to build**: Hook seedDocumentDefaults into the company creation flow so new companies get document defaults automatically.

**Acceptance criteria**

- [ ] `seedDocumentDefaults` called after company creation
- [ ] New company has 13 document_type rows with correct chain links
- [ ] New company has 13 document_group rows (Standard, group number 0)
- [ ] New company has 13 number_sequence rows with correct prefixes
- [ ] Error handling: if seed fails, company creation rolls back or reports error

**Tests**: New company creation results in 39 rows total (13×3). Correct prefixes, correct chain links. Prior art: existing company creation flow.

---

### #11 Schema Migration — Statistics + Info Center gaps

**What to build**: Drizzle migrations that fill the delta between current schema and the target state for both the Statistics Module and Info Center. After this slice every table and view the later slices depend on exists in the DB.

**Acceptance criteria**

- [ ] `document` gets `due_date date` nullable column
- [ ] `schema_annotations.module_id` gets FK reference to `modules.module_id`
- [ ] `schema_annotations.data_class` gets CHECK constraint `IN ('master','transaction','derived','metadata')`
- [ ] `import_batch.source_batch_id` gets self-referential FK to `import_batch.batch_id`
- [ ] 8 Materialized Views created via raw SQL migration: `mv_sales_period`, `mv_sales_period_customer`, `mv_sales_period_article`, `mv_sales_period_article_group`, `mv_sales_period_address_category`, `mv_purchase_period`, `mv_purchase_period_supplier`, `mv_purchase_period_article`
- [ ] Each MV has a `UNIQUE INDEX` on its grouping key (required for `CONCURRENTLY` refresh)
- [ ] Additional indexes: `document(tenant_id, status) WHERE status != 'posted'`, `document(tenant_id, customer_id, due_date) WHERE is_paid = false`
- [ ] `modules` seed rows for slugs: `inventory`, `documents`, `addresses`, `articles`, `metadata`, `financials`, `integration`
- [ ] `schema_annotations` table: no RLS (platform infrastructure), `column_name` defaults to `''` for table-level annotations, UNIQUE(table_name, column_name)
- [ ] `pnpm db generate && pnpm db migrate` runs clean

**Tests**: `pnpm db migrate` succeeds. MVs exist and are queryable. Constraints reject invalid data.

---

### #12 postDocument() — AVCO + COGS + fiscal period + due_date + pg_notify

**What to build**: Extend the existing `postDocument()` command with five new write paths: fiscal period resolution (with `is_closed` guard), AVCO calculation for vendor invoices (`r`), COGS snapshot for sales invoices (`R`), purchase fact insert for `r`/`g`, `due_date` calculation, and a `pg_notify` after every successful commit.

**Acceptance criteria**

- [ ] `resolveFiscalPeriodId(sql, tenantId, companyId, date)` — looks up `fiscal_period` by date range; lazy-generates 12 periods via `generateFiscalPeriods()` if none found; throws `errorCode: "PERIOD_CLOSED"` if matched period has `is_closed = true`
- [ ] `generateFiscalPeriods(sql, companyId, tenantId, fiscalYear)` — creates 12 rows from `company.fiscal_year_start_month`; handles fiscal years spanning two calendar years
- [ ] AVCO write for `r`-type: `SELECT ... FOR UPDATE` on `inventory_balance`, compute weighted average, `UPDATE gld_purchase`; if `newQty <= 0` leave `gld_purchase` unchanged (freeze)
- [ ] `fact_purchase_event` insert for `r`/`g` with `avg_cost_before` / `avg_cost_after`
- [ ] COGS snapshot for `R`-type: reads `gld_purchase` per article, writes `cogs_delta = gld_purchase × |quantity_delta|` into `fact_sales_event`
- [ ] `document.due_date` calculated from `document_date + payment_term.days` and persisted for invoice types (`R`, `r`)
- [ ] `SELECT pg_notify('stats_refresh', tenantId)` called inside the posting transaction (PostgreSQL delivers after commit)
- [ ] All new writes inside the existing posting transaction — one commit

**Tests**: AVCO correct for normal case; AVCO frozen when qty goes negative; `PERIOD_CLOSED` thrown for closed period; `due_date` correct for standard 30-day term. Prior art: `packages/domain/src/__tests__/posting-command.test.ts`.

---

### #13 Integration Service — MV Refresh Listener

**What to build**: Add a `pg_notify` listener to `packages/integration` that refreshes all 8 Materialized Views. On startup it does a full refresh; then switches to debounced event-driven refresh.

**Acceptance criteria**

- [ ] On startup: `REFRESH MATERIALIZED VIEW CONCURRENTLY` for all 8 MVs sequentially before entering listen mode
- [ ] `LISTEN stats_refresh` channel active after startup refresh
- [ ] Incoming notifications debounced to 5 seconds (timer reset on each event within the window)
- [ ] On debounce fire: refresh all 8 MVs (separate DB connection from the LISTEN connection)
- [ ] Integration service starts as part of `dev.sh` (added to the parallel dev command)
- [ ] If DB is unavailable on startup: service retries with exponential backoff

**Tests**: Startup refresh runs all 8 statements. Debounce collapses rapid notifications into a single refresh cycle.

---

### #14 KPI Dashboard — echte Daten

**What to build**: Replace the hardcoded mock KPIs in `views/stats/kpi-view.tsx` with a server function that queries MVs and live document data. Registered as `stats:kpi` in `VIEW_REGISTRY` (`kind: "custom"`). Uses `useWorkspaceContext()` for state.

**Acceptance criteria**

- [ ] `views/stats/kpi-view.tsx` registered as `stats:kpi` in `VIEW_REGISTRY` (`kind: "custom"`), uses `useWorkspaceContext()`
- [ ] `$getDashboardKpis()` server function with `authMiddleware`
- [ ] Queries `mv_sales_period` for current fiscal year → Umsatz, Rohertrag
- [ ] Queries `mv_sales_period` for prior fiscal year → YoY-Delta berechnet
- [ ] Live query `document` → open order count + value (status != 'posted', relevant types)
- [ ] Live query `document` with `is_paid = false` → open invoices count + value
- [ ] Live query `inventory_balance × gld_purchase` → total inventory value
- [ ] Queries `mv_sales_period_article_group` → top 5 article groups by Umsatz
- [ ] `kpi-view.tsx` renders real data; loading state shown while fetching
- [ ] Mocked data and `mock-data.ts` references removed from KPI view

**Tests**: Server function returns correct shape. No UI tests.

---

### #15 Period Comparison View

**What to build**: New standalone workspace view for side-by-side fiscal year comparison with a chart per period.

**Acceptance criteria**

- [ ] `$getPeriodComparisonStats(fiscalYear, companyId)` server function returns 12 period rows with `total_amount_net`, `total_profit`, `period_no`
- [ ] `views/stats/period-comparison-view.tsx` registered in `VIEW_REGISTRY` as `stats:period-comparison` (`kind: "custom"`), uses `useWorkspaceContext()`
- [ ] Fiscal year selector (dropdown of available years from `fiscal_period`)
- [ ] Chart: Umsatz vs. Rohertrag per Periode (1–12); bar or line, user-toggleable
- [ ] YoY toggle: overlays prior year as second data series
- [ ] Works when no prior-year data exists (graceful empty state)

**Tests**: Server function returns 12 rows for a full fiscal year. No UI tests.

---

### #16 Address Detail — Statistik + Offene Posten + Bewegungen + Belege

**What to build**: New workspace view `views/address/address-detail-view.tsx` with four data tabs. Registered as `address:detail` in `VIEW_REGISTRY` (`kind: "custom"`). Uses `useWorkspaceContext()` for state. Supersedes slice #9 (customer stats in address dialog).

**Acceptance criteria**

- [ ] `$getAddressStats(addressId)` server function with four sub-queries
- [ ] Tab **Statistik**: `mv_sales_period_customer` → Umsatz/Rohertrag per Periode als Chart
- [ ] Tab **Offene Posten**: live query `document` where `customer_id = addressId AND is_paid = false`; columns: Beleg-Nr., Typ, Datum, Fälligkeit (`due_date`), Bruttobetrag; sortiert nach `due_date`
- [ ] Tab **Bewegungen**: live query `document_line JOIN document` filtered by `customer_id`; columns: Datum, Beleg-Nr., Artikel, Menge, Preis
- [ ] Tab **Belege**: live query `document` filtered by `customer_id`; columns: Datum, Beleg-Nr., Typ, Status, Brutto
- [ ] Tabs nur sichtbar wenn `is_customer = true`
- [ ] Offene-Posten-Tab zeigt Hinweis wenn keine offenen Posten vorhanden

**Tests**: Server function returns correct data per sub-query. No UI tests.

---

### #17 Article Detail — Statistik + Lagerstandsjournal + Bewegungen + Belege

**What to build**: New workspace view `views/article/article-detail-view.tsx` with four data tabs. Registered as `article:detail` in `VIEW_REGISTRY` (`kind: "custom"`). Uses `useWorkspaceContext()` for state. Supersedes slice #8 (inventory balance in article dialog).

**Acceptance criteria**

- [ ] `$getArticleStats(articleId)` server function with four sub-queries
- [ ] Tab **Statistik**: `mv_sales_period_article` → Umsatz/Rohertrag per Periode; `mv_purchase_period_article` → Einkaufsmenge per Periode
- [ ] Tab **Lagerjournal**: `StockLedgerTable` component
  - Default: Gesamt-Saldo (alle Lager summiert), window function `SUM(qty_delta) OVER (ORDER BY movement_date, created_at)` als laufender Lagerstand
  - Toggle: per-Lager-Ansicht (Warehouse-Dropdown, Saldo warehouse-spezifisch via Partitionierung)
  - Columns: Datum | Beleg-Nr. | Typ | Lagerort | Zugang | Abgang | Lagerstand
  - Serial-Modus: extra Seriennummer-Spalte; Batch-Modus: extra Charge-Spalte
  - Pinned footer row: aktuelle `reserved_qty` + `expected_purchase_qty` aus `inventory_balance`
- [ ] Tab **Bewegungen**: `document_line JOIN document` filtered by `article_id`
- [ ] Tab **Belege**: `document` filtered by `article_id` via lines join

**Tests**: Lagerstandsjournal query returns correct running balance. Serial/batch filter correct. No UI tests.

---

### #18 Article Group Detail Stats

**What to build**: New workspace view `views/article/article-group-detail-view.tsx` with aggregated stats tabs. Registered as `article:group-detail` in `VIEW_REGISTRY` (`kind: "custom"`). Uses `useWorkspaceContext()` for state.

**Acceptance criteria**

- [ ] `$getArticleGroupStats(articleGroupId)` server function
- [ ] Tab **Statistik**: `mv_sales_period_article_group` → Umsatz/Rohertrag per Periode
- [ ] Tab **Bewegungen**: `document_line JOIN article` filtered by `article_group_id`
- [ ] Tab **Belege**: `document` filtered by `article_group_id` via lines→article join
- [ ] Empty state wenn keine Artikel in der Gruppe gebucht wurden

**Tests**: Server function returns correct aggregates. No UI tests.

---

### #19 Fiscal Period Settings Entity + close_period Command

**What to build**: Fiscal periods as a manageable settings entity with a close-period action.

**Acceptance criteria**

- [ ] `fiscal_period` in `ENTITY_REGISTRY` under `category: "settings"`, group `"organisation"`
- [ ] List view shows: Fiscal Year, Periode Nr., Von, Bis, Status (offen/geschlossen)
- [ ] `close_period` entity command registered in `entity_commands` seed (`commandKey: "close_period"`, `minRole: "tenant_admin"`)
- [ ] Server function for `close_period` sets `is_closed = true`; idempotent if already closed
- [ ] Closed periods show badge "Geschlossen" in list; close action hidden for already-closed periods
- [ ] No re-open action in scope

**Tests**: `close_period` sets flag correctly. Already-closed idempotent. Posting against closed period returns `PERIOD_CLOSED`.

---

### #20 Credentials Encryption + LiteLLM Admin Config

**What to build**: Application-level credential encryption for connector secrets, plus a single admin UI route to configure the LiteLLM endpoint.

**Acceptance criteria**

- [ ] `encryptCredentials(data, key)` and `decryptCredentials(ciphertext, key)` in `packages/integration/src/crypto.ts` using AES-GCM via `SubtleCrypto`
- [ ] `CREDENTIALS_ENCRYPTION_KEY` (32-byte hex) added to `.env` and documented
- [ ] All reads of `tenant_connector.credentials` decrypt before returning; all writes encrypt before storing
- [ ] Admin route (platform-admin only) to set: LiteLLM base URL, API key, default model slug
- [ ] Config stored in `system_settings` under scope `global`, keys `litellm.base_url`, `litellm.api_key`, `litellm.default_model`
- [ ] Admin route has a "Test Connection" button that calls `/models` on the configured endpoint

**Tests**: Encrypt → decrypt round-trip identical. Wrong key throws. No UI tests.

---

### #21 Connector Definition Admin + Tenant Connector Config UI

**What to build**: Platform-admin CRUD for connector definitions (`views/settings/connector-definitions-view.tsx`) and tenant-facing UI to activate connectors and enter credentials (`views/integration/tenant-connectors-view.tsx`). Both registered in `VIEW_REGISTRY` (`kind: "custom"`). Uses `useWorkspaceContext()` for state.

**Acceptance criteria**

- [ ] `views/settings/connector-definitions-view.tsx` registered as `settings:connector-definitions` in `VIEW_REGISTRY` (`kind: "custom"`), uses `useWorkspaceContext()` — platform-admin only
- [ ] `views/integration/tenant-connectors-view.tsx` registered as `integration:tenant-connectors` in `VIEW_REGISTRY` (`kind: "custom"`), uses `useWorkspaceContext()`
- [ ] `connector_definition` in `ENTITY_REGISTRY` under `category: "settings"`, visible only to platform admins
- [ ] Fields: slug, label (DE/EN), script_path, atomicity_mode, locked_fields (JSONB editor), default_mappings (JSONB editor)
- [ ] `tenant_connector` settings view: list of available connector definitions; tenant can activate (creates row) or deactivate
- [ ] Credentials form per connector: fields derived from `connector_definition.default_mappings` schema hints; values encrypted before save
- [ ] `cron_expression` field for scheduled connectors (nullable)

**Tests**: Connector activation creates `tenant_connector` row. Credentials stored encrypted. No UI tests.

---

### #22 Tenant Connector Mappings UI + Two-Level Lock Enforcement

**What to build**: Mapping editor view `views/integration/connector-mappings-view.tsx` where tenants override source-field → target-column mappings, with both lock checks enforced server-side. Registered as `integration:connector-mappings` in `VIEW_REGISTRY` (`kind: "custom"`). Uses `useWorkspaceContext()` for state.

**Acceptance criteria**

- [ ] `views/integration/connector-mappings-view.tsx` registered as `integration:connector-mappings` in `VIEW_REGISTRY` (`kind: "custom"`), uses `useWorkspaceContext()`
- [ ] Mapping editor lists all source fields from `connector_definition.default_mappings`; fields in `locked_fields` shown read-only with lock icon
- [ ] Editable fields: target_table, target_column (dropdown from `schema_annotations`), transform type + params, default_value
- [ ] `PATCH /api/connectors/:tenantConnectorId/mappings` handler enforces two independent guards:
  - Check 1: `source_field IN connector_definition.locked_fields` → HTTP 409 `{ reason: "source_locked" }`
  - Check 2: `connector_definition.slug IN schema_annotations.locked_for` for the target column → HTTP 409 `{ reason: "target_locked" }`
- [ ] target_column dropdown shows `business_name` from `schema_annotations` where available
- [ ] Mandatory fields (from `schema_annotations.mandatory_for`) highlighted; save blocked if any mandatory field unmapped
- [ ] `import_row.mapped_payload` is derived on-demand from `payload` + active mapping — **never stored**

**Tests**: Both 409 paths return correct reason. Mandatory field validation correct. No UI tests.

---

### #23 Connector Subprocess Runner

**What to build**: The integration service gains the ability to spawn a connector script as a Bun subprocess with a tenant-scoped JWT, write rows to `import_batch`/`import_row`, and enforce a hard-kill timeout.

**Acceptance criteria**

- [ ] `runConnector(tenantConnectorId)` function in `packages/integration`
- [ ] Creates `import_batch` (status: `pending`) before spawning
- [ ] Generates tenant-scoped JWT (`audience: "integration-service"`, scopes: `["staging:write", "staging:read"]`, exp: 5 min) via existing `createJWT()`
- [ ] `Bun.spawn(['bun', scriptPath], { env: { TENANT_JWT: signedJwt } })` with stdout/stderr captured
- [ ] Hard-kill after 5 min (configurable via `CONNECTOR_TIMEOUT_MS` env)
- [ ] On completion: sets `import_batch.status = 'validating'`; on timeout/crash: `status = 'failed'`, writes `error_summary`
- [ ] `posted_entity_count` incremented atomically per successfully posted `import_row`
- [ ] Rerun batches (`is_rerun = true`) excluded from billing aggregate queries
- [ ] `import_batch` supports `approved` status as internal crash-recovery marker (not user-visible)
- [ ] `import_batch` supports `target_entity` + `target_command_key` fast-path for homogeneous batches; row-level overrides batch-level
- [ ] Atomicity rules: `file` (XRechnung, onboarding), `entity` (Shopify/Amazon), `run` (batch-level)

**Tests**: Subprocess timeout triggers hard-kill and `failed` status. JWT contains correct claims. `Bun.spawn` mocked in tests.

---

### #24 Import Approval Queue UI

**What to build**: New workspace view `views/integration/import-queue-view.tsx`. Registered as `integration:import-queue` in `VIEW_REGISTRY` (`kind: "custom"`). Uses `useWorkspaceContext()` for state. Tenant-admin view showing failed import batches with options to rerun or reject.

**Acceptance criteria**

- [ ] `views/integration/import-queue-view.tsx`: lists `import_batch` rows with `status = 'failed'`
- [ ] Columns: Connector, Datum, Zeilen gesamt, Fehlerhaft, Fehlerbeschreibung (`error_summary`)
- [ ] **Rerun**: creates new `import_batch` with `is_rerun = true`, `source_batch_id = original`; replays original `import_row` payloads through current mapping; new batch goes through normal validation → post flow
- [ ] **Ablehnen**: sets `status = 'rejected'`; batch leaves queue
- [ ] Rerun batch's `posted_entity_count` excluded from billing aggregation (filtered by `is_rerun = true`) — economically critical: mapping errors on large batches must not bill tenant repeatedly
- [ ] No force-approve: validation cannot be bypassed
- [ ] Empty state when no failed batches

**Tests**: Rerun creates new batch with correct flags. Billing query excludes rerun batches. No UI tests.

---

### #25 XRechnung Inbound Connector

**What to build**: Platform connector for ingesting supplier XRechnung/ZUGFeRD XML files through the standard connector pipeline.

**Acceptance criteria**

- [ ] `connector_definition` seed row for XRechnung (`slug: "xrechnung"`, `atomicity_mode: "file"`)
- [ ] `locked_fields` contains all legally fixed source fields (invoice number, date, seller, amounts, tax)
- [ ] Connector script: parses UBL 2.1 / CII XML, maps to `import_row` payloads (`target_entity: "document"`)
- [ ] Validation pass → `import_batch.status = 'approved'` → auto-posted as `r`-Beleg
- [ ] Validation failure → `status = 'failed'`, lands in approval queue
- [ ] `schema_annotations.locked_for` set to `["xrechnung"]` for legally fixed target columns (e.g. `document.document_number`)

**Tests**: Valid XRechnung XML produces correct `import_row` payload. Invalid XML lands in `failed`. Locked field override returns 409.

---

### #26 XRechnung Outbound Generator

**What to build**: On-demand generator that produces a standards-compliant XRechnung XML (UBL 2.1) from a posted sales invoice.

**Acceptance criteria**

- [ ] `buildXRechnungXml(document, lines, company, customer)` pure function in `packages/domain` — no side effects, returns XML string
- [ ] Output validates against EN 16931 / XRechnung 3.x schematron rules (offline validation in tests)
- [ ] `$generateXRechnung(documentId)` server function: fetches document + lines + addresses, calls `buildXRechnungXml`, returns XML as download
- [ ] Only callable for `R`-type documents with `status = 'posted'`; returns 422 otherwise
- [ ] ZUGFeRD PDF embedding out of scope for this slice

**Tests**: `buildXRechnungXml` output is valid XRechnung XML for a representative fixture. Non-posted document returns 422.

---

### #27 Schema Annotations Admin + LiteLLM Annotation Trigger

**What to build**: Admin view `views/settings/schema-annotations-view.tsx` to view and manually override schema annotations, plus a trigger that calls LiteLLM to annotate unannotated columns. Registered as `settings:schema-annotations` in `VIEW_REGISTRY` (`kind: "custom"`). Uses `useWorkspaceContext()` for state.

**Acceptance criteria**

- [ ] `views/settings/schema-annotations-view.tsx` registered as `settings:schema-annotations` in `VIEW_REGISTRY` (`kind: "custom"`), uses `useWorkspaceContext()`
- [ ] `schema_annotations` list view: grouped by `modules.slug`, columns: table_name, column_name, business_name, description, data_class, human_override badge
- [ ] Inline edit for `business_name`, `description`, `data_class`, `module_id`; toggling edit sets `human_override = true`
- [ ] "Annotieren" button triggers server function: reads rows where `human_override = false AND ai_generated_at IS NULL`, calls LiteLLM endpoint per row, writes results back
- [ ] LiteLLM call uses config from `system_settings` (`litellm.base_url`, `litellm.api_key`, `litellm.default_model`)
- [ ] Rows with `human_override = true` skipped by annotation trigger
- [ ] Progress shown in UI (count annotated / total)

**Tests**: Annotation trigger skips `human_override = true` rows. LiteLLM call mocked in tests. No UI tests.

---

### #28 applyDeltaEffect + changeQuantity posted path + tests

**What to build**: Compensation mechanism for correcting quantities on posted documents. When a line quantity changes on a posted document, write an inverse compensating movement to the ledger so inventory stays correct.

**Acceptance criteria**

- [ ] `applyDeltaEffect(sql, lineId, oldQty, newQty, userId)` — writes inverse compensation movement to `inventory_movement` + updates `inventory_balance`
- [ ] `changeQuantity` command branches on `document.status`: `'draft'` → direct update; `'posted'` → calls `applyDeltaEffect`
- [ ] Compensation movement uses same `transaction_id` as original, linked via `parent_document_id`
- [ ] Old + new movement sum to 0 (neutrality)
- [ ] Posted document remains `status = 'posted'` after correction (no re-post needed)

**Tests**: Correct inverse delta written. Neutrality: old + new = 0. Draft path skips compensation. Prior art: `packages/domain/src/__tests__/posting-command.test.ts`.

---

### #29 Beleggruppen-Redesign — X00/X01 seed, TYPE_SEQUENCE, direction, X00 protection

**What to build**: Structured document group system with protected X00 base groups, TYPE_SEQUENCE sorting, automatic direction derivation, and `listDocumentGroupsFn` server function.

**Acceptance criteria**

- [ ] `seedDocumentDefaults` creates 2 groups per type: X00 (base, non-deletable) + X01 (standard, deletable)
- [ ] Production types `q` (Produktionsauftrag) and `p` (Produktionsbeleg) added to seed with X00 + number sequences
- [ ] X00 delete protection: `deleteEntity` returns 409 when `group_number = 0`
- [ ] `require_serial_tracking` / `require_batch_tracking` on X00 groups (default `false` for N, A, b)
- [ ] TYPE_SEQUENCE map: OUTBOUND N=1,A=2,L=3,R=4,G=5 | INBOUND b=1,l=2,r=3,g=4 | ADJUSTMENT V=1,Z=2,E=3,U=4 | PRODUCTION q=1,p=2
- [ ] Direction derived automatically from document_type on save
- [ ] `listDocumentGroupsFn` server function returns `{ direction, types: [{ code, sequence, groups: [{ groupId, groupNumber, name, docCount }] }] }` grouped by direction, sorted by TYPE_SEQUENCE + group_number
- [ ] Document list filter accepts `document_group_id`; API derives `document_type` internally
- [ ] `docFilter` in workspace changed from String-Key to UUID (`documentGroupId`)

**Tests**: X00 delete returns 409. `listDocumentGroupsFn` correct grouping and sorting. Direction derived correctly. Prior art: `packages/domain/src/__tests__/seed-document-defaults.test.ts`.

---

### #30 Serien/Chargen-Tracking — article.tracking_mode, validation API, completeness check

**What to build**: Inline serial/batch tracking in document lines with scan mode, completeness validation before posting, and SN lifecycle management.

**Acceptance criteria**

- [ ] `article.tracking_mode` field: `select` with options `null` (Kein Tracking), `serial`, `batch` (DE/EN)
- [ ] `document_group.require_serial_tracking` / `require_batch_tracking` flags
- [ ] Validation API: `POST /api/serial-numbers/validate` (inbound: SN must not exist; outbound: SN must be `in_stock`)
- [ ] Validation API: `GET /api/batch/validate?article_id&batch_no&warehouse_id&qty` — calculates batch balance via `SUM(qty_delta)` from `inventory_movement`
- [ ] `GET /api/document-lines/:id/tracking` — returns `document_line_tracking` entries
- [ ] Completeness check in posting service: `COUNT(dlt) = line.qty` for serial; `SUM(dlt.qty) = line.qty` for batch. Violation → 409
- [ ] WE posting (l/r/g): new `serial_number` rows with `status = 'in_stock'`, `created_movement_id` set
- [ ] WA posting (L/R/G): `status = 'sold'`, `consumed_movement_id` set
- [ ] Gutschrift (G/g): auto-reset SNs from source document via `parent_document_id` — no re-scan needed
- [ ] Scan mode in lines editor: `onKeyDown` catches Enter, prevents form submit
- [ ] Progress indicator: "N of M scanned"
- [ ] "Verbuchen" button disabled with tooltip when tracking incomplete

**Tests**: Completeness check returns 409 when tracking incomplete. SN status transitions correct (in_stock → sold → in_stock on credit). Batch balance calculation correct. No UI tests.

---

### #31 Stücklisten/BOM — article.bom_type, BOM explosion, createProductionOrder

**What to build**: BOM management on article level with automatic explosion for sales sets and production orders, inline BOM table in article dialog.

**Acceptance criteria**

- [ ] `article.bom_type` field: `select` with options `none`, `production`, `sales` (DE/EN)
- [ ] `addLine` command extension: if `article.bom_type = 'sales'` → insert `bom_component` sub-lines (`net_price = 0`); if `bom_type = 'production'` in production context → insert `production_input` lines
- [ ] `changeQuantity` on BOM lines: proportional scaling `newOutputQty × bom.quantity` (not ratio of current line qty to avoid rounding drift)
- [ ] `createProductionOrder(sql, auftragId, userId)` — checks if `q` document with `parent_document_id = auftragId` exists → 409; else creates `q` document with BOM explosion from order lines
- [ ] Inline BOM table in article dialog for managing components
- [ ] Individual BOM lines can be deactivated (not deleted) to preserve history
- [ ] `scrap_percentage` field exists in `article_bom` but is ignored in Phase 1
- [ ] Flat BOM only (non-recursive explosion)

**Tests**: `addLine` for sales BOM creates bom_component lines. Production BOM creates production_input lines. Quantities correct (`qty × bom.quantity`). `createProductionOrder` returns 409 on duplicate. Prior art: `packages/domain/src/__tests__/commands.test.ts`.

---

### #32 bookProductionDocument + POSTABLE_TYPES update

**What to build**: Production document posting logic and frontend POSTABLE_TYPES update.

**Acceptance criteria**

- [ ] `bookProductionDocument(doc, lines, tx)`: `production_input` → `inventory_movement −qty`; `production_output` → `inventory_movement +qty`; all in one transaction
- [ ] Sales BOM posting (L/R): header line (`line_type = 'article'`, `bom_type = 'sales'`) → no `inventory_movement`, but `fact_sales_event`. `bom_component` lines → `inventory_movement −qty`
- [ ] `POSTABLE_TYPES` in frontend extended with `p` (Produktionsbeleg). `q` (Produktionsauftrag) remains non-postable
- [ ] Production types `q` and `p` visible in "Produktion" sidebar section (separate from sales/purchase)

**Tests**: Production posting creates correct input/output movements. Sales BOM posting creates fact_sales_event for header, inventory_movement for components. Prior art: `packages/domain/src/__tests__/posting-command.test.ts`.

---

### #33 Wandlungs-Dialog — confirmation modal + next_group_id preselection

**What to build**: Conversion dialog with mandatory confirmation, `next_group_id` preselection, and multi-target group selection.

**Acceptance criteria**

- [ ] Always shown as modal with confirmation, even when `next_group_id` is set
- [ ] `next_group_id` of source group preselects target group; user can pick another group of same target type
- [ ] Target group list shows all groups of next type in TYPE_SEQUENCE, sorted by group_number
- [ ] Multiple possible target groups → selection list
- [ ] Single target → preselected, still requires confirmation click

**Tests**: No UI tests per PRD.

---

### #34 DocumentHeaderForm — Typ, Gruppe, Datum, Kunde, Währung, Lager

**User Stories Covered**: [Story #5, #6, #8, #9, #10]

**What to build**: A document header form component that allows creating a new document by selecting type, group, date, customer (autocomplete), currency, and warehouse. The form pre-fills values from the selected document group's defaults.

**Acceptance criteria**

- [ ] [Story #5] "Neuer Beleg" button visible in document list view; clicking opens document detail pane with empty form
- [ ] [Story #5] Document type selector shows all 13 document types grouped by direction (Warenausgang/Wareneingang/Lagerbuchungen)
- [ ] [Story #6] Document group selector shows groups for selected type; selecting group auto-fills default warehouse, default tax, and conversion target
- [ ] [Story #6] `document_group.default_warehouse_id` → pre-fills `document.warehouse_id`
- [ ] [Story #8] Customer autocomplete field: shows "Number + Name" format, calls `lookupHelperTableFn` or dedicated server function, returns UUID on selection
- [ ] [Story #9] Currency field pre-filled from selected customer's address or company default; editable
- [ ] [Story #10] Warehouse field pre-filled from document group's `default_warehouse_id`; editable override
- [ ] Document date field defaults to today, editable
- [ ] Form state held in component state (not persisted until explicit save)

**Tests**: No UI tests per PRD. Server function for customer lookup returns correct format.

---

### #35 Create-Flow — Neuer Beleg Button + createDocumentFn wire-up

**User Stories Covered**: [Story #5, #7]

**What to build**: Wire the document header form to `createDocumentFn` so that clicking "Speichern" creates a draft document with an allocated number.

**Acceptance criteria**

- [ ] [Story #5] "Speichern" button in document detail pane calls `createDocumentFn` with header data + empty lines
- [ ] [Story #7] After save, document number is displayed (e.g., "AUF-00042") — fetched from `next_sequence_no` via `createDocument`
- [ ] [Story #7] Document status is `draft` after creation
- [ ] [Story #5] After successful creation, detail pane switches to edit mode with populated header
- [ ] Create mutation invalidates document list query to show new document
- [ ] Error handling: if create fails, show error message, keep form data

**Tests**: `createDocumentFn` creates document with number, status=draft. Prior art: `packages/domain/src/__tests__/commands.test.ts`.

---

### #36 DocumentLinesEditor — Artikel-Autocomplete, Preis/Steuer, inline Edit

**User Stories Covered**: [Story #11, #12, #13, #15]

**What to build**: Replace the mock lines editor with a real tabular editor that supports article autocomplete with price/tax resolution and inline editing of quantity and price.

**Acceptance criteria**

- [ ] [Story #11] Article autocomplete field in each line: search by article number + name, returns article UUID on selection
- [ ] [Story #12] On article selection, call `resolveArticlePricing(article_id, customer_id, document_date)` → pre-fills `net_price` from customer's price list
- [ ] [Story #13] On article selection, same call resolves tax: `article.tax_class × address.tax_class × country → tax_rate` → pre-fills `tax_code_id` and `tax_rate`
- [ ] [Story #15] Quantity field inline editable (numeric input)
- [ ] [Story #15] Net price field inline editable (numeric input)
- [ ] Lines stored in component state, synced to server on explicit save (not auto-saved)
- [ ] Remove `mockLinesData` from `lines-panel-adapter.tsx` — use real empty array or fetched data
- [ ] Lines table shows: Artikel, Menge, Einheitspreis, Steuersatz, Zeilensumme

**Tests**: `resolveArticlePricing` returns correct price and tax. No UI tests per PRD.

---

### #37 Live-Kalkulation + Save — Zeilensummen, Gesamt, expliziter Save

**User Stories Covered**: [Story #14, #19]

**What to build**: Real-time calculation of line totals, net total, tax, and gross. Explicit save button that persists all changes.

**Acceptance criteria**

- [ ] [Story #14] Line total (`line_total_net = quantity × net_price`) calculated in real-time per row
- [ ] [Story #14] Net total (`SUM(line_total_net)`) displayed in footer row
- [ ] [Story #14] Tax amount (`SUM(line_total_net × tax_rate / 100)`) displayed in footer row
- [ ] [Story #14] Gross total (`net_total + tax_amount`) displayed in footer row
- [ ] [Story #19] "Speichern" button persists header + lines via `updateDocumentFn` (for existing) or `createDocumentFn` (for new)
- [ ] [Story #19] No auto-save during editing — only explicit button click persists
- [ ] Save button disabled during save operation (loading state)
- [ ] After save: mutation invalidates queries, shows success feedback

**Tests**: `updateDocumentFn` persists header + lines correctly. No UI tests per PRD.

---

### #38 Kommentarzeilen + Tastaturnavigation + Lager pro Zeile

**User Stories Covered**: [Story #16, #17, #18]

**What to build**: Support for comment lines (no article), keyboard navigation through line fields, and per-line warehouse assignment.

**Acceptance criteria**

- [ ] [Story #16] Warehouse column in lines table: defaults to header warehouse, editable per line
- [ ] [Story #17] "+ Kommentar" button adds a comment line (no article, text field only)
- [ ] [Story #17] Comment lines render with distinct styling (italic, muted text, no quantity/price fields)
- [ ] [Story #18] Tab key navigation: Menge → Preis → Steuer → Lager → naechste Zeile Menge
- [ ] [Story #18] Enter key on article autocomplete: selects first result, moves focus to quantity
- [ ] [Story #18] Delete key on empty line: removes line; on filled line: confirms deletion

**Tests**: No UI tests per PRD.

---

### #39 Löschregeln UI — delete button visibility + confirmation

**User Stories Covered**: [Story #25, #26]

**What to build**: Delete button in document detail pane with visibility rules and confirmation dialog.

**Acceptance criteria**

- [ ] [Story #25] Delete button visible for document types N, A, L, b, l, V, Z, E, U regardless of status
- [ ] [Story #26] Delete button HIDDEN for document types R, r, G, g (all statuses)
- [ ] [Story #25] Clicking delete shows confirmation dialog with document number and type
- [ ] [Story #25] Confirmed delete calls `deleteDocumentFn`, invalidates list query
- [ ] [Story #26] If `deleteDocumentFn` returns 409 (should not happen for allowed types), show error message

**Tests**: `deleteDocumentFn` rejects R/r/G/g with 409. No UI tests per PRD.

---

### #41 Hotkey Core — @tanstack/react-hotkeys setup, scope stack store, hooks

**What to build**: Install `@tanstack/react-hotkeys` and build the foundation: Zustand store for scope stack, `useHotkeyLayer(id)` hook for scope lifecycle, and `useScopedHotkey` hook for registering keys with scope checks.

**Acceptance criteria**

- [ ] `@tanstack/react-hotkeys` installed in `apps/web` and workspace
- [ ] `hotkey-store.ts`: Zustand store with scope stack (push/pop), registry, and input suppression logic
- [ ] `use-hotkey-layer.ts`: Hook that pushes layer on mount, pops on unmount. Hotkey only fires when layer is topmost.
- [ ] `use-scoped-hotkey.ts`: Hook for registering keys with scope checks. F-keys/modifier combos pass through inputs. Bare letters/digits/Enter/Space suppressed when input focused.
- [ ] Input suppression: F-keys and modifier combos always pass through inputs. Bare letters, digits, Enter, Space only fire when no input has focus.

**Tests**: Scope stack push/pop correct. Layer isolation verified (hotkey in layer A doesn't fire when layer B is top). Input suppression works for bare keys. Prior art: hook tests in `apps/web/src/__tests__/`.

---

### #42 Grid Focus Model — aria-activedescendant, ↑↓/Home/End/Enter/Space navigation

**What to build**: Implement `aria-activedescendant` focus model in EntityDataTable. Real focus on `<div role="grid" tabIndex={0}>`, active row referenced by id + CSS class. Survives virtualization.

**Acceptance criteria**

- [ ] `aria-activedescendant` on grid element. Real focus stays on grid, active row tracked by id.
- [ ] ↑ / ↓: Move active row up/down within viewport
- [ ] Home / End: Jump to first/last row
- [ ] Enter: Open record (equivalent to double-click)
- [ ] Space: Toggle selection for active row
- [ ] Single-click = select, Double-click = open (changed from previous behavior)
- [ ] Survives virtualization (active row id persists across scroll)

**Tests**: Focus model works with virtualized rows. Keyboard navigation updates active row. No UI interaction tests per PRD.

---

### #43 Grid Actions — F3/F4/F8 + duplicateEntityFn + domain command

**What to build**: Wire F3 (new), F4 (delete), F8 (duplicate) to ListPanelAdapter. Implement `duplicateEntityFn` server function and `duplicateEntity` domain command.

**Acceptance criteria**

- [ ] F3: Triggers `openCreateDialog` in ListPanelAdapter
- [ ] F4: Calls `deleteEntityFn` (triggers `deactivateEntity` for master data)
- [ ] F8: Calls `duplicateEntityFn` — copies record with all fields, clears ID, sets status to draft
- [ ] `duplicateEntity` domain command: reads source record, strips ID/audit fields, returns payload for new record
- [ ] `duplicateEntityFn` server function: authMiddleware, calls domain command, returns new record
- [ ] All actions scoped to Grid (only fire when grid has focus)

**Tests**: `duplicateEntity` creates valid payload. `duplicateEntityFn` returns new record with fresh ID. Prior art: `packages/domain/src/__tests__/commands.test.ts`.

---

### #44 Dialog & Lines Hotkeys — F10 (save) in CrudDialog, Ctrl+Enter in LinesPanelAdapter

**What to build**: F10 saves and closes CrudDialog. Ctrl+Enter saves current line in LinesPanelAdapter.

**Acceptance criteria**

- [ ] F10: Triggers submit handler in CrudDialog. Saves and closes dialog.
- [ ] Ctrl+Enter: Saves current line in LinesPanelAdapter and moves to next line
- [ ] Both hotkeys scoped to their respective components (Dialog/Lines layer)
- [ ] F10 does not fire when dialog is not open (scope stack handles this)

**Tests**: Hotkey registration/unregistration verified. No UI tests per PRD.

---

### #45 Document Hotkeys — F7/F9 (convert) + F5 (lookup table)

**What to build**: F7/F9 triggers ConvertDocumentModal. F5 opens lookup table for FK inputs (AddressCombobox, LookupSelect).

**Acceptance criteria**

- [ ] F7 / F9: Opens ConvertDocumentModal for active document. Scoped to Document grid/Mask.
- [ ] F5: Opens Auswahltabelle for active FK input. Works in AddressCombobox, LookupSelect, etc.
- [ ] Hotkeys only fire when their scope layer is active

**Tests**: Hotkey scoping verified. No UI tests per PRD.

---

### #46 Overlays — ? Cheatsheet + Alt+I StatisticsDrawer

**What to build**: `?` shows HotkeyCheatsheet modal with all shortcuts. `Alt+I` opens StatisticsDrawer with context-aware stats.

**Acceptance criteria**

- [ ] `?` (Shift+/): Opens HotkeyCheatsheet modal. Shows all shortcuts grouped by scope. Closes on `?` again or Esc.
- [ ] Alt+I: Opens StatisticsDrawer. Context-aware: shows ArticleStatistics, CustomerStats, etc. based on active entity.
- [ ] Both overlays use scope stack (close when their layer is popped)
- [ ] Cheatsheet content derived from hotkey registry (not hardcoded)

**Tests**: Cheatsheet renders correct shortcuts from registry. No UI tests per PRD.

---

### #47 Cleanup & Esc — Remove ad-hoc keydown listeners, Esc contextual back/close

**What to build**: Remove all ad-hoc `window.addEventListener("keydown")` from workspace.tsx and crud-dialog.tsx. Implement Esc as contextual back/close on topmost layer.

**Acceptance criteria**

- [ ] All `window.addEventListener("keydown")` removed from workspace.tsx and crud-dialog.tsx
- [ ] Esc: Pops topmost layer. Closes modal, closes dialog, or discards prompt.
- [ ] Esc behavior is contextual: depends on what layer is topmost
- [ ] No regressions: all previous keyboard shortcuts still work after cleanup

**Tests**: Esc pops layers correctly. No ad-hoc listeners remain. Prior art: cleanup verification test.

---

## CRUD Dialog Improvements PRD

[x] #48 parseServerError + in-dialog error banner + unified error handling | M | L2 | AFK | Blocked by: none [IN PROGRESS Cycle 66]
[x] #49 field.\* i18n translations + missing validation keys + caller verification | S | L1 | AFK | Blocked by: #48 [DONE Cycle 67]

---

### #48 parseServerError + in-dialog error banner + unified error handling

**What to build**: Extract `parseServerError` utility, deduplicate error handling across mutations, and add a visible in-dialog error banner above the action buttons. Replaces hidden `toast()` calls for dialog-specific errors.

**Acceptance criteria**

- [ ] `parseServerError(rawError: string, visibleFields: any[])` utility returning `{ fieldErrors: Record<string, string>, globalError: string | null, source: "zod" | "domain" | "fallback", code?: string }`
- [ ] Parsing rule 1 — JSON/Zod: parse structured issues, extract paths mapped to known fields in `visibleFields`
- [ ] Parsing rule 2 — Domain errors: parse semicolon-separated strings, extract field-specific constraints
- [ ] Parsing rule 3 — Fallback: unmappable field errors and unknown errors become `globalError`
- [ ] Mapping constraint: error maps to `fieldErrors` ONLY if field name exists in `visibleFields`
- [ ] In-dialog error banner: rendered above action buttons, shows "Speichern fehlgeschlagen" + normalized error
- [ ] Deduplicate error handling: both `createMutation` and `patchMutation` use `parseServerError` in `onSuccess` (res.error) and `onError` (err.message)
- [ ] Replace `toast()` calls for save errors with in-dialog banner state (`globalError`)
- [ ] Local validation errors (`validateLocally`) also show in the banner
- [ ] Banner clears on successful save or dialog close

**Tests**: `parseServerError` unit tests for JSON/Zod input, domain error string, fallback. Prior art: utility tests in `apps/web/src/__tests__/`.

---

### #49 field.\* i18n translations + missing validation keys + caller verification

**What to build**: Add `field.*` translations to the static i18n dictionary for common field names, add missing validation i18n keys, and verify all callers render the updated dialog correctly.

**Acceptance criteria**

- [ ] `field.*` translations added to both `en` and `de` dictionaries: `name`, `status`, `description`, `email`, `phone`, `active`, `created_at`, `updated_at`, `company_id`, `tenant_id`, `type`, `group`, `date`, `customer`, `currency`, `warehouse`, `article`, `price`, `qty`, `tax_rate`
- [ ] `list.crud.validation.failed` key added to both languages (used in `handleSubmit`)
- [ ] `list.crud.save.error` key verified in both languages
- [ ] FieldRenderer fallback chain verified: metadata label > base lang > static i18n > raw column name
- [ ] Verify `entity-data-table.tsx` renders dialog with error banner correctly
- [ ] Verify `detail-panel-adapter.tsx` renders dialog with error banner correctly
- [ ] Verify `settings-main-view.tsx` renders dialog with error banner correctly

**Tests**: No new tests (L1 — vp check only). Manual verification of i18n keys.
