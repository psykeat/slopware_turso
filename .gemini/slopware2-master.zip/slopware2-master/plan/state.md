# Slopware v2 — State

## STATUS: Phase 2 complete — hotkey integration (raw keydown listeners replaced)

## Progress

100% PRD Coverage (41/41 stories) | Cycle #66 done | 2026-05-09

## Done

- [x] Monorepo scaffold (8 packages + tooling)
- [x] DB schema (70 tables) + migrations + seed
- [x] Auth routes + authMiddleware + $getUser
- [x] Domain: runtime, entities (16), queries, commands, lookups
- [x] Server functions: Generic CRUD wired to domain with tenant context
- [x] entity-ops: Generic $listEntity/$createEntity/$patchEntity/$deleteEntity
- [x] Server function handlers: handleListEntity, handleCreateEntity, etc.
- [x] $getTenantId: Extract tenant from headers/search params
- [x] $getRequestContext: Full context builder
- [x] authMiddleware (requireAuth) on all server functions
- [x] Grid components (GridRoot, GridTable, GridToolbar, GridSearch, GridFooter, GridPagination)
- [x] Panel adapters (list/detail/lines) + i18n (en/de)
- [x] TreeView, KpiView, ListView, DetailView, Panel resolver, CrudDialog
- [x] Workspace integration — search params, slot management, dispatchIntent
- [x] Admin routes: 6 routes — dashboard, users, orgs, tenants, companies, integration
- [x] Admin i18n: en/de messages for all admin pages
- [x] API Layer: Entity/Command/Lookup/Metadata/Auth handlers + routers
- [x] Social providers: GitHub + Google OAuth in Better Auth config
- [x] Fallow audit config: .fallowrc.json for dead-code/duplicate detection
- [x] Route tests: 13 tests covering all route files
- [x] Overlays: HotkeyCheatsheet (?) + StatisticsDrawer (Alt+I) — Cycle 46
- [x] Tests: 480/480 passing across 30 test files
- [x] Tenant CRUD: registry entry, server functions, admin UI with base-tenant protection
- [x] Admin dashboard: real counts from DB (getAdminStatsFn)
- [x] Admin integration: real connector data (listConnectorsFn)
- [x] Admin navigation: i18n consistent across all pages
- [x] Document commands: createDocument (number allocation, draft, lines) + deleteDocument (credit memo protection)
- [x] Document server functions: createDocumentFn + deleteDocumentFn with authMiddleware
- [x] Document update: updateDocument with line replacement + total calculation (Cycle 21 retry)
- [x] Document list: sidebar tree, EntityDataTable, server-side filter (Cycle 22)
- [x] Document posting: postDocument with full 13-type matrix, idempotency, UI button (Cycle 23)
- [x] Document convert + storno: convertDocument (Wandlung) + stornoDocument with conversion chain (Cycle 24)
- [x] Article autocomplete: resolveArticlePricing query + server function (Cycle 25)
- [x] Inventory balance table: balance per warehouse in article dialog (Cycle 26)
- [x] Customer stats: document history + yearly revenue in address dialog (Cycle 27)
- [x] Onboarding: seedDocumentDefaults wired into company creation (Cycle 28)
- [x] Schema migration: due_date, constraints, 8 MVs, module seeds (Cycle 29)
- [x] PostDocument: AVCO + COGS fix + fiscal period guard + due_date + pg_notify (Cycle 30)
- [x] MV Refresh Listener: startup refresh all 8 MVs + LISTEN stats_refresh + debounce (Cycle 31)
- [x] KPI Dashboard: real data from MVs + live document queries + shape test (Cycle 32)
- [x] Period Comparison View: mv_sales_period per period + YoY toggle + fiscal year selector (Cycle 33)
- [x] Address Detail View: 4 data tabs (stats, open items, movements, documents) + server function (Cycle 34)
- [x] Article Detail View: 4 data tabs (stats, stock journal, movements, documents) + running balance + warehouse toggle (Cycle 35)
- [x] Article Group Detail View: 3 data tabs (stats, movements, documents) + aggregated MV query (Cycle 36)
- [x] Fiscal Period Settings: entity registry, close_period command, settings view with status badges (Cycle 37)
- [x] Credentials Encryption: AES-GCM encrypt/decrypt + LiteLLM admin config with test connection (Cycle 38)
- [x] Connector Definition Admin: entity registry, settings view, tenant connector activation UI with encrypted creds (Cycle 39)
- [x] Connector Mappings UI: two-level lock enforcement, mapping editor, 4 server functions (Cycle 40)
- [x] DocumentHeaderForm: type/group/date/customer/currency/warehouse fields + createDocument wiring (Cycle 42)
- [x] Create Flow: Neuer Beleg button, query invalidation, allocated number display, error handling (Cycle 43)
- [x] LinesEditor UI: article autocomplete, inline qty/price editing, totals footer (Cycle 45)
- [x] Price/Tax Auto-Fill: resolveArticlePricing wired, tax_rate displayed, 7 tests (Cycle 46)
- [x] Live Calculation + Save: real-time line totals, footer, explicit save button (Cycle 47)
- [x] Warehouse per Line + Keyboard Navigation: warehouse column, tab/enter/delete keys (Cycle 48)
- [x] Comment Lines + Delete Handling: comment line type, delete key, excluded from totals (Cycle 49)
- [x] Per-Line Warehouse + Keyboard Nav: warehouse column with search, Tab/Shift+Tab nav, Enter on autocomplete, Delete confirm (Cycle 48)
- [x] Delete Rules UI: delete button in detail pane with type-based visibility (DELETABLE_TYPES), confirmation dialog, query invalidation (Cycle 50)
- [x] Sidebar Tree Real Data: replace MOCK_DOC_TREE with listDocumentTreeFn, collapsed from data (Cycle 51)
- [x] Convert Dialog: confirmation modal with target group preselection from next_group_id + group selector (Cycle 52)
- [x] PRD Partials: Detail pane with real data fetch (getEntityFn, customer lookup, line totals) + Address search with persistent number+name display (Cycle 53)
- [x] Connector Subprocess Runner: runConnector with JWT, Bun.spawn, timeout, import_batch lifecycle (Cycle 54)
- [x] Warehouse Visual Indicators + Status Buttons: per-line warehouse diff badge (≠), missing warehouse warning (⚠), convert button hidden for archived docs, storno button hidden for cancelled docs (Cycle 55)
- [x] Import Queue UI: total_rows/error_count columns, i18n for import batch view (Cycle 56)
- [x] XRechnung Inbound Connector: UBL 2.1/CII parser, connector script, validation, seed, 6 tests (Cycle 57)
- [x] Hotkey Core: Zustand scope stack, useHotkeyLayer, useScopedHotkey with input suppression, 15 tests (Cycle 58)
- [x] Grid Focus Model: aria-activedescendant, keyboard nav (ArrowUp/Down, Home, End, Enter, Space), single/double-click, 9 tests (Cycle 59)
- [x] Grid Actions: F3 (new), F4 (delete), F8 (duplicate) + duplicateEntity domain command + server function (Cycle 43)
- [x] Dialog & Lines Hotkeys: F10 saves/closes CrudDialog, Ctrl+Enter saves line in LinesPanelAdapter (Cycle 44)
- [x] Document Hotkeys: F7/F9 opens ConvertDialog in detail panel, F5 opens LookupSelect dropdown (Cycle 45)
- [x] Overlays: HotkeyCheatsheet (?) and StatisticsDrawer (Alt+I) with registry-derived content, 10 tests (Cycle 63)
- [x] Cleanup & Esc: compound key support, remove ad-hoc keydown listeners, contextual Escape (Cycle 64)
- [x] Hotkey Scope Fix: global hotkeys fire regardless of child panel scope stack (Cycle 65)
- [x] Error Handling: parseServerError utility, deduplicated mutations, in-dialog error banner (Cycle 66)
- [x] Field i18n: field.\* translations (20 keys en/de) + validation.failed key + caller verification (Cycle 67)

## Blockers

(keine)

## Constants

SYSTEM_ORG_ID: 00000000-0000-0000-0000-000000000001
BASE_TENANT_ID: 00000000-0000-0000-0000-000000000002
