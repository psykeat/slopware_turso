# Task — Cycle 68

**Slice**: #26 XRechnung Outbound Generator
**PRD**: Belegerfassung & Verbuchung
**Complexity**: M
**Test Level**: L3
**Status**: in_progress

## What to build

On-demand XRechnung XML (UBL 2.1) generator from a posted sales invoice. Pure function + server function with guards.

## Files to modify

- `packages/domain/src/` — new `buildXRechnungXml` function
- `apps/web/src/server/` — new `$generateXRechnung` server function
- `apps/web/src/__tests__/` — tests for the pure function + guards

## Deliverables

1. `buildXRechnungXml(document, lines, company, customer)` pure function → XML string
2. `$generateXRechnung(documentId)` server function with authMiddleware
3. Guard: only R-type + posted documents allowed (422 otherwise)
4. Tests for XML output shape + guard behavior

## Acceptance Criteria

- [ ] `buildXRechnungXml` pure function in `packages/domain` — no side effects
- [ ] Output validates against EN 16931 / XRechnung 3.x schematron rules
- [ ] `$generateXRechnung(documentId)` server function with authMiddleware
- [ ] Only callable for R-type + posted (422 otherwise)
- [ ] Tests: valid XML for representative fixture, 422 for non-posted
