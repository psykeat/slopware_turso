#!/bin/bash
set -e

if [ -z "$1" ]; then
  echo "Usage: $0 <iterations>"
  exit 1
fi

for ((i=1; i<=$1; i++)); do
  echo "------- ITERATION $i --------"

  ralph_commits=$(git log --grep="RALPH" -n 10 --format="%H%n%ad%n%B---" --date=short 2>/dev/null || echo "No RALPH commits found")

  # Gemini --yolo handles its own inner loop, but we can wrap it for multi-pass sessions
  # We look for the same stop tokens in the output
  output=$(gemini --yolo "@plans/prompt.md Previous RALPH commits: $ralph_commits")
  echo "$output"

  if [[ "$output" == *"<promise>NO MORE TASKS</promise>"* ]]; then
    echo "Gemini Ralph complete after $i iterations."
    exit 0
  fi

  if [[ "$output" == *"<promise>ABORT</promise>"* ]]; then
    echo "Gemini Ralph aborted after $i iterations."
    exit 1
  fi
done
