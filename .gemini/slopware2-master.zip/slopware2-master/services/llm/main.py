import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
import litellm

app = FastAPI(title="LiteLLM Proxy Service")

class CompletionRequest(BaseModel):
    prompt: str
    model: Optional[str] = "gpt-4o"
    endpoint_url: Optional[str] = None
    api_key: Optional[str] = None
    provider: Optional[str] = None

@app.get("/health")
async def health():
    return {"status": "ok"}

@app.post("/complete")
async def complete(req: CompletionRequest):
    try:
        # Construct messages from prompt
        messages = [{"role": "user", "content": req.prompt}]
        
        # Configure litellm call
        model_name = req.model
        if req.provider and req.provider != "openai" and "/" not in model_name:
            model_name = f"{req.provider}/{model_name}"
            
        kwargs = {
            "model": model_name,
            "messages": messages,
        }
        
        if req.api_key:
            kwargs["api_key"] = req.api_key
        
        if req.endpoint_url:
            # LiteLLM/OpenAI client often fails if there is a trailing slash on some providers
            # or if /v1 is missing/present depending on the server.
            base_url = req.endpoint_url.rstrip("/")
            kwargs["base_url"] = base_url
            print(f"DEBUG: Using base_url: {base_url}")
            
        # If provider is specified but not in model string, 
        if req.provider:
            kwargs["custom_llm_provider"] = req.provider
            print(f"DEBUG: Using custom_llm_provider: {req.provider}")

        print(f"DEBUG: Calling litellm.completion with model: {model_name}")
        response = litellm.completion(**kwargs)
        
        return {
            "content": response.choices[0].message.content
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("LLM_SERVICE_PORT", 11435))
    uvicorn.run(app, host="0.0.0.0", port=port)
