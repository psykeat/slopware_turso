# Slopware v2 - Comprehensive Implementation Plan

## 1. Core Architecture & Foundations

- **Keyboard-First Design**: Primary mandate. All features must be fully operable without mouse. Focus management via `aria-activedescendant` and scope-stack based hotkey resolution.
- **Stack**: pnpm monorepo. React, TanStack Start, Vite. PostgreSQL 16+. Better Auth. Drizzle ORM.
- **Design System**: Vanilla CSS tokens (`--sw-*`), no Tailwind inside `.sw-root`. Components: `sw-btn`, `sw-pane`.
- **Multi-Tenancy**: `tenant_id` on all customer tables + RLS policies. `SYSTEM_ORG_ID`, `BASE_TENANT_ID` constants.
- **Auth**: Better Auth proxy at `api/auth/$.ts`. Server functions protected via `authMiddleware`.
- **Routing**: `_auth` (protected) / `_guest` (public). Workspace state in URL hash (`#ws=<id>&pane1=<key>`).
- **View Convention**: `[prefix]:[suffix]` -> `views/[prefix]/[prefix]-[suffix]-view.tsx`. No props, state via `useWorkspaceContext()`. Registry (`view-registry.ts`) manages `kind: "generic" | "custom" | "dashboard"`.

## 2. Database Schema (Bottom-Up)

### 2.1. System & Auth

- **Auth**: `user`, `session`, `account`, `verification`.
- **Core**: `organization` (slug, isActive), `tenant` (RLS root), `app_user` (email, hash, role), `user_tenant`.
- **Roles**: `tenant_user` < `tenant_admin` < `org_admin` < `system_admin`.

### 2.2. Master Data

- **Settings Entities**: `company`, `address`, `address_category`, `industry`, `country`, `currency`, `unit`, `warehouse`, `tax_class`, `tax_code`, `cost_center`, `gl_account`, `payment_term`, `shipping_method`, `price_list`, `discount_group`, `article_group`.
- **Article**: `article` table. Fields include `tracking_mode` (serial/batch) and `bom_type` (sales/production).

### 2.3. Metadata System

- **Core**: `entity_definition`, `field_definition`, `entity_field`.
- **Tenant Overrides**: `tenant_fields`, `tenant_groups`, `tenant_layouts`, `tenant_rules`.
- **Views**: `effective_fields`, `effective_layout`, `effective_rules`, `effective_settings`. (App ONLY reads effective views, never raw tables).

### 2.4. Document Flow

- **Config**: `document_type` (13 types: N, A, L, R, G, b, l, r, g, V, Z, E, U), `document_group` (X00 protected base, X01 deletable), `number_sequence`.
- **Records**: `document` (header), `document_line` (positions).
- **Tracking**: `inventory_balance`, `inventory_movement`, `serial_number`, `document_line_tracking`.
- **Facts**: `fact_sales_event`, `fact_purchase_event`, `fiscal_period`.

### 2.5. Integration & Statistics

- **Integration**: `connector_definition`, `tenant_connector`, `import_batch` (with rerun links), `import_row`, `schema_annotations`.
- **Statistics MVs**: 8 Materialized Views (e.g., `mv_sales_period`). `UNIQUE INDEX` for concurrent refresh.

## 3. Domain Layer (Business Logic)

- **Context**: `withTenant(tenantId, fn)` isolates DB calls.
- **Generic CRUD**: `listEntity`, `getEntityById`, `createEntity`, `patchEntity`, `deleteEntity`, `deactivateEntity`. Driven by `ENTITY_REGISTRY`.
- **Document Commands**:
  - `createDocument`: Allocates number via `next_sequence_no` (atomic `SELECT FOR UPDATE`). Inserts header + lines sequentially. Status: `draft`.
  - `updateDocument`: Only for `draft`. Computes `line_total_net`, `tax_amount`, `total_net`, `total_gross`.
  - `convertDocument`: Hardcoded flow (e.g., N->A->L->R). Source gets `archived`. Target inherits `transaction_id`.
  - `stornoDocument`: Only for posted R/r. Creates G/g with positive qty. Source gets `cancelled`.
- **Document Posting (`postDocument`)**:
  - Validates fiscal period (`resolveFiscalPeriodId`).
  - 13-type matrix mapping to `inventory_movement` (issue, receipt, return, correction).
  - Updates `inventory_balance` (`available_qty = on_hand_qty - reserved_qty`).
  - AVCO calculation for purchases (`r`). COGS snapshot for sales (`R`).
  - Sets `due_date`, fires `pg_notify('stats_refresh', tenantId)`.
- **Validation**: Completeness check for serial/batch tracking before posting.

## 4. API & Server Functions

- **Location**: `apps/web/src/server/server-functions.ts`.
- **Pattern**: Domain logic wrapped in `createServerFn`. Uses `authMiddleware`.
- **Functions**: `listEntityFn`, `createEntityFn`, `lookupHelperTableFn`, `getEffectiveFieldsFn`.
- **Specific**: `postDocumentFn`, `convertDocumentFn`, `stornoDocumentFn`, `duplicateEntityFn`.
- **Resolution**: `resolveArticlePricingFn` (resolves `net_price`, `tax_rate`, `tax_code_id` in one call).

## 5. UI Core & Workspace

### 5.1. Panels & Components

- **Generic**: `EntityDataTable` + `CrudDialog`.
- **CrudDialog**: Handles local validation, error banner (`parseServerError` normalizes Zod/Domain errors), field i18n fallback chain. Pseudo-singleton support via `inline={true}`.
- **ListPanelAdapter**: Orchestrates grid state, search focus, and intent mapping. Pushes a dedicated hotkey layer for scoped actions (F3, F4, F8). Manages transition between "Navigation Mode" (grid focus) and "Action Mode" (filter/search focus).
- **DetailPanelAdapter**: Maps entity metadata to `CrudDialog`.
- **LinesPanelAdapter**: Tabular position editor with specialized keyboard flow (Ctrl+Enter to save line).

### 5.2. Keyboard Navigation

- **Store**: `hotkey-store.ts` (Zustand scope stack).
- **Hooks**: `useHotkeyLayer`, `useScopedHotkey` (suppresses bare keys in inputs).
- **Grid Focus**: `aria-activedescendant` implementation. Up/Down, Home/End, Enter, Space.
- **Shortcuts**: F3 (New), F4 (Delete), F5 (Lookup), F7/F9 (Convert), F8 (Duplicate), F10 (Save).
- **Overlays**: `?` (Cheatsheet modal), `Alt+I` (StatisticsDrawer).

## 6. App Features & Workflows

### 6.1. Administration & Settings

- **Admin**: Dashboard, Users, Orgs, Tenants, Companies, Integrations. Protected by `requireAdminRole`.
- **Settings View**: Sidebar layout. Firmenstamm uses inline CrudDialog (pseudo-singleton). Other 19 entities use standard grids.
- **Fiscal Periods**: Manage open/closed periods.

### 6.2. Document Entry & Management

- **Sidebar**: 3-level tree (Direction -> Type -> Group). Auto-collapsed logic.
- **List View**: Server-side filtering by type/group.
- **Header Form**: Auto-fills warehouse/currency/tax based on group/address. Customer autocomplete (number+name).
- **Lines Editor**:
  - Article autocomplete fetches price and tax.
  - Inline qty/price editing. Live calculation.
  - Per-line warehouse with visual warning badges.
  - Comment lines (text only). Tab-based navigation.
- **Actions**: Explicit Save, Buchen, Wandeln (dialog with group selector), Stornieren, Löschen (hidden for R, r, G, g).

### 6.3. CRM & Articles (Stats Integration)

- **Address Detail**: 4 tabs (Stats chart, Open Items, Movements, Documents).
- **Article Detail**: Stock ledger with running balance (`SUM(qty_delta) OVER()`), Warehouse toggle, Pinned reserved footer.
- **Article Group Detail**: Aggregated MV stats.

### 6.4. Integrations & Import

- **Service**: Listen for `stats_refresh` pg_notify -> debounce -> `REFRESH MATERIALIZED VIEW CONCURRENTLY`.
- **Admin**: Connector Definitions. Encrypted credentials (`AES-GCM`).
- **Tenant Mappings UI**: Two-level lock enforcement (source locked, target locked). Mandatory fields badge.
- **Runner**: `Bun.spawn` subprocess. Tenant-scoped JWT. Hard-kill timeout. Status lifecycle (pending -> validating/failed/approved).
- **Queue**: Failed import batches UI. Rerun capability (creates new batch, excludes rerun from billing).
- **XRechnung**: Inbound UBL 2.1/CII parser -> validate -> auto-post. Outbound generator (pending).

### 6.5. AI-Augmented Feedback Service

- **UI**: Header `?` button / `Shift+F1`. Captures workspace context, pane layout, selected entity, JS errors.
- **Backend**: Proxies to LiteLLM Python microservice via FastAPI (`/complete`).
- **Admin**: Config panel for LLM endpoint, model, provider, API key, GitHub PAT (stored encrypted).
- **Output**: Auto-formats Bug/Feature issue and posts directly to GitHub repo.
