#!/bin/bash
# status.sh — quick workflow dashboard
# Usage: sh status.sh

set -e

export FORCE_COLOR=1

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}=== Slopware v2 — Workflow Status ===${NC}"
echo ""

# State
if [ -f "plan/state.md" ]; then
    STATUS=$(grep "STATUS:" plan/state.md | head -1 | cut -d: -f2 | xargs)
    PROGRESS=$(grep "%" plan/state.md | head -1)
    echo -e "${GREEN}State:${NC} $STATUS"
    echo -e "${GREEN}Progress:${NC} $PROGRESS"
else
    echo -e "${YELLOW}State:${NC} plan/state.md not found"
fi

echo ""

# Queue
if [ -f "plan/queue.md" ]; then
    TOTAL=$(grep -c "^\[.\]" plan/queue.md 2>/dev/null || true)
    DONE=$(grep -c "^\[x\]" plan/queue.md 2>/dev/null || true)
    PENDING=$(grep -c "^\[ \]" plan/queue.md 2>/dev/null || true)
    RETRY=$(grep -c "\[retry\]" plan/queue.md 2>/dev/null || true)
    SKIP=$(grep -c "\[skip\]" plan/queue.md 2>/dev/null || true)
    TOTAL=${TOTAL:-0}
    DONE=${DONE:-0}
    PENDING=${PENDING:-0}
    RETRY=${RETRY:-0}
    SKIP=${SKIP:-0}
    echo -e "${GREEN}Queue:${NC} $DONE/$TOTAL done | $PENDING pending"
    [ "$RETRY" -gt 0 ] && echo -e "${YELLOW}  Retries:${NC} $RETRY"
    [ "$SKIP" -gt 0 ] && echo -e "${RED}  Skipped:${NC} $SKIP"
else
    echo -e "${YELLOW}Queue:${NC} plan/queue.md not found"
fi

echo ""

# Blockers
if [ -f "plan/blockers.md" ]; then
    BLOCKERS=$(grep -c "^\[BLOCKER\]" plan/blockers.md 2>/dev/null || true)
    FIXED=$(grep -c "^\[FIXED\]" plan/blockers.md 2>/dev/null || true)
    BLOCKERS=${BLOCKERS:-0}
    FIXED=${FIXED:-0}
    echo -e "${GREEN}Blockers:${NC} $BLOCKERS open | $FIXED resolved"
    if [ "$BLOCKERS" -gt 0 ]; then
        grep "^\[BLOCKER\]" plan/blockers.md | while read -r line; do
            echo -e "${RED}  $line${NC}"
        done
    fi
else
    echo -e "${GREEN}Blockers:${NC} none"
fi

echo ""

# Recent commits
echo -e "${BLUE}Recent Commits:${NC}"
git log --oneline -5 2>/dev/null || echo "  No commits yet"

echo ""

# vp check
echo -e "${BLUE}vp check:${NC}"
vp check 2>&1 | tail -1 || echo "  vp check not available"
