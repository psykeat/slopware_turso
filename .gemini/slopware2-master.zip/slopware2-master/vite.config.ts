import path from "path";
import { fileURLToPath } from "url";

import { defineConfig } from "vite-plus";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const resolve = (p: string) => path.resolve(__dirname, p);

export default defineConfig({
  staged: {
    "*": "vp fmt --no-error-on-unmatched-pattern",
  },

  test: {
    include: [
      "packages/**/src/__tests__/**/*.test.ts",
      "apps/**/src/server/__tests__/**/*.test.ts",
      "apps/**/src/features/**/__tests__/**/*.test.ts",
      "apps/**/src/routes/__tests__/**/*.test.ts",
    ],
    globalSetup: ["packages/db/src/__tests__/global-setup.ts"],
    setupFiles: [resolve("packages/db/src/__tests__/setup-env.ts")],
    testTimeout: 60000,
    hookTimeout: 60000,
    alias: {
      "@repo/db/__tests__/fixtures": resolve("packages/db/src/__tests__/fixtures"),
      "@repo/db": resolve("packages/db/src"),
      "@repo/domain/runtime": resolve("packages/domain/src/runtime"),
      "@repo/domain/metadata": resolve("packages/domain/src/metadata"),
      "@repo/domain/lookups": resolve("packages/domain/src/lookups"),
      "@repo/domain/queries": resolve("packages/domain/src/queries"),
      "@repo/domain/commands": resolve("packages/domain/src/commands"),
      "@repo/domain": resolve("packages/domain/src"),
      "@repo/api/commands": resolve("packages/api/src/command-handlers.ts"),
      "@repo/api/entities": resolve("packages/api/src/entity-handlers.ts"),
      "@repo/api/lookups": resolve("packages/api/src/lookup-handlers.ts"),
      "@repo/api/metadata": resolve("packages/api/src/metadata-handlers.ts"),
      "@repo/api": resolve("packages/api/src"),
      "~": resolve("apps/web/src"),
    },
  },

  run: {
    cache: {
      tasks: false,
    },
  },

  fmt: {
    tabWidth: 2,
    semi: true,
    printWidth: 100,
    singleQuote: false,
    endOfLine: "lf",
    trailingComma: "all",
    sortImports: {},
    sortTailwindcss: {
      stylesheet: "./packages/ui/styles/base.css",
      attributes: ["class", "className"],
      functions: ["clsx", "cn", "cva", "tw"],
    },
    sortPackageJson: true,
    ignorePatterns: [
      "pnpm-lock.yaml",
      "package-lock.json",
      "yarn.lock",
      "bun.lock",
      "routeTree.gen.ts",
      ".tanstack-start/",
      ".tanstack/",
      "drizzle/",
      "migrations/",
      ".drizzle/",
      ".cache",
      "worker-configuration.d.ts",
      ".vercel",
      ".output",
      ".wrangler",
      ".netlify",
      "dist",
    ],
  },

  lint: {
    plugins: ["typescript", "react", "react-perf", "jsx-a11y"],
    env: {
      builtin: true,
      node: true,
      browser: true,
    },
    options: {
      typeAware: true,
      typeCheck: true,
    },
    jsPlugins: [
      { name: "react-hooks-js", specifier: "eslint-plugin-react-hooks" },
      {
        name: "eslint-tanstack-router",
        specifier: "@tanstack/eslint-plugin-router",
      },
      {
        name: "eslint-tanstack-query",
        specifier: "@tanstack/eslint-plugin-query",
      },
    ],
    rules: {
      "no-deprecated": "off",
      "typescript/no-base-to-string": "off",
      "typescript/no-floating-promises": "off",
      "typescript/no-misused-spread": "off",
      "jsx-a11y/no-autofocus": "off",
      "jsx-a11y/prefer-tag-over-role": "off",
      "eslint-tanstack-query/no-unstable-deps": "off",

      "eslint-tanstack-router/create-route-property-order": "warn",

      "eslint-tanstack-query/exhaustive-deps": "warn",
      "eslint-tanstack-query/stable-query-client": "warn",
      "eslint-tanstack-query/no-rest-destructuring": "warn",
      "eslint-tanstack-query/infinite-query-property-order": "warn",
      "eslint-tanstack-query/no-void-query-fn": "warn",
      "eslint-tanstack-query/mutation-property-order": "warn",

      "react-hooks-js/config": "error",
      "react-hooks-js/error-boundaries": "error",
      "react-hooks-js/gating": "error",
      "react-hooks-js/globals": "error",
      "react-hooks-js/immutability": "error",
      "react-hooks-js/incompatible-library": "off",
      "react-hooks-js/preserve-manual-memoization": "error",
      "react-hooks-js/purity": "error",
      "react-hooks-js/refs": "error",
      "react-hooks-js/set-state-in-effect": "off",
      "react-hooks-js/set-state-in-render": "error",
      "react-hooks-js/static-components": "error",
      "react-hooks-js/unsupported-syntax": "warn",
      "react-hooks-js/use-memo": "error",
      "react-hooks-js/void-use-memo": "error",
    },
    ignorePatterns: [
      "dist",
      ".wrangler",
      ".vercel",
      ".netlify",
      ".output",
      "build/",
      "worker-configuration.d.ts",
      "scripts/",
      ".ignored_node_modules/",
    ],
  },
});
