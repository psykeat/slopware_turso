CREATE TYPE "commerce_sync_dlq_status" AS ENUM('pending', 'resolved', 'abandoned');--> statement-breakpoint
CREATE TYPE "commerce_sync_run_direction" AS ENUM('push', 'pull', 'bidirectional');--> statement-breakpoint
CREATE TYPE "commerce_sync_run_mode" AS ENUM('single', 'full');--> statement-breakpoint
CREATE TYPE "commerce_sync_run_status" AS ENUM('queued', 'running', 'success', 'partial_error', 'error', 'cancel_requested', 'cancelled');--> statement-breakpoint
CREATE TYPE "commerce_sync_step_phase" AS ENUM('plan', 'map', 'push', 'pull', 'finalize');--> statement-breakpoint
CREATE TYPE "commerce_sync_step_status" AS ENUM('pending', 'running', 'success', 'error', 'skipped');--> statement-breakpoint
CREATE TYPE "commerce_webhook_event_status" AS ENUM('pending', 'processing', 'processed', 'ignored', 'failed');--> statement-breakpoint
CREATE TYPE "seller_tax_registration_type" AS ENUM('domestic', 'oss', 'foreign_vat');--> statement-breakpoint
ALTER TYPE "external_sync_entity_type" ADD VALUE 'address' BEFORE 'article';--> statement-breakpoint
ALTER TYPE "external_sync_entity_type" ADD VALUE 'article_group' BEFORE 'article_variant';--> statement-breakpoint
CREATE TABLE "agent" (
	"agent_id" uuid PRIMARY KEY DEFAULT uuidv7(),
	"tenant_id" uuid NOT NULL,
	"agent_no" text NOT NULL,
	"name" text,
	"address_id" uuid,
	"user_id" text,
	"commission_rate" numeric(5,2),
	"active" boolean DEFAULT true NOT NULL,
	"archived_at" timestamp with time zone,
	"custom_attributes" jsonb,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone,
	CONSTRAINT "uq_agent_tenant_no" UNIQUE("tenant_id","agent_no")
);
--> statement-breakpoint
CREATE TABLE "bueroware_record_field" (
	"field_id" uuid PRIMARY KEY DEFAULT uuidv7(),
	"layout_id" uuid NOT NULL,
	"bueroware_field_id" text NOT NULL,
	"label" text,
	"sample_value" text,
	"position" integer,
	"length" integer,
	"formatting" text,
	"refresh_table" text,
	"import_marker" text,
	"ordinal" integer,
	"default_target_field" text,
	"default_reference_entity" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "bueroware_record_layout" (
	"layout_id" uuid PRIMARY KEY DEFAULT uuidv7(),
	"file_name" text NOT NULL,
	"data_area" text NOT NULL,
	"qualifier" text,
	"default_target_entity" text,
	"catalog_version" integer DEFAULT 1 NOT NULL,
	"is_active" boolean DEFAULT true NOT NULL,
	"field_count" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "uq_bueroware_layout_file_qualifier_version" UNIQUE("file_name","qualifier","catalog_version")
);
--> statement-breakpoint
CREATE TABLE "commerce_sync_dead_letter" (
	"item_id" uuid PRIMARY KEY DEFAULT uuidv7(),
	"run_id" uuid NOT NULL,
	"tenant_id" uuid NOT NULL,
	"sales_channel_id" uuid NOT NULL,
	"entity_type" "external_sync_entity_type" NOT NULL,
	"internal_id" uuid NOT NULL,
	"error_message" text NOT NULL,
	"attempt_count" integer DEFAULT 1 NOT NULL,
	"last_attempted_at" timestamp with time zone NOT NULL,
	"next_retry_at" timestamp with time zone,
	"status" "commerce_sync_dlq_status" DEFAULT 'pending'::"commerce_sync_dlq_status" NOT NULL,
	"resolved_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "commerce_sync_run" (
	"run_id" uuid PRIMARY KEY DEFAULT uuidv7(),
	"tenant_id" uuid NOT NULL,
	"sales_channel_id" uuid NOT NULL,
	"direction" "commerce_sync_run_direction" NOT NULL,
	"mode" "commerce_sync_run_mode" NOT NULL,
	"status" "commerce_sync_run_status" DEFAULT 'queued'::"commerce_sync_run_status" NOT NULL,
	"requested_entities" jsonb NOT NULL,
	"dry_run" boolean DEFAULT false NOT NULL,
	"total_items" integer DEFAULT 0 NOT NULL,
	"succeeded_items" integer DEFAULT 0 NOT NULL,
	"failed_items" integer DEFAULT 0 NOT NULL,
	"error_summary" text,
	"started_at" timestamp with time zone,
	"completed_at" timestamp with time zone,
	"cancel_requested_at" timestamp with time zone,
	"created_by_user_id" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "commerce_sync_run_step" (
	"step_id" uuid PRIMARY KEY DEFAULT uuidv7(),
	"run_id" uuid NOT NULL,
	"tenant_id" uuid NOT NULL,
	"sales_channel_id" uuid NOT NULL,
	"entity_type" "external_sync_entity_type" NOT NULL,
	"phase" "commerce_sync_step_phase" NOT NULL,
	"status" "commerce_sync_step_status" DEFAULT 'pending'::"commerce_sync_step_status" NOT NULL,
	"sequence" integer NOT NULL,
	"batch_no" integer DEFAULT 0 NOT NULL,
	"cursor" text,
	"planned_items" integer DEFAULT 0 NOT NULL,
	"succeeded_items" integer DEFAULT 0 NOT NULL,
	"failed_items" integer DEFAULT 0 NOT NULL,
	"payload_summary" jsonb,
	"error_summary" text,
	"started_at" timestamp with time zone,
	"completed_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "uq_commerce_sync_step_sequence" UNIQUE("run_id","sequence","batch_no")
);
--> statement-breakpoint
CREATE TABLE "commerce_webhook_event" (
	"event_id" uuid PRIMARY KEY DEFAULT uuidv7(),
	"tenant_id" uuid NOT NULL,
	"sales_channel_id" uuid NOT NULL,
	"event_name" text NOT NULL,
	"dedupe_key" text NOT NULL,
	"payload" jsonb NOT NULL,
	"status" "commerce_webhook_event_status" DEFAULT 'pending'::"commerce_webhook_event_status" NOT NULL,
	"attempt_count" integer DEFAULT 0 NOT NULL,
	"error_message" text,
	"next_retry_at" timestamp with time zone,
	"processed_at" timestamp with time zone,
	"received_at" timestamp with time zone DEFAULT now() NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "uq_commerce_webhook_event_dedupe" UNIQUE("tenant_id","sales_channel_id","dedupe_key")
);
--> statement-breakpoint
CREATE TABLE "import_field_mapping" (
	"mapping_id" uuid PRIMARY KEY DEFAULT uuidv7(),
	"tenant_id" uuid,
	"version_id" uuid NOT NULL,
	"position" integer,
	"length" integer,
	"qualifier" text,
	"formatting" text,
	"source_field" text,
	"target_field" text NOT NULL,
	"target_entity" text,
	"reference_entity" text,
	"is_required" boolean DEFAULT false NOT NULL,
	"default_value" text,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "seller_tax_registration" (
	"seller_tax_registration_id" uuid PRIMARY KEY DEFAULT uuidv7(),
	"tenant_id" uuid NOT NULL,
	"company_id" uuid,
	"country_code" char(2) NOT NULL,
	"vat_id" text,
	"registration_type" "seller_tax_registration_type" NOT NULL,
	"valid_from" date NOT NULL,
	"valid_to" date,
	"archived" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "address" ADD COLUMN "salutation" text;--> statement-breakpoint
ALTER TABLE "address" ADD COLUMN "phone_landline" text;--> statement-breakpoint
ALTER TABLE "address" ADD COLUMN "phone_fax" text;--> statement-breakpoint
ALTER TABLE "address" ADD COLUMN "phone_mobile" text;--> statement-breakpoint
ALTER TABLE "address" ADD COLUMN "email" text;--> statement-breakpoint
ALTER TABLE "address" ADD COLUMN "homepage" text;--> statement-breakpoint
ALTER TABLE "address" ADD COLUMN "leitweg_id" text;--> statement-breakpoint
ALTER TABLE "address" ADD COLUMN "peppol_id" text;--> statement-breakpoint
ALTER TABLE "address" ADD COLUMN "coordinates" jsonb;--> statement-breakpoint
ALTER TABLE "address" ADD COLUMN "agent_id" uuid;--> statement-breakpoint
ALTER TABLE "address" ADD COLUMN "commission_rate" numeric(5,2);--> statement-breakpoint
ALTER TABLE "address" ADD COLUMN "credit_rating_score" text;--> statement-breakpoint
ALTER TABLE "address" ADD COLUMN "shop_active" boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE "address_contact" ADD COLUMN "salutation" text;--> statement-breakpoint
ALTER TABLE "address_contact" ADD COLUMN "phone_fax" text;--> statement-breakpoint
ALTER TABLE "address_contact" ADD COLUMN "twitter_handle" text;--> statement-breakpoint
ALTER TABLE "address_contact" ADD COLUMN "youtube_url" text;--> statement-breakpoint
ALTER TABLE "document" ADD COLUMN "total_weight_kg" numeric;--> statement-breakpoint
ALTER TABLE "document" ADD COLUMN "agent_id" uuid;--> statement-breakpoint
ALTER TABLE "document" ADD COLUMN "commission_rate" numeric(5,2);--> statement-breakpoint
ALTER TABLE "document_line" ADD COLUMN "tax_reason" text;--> statement-breakpoint
ALTER TABLE "document_line" ADD COLUMN "tax_rule_id" uuid;--> statement-breakpoint
ALTER TABLE "document_line" ADD COLUMN "tax_country_code_used" varchar(2);--> statement-breakpoint
ALTER TABLE "document_line" ADD COLUMN "tax_rate_snapshot" numeric;--> statement-breakpoint
ALTER TABLE "document_line" ADD COLUMN "line_weight_kg" numeric;--> statement-breakpoint
ALTER TABLE "external_sync_mapping" ADD COLUMN "source_system" text DEFAULT 'sales_channel' NOT NULL;--> statement-breakpoint
ALTER TABLE "import_batch" ADD COLUMN "is_dry_run" boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE "import_batch" ADD COLUMN "source_file_name" text;--> statement-breakpoint
ALTER TABLE "import_batch" ADD COLUMN "failed_entity_count" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "import_batch" ADD COLUMN "pending_reference_count" integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE "import_batch" ADD COLUMN "file_path" text;--> statement-breakpoint
ALTER TABLE "import_batch" ADD COLUMN "layout_id" uuid;--> statement-breakpoint
ALTER TABLE "import_profile_mapping_version" ADD COLUMN "source_system" text;--> statement-breakpoint
ALTER TABLE "import_profile_mapping_version" ADD COLUMN "source_file_name" text;--> statement-breakpoint
ALTER TABLE "import_profile_mapping_version" ADD COLUMN "target_entity" text;--> statement-breakpoint
ALTER TABLE "import_profile_mapping_version" ADD COLUMN "layout_id" uuid;--> statement-breakpoint
ALTER TABLE "import_row" ADD COLUMN "missing_references" jsonb;--> statement-breakpoint
ALTER TABLE "external_sync_mapping" ALTER COLUMN "sales_channel_id" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "import_profile_mapping_version" ALTER COLUMN "tenant_id" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "import_profile_mapping_version" ALTER COLUMN "tenant_connector_id" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "import_profile_mapping_version" ALTER COLUMN "profile_id" DROP NOT NULL;--> statement-breakpoint
ALTER TABLE "external_sync_mapping" ADD CONSTRAINT "uq_ext_sync_external_key" UNIQUE("tenant_id","source_system","entity_type","external_id");--> statement-breakpoint
ALTER TABLE "import_profile_mapping_version" ADD CONSTRAINT "uq_import_mapping_source_version" UNIQUE("source_system","source_file_name","layout_id","version_no");--> statement-breakpoint
CREATE INDEX "idx_address_agent" ON "address" ("tenant_id","agent_id");--> statement-breakpoint
CREATE INDEX "idx_agent_tenant" ON "agent" ("tenant_id");--> statement-breakpoint
CREATE INDEX "idx_agent_address" ON "agent" ("address_id");--> statement-breakpoint
CREATE INDEX "idx_agent_user" ON "agent" ("user_id");--> statement-breakpoint
CREATE INDEX "idx_bueroware_field_layout" ON "bueroware_record_field" ("layout_id");--> statement-breakpoint
CREATE INDEX "idx_bueroware_layout_file_active" ON "bueroware_record_layout" ("file_name","is_active");--> statement-breakpoint
CREATE INDEX "idx_commerce_sync_dlq_tenant" ON "commerce_sync_dead_letter" ("tenant_id");--> statement-breakpoint
CREATE INDEX "idx_commerce_sync_dlq_pending" ON "commerce_sync_dead_letter" ("tenant_id","status","next_retry_at");--> statement-breakpoint
CREATE INDEX "idx_commerce_sync_dlq_item" ON "commerce_sync_dead_letter" ("tenant_id","sales_channel_id","entity_type","internal_id");--> statement-breakpoint
CREATE INDEX "idx_commerce_sync_run_tenant" ON "commerce_sync_run" ("tenant_id");--> statement-breakpoint
CREATE INDEX "idx_commerce_sync_run_sales_channel" ON "commerce_sync_run" ("tenant_id","sales_channel_id");--> statement-breakpoint
CREATE INDEX "idx_commerce_sync_run_status" ON "commerce_sync_run" ("tenant_id","status");--> statement-breakpoint
CREATE INDEX "idx_commerce_sync_step_run" ON "commerce_sync_run_step" ("run_id");--> statement-breakpoint
CREATE INDEX "idx_commerce_sync_step_tenant" ON "commerce_sync_run_step" ("tenant_id");--> statement-breakpoint
CREATE INDEX "idx_commerce_webhook_event_tenant" ON "commerce_webhook_event" ("tenant_id");--> statement-breakpoint
CREATE INDEX "idx_commerce_webhook_event_pending" ON "commerce_webhook_event" ("tenant_id","sales_channel_id","status","next_retry_at");--> statement-breakpoint
CREATE INDEX "idx_document_agent" ON "document" ("tenant_id","agent_id");--> statement-breakpoint
CREATE INDEX "idx_ext_sync_tenant_lookup" ON "external_sync_mapping" ("tenant_id","source_system","entity_type");--> statement-breakpoint
CREATE INDEX "idx_field_mapping_version" ON "import_field_mapping" ("version_id");--> statement-breakpoint
CREATE INDEX "idx_field_mapping_tenant" ON "import_field_mapping" ("tenant_id");--> statement-breakpoint
CREATE INDEX "idx_import_mapping_version_source_file" ON "import_profile_mapping_version" ("source_system","source_file_name","is_active");--> statement-breakpoint
CREATE INDEX "idx_import_row_batch_status" ON "import_row" ("batch_id","status");--> statement-breakpoint
CREATE INDEX "idx_seller_tax_registration_lookup" ON "seller_tax_registration" ("tenant_id","company_id","country_code","registration_type","valid_from");--> statement-breakpoint
CREATE INDEX "idx_seller_tax_registration_tenant" ON "seller_tax_registration" ("tenant_id");--> statement-breakpoint
ALTER TABLE "address" ADD CONSTRAINT "address_agent_id_agent_agent_id_fkey" FOREIGN KEY ("agent_id") REFERENCES "agent"("agent_id");--> statement-breakpoint
ALTER TABLE "agent" ADD CONSTRAINT "agent_tenant_id_tenant_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "tenant"("tenant_id");--> statement-breakpoint
ALTER TABLE "agent" ADD CONSTRAINT "agent_user_id_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "user"("id");--> statement-breakpoint
ALTER TABLE "bueroware_record_field" ADD CONSTRAINT "bueroware_record_field_iNJ3tE0DM0uj_fkey" FOREIGN KEY ("layout_id") REFERENCES "bueroware_record_layout"("layout_id");--> statement-breakpoint
ALTER TABLE "commerce_sync_dead_letter" ADD CONSTRAINT "commerce_sync_dead_letter_run_id_commerce_sync_run_run_id_fkey" FOREIGN KEY ("run_id") REFERENCES "commerce_sync_run"("run_id");--> statement-breakpoint
ALTER TABLE "commerce_sync_dead_letter" ADD CONSTRAINT "commerce_sync_dead_letter_tenant_id_tenant_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "tenant"("tenant_id");--> statement-breakpoint
ALTER TABLE "commerce_sync_dead_letter" ADD CONSTRAINT "commerce_sync_dead_letter_ijxZXWLkVxuO_fkey" FOREIGN KEY ("sales_channel_id") REFERENCES "sales_channel"("sales_channel_id");--> statement-breakpoint
ALTER TABLE "commerce_sync_run" ADD CONSTRAINT "commerce_sync_run_tenant_id_tenant_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "tenant"("tenant_id");--> statement-breakpoint
ALTER TABLE "commerce_sync_run" ADD CONSTRAINT "commerce_sync_run_m3rScD2kfxtQ_fkey" FOREIGN KEY ("sales_channel_id") REFERENCES "sales_channel"("sales_channel_id");--> statement-breakpoint
ALTER TABLE "commerce_sync_run_step" ADD CONSTRAINT "commerce_sync_run_step_run_id_commerce_sync_run_run_id_fkey" FOREIGN KEY ("run_id") REFERENCES "commerce_sync_run"("run_id");--> statement-breakpoint
ALTER TABLE "commerce_sync_run_step" ADD CONSTRAINT "commerce_sync_run_step_tenant_id_tenant_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "tenant"("tenant_id");--> statement-breakpoint
ALTER TABLE "commerce_sync_run_step" ADD CONSTRAINT "commerce_sync_run_step_rwSRS8QQxPIl_fkey" FOREIGN KEY ("sales_channel_id") REFERENCES "sales_channel"("sales_channel_id");--> statement-breakpoint
ALTER TABLE "commerce_webhook_event" ADD CONSTRAINT "commerce_webhook_event_tenant_id_tenant_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "tenant"("tenant_id");--> statement-breakpoint
ALTER TABLE "commerce_webhook_event" ADD CONSTRAINT "commerce_webhook_event_5soiYuKvismJ_fkey" FOREIGN KEY ("sales_channel_id") REFERENCES "sales_channel"("sales_channel_id");--> statement-breakpoint
ALTER TABLE "document" ADD CONSTRAINT "document_agent_id_agent_agent_id_fkey" FOREIGN KEY ("agent_id") REFERENCES "agent"("agent_id");--> statement-breakpoint
ALTER TABLE "document_line" ADD CONSTRAINT "document_line_tax_rule_id_tax_rule_tax_rule_id_fkey" FOREIGN KEY ("tax_rule_id") REFERENCES "tax_rule"("tax_rule_id");--> statement-breakpoint
ALTER TABLE "import_batch" ADD CONSTRAINT "import_batch_layout_id_bueroware_record_layout_layout_id_fkey" FOREIGN KEY ("layout_id") REFERENCES "bueroware_record_layout"("layout_id");--> statement-breakpoint
ALTER TABLE "import_field_mapping" ADD CONSTRAINT "import_field_mapping_tenant_id_tenant_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "tenant"("tenant_id");--> statement-breakpoint
ALTER TABLE "import_field_mapping" ADD CONSTRAINT "import_field_mapping_sJkMfMBkOUPB_fkey" FOREIGN KEY ("version_id") REFERENCES "import_profile_mapping_version"("version_id");--> statement-breakpoint
ALTER TABLE "import_profile_mapping_version" ADD CONSTRAINT "import_profile_mapping_version_tBhcwjCXrEXv_fkey" FOREIGN KEY ("layout_id") REFERENCES "bueroware_record_layout"("layout_id");--> statement-breakpoint
ALTER TABLE "seller_tax_registration" ADD CONSTRAINT "seller_tax_registration_tenant_id_tenant_tenant_id_fkey" FOREIGN KEY ("tenant_id") REFERENCES "tenant"("tenant_id");--> statement-breakpoint
ALTER TABLE "seller_tax_registration" ADD CONSTRAINT "seller_tax_registration_company_id_company_company_id_fkey" FOREIGN KEY ("company_id") REFERENCES "company"("company_id");--> statement-breakpoint
ALTER TABLE "import_batch" DROP CONSTRAINT "import_batch_status_check", ADD CONSTRAINT "import_batch_status_check" CHECK (status IN ('pending', 'queued', 'processing', 'validating', 'validated', 'approved', 'posted', 'failed', 'rejected'));--> statement-breakpoint
ALTER TABLE "import_row" DROP CONSTRAINT "import_row_status_check", ADD CONSTRAINT "import_row_status_check" CHECK (status IN ('pending', 'valid', 'posted', 'failed', 'pending_references'));